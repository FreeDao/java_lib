﻿/*********
 * @author sam,king,xuxiaowei
 * 
 * 
 * **/

package com.sam.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 匹配 a*a格式的字符
		String regex = "\\ba\\w*a\\w";
		String input = ".as.sad.  asd; asadsa  asd  asa  asjjkdfa  asdj// sjjsa salasa //asdfkl ashjaha aa  sasd  aaas";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(input);
		
		while(m.find()){
			System.out.println(m.group());
		}
	}

}
