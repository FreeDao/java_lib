package com.sam.template;

public class TemplateConcrete extends Template{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("this is the subclass");
	}
	
}
