/*****************************************************************************
*
*                      AIRBIQUITY PROPRIETARY INFORMATION
*
*          The information contained herein is proprietary to Airbiquity
*           and shall not be reproduced or disclosed in whole or in part
*                    or used for any design or manufacture
*              without direct written authorization from Airbiquity.
*
*            Copyright (c) 2012 by Airbiquity.  All rights reserved.
*            
*                   @author Jiang, Sheldon
*
*****************************************************************************/
var appServer = require("./lib/http/http_server").start(8081);

//define socketio server
socketioServer = require("./lib/socketio/socketio_server");
socketioServer.server(appServer);