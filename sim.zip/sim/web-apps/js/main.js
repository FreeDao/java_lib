$(window).load(function() {
	var Socket = {
		_socket: null,
		_connect: function(){
			if (!this._socket) this._socket = io.connect();
		},
		on : function(event, cb) {
			this._connect();
			this._socket.on(event, cb);
		},
		emit : function(event, data) {
			this._connect();
			this._socket.emit(event, data);
		}
	};
	
//	$('#messageSend').click(function() {
//		Socket.emit("AQCommand",$('#message1').val());
//	});
	$("select[name='messageType']").change(function(){
		var msgType = $(this).val();
		$("#form-body").empty();
		$("#form-body").append($("#"+msgType).html());
	});
	$(".sendCommand").click(function(){
		var isvalid = true;
		var message = {};
		$(".command-form").find("input[name!='submit'], select").each(function(){
			isvalid = isvalid && this.checkValidity();
			message[$(this).attr("name")] = $(this).val();
		});

		if (isvalid) {
			Socket.emit("AQCommand", JSON.stringify(message));
		} else {
			$(".command-form input[name='submit']").click();
		}
	
	});

});
