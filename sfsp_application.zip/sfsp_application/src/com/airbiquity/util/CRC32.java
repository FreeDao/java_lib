/*
 * Java CRC32 implementation based upon the zlib C implementation.
 * Per license stated below ... This is a modified version based upon
 * the zlib original work and thus must be considered as an altered
 * version of the original.
 *
 * The zlib C implementation is copyright as follows:
 *
 * crc32.c -- compute the CRC-32 of a data stream
 * Copyright (C) 1995-2006, 2010 Mark Adler
 * For conditions of distribution and use, see copyright notice in zlib.h
 *
 * Copyright notice from zlib.h:
 *
 * zlib.h -- interface of the 'zlib' general purpose compression library
 *   version 1.2.5, April 19th, 2010
 * 
 *   Copyright (C) 1995-2010 Jean-loup Gailly and Mark Adler
 * 
 *   This software is provided 'as-is', without any express or implied
 *   warranty.  In no event will the authors be held liable for any damages
 *   arising from the use of this software.
 * 
 *   Permission is granted to anyone to use this software for any purpose,
 *   including commercial applications, and to alter it and redistribute it
 *   freely, subject to the following restrictions:
 * 
 *   1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software. If you use this software
 *      in a product, an acknowledgment in the product documentation would be
 *      appreciated but is not required.
 *   2. Altered source versions must be plainly marked as such, and must not be
 *      misrepresented as being the original software.
 *   3. This notice may not be removed or altered from any source distribution.
 * 
 *   Jean-loup Gailly        Mark Adler
 *   jloup@gzip.org          madler@alumni.caltech.edu
 * 
 * 
 *   The data format used by the zlib library is described by RFCs (Request for
 *   Comments) 1950 to 1952 in the files http://www.ietf.org/rfc/rfc1950.txt
 *   (zlib format), rfc1951.txt (deflate format) and rfc1952.txt (gzip format).
 *   
 *   HISTORY:
 *   18/24/2012 Jack William Bell - Modified for Android. Made threadsafe. Removed
 *   code to open files, modifying to use passed input stream instead.
 */

package com.airbiquity.util;

import java.io.IOException;
import java.io.InputStream;

/**
 * <p>Calculates CRC </p>
 * 
 */
public class CRC32
{
	protected static final String TAG = "CRC32";
	
    private long[] crcSTab = null; 
    private long crcSReg = 0xFFFFFFFFL;
    
    /**  Call this function when CRC32 calcs needed
     * ASSUMES that there is only one client to crc32
     * and when done the caller will call release()
     * which will free the memory consumed by this
     * table
     */
    private void initCrcTable()
    {
        if (null == crcSTab) {
        	crcSTab = new long[16];
            long c;
            long poly = 0xEDB88320L;
            
            for(int n = 0; n < 16; n++)
            {
                c = (int) n;
                for (int k = 0; k < 4; k++)
                {
                    c = ( 0 != ( c & 1 ) ) ? poly ^ (c >>> 1) : c >>> 1;
                    //System.out.println("c = " + Integer.toHexString(c));
                }
                crcSTab[n] = c;
            }        	
        }
    }

    /** Creates a new CRC32 object */
    public CRC32()
    {
    	initCrcTable();
    }
    

    /**
     * @return
     */
    protected long[] getCrcSTab()
    {
        return crcSTab.clone();
    }
    
    /** Returns CRC-32 value.
     *
     *  @returns the current checksum value.
     */
    public long getValue()
    {
        return crcSReg ^ 0xFFFFFFFFL;
    }

    /** Resets CRC-32 to initial value.
     */
    public void reset()
    {
        crcSReg = 0xFFFFFFFFL;
    }

    /**
     * @param ba
     * @param offset
     * @param len
     */
    public void update( byte[] ba, int offset, int len )
    {
        for(int i = offset; i < len; i++) {
        	long idx = crcSReg ^ ba[i];
        	crcSReg = (crcSReg >>> 4 ) ^ crcSTab[(int) (idx & 0x0f)];
        	idx = crcSReg ^ (ba[i] >>> 4);
        	crcSReg = (crcSReg >>> 4 ) ^ crcSTab[(int) (idx & 0x0f)];
        }
    }

    /** Updates checksum with specified array of bytes. 
     * 
     * @param b the array of bytes to update the checksum with
     */
    public void update( byte[] b )
    {
        update( b, 0, b.length );
    }

    /** Computes the CRC32 checksum for all bytes contained within
     *  an input stream.
     *  
     * @param fis The imput stream to perform the CRC32 checksum upon.
     * @param closeWhenDone True if you want this routine to close the input stream
     * when it completes, otherwise false.
     * @return The CRC32 checksum of the given file.  If the file can't be opened
     *         the value of -1 will be returned instead.
     */
    public static long computeFileCrc(InputStream fis, boolean closeWhenDone)
    {
    	long retval = -1;
    	byte[] buf = new byte[256];
    	CRC32 crc32 = new CRC32();

    	int x = 0;
    	if( null != fis )
    	{
    		try {
    			int avail = fis.available();
				while( avail > 0 )
				{
					//^^FS1=computeFileCrc() avail:
					//if( 0 == ( x % 10) ) Log.d(TAG, "^^FS1 " + avail );
					x++;
					int numUpdateBytes = 256;
					if( avail < 256 )
					{	
						//^^FS2=computeFileCrc() avail:
						//Log.d(TAG, "^^FS2 " + avail );
						numUpdateBytes = avail;
					}
					fis.read( buf, 0, numUpdateBytes );
					crc32.update(buf, 0, numUpdateBytes );
					avail = fis.available();
				}
				if (closeWhenDone) fis.close();
				retval = crc32.getValue();
			} catch (IOException e) {
				//^^FS3=Error while computing file CRC
				//Log.e(TAG,  "^^FS3", e);
				e.printStackTrace();
			}
    	}

    	return retval;
    }
}