/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2007-2012 by Airbiquity.  All rights reserved.
 *            
 *  History:
 *  08-20-2012 Jack William Bell - Modified for use in Android projects.
 *
 * ***************************************************************************
 */
//@@EK=ByteDecoder.java

package com.airbiquity.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.RuntimeException;

//import com.airbiquity.aqlog.AqLog;

/**
 * Provides utility methods for decoding binary messages.
 * 
 * @author Mike O'Meara
 *
 */
public class ByteDecoder {

    private byte[] data;
    private InputStream is;
    

    // This is used externally when the cfms data is being packed to determine
    // if the item under consideration to be packed should be included ---
    // sort of a cheat for now.  puts off having to build a factory
    // for this structure.
    private int cfmsVersion = 0;
    
    /**
     * Creates a <tt>MessageDecoder</tt>.
     * 
     * @param data byte array to read message data from
     */
    public ByteDecoder(byte[] data) {
        this.data = data;
        this.is = new ByteArrayInputStream(data);
    }

    /**
     * Creates a <tt>MessageDecoder</tt>.
     * 
     * @param packet byte array to read message data from
     */
    public ByteDecoder(InputStream is) {
        this.is = is;
    }

    public int getCfmsProtocolVersion()
    {
        return cfmsVersion;
    }

    public void setCfmsProtocolVersion( int version )
    {
        cfmsVersion = version;
    }
    
    
    private int internalReadInt( int size ) throws IOException
    {
        int total = 0;
        int val = 0;
        for (int i=size; i>0; i--) {
            val = is.read();
            if (val < 0) {
                //^^EK3=end of stream
                throw new IOException("^^EK3");
            }
            total += (val << (i-1)*8);
        }

        // System.out.println("internalReadInt() size: " + size + ", value: " + total );
        return total;
    }
    /**
     * Reads an integer value of the specified size from the input stream.
     * 
     * @param size number of bytes (between 1 and 4) to read
     * @return the value read
     * @throws IOException if the end of the input stream is reached while reading the value
     */
    private int aaa_readInt(int size, boolean isStuff) throws IOException {
        int retval = 0;
        size = ByteEncoder.checkIntSize( size );

        retval = internalReadInt( size );
        if( isStuff && ( ByteEncoder.intOverflowExceptionValues[size - 1] == retval ) )
        {
            retval = internalReadInt( 4 );
        }
        return retval;
    }

    public int readInt( int size ) throws IOException
    {
        return aaa_readInt( size, false );
    }

    public int limitedReadInt( int size ) throws IOException
    {
        return aaa_readInt( size, false );
    }

    public int stuffedReadInt( int size ) throws IOException
    {
        return aaa_readInt( size, true );
    }
    
    /**
     * Reads a signed (2's complement) integer value of the specified size from the input stream.
     * 
     * @param size number of bytes (between 1 and 4) to read
     * @return the value read
     * @throws IOException if the end of the input stream is reached while reading the value
     */
    private int internalReadSignedInt(int size, boolean isStuff) throws IOException {
        size = ByteEncoder.checkIntSize( size );
        int val = internalReadInt(size);

        if( isStuff && ( ByteEncoder.signedIntOverflowExceptionValues[ size - 1 ] == val ) )
        {
            size = 4;
            val = internalReadInt(size);
        }

        if ((val & (0x80 << ((size - 1) * 8))) == 0) {
            return val;
        }
        
        if (size == 1) {
            return -((~(val - 1)) & 0xff);
        }
        else if (size == 2) {
            return -((~(val - 1)) & 0xffff);
        }
        else if (size == 3) {
            return -((~(val - 1)) & 0xffffff);
        }
        else {
            return -((~(val - 1)) & 0xffffffff);
        }
    }

    public int readSignedInt( int size ) throws IOException
    {
        return internalReadSignedInt( size, false );
    }

    public int limitedReadSignedInt( int size ) throws IOException
    {
        return internalReadSignedInt( size, false );
    }

    public int stuffedReadSignedInt( int size ) throws IOException
    {
        return internalReadSignedInt( size, true );
    }
    
    public long readLong(int size) throws IOException {
        if (size < 1 || size > 8) {
            //^^EK4=size must be between 1 and 8:
            throw new IllegalArgumentException("^^EK4" + size);
        }
        long total = 0;
        long val = 0;
        for (int i=size; i>0; i--) {
            val = is.read();
            if (val < 0) {
                //^^EK5=end of stream
                throw new IOException("^^EK5");
            }
            total += (val << (i-1)*8);
        }
        return total;

    }

    /**
     * Reads a byte array of the specified length from the input stream.
     * 
     * @param size the number of bytes to read
     * @return the bytes read
     * @throws IOException if the end of the input stream is reached while reading the bytes
     */
    public byte[] readBytes(int size) throws IOException {
        byte[] data = new byte[size];
        int val = 0;
        for (int i=0; i<size; i++) {
            val = is.read();
            if (val < 0) {
                //^^EK6=end of stream trying to read.  bytes:
                throw new IOException("^^EK6" + size );
            }
            data[i] = (byte) val;
        }
        return data;
    }

    /**
     * Reads an ASCII string from the input stream.
     *  
     * @param size the number of bytes to read as a string
     * @return the value as a string
     * @throws IOException if the end of the input stream is reached while reading the string
     */
    public String readString(int size) throws IOException {
        String retval = null;
        if( 0 == size )
        {
            retval = new String();
        }
        else
        {
            try
            {
                retval = new String(readBytes(size));
            }
            catch (UnsupportedEncodingException e)
            {
                // throw new RuntimeException(e);
                throw new RuntimeException(e.toString());
            }
        }
        return retval;
    }
    
    /**
     * Reads an ASCII string (up to 255 bytes) from the input stream.
     *  
     * @param none
     * @return the value as a string
     * @throws IOException if the end of the input stream is reached while reading the string
     */
    public String readShortString() throws IOException {
        int len = 0;
        try
        {
            len = readInt(1);
        }
        catch( IOException e )
        {
            //^^EK1=Error reading short string length: 
            //AqLog.getInstance().error("^^EK1" + e.toString(), e );
        }
        
        return readString(len);
    }

    public String readLongString() throws IOException {
        int len = 0;

        try
        {
            len = readInt(2);
        }
        catch( IOException e )
        {
            //^^EK2=Error reading long string length: 
            //AqLog.getInstance().error("^^EK2" + e.toString(), e );
        }

        return readString( len );
    }
    
    /** Attempt to decode an integer value with the specified width.  If one of the special 
     *  "Data not available" values is read from the decode stream, then return the supplied exception value
     * 
     * @param size The number of bytes to read from the decoder stream that are to be intrepreted as an int
     */
    public int checkedReadInt( int size, int exceptVal ) throws IOException
    {
        int retval = 0;
        if( ( size > 4 ) || ( size < 1 ) )
        {
        	retval = exceptVal;
        }
        else
        {
        	retval = internalReadInt( size );
        	if( ( ByteEncoder.intByteEncoderExceptionValues[size - 1] == retval ) || 
        			( ByteEncoder.intConstraintExceptionValues[size - 1] == retval ) ||
        			( ByteEncoder.intOverflowExceptionValues[size - 1] == retval )  )
        	{
        		retval = exceptVal;
        	}
        }
        return retval;
    }

    public int checkedReadSignedInt( int size, int exceptVal ) throws IOException
    {
        int retval;
        if( ( size > 4 ) || ( size < 1 ) )
        {
        	retval = exceptVal;
        }
        else
        {
        	retval = readSignedInt( size );
        	if( ( ByteEncoder.signedIntByteEncoderExceptionValues[size - 1] == retval ) ||
        		( ByteEncoder.signedIntConstraintExceptionValues[size - 1] == retval ) ||
        		( ByteEncoder.signedIntOverflowExceptionValues[size - 1] == retval ) )
        	{
        		retval = exceptVal;
        	}
        }
        return retval;
    }

    public float checkedReadFloat( float base, float scalar, int size, float exceptVal ) throws IOException
    {
        int encodedValue;
        float retval = exceptVal;
        
        if( ( size > 0 ) && ( size <=4 ) )
        {
        	encodedValue = internalReadInt( size );
        	
        	if( ( ByteEncoder.intByteEncoderExceptionValues[size - 1] == encodedValue ) ||
        		( ByteEncoder.intConstraintExceptionValues[size - 1] == encodedValue ) ||
        		( ByteEncoder.intOverflowExceptionValues[size - 1] == encodedValue ) )
        	{
        		retval = exceptVal;
        	}
        	else
        	{
        		retval = AqUtils.packedToFloat( base, scalar, encodedValue );
        	}
        }
        return retval;
    }
    
    public boolean hasMoreData() throws IOException {
        return (is.available() > 0);
    }

    public byte[] readRemainder() throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        int val = 0;
        while (true) {
            val = is.read();
            if (val < 0) {
                break;
            }
            os.write(val);
        }
        return os.toByteArray();
    }
    
    public byte[] readUpto(int size) throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        int val = 0;
        for (int i=0; i<size; i++) {
            val = is.read();
            if (val < 0) {
                return os.toByteArray();
            }
            os.write((byte) val);
        }
        return os.toByteArray();
    }

    public byte readByte() throws IOException {
        byte[] data = readBytes(1);
        return data[0];
    }

    public byte[] getData() {
        return data;
    }

    public long readTimeInSecAsTimeInMs() throws IOException
    {
    	return readLong( 4 ) * 1000;
    }

    /** Decode the specified bytes from a CAN PDU.  It is assumed that any multi-byte
     *  field is to be interpreted in little endian byte order.  
     * 
     * @param pdu The raw payload bytes of a CAN Portable Data Unit (PDU).
     * @param startByte The first byte of pdu payload to decode (0 based)
     * @param numBytes The total number of bytes of the PDU payload to decode.
     * @return The decoded value.  -1 represents an error.
     */
    public static long decodePduBytes( byte pdu[], int startByte, int numBytes )
    {
        long retval = -1;
        if( ( null != pdu ) && ( ( startByte + numBytes ) <= pdu.length ) && ( numBytes > 0 ) )
        {
            retval = 0;
            int i;
            int lastByte = startByte + numBytes - 1;
            for( i=lastByte;i>=startByte;i-- )
            {
                int tmp = (pdu[i] & 0xff);
                retval = (retval << 8 ) + tmp;
            }
        }
        return retval;
    }

    /** Decode the specified bytes from a CAN PDU.  It is assumed that any multi-byte
     *  field is to be interpreted in little endian byte order.  
     * 
     * @param pdu The raw payload bytes of a CAN Portable Data Unit (PDU).
     * @param startByte The first byte of pdu payload to decode (0 based)
     * @param numBytes The total number of bytes of the PDU payload to decode.
     * @return The decoded value.  -1 represents an error.
     */
    public static int intDecodePduBytes(byte pdu[], int startByte, int numBytes )
    {
    	int retval = -1;
    	if( numBytes < 4 )
    	{
    		retval = (int) decodePduBytes( pdu, startByte, numBytes );
    	}
    	return retval;
    }

    /** Decode the specified bits from a CAN PDU payload.  It is assumed that all bits
     *  to be decoded are within the same data byte of the payload.  
     *  
     * @param pdu The CAN Portable Data Unit (PDU) payload.
     * @param startByte The byte within the payload which contains the bits to be decoded.
     * @param startBit The first bit of the byte to decode (0 is most significant bit, 7 is least significant)
     * @param numBits The number of bits to decode.
     * @return The decoded value of the specified bits.  -1 represents an error condition.
     */
    public static byte decodePduBits( byte pdu[], int startByte, int startBit, int numBits )
    {
        byte retval = -1;

        if( ( startByte < pdu.length ) && ( numBits < 8 ) && ( ( startBit + numBits ) <= 8 ) )
        {
            int mask = (1 << numBits) -1;
            int shift = 8 - (startBit + numBits );
            int tmp = pdu[startByte] & 0xff;
            retval = (byte) ( ( tmp >> shift ) & mask );
        }
        return retval;
    }


    
    
    /** Decode the specified sub-array of bytes as a long assuming
     *  big endian format (the most signifiant byte is the first byte
     *  of the sub-array).
     *  
     * 
     * @param a The array to containing the sub-array
     * @param startByte The first byte a to decode (0 based)
     * @param numBytes The total number of bytes of a to decode.
     * @return The decoded value.  -1 represents an error.
     */
    public static long byteArrayToBigEndianLong( byte a[], int startByte, int numBytes )
    {
        long retval = -1;
        if( ( null != a ) && ( ( startByte + numBytes ) <= a.length ) && ( numBytes > 0 ) && ( numBytes <= 8 ) )
        {
            retval = 0;
            int i;
            int lastByte = startByte + numBytes;
            for( i=0;i<lastByte;i++ )
            {
                int tmp = (a[i] & 0xff);
                retval = (retval << 8 ) + tmp;
            }
        }
        return retval;
    }

    /** Decode the specified bits from a CAN PDU payload.  It is assumed that all bits
     *  to be decoded are within the same data byte of the payload.  
     *  
     * @param pdu The CAN Portable Data Unit (PDU) payload.
     * @param startByte The byte within the payload which contains the bits to be decoded.
     * @param startBit The first bit of the byte to decode (0 is most significant bit, 7 is least significant)
     * @param numBits The number of bits to decode.
     * @return The decoded value of the specified bits.  -1 represents an error condition.
     */
    public static long byteArrayToBigEndianLong( byte pdu[], int startByte, int startBit, int numBits )
    {
        byte retval = -1;

        if( ( startByte < pdu.length ) && ( numBits < 8 ) && ( ( startBit + numBits ) <= 8 ) )
        {
            int mask = (1 << numBits) -1;
            int shift = 8 - (startBit + numBits );
            int tmp = pdu[startByte] & 0xff;
            retval = (byte) ( ( tmp >> shift ) & mask );
        }
        return retval;
    }
    
}
