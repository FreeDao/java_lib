/*****************************************************************************
 *
 * Taken from Public Domain code published here: 
 * 	http://www.xinotes.org/notes/note/407/
 * 
 * History: 
 * 08/24/2012 Jack William Bell - Modified for Airbiquity. Removed deprecated
 * usages. Used HashMaps instead of Property objects. Added fromString()/toString()  
 * to support loading/saving String values containing ini configurations. 
 * Other misc. cleanup.
 *
*****************************************************************************/
package com.airbiquity.util;

import java.util.*;
import java.io.*;

/**
 * <p>Provides a Properties-like interface for managing 'ini file' style configuration
 * values.</p>
 * 
 * <p><b>TODO:</b> This doesn't preserve comments. Need to consider if it is worth the 
 * effort to add that functionality. (JWB)</p>
 */
public class IniProperties {
	protected static final int BUFF_SIZE = 4096;
	
    private HashMap<String, String> globalProperties;
    private Map<String,HashMap<String, String>> properties;

    private enum ParseState {
        NORMAL,
        ESCAPE,
        ESC_CRNL,
        COMMENT
    }

    /**
     * Default Constructor.
     */
    public IniProperties() {
        globalProperties = new HashMap<String, String>();
        properties = new HashMap<String, HashMap<String, String>>();
    }
    
    public IniProperties(String iniString) throws IOException {
        this();
        fromString(iniString);
    }
    

    /**
     * Load ini as properties from String.
     * 
     * @param iniString
     * @throws IOException
     */
    public void fromString(String iniString) throws IOException {
    	StringReader sr = new StringReader(iniString);
    	load(sr);
    }

    /**
     * Load ini as properties from Reader.
     * 
     * @param in
     * @throws IOException
     */
    public void load(Reader in) throws IOException {
        
        char[] buffer = new char[BUFF_SIZE];
        int n = in.read(buffer, 0, BUFF_SIZE);

        ParseState state = ParseState.NORMAL;
        boolean section_open = false;
        String current_section = null;
        String key = null, value = null;
        StringBuilder sb = new StringBuilder();
        while (n >= 0) {
            for (int i = 0; i < n; i++) {
                char c = (char) buffer[i];

                if (state == ParseState.COMMENT) { // comment, skip to end of line
                    if ((c == '\r') ||(c == '\n')) {
                        state = ParseState.NORMAL;
                    }
                    else {
                        continue;
                    }
                }

                if (state == ParseState.ESCAPE) {
                    sb.append(c);
                    if (c == '\r') {
                        // if the EOL is \r\n, \ escapes both chars
                        state = ParseState.ESC_CRNL; 
                    }
                    else {
                        state = ParseState.NORMAL;
                    }
                    continue;
                }

                switch (c) {
                    case '[': // start section
                        sb = new StringBuilder();
                        section_open = true;
                        break;
                    
                    case ']': // end section
                        if (section_open) {
                            current_section = sb.toString().trim();
                            sb = new StringBuilder();
                            properties.put(current_section, new HashMap<String, String>());
                            section_open = false;
                        }
                        else {
                            sb.append(c);
                        }
                        break;

                    case '\\': // escape char, take the next char as is
                        state = ParseState.ESCAPE;
                        break;

                    case '#': 
                    case ';': 
                        state = ParseState.COMMENT;
                        break;

                    case '=': // assignment operator
                    case ':':
                        if (key == null) {
                            key = sb.toString().trim();
                            sb = new StringBuilder();
                        }
                        else {
                            sb.append(c);
                        }
                        break;

                    case '\r':
                    case '\n':
                        if ((state == ParseState.ESC_CRNL) && (c == '\n')) {
                            sb.append(c);
                            state = ParseState.NORMAL;
                        }
                        else {
                            if (sb.length() > 0) {
                                value = sb.toString().trim();
                                sb = new StringBuilder();
                        
                                if (key != null) {
                                    if (current_section == null) {
                                        this.setProperty(key, value);
                                    }
                                    else {
                                        this.setProperty(current_section, key, value);
                                    }
                                }
                            }
                            key = null;
                            value = null;
                        }
                        break;

                    default: 
                        sb.append(c);
                }
            }
            n = in.read(buffer, 0, BUFF_SIZE);
        }
    }

    /**
     * Get global property by name.
     * 
     * @param name
     * @return
     */
    public String getProperty(String name) {
        return globalProperties.get(name);
    }

    /**
     * Set global property.
     * 
     * @param name
     * @param value
     */
    public void setProperty(String name, String value) {
        globalProperties.put(name, value);
    }
    
    /**
     * Return the key values for the global properties.
     * @return
     */
    public Set<String> propertyKeys() {
    	return globalProperties.keySet();
    }

    /**
     * Get property value for specified section and name. Returns null
     * if section or property does not exist.
     * 
     * @param section
     * @param name
     * @return
     */
    public String getProperty(String section, String name) {
    	HashMap<String, String> p = properties.get(section);
        return p == null ? null : p.get(name);
    }

    /**
     * Set property value for specified section and name. Creates section
     * if not existing.
     * 
     * @param section
     * @param name
     * @param value
     */
    public void setProperty(String section, String name, String value) {
    	HashMap<String, String> p = properties.get(section);
        if (p == null) {
            p = new HashMap<String, String>();
            properties.put(section, p);
        }
        p.put(name, value);
    }

    /**
     * Return the key values for a section.
     * 
     * @param section
     * @return
     */
    public Set<String> propertyKeys(String section) {
    	return properties.get(section).keySet();
    }

    /**
     * Return iterator of names of section.
     */
    public Set<String> sections() {
        return properties.keySet();
    }

    @Override
    public String toString() {
    	StringWriter wr = new StringWriter();
    	try {
			dump(wr);
		} catch (IOException e) {
		}
    	return wr.toString();
    }
    
    /**
     * Dumps properties to output stream.
     * 
     * @param out
     * @throws IOException
     */
    public void dump(Writer out) throws IOException {
        // Global properties
        Iterator<String> props = globalProperties.keySet().iterator();
        while (props.hasNext()) {
            String name = props.next();
            out.write(name + "=" + dumpEscape(getProperty(name)) + "\n");
        }

        // sections
        Iterator<String> sections = this.sections().iterator();
        while (sections.hasNext()) {
            String section = sections.next();
            out.write("\n[" + section + "]\n");
            props = this.properties.keySet().iterator();
            while (props.hasNext()) {
                String name = props.next();
                out.write(name + "=" + dumpEscape(getProperty(section, name)) + "\n");
            }
        }
    }

    private static String dumpEscape(String s) {
        return s.replaceAll("\\\\", "\\\\\\\\")
                .replaceAll(";", "\\\\;")
                .replaceAll("#", "\\\\#")
                .replaceAll("(\r?\n|\r)", "\\\\$1");
    }
  
}
