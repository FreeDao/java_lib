/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2008-2012 by Airbiquity.  All rights reserved.
 *
 *  History:
 *  08-20-2012 Jack William Bell - Created.
 *
*****************************************************************************/
package com.airbiquity.util;

/**
 * Selected constants taken from the OBU project.
 * 
 * @author Jack William Bell
 */
public class AqConsts {

    // public static final long JAN_1_2000 = 946684800000L;
    public static final long JAN_1_2005 = 1104537600000L;
    public static final long JAN_1_1970_TO_JAN_1_2002_IN_MS = 1009843200000L;

    public static final int SECS_IN_DAY = 86400;
    public static final long MS_IN_HOUR = 3600000;
    public static final long MS_IN_DAY = MS_IN_HOUR * 24;

    public static final String NEXT_GUID_BASE_KEY = "nextGuidBase";
    
    public  static final int   SOCKET_READ_TIMEOUT = 30000; // 30s = 30000ms
    public static final String UNKNOWN_DRIVER_ID = "@@@UNKNOWN";	

    public static final int    ATP_CFMS_ALERT_REQ = 0x18;
    public static final int    ATP_CFMS_ALERT_ACK = 0x19;
    
    public static final int ATP_GENERIC_NOTIFICATION = 0x56;
    public static final int ATP_TEXT_MESSAGE_REQUEST = 0x57;
    public static final int ATP_TEXT_MESSAGE = 0x58;
    public static final int ATP_TEXT_MESSAGE_STATUS_UPDATE = 0x59;
    public static final int ATP_TEXT_MESSAGE_STATUS_UPDATE_RESPONSE = 0x5a;
    public static final int ATP_OBU_STATUS = 0x5B;
    public static final int ATP_OBU_STATUS_RESPONSE = 0x5C;
    public static final int ATP_ICS_EVENT = 0x5D;
    public static final int ATP_ICS_EVENT_RESPONSE = 0x5E;
    
}
