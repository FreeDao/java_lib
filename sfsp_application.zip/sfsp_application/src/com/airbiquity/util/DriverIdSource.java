package com.airbiquity.util;

import com.airbiquity.aqlog.AqLog;

/**
 * Generates unique CFMS driver ID's that are 6 characters in length;
 * 5 base characters + 1 check character. Valid character values are 
 * between 1 and 4 inclusive.
 * 
 * The algorithm used is based on the public domain one described at
 * @see <a href="http://en.wikipedia.org/wiki/Luhn_mod_N_algorithm">Luhn_mod_N_algorithm</a>
 * 
 * @author Mike O'Meara
 */
public class DriverIdSource {

	private static final int BASE_ID_LENGTH = 5;
	private static final int UNIQUE_CHARACTERS = 4;
	private static final int MAX_ID_COUNT = (int) Math.pow(UNIQUE_CHARACTERS, BASE_ID_LENGTH);

	private int currentBaseId = 11110;
	private int idCount = 0;
    
    private static DriverIdSource SINGLETON = null;

    public static DriverIdSource getInstance()
    {
        if( null == SINGLETON )
        {
            SINGLETON = new DriverIdSource();
        }
        return SINGLETON;
    }
    
	/**
	 * Check to see if another driver id is available.
	 * 
	 * @return true if an additional driver id is available, false id no more
	 * driver ids are available.
	 */
	public boolean hasNext() {
		return (idCount < MAX_ID_COUNT);
	}

	/**
	 * Get the next driver id value.
	 * 
	 * @return the next driver id
	 */
	public String next() {
		if (!hasNext()) {
			throw new IllegalStateException("no more id's available");
		}
		idCount++;
		return nextId();
	}
	
	private String nextId() {
		String baseId = String.valueOf(nextValue(1));
		char checkChar = generateCheckCharacter(baseId);
		return baseId + checkChar;
	}
	
	/*
	 * Create the next integer value of the base driver id with each digit of the number
	 * incremented mod 4.
	 * 
	 * Example:  111111, 111112, 111113, 111114, 111121, ...
	 *  
	 * Implemented recursively.
	 */
	private int nextValue(int position) {
		if (position <= BASE_ID_LENGTH) {
		    //add 1 to current position digit
			int addend = (int) (Math.pow(10, (position - 1)));
			currentBaseId += addend;
			String idStr = String.valueOf(currentBaseId);
			int digit = Integer.valueOf(idStr.substring(idStr.length() - position, idStr.length() - position + 1)).intValue();
			//check if the digit at current position exceeds max value and
			//if so flow over to the next position
			if (digit > UNIQUE_CHARACTERS) {
				currentBaseId = currentBaseId - (UNIQUE_CHARACTERS * addend);
				return nextValue(position + 1);
			}
		}
		return currentBaseId;
	}
	
	private int codePointFromCharacter(char character) {
		if (character == '1') {
			return 0;
		}
		else if (character == '2') {
			return 1;
		}
		else if (character == '3') {
			return 2;
		}
		else if (character == '4') {
			return 3;
		}
		throw new RuntimeException("invalid character " + character);
	}

	private char characterFromCodePoint(int codePoint) {
		switch (codePoint) {
			case 0:
				return '1';
			case 1:
				return '2';
			case 2:
				return '3';
			case 3:
				return '4';
			default:
				throw new RuntimeException("invalid code point " + codePoint);
		}
	}

	/*
	 * Compute the check character for the specified base driver id.
	 */
	private char generateCheckCharacter(String inputStr) {
		int factor = 2;
		int sum = 0;
		int n = UNIQUE_CHARACTERS;
		
		char[] input = inputStr.toCharArray();

		// Starting from the right and working leftwards is easier since 
		// the initial "factor" will always be "2" 
		for (int i = input.length - 1; i >= 0; i--) {
			int codePoint = codePointFromCharacter(input[i]);
			int addend = factor * codePoint;

			// Alternate the "factor" that each "codePoint" is multiplied by
			factor = (factor == 2) ? 1 : 2;

			// Sum the digits of the "addend" as expressed in base "n"
			addend = (addend / n) + (addend % n);
			sum += addend;
		}

		// Calculate the number that must be added to the "sum" 
		// to make it divisible by "n"
		int remainder = sum % n;
		int checkCodePoint = n - remainder;
		checkCodePoint %= n;

		return characterFromCodePoint(checkCodePoint);
	}

	/**
	 * Check the driver id check character to make sure it is valid according
	 * to the Luhn mod N algorithm (where N = 4).
	 * 
	 * @param id the driver id to check
	 * @return true indicates the driver id id valid, false indicates it is invalid
	 */
	public boolean checkId(String id) {
		int factor = 1;
		int sum = 0;
		int n = UNIQUE_CHARACTERS;
		boolean retval = false;

		try
		{
			// Starting from the right, work leftwards
			// Now, the initial "factor" will always be "1" 
			// since the last character is the check character
			char[] input = id.toCharArray();

			for (int i = input.length - 1; i >= 0; i--) {
				int codePoint = codePointFromCharacter(input[i]);
				int addend = factor * codePoint;

				// Alternate the "factor" that each "codePoint" is multiplied by
				factor = (factor == 2) ? 1 : 2;

				// Sum the digits of the "addend" as expressed in base "n"
				addend = (addend / n) + (addend % n);
				sum += addend;
			}
			int remainder = sum % n;
			retval = (remainder == 0);
		}
		catch( Exception e )
		{
			AqLog.getInstance().warn("PIN check fail");
		}
		return retval;
	}

    private static String getCodeString( int code, int numDigits )
    {
        byte[] digits = new byte[numDigits];
        
        while( numDigits > 0 )
        {
            digits[numDigits-1] = (byte)(0x31 + (code & 0x03));
            numDigits--;
            code = code >> 2;
        }

        return new String( digits );
    }
    
    public static void main( String args[] )
    {
        int i;
        for(i=0;i<4096;i++)
        {
            String pin = getCodeString( i, 6 );
            System.out.println("pin,isValid: " + pin + "," + getInstance().checkId( pin ) );
        }
    }
}
