/**  
* @Title: SystemManager.java
* @Package com.airbiquity.util
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-10-15
* @version V1.0  
*/
package com.airbiquity.util;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import android.util.Log;

public class SystemManager {
	private static String TAG = "SystemManager";
	private static SystemManager _instance = null;
	private static String PROPERTIES_PATH = "/data/data/com.airbiquity.android/files/";
	private static String PROPERTIES_FILE = PROPERTIES_PATH + "sfsp.properties";
	
	public static SystemManager getInstance() {
		if(_instance == null) _instance = new SystemManager();
		
		return _instance;
	}
	
	/**
	 * Execute commands as super user
	 * @param String commands
	 * @param boolean newThread: True if execute in new thread.
	 * @return true | false
	 */
	public boolean execAsRoot(String command, boolean newThread) {
		String[] commands = {command};
		return execAsRoot(commands, newThread);
    }
	
	/**
	 * Execute commands as super user
	 * @param String[] commands
	 * @param boolean newThread: True if execute in new thread.
	 * @return true | false
	 */
    public boolean execAsRoot(final String[] commands, boolean newThread) {
    	if(newThread) {
    		new Thread(new Runnable() {
				@Override
				public void run() {
					exec(commands);
				}
    		}).start();
    		return true;
    	}
		return exec(commands);
    }
    
	/**
     * Execute commands as super user
     * @param commands
     * @return true | false
     */
	private synchronized boolean exec(String[] commands) {
		if (commands.length < 1) return false;

		Process process = null;
		DataOutputStream os = null;
		try {
//			process = Runtime.getRuntime().exec(
//					new String[] { "/system/bin/su", "-c", "system/bin/sh" });
			process = Runtime.getRuntime().exec(
					new String[] { "su", "-c", "system/bin/sh" });

			os = new DataOutputStream(process.getOutputStream());
			for (String cmd : commands) {
				os.writeBytes(cmd + "\n");
			}
			os.writeBytes("exit\n");
			os.flush();
			os.close();
			process.waitFor();
		} catch (Exception e) {
			Log.e(TAG, "Exec commands as super user failed: ", e);
			return false;
		} finally {
			process.destroy();
			
		}

		Log.d(TAG, "Exec commands sucessfully");
		return true;
	}
	
	public String getProperty(String key, String defaultValue) {
		String property = "";
		Properties prop = loadProperties(PROPERTIES_FILE);
		property = prop.getProperty(key, defaultValue);
		
		return property;
	}

	public Properties loadProperties() {		
		return loadProperties(PROPERTIES_FILE);
	}
	
	private Properties loadProperties(String file) {		
		Properties properties = new Properties();
		
		File f = new File(file);
		if (f.exists()) {
			try {
				FileInputStream s = new FileInputStream(file);
				properties.load(s);
			} catch (Exception e) {
				Log.e(TAG, "Load properties failed: " + file +", ", e);
			}
		}
		
		return properties;
	}

	public void setProperty(String key, String value) {
		Properties prop = loadProperties(PROPERTIES_FILE);
		prop.setProperty(key, value);
		saveProperties(PROPERTIES_FILE, prop);
	}
	
	private void saveProperties(String file, Properties properties) {
		try {			
			File f = new File(file);
			Log.d(TAG, "Properties file exist: " + f.exists());
			if (!f.exists()) {
				File path = new File(PROPERTIES_PATH);
				if (!path.isDirectory()) {
					path.mkdirs();
				}
				
				f.createNewFile();
			}
			
			Log.d(TAG, "Properties file exist: " + f.exists());
			
			FileOutputStream s = new FileOutputStream(file, false);
			properties.store(s, "");
		} catch (Exception e) {
			Log.e(TAG, "Save properties failed: " + file +", ", e);
		}
	}
}