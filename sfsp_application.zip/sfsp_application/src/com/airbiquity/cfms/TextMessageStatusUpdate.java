package com.airbiquity.cfms;

import java.io.IOException;

import com.airbiquity.aqlog.AqLog;
import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;

public class TextMessageStatusUpdate {

	private static final int IS_READ_BIT = 0x02;
	private static final int IS_RX_BY_ICS_BIT = 0x01;
	
	private long messageId;
	private int status = 0x01;
	
	public long getMessageId() {
		return messageId;
	}
	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	private void setBooleanStatusBits( int bits, boolean val  )
	{
		if( val )
		{
			// set the bits
			status |= bits;
		}
		else
		{
			// clear the bits
			bits =  ~bits;
			status &= bits;
		}
	}
	
	private boolean getBooleanStatusBits( int bits )
	{
		return ( bits == ( status & bits ) );		
	}

	public void setIsReadByDriver( boolean isRead )
	{
		setBooleanStatusBits( IS_READ_BIT, isRead );
	}
	
	public boolean isReadByDriver()
	{
		return getBooleanStatusBits( IS_READ_BIT );
	}
	
	public boolean isRxByIcs()
	{
		return getBooleanStatusBits( IS_RX_BY_ICS_BIT );
	}
  
	public void setIsRxByIcs( boolean isRx )
	{
		setBooleanStatusBits( IS_RX_BY_ICS_BIT, isRx );
	}
	
	public byte[] encodePackedDataToBytes() 
	{
		byte[] b = null;
		try
		{
			ByteEncoder be = new ByteEncoder();
			be.writeLong( 8, this.getMessageId() );
			be.writeInt( 1, this.getStatus() );
			b = be.getContent();
		}
		catch( Exception e )
		{
			AqLog.getInstance().error("Error encoding TextMessageStatusUpdate", e );
		}
		return b;
	}
	
	public void decodePackedDataFromBytes( byte[] raw )
	{
		ByteDecoder bd = new ByteDecoder( raw );
		try
		{
			this.setMessageId( bd.readLong( 8 ) );
			this.setStatus( bd.readInt( 1 ));
		}
		catch( Exception e )
		{
			AqLog.getInstance().error("Error decoding TextMessageStatusUpdate", e );
		}
	}	
}
