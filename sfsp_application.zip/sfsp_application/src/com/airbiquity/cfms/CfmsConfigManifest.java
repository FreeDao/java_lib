/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2009 by Airbiquity.  All rights reserved.
 *
 * ***************************************************************************
 */
//@@CL=CfmsConfigManifest.java

package com.airbiquity.cfms;

//import com.airbiquity.util.AqProperties;
import com.airbiquity.util.AqUtils;
//import com.airbiquity.util.AqSys;
import com.airbiquity.aqlog.AqLog;
//import com.airbiquity.util.Properties;
//import com.airbiquity.util.ObuManifest;
import java.util.StringTokenizer;
import com.airbiquity.util.ByteEncoder;
import com.airbiquity.util.ByteDecoder;

import java.lang.String;

/** This class holds the configuration information necessary to determine which OBU software
 *  and configurations are currently active on an OBU from the OBU's point of view (i.e. config
 *  and application are currently installed and running).
 */
public class CfmsConfigManifest
{
    private String coreVersion;
    private String tspConfigVersion;
    private String obuSwVersion;
    private String geoFenceSetVersion;
    private String fmsVersion;
    
    private static final int CFMS_CONFIG_MANIFEST_VERSION = 2;	//max to 15
    private static int cfmsCM_vers = 0;
    
    private CfmsConfigManifest()
    {
    }
    
    public CfmsConfigManifest( boolean isEncoder )
    {
        reset( isEncoder );
    }
    
    /** Reset configuration to default values.  This method makes sense from the decoder.  If
     *  the config manifest is being re-used by a vperf decoder, the config manifest should
     *  be reset before the manifest is re-used.
     */
    protected void reset( boolean isEncoder )
    {
        if( isEncoder )
        {
//            coreVersion = new String( AqProperties.getProperties().getProperty( AqProperties.KEY_CORE_VERSION, AqProperties.DEFAULT_CORE_VERSION ) );
//            tspConfigVersion = new String( AqUtils.getObuConfigVersionString() );
//            geoFenceSetVersion = new String( GeoFence.getGFS_Vers() );
//            obuSwVersion = new String( AqUtils.getObuAppVersionString() );
//            fmsVersion = new String ( ObuManifest.getFmsVersion() ) ;
        }
        else
        {
            // Decoder defaults to empty string until populated with OTA message
            coreVersion = new String( "" );
            tspConfigVersion = new String( "" );
            geoFenceSetVersion = new String( "" );
            obuSwVersion = new String( "" );
            fmsVersion = new String( "" ); 
        }
    }

    
    /** Returns the obu configuration file element "cfmsVersion" which indicates
     *  the configuration parameter set as identfied by core.
     */
    public String getCoreVersion()
    {
        return coreVersion;
    }

    /** Returns the obu configuration file element "cfmsVersion" which indicates
     *  the configuration parameter set as identfied by the TSP.
     */
    public String getTspConfigVersion()
    {
        return tspConfigVersion;
    }

    /** Returns the obu software version */
    public String getObuSwVersion()
    {
        return obuSwVersion;
    }

//     protected void setCfgManifestVersion( int i )
//     {
//         cfmsCM_vers = i;
//     }

    protected int getCfgManifestVersion()
    {
        return cfmsCM_vers;
    }
           
    protected void setCoreVersion( String s )
    {
        coreVersion = new String( s );
    }

    protected void setTspConfigVersion( String s )
    {
        tspConfigVersion = new String( s );
    }

    protected void setObuSwVersion( String s )
    {
        obuSwVersion = new String( s );
    }
    
    protected void setFmsVersion( String v )
    {
        fmsVersion = new String( v );
    }

    protected String getFmsVersion()
    {
        return fmsVersion;
    }
    
    protected void setGeoFenceSetVersion( String v )
    {
        geoFenceSetVersion = new String ( v );
    }

    protected String getGeoFenceSetVersion()
    {
        return geoFenceSetVersion;
    }
    
    /** Consumes the bytes for the given byte stream to initialize the object */
    public void decodePackedData( ByteDecoder bd ) 
    {
        try
        {
            int len =  bd.readByte();
            cfmsCM_vers = len /16;
            len = len & 0x0f;
        	
            setObuSwVersion( bd.readString(len) );
        }
        catch( Exception e )
        {
            //^^CL2=Unable to read configManifest.obuSwVersion:
            AqLog.getInstance().error("^^CL2" + e.toString(), e );
        }
        
        try
        {
            setTspConfigVersion( bd.readShortString() );
        }
        catch( Exception e )
        {
            //^^CL3=Unable to read configManifest.tspConfigVersion:
            AqLog.getInstance().error("^^CL3" + e.toString(), e );
        }

        try
        {
        	geoFenceSetVersion =  bd.readShortString();
        }
        catch( Exception e )
        {
            //^^CL5=gfver
        	AqLog.getInstance().error("^^CL5", e );
        }
        
        try
        {
            setCoreVersion( bd.readShortString() );
        }
        catch( Exception e )
        {
            //^^CL4=Unable to read configManifest.coreVersion:
            AqLog.getInstance().error("^^CL4 " + e.toString(), e );
        }

        try
        {
        	fmsVersion = bd.readShortString();
        }
        catch( Exception e )
        {
            //^^CL6=fmsver
        	AqLog.getInstance().error("^^CL6", e );
        }
    }
    
    /** Append the packed format for the given Event to the given byte encoder object */
    public void encodePackedData( ByteEncoder be ) // throws Exception
    {
        try
        {
            int len = getObuSwVersion().length();
            len |= (CFMS_CONFIG_MANIFEST_VERSION << 4);
            be.writeInt(1, len);
            be.writeString( getObuSwVersion() );
        }
        catch( IllegalArgumentException iae )
        {
            be.writeInt(".obuSwVersion", 0, 0, 1, 0 );
        }

        try
        {
            be.writeShortString( getTspConfigVersion() );
        }
        catch( IllegalArgumentException iae )
        {
            be.writeInt(".tspConfigVersion", 0, 0, 1, 0 );
        }

        try
        {
            be.writeShortString( geoFenceSetVersion );
        }
        catch (IllegalArgumentException iae) {
            be.writeInt(".GeoFenceSetVersion", 0, 0, 1, 0);
        }
        
        try
        {
            be.writeShortString( getCoreVersion() );
        }
        catch( IllegalArgumentException iae )
        {
            be.writeInt(".coreVersion", 0, 0, 1, 0 );
        }
        
        try
        {
            be.writeShortString( fmsVersion );
        }
        catch( IllegalArgumentException iae )
        {
            be.writeInt(".fmsVersion", 0, 0, 1, 0 );
        }
    }
}
