/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2009 by Airbiquity.  All rights reserved.
 *
 * ***************************************************************************
 */
//@@AU=AqDriverId.java

package com.airbiquity.cfms;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import com.airbiquity.aqlog.AqLog;
import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.AqConsts;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;

public class AqDriverId
{
    public static final byte ID_TYPE_TACHO = (byte) 0x00;
    public static final byte ID_TYPE_UBU_KEYPAD = (byte) 0x40;
    public static final byte ID_TYPE_ALT = ID_TYPE_UBU_KEYPAD; /* DEPRICATED --- constant now documented in ICD OBU_KEYPAD */
    public static final byte ID_TYPE_UNKNOWN = (byte) 0x20;
    public static final byte ID_TYPE_IBUTTON = (byte) 0x60;
    public static final byte ID_TYPE_MASK = (byte) 0x60;
    
    public static final byte ID_SIZE_MAX = (byte) 0x1f;
    public static final byte ID_SIZE_MASK = ID_SIZE_MAX;
    public static final String ALT_ID_PREFIX = "@@@";
    public static final String IBUTTON_ID_PREFIX = "iB:";
    
    String driverId = "";
    byte source = 0;

    public AqDriverId()
    {
        this( (AqDriverId) null );
    }
    
    public AqDriverId( AqDriverId id )
    {
        if( null != id )
        {
            this.driverId = id.getDriverId();
            this.source = id.getDriverIdSrc();
        }
        else
        {
            this.driverId = "";
            this.source = ID_TYPE_UNKNOWN;
        }            
    }

    public boolean equals( AqDriverId cmpId )
    {
        boolean retval = false;

        if( ( null != cmpId ) &&
            ( getDriverIdSrc() == cmpId.getDriverIdSrc() ) &&
            ( null != driverId ) && ( null != cmpId.driverId ) &&
            ( driverId.equals( cmpId.driverId ) ) )
        {
            retval = true;
        }
        return retval;
    }
    
    public AqDriverId( String raw )
    {
        raw = raw.trim();
        if( null != raw )
        {
            if( raw.length() > ALT_ID_PREFIX.length() )
            {
                if( raw.startsWith( ALT_ID_PREFIX ) )
                {
                    if( 0 == raw.compareTo( AqConsts.UNKNOWN_DRIVER_ID ) )
                    {
                        driverId = "";
                        source = ID_TYPE_UNKNOWN;
                    }
                    else
                    {
                        driverId = raw.substring( 3 );
                        source = ID_TYPE_ALT;
                    }
                }
                else if( raw.startsWith( IBUTTON_ID_PREFIX ) )
                {
                    driverId = raw.substring( 3 );
                    source = ID_TYPE_IBUTTON;
                }
                else
                {
                    driverId = raw;
                    source = ID_TYPE_TACHO;
                }
            }
        }
    }
    
    public void reset()
    {
        driverId = "";
        source = ID_TYPE_UNKNOWN;
    }

    // OBU 2.4.? Driver Id  -- This is a requirement but not defined in output parameters for Driver Id Event
    public String getDriverId()
    {
        return driverId;
    }

    // OBU 2.4.? Driver Id  -- This is a requirement but not defined in output parameters for Driver Id Event
    public byte getDriverIdSrc()
    {
        return (byte) (source & ID_TYPE_MASK);
    }

    public String getRawDriverId()
    {
        byte idType = getDriverIdSrc();
        String s = new String( driverId );

        if( ID_TYPE_ALT == idType )
        {
            s = ALT_ID_PREFIX + s;
        }
        else if( ID_TYPE_IBUTTON == idType )
        {
            s = IBUTTON_ID_PREFIX + s;
        }
        else if( ID_TYPE_UNKNOWN == idType )
        {
            s = AqConsts.UNKNOWN_DRIVER_ID;
        }
        return s;
    }

    // OBU 2.4.? Driver Id  -- This is a requirement but not defined in output parameters for Driver Id Event
    public void setDriverId( String id )
    {
        driverId = id;
    }
    
    protected void setDriverId( byte[] id ) throws UnsupportedEncodingException
    {
        String s = new String( id );
        setDriverId( s );
    }

    // OBU 2.4.? Driver Id  -- This is a requirement but not defined in output parameters for Driver Id Event
    public void setDriverIdSrc( byte src )
    {
        source = (byte) ( (byte) src & (byte) ID_TYPE_MASK);
    }

    private int getDriverIdLen( byte b )
    {
        return b & ID_SIZE_MASK;
    }
    
//     public String toString( String prefix )
//     {
//         String s = new String();

//         s = prefix + "DriverId: ";

//         if( ID_TYPE_ALT == source )
//         {
//             s = s + "ID_TYPE_OBU_KEYPAD: ";
//         }
//         else if( ID_TYPE_IBUTTON == source )
//         {
//             s = s + "ID_TYPE_IBUTTON: ";
//         }
//         else if( ID_TYPE_UNKNOWN == source )
//         {
//             s = s + "ID_TYPE_UNKNOWN: ";
//         }
//         else
//         {
//             s = s + "ID_TYPE_TACHO: ";
//         }
//         s = s + getDriverId();
//         return s;
//     }
    
//     public String toString()
//     {
//         return toString("");
//     }
    
    /** Consumes the bytes for the given byte stream to initialize the object */
    public void decodePackedData( ByteDecoder bd ) throws IOException, AqErrorException
    {
        byte tmp =  bd.readByte();
        int idLen = idLen = getDriverIdLen( tmp );
        setDriverIdSrc( tmp );
        setDriverId( bd.readBytes( idLen ) );
    }

    /** Append the packed format for the given Event to the given byte encoder object */
    public void encodePackedData( String desc, ByteEncoder be ) // throws Exception
    {
        byte[] id = new byte[0];
        try
        {
            id = driverId.getBytes();
        }
        catch( Exception e )
        {
            //^^AU1=Unable to convert driverId to byte array:
            AqLog.getInstance().error("^^AU1 " + e.toString(), e );
        }

        if( id.length > ID_SIZE_MAX )
        {
            byte tmp_id[] = id;
            id = new byte[ID_SIZE_MAX];
            System.arraycopy( tmp_id, 0, id, 0, ID_SIZE_MAX );
        }

        byte tmp = (byte) ( ( (byte) id.length ) | source );

        try
        {
            be.writeInt( 1, tmp );
            be.writeBytes( id );
        }
        catch( Exception e )
        {
            //^^AU2=Error packing driverId:
            AqLog.getInstance().error("^^AU2 " + e.toString(), e );
            be.writeInt(desc + ".exceptionDriverId", 0, 255, 1, 0 );
        }
    }
    
    public static AqDriverId decodeRawBytes( byte[] raw ) throws IOException, AqErrorException
    {
    	AqDriverId did = new AqDriverId();
    	ByteDecoder bd = new ByteDecoder(raw);
    	did.decodePackedData(bd);
    	return did;
    }
    
    public byte[] encodeRawBytes()
    {
    	ByteEncoder be = new ByteEncoder();
    	this.encodePackedData("", be);
    	return be.getContent();
    }
}