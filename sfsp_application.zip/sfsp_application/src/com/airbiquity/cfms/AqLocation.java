/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2009 by Airbiquity.  All rights reserved.
 *
 * ***************************************************************************
 */
//@@BN=AqLocation.java

package com.airbiquity.cfms;
import java.io.IOException;
import java.util.Date;


import com.airbiquity.aqlog.AqLog;
import com.airbiquity.exception.AqDataNotAvailableException;
import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.ByteEncoder;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.AqUtils;
import java.util.StringTokenizer;



public class AqLocation
{
    // protected double latitude;
    // protected double longitude;

    protected int masLatitude = 0;
    protected int masLongitude = 0;
    protected int altitude = 0;
    protected int spd_heading = 0; 

    
    protected long timeInMs = 0; /* ms since 1/1/1970 ... or should we choose another epoch? */

    // OBU 2.2   Fuel Filling Event  -- aggregate   
    // OBU 2.3   Fuel Theft Event    -- aggregate   
    // OBU 2.4   Driver Logon Event  -- aggregate   
    // OBU 2.5   Driver Logoff Event -- aggregate   
    // OBU 2.6   Ignition on Event   -- aggregate   
    // OBU 2.7   Ignition off Event  -- aggregate   
    
    public AqLocation()
    {
    }

    public AqLocation( String lat, String lon, String time, String alt, String speed, String heading )
    {
        init( lat, lon, time, alt, speed, heading );
    }

    private void init( String lat, String lon, String time, String alt, String speed, String heading )
    {
        setLatitude( AqUtils.parseDouble( "location.lat", lat, 0 ) );
        setLongitude( AqUtils.parseDouble( "location.lon", lon, 0 ) );
        setTimeInMs( AqUtils.parseLong( "location.time", time, 0 ) );
        
        setAltitudeInMeters( AqUtils.parseFloat( "location.alt", alt, 0 ) );
        setSpeedInMetersPerSecond( AqUtils.parseFloat( "location.speed", speed, 0 ) );
        setHeadingInDegrees( AqUtils.parseFloat( "location.heading", heading, 0 ) );
    }
        
    // lat, lon, time, altitude, speed, heading 
    public AqLocation( String csv )
    {
        StringTokenizer st = new StringTokenizer( csv, "," );
        fromTokenizer( st );
    }

    public AqLocation( AqLocation loc )
    {
        if( null != loc )
        {
            this.masLatitude = loc.masLatitude;
            this.masLongitude = loc.masLongitude;
            this.altitude = loc.altitude;
            this.spd_heading = loc.spd_heading;
            this.timeInMs = loc.timeInMs;
        }
    }
    
    private static final int MILLIARCSECONDS_PER_DEGREE = 3600000;

    public void reset()
    {
        masLatitude = 0;
        masLongitude = 0;
        altitude = 0;
        timeInMs = 0;        
    }

    // OBU 2.x.2 Date                -- aggregate   
    // OBU 2.x.3 Time                -- aggregate   
    public long getTimeInMs() throws AqDataNotAvailableException
    {
        return timeInMs;
    }

    public Date getTime() throws AqDataNotAvailableException
    {
        return new Date( timeInMs );
    }

    // OBU 2.x.4 Location lat/lon    -- aggregate   
    public double getLatitude() throws AqDataNotAvailableException
    {
        return getMilliarcSecondsAsDegrees( masLatitude );
    }

    public double getLongitude() throws AqDataNotAvailableException
    {
        return getMilliarcSecondsAsDegrees( masLongitude );
    }

    // OBU 2.x.? Not defined by TSP requirements
    // altitude, heading and speed but they show up in XSD.
    public float getAltitudeInMeters() throws AqDataNotAvailableException
    {
        return altitude;
    }

    public float getHeadingInDegrees() throws AqDataNotAvailableException
    {
        return spd_heading / 180;
    }

    public float getSpeedInKph() throws AqDataNotAvailableException
    {
        return spd_heading % 180;
    }

    
    // OBU 2.x.2 Date                -- aggregate   
    // OBU 2.x.3 Time                -- aggregate   
    protected void setTimeInMs( long ms )
    {
        timeInMs = ms;
    }

    // OBU 2.x.4 Location lat/lon    -- aggregate   
    protected void setLongitude( double lon )
    {
        masLongitude = getCordinateAsMilliarcSeconds( lon );
    }

    protected void setLatitude( double lat )
    {
        masLatitude = getCordinateAsMilliarcSeconds( lat );
    }


    // OBU 2.x.? Not defined by TSP requirements
    // altitude, heading and speed but they show up in XSD.
    protected void setAltitudeInMeters( float alt )
    {
        altitude = ( (int) ( alt + 0.5 ) );
    }

    protected void setAltitudeInMeters( double alt )
    {
        setAltitudeInMeters( (float) alt );
    }

    protected void setHeadingInDegrees( float degrees )
    {
        int speed = spd_heading % 180;

        // normalize between 0 and 360
        degrees = degrees % (float) 360.0;
        int head = (int) ( degrees + 0.5 );

        spd_heading = ( ( head * 180 ) + speed );
    }

    protected void setHeadingInDegrees( double degrees )
    {
        setHeadingInDegrees( (float) degrees );
    }
    
    protected void setSpeedInKph( float kph )
    {
        int speed = (int) ( kph + 0.5 );
        if( speed > 179 ) speed = 179;

        int head = (int) spd_heading / 180;

        spd_heading = ( ( head * 180 ) + speed );
    }

    // Another standard used by some HW manufacturers
    protected void setSpeedInMetersPerSecond( double mPs )
    {
        float kph = (float) ( mPs * (float) 3.6 );
        setSpeedInKph( kph );
    }
    
    public String toCsv()
    {
        String s = new String();

        s = getMilliarcSecondsAsDegrees( masLatitude ) + ", "
            + getMilliarcSecondsAsDegrees( masLongitude ) + ", "
            + timeInMs + ", "
            + altitude + ", "
            + spd_heading % 180 + ", "
            + spd_heading / 180;

        return s;
    }

    public void fromTokenizer( StringTokenizer st )
    {
        String lat_s = null;
        String lon_s = null;
        String time_s = null;
        String alt_s = null;
        String speed_s = null;
        String heading_s = null;

        try
        {
            lat_s = st.nextToken();
            lon_s = st.nextToken();
            time_s = st.nextToken();
            alt_s = st.nextToken();
            speed_s = st.nextToken();
            heading_s = st.nextToken();
        }
        catch( Exception e )
        {
            //^^BN1=Unable to tokenize location csv:
            AqLog.getInstance().error("^^BN1 " + e.toString(), e );
        }

        init( lat_s, lon_s, time_s, alt_s, speed_s, heading_s );
    }
    
    protected static int getCordinateAsMilliarcSeconds( double coordinate )
    {
        int mas;
        mas = (int) (  coordinate * MILLIARCSECONDS_PER_DEGREE );
        return mas;
    }

    protected static double getMilliarcSecondsAsDegrees( int mas )
    {
        double degrees = mas;

        return degrees / MILLIARCSECONDS_PER_DEGREE;
    }
    
    /** Consumes the bytes for the given byte stream to initialize the object */
    public void decodePackedData( ByteDecoder bd ) throws IOException, AqErrorException
    {
        /* wipe the slate */
        reset();

        masLatitude = bd.checkedReadSignedInt( 4, 0 );
        masLongitude = bd.checkedReadSignedInt( 4, 0 );
        timeInMs = bd.checkedReadInt( 4, 0 ) * 1000;
        altitude = bd.checkedReadInt( 2, 0 );
        spd_heading = bd.checkedReadInt( 2, 0 );
    }
    
    /** Append the packed format for the given Event to the given byte encoder object */
    public void encodePackedData( String desc, ByteEncoder be ) // throws Exception
    {
    	be.writeSignedInt( desc + ".latitude", -90 * MILLIARCSECONDS_PER_DEGREE, 90 * MILLIARCSECONDS_PER_DEGREE, 4, masLatitude );
        be.writeSignedInt( desc + ".longitude", -180 * MILLIARCSECONDS_PER_DEGREE, 180 * MILLIARCSECONDS_PER_DEGREE, 4, masLongitude );
        be.writeInt( desc + ".time", 0, 0x7fffffff, 4,  (int) ( timeInMs / 1000 ) );
        
        // TODO figure out why sometimes altitude is out of range
        int a = altitude;
        if( a < -1000) a = -1000;
        else if( a > 20000 ) a = 20000;
        be.writeInt( desc + ".altitude", -1000, 20000, 2, a );
        be.writeInt( desc + ".speedHeading", 0, 64800, 2, spd_heading );
    }

    // Health report still uses legacy format
    /** Append the packed format for the given Event to the given byte encoder object */
    public void encodePackedData( ByteEncoder be ) // throws Exception
    {
        be.writeSignedInt( 4, masLatitude );
        be.writeSignedInt( 4, masLongitude );
        be.writeLong( 4, timeInMs / 1000 );
        be.writeSignedInt( 2, altitude );
        be.writeInt( 2, spd_heading );
    }
}