package com.airbiquity.cfms;

import com.airbiquity.aqlog.AqLog;
import com.airbiquity.exception.AqDataNotAvailableException;
import com.airbiquity.util.AqUtils;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;


/** This class is used by the OBU to construct OBU status to be consumed by lower layers of the ICS.  The
 *  ICS will then translate to a JSON object to be consumed by the HMI.  This class is purposfully un-aware of
 *  the JSON encoding in order to insure that the OBU doesn't require a JSON .jar file be included as a 
 *  as part of its build (and associated SW update).  Also, any maintenence of this class needs to consider
 *  that it must still be capable of running on J2ME and J2EE platforms (i.e. don't use Annotations or other nice new features)!
 * 
 * @author DQuimby
 *
 */
public class ObuStatus {

	private int speed = 0;
	private AqDriverId driverId = new AqDriverId();
	private boolean isGprsUp = false;
	private long timestamp = AqUtils.getRtcTimeInMs();;
	private AqLocation location = new AqLocation();
	private String shiftId = "";

	
	public String getShiftId() {
		return shiftId;
	}

	public void setShiftId(String shiftId) {
		this.shiftId = shiftId;
	}

	public double getLatitude()
	{
		double lat = 0;
		try {
			lat = location.getLatitude();
		} catch (AqDataNotAvailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lat;
	}
	
	public double getLongitude()
	{
		double lon = 0;
		try {
			lon = location.getLongitude();
		} catch (AqDataNotAvailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lon;
	}
	
	// more GPS type methods if/when needed here !
	
	public AqLocation getLocation() {
		return location;
	}

	public void setLocation(AqLocation location) {
		this.location = location;
	}

	public int getSpeed() {
		return speed;
	}
	
	public float getSpeedInKph()
	{
		float kph = speed;
		kph /= ((float) 256.0 );
		return kph;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public AqDriverId getDriverId() {
		return driverId;
	}

	public void setDriverId(AqDriverId driverId) {
		this.driverId = driverId;
	}

	public boolean isGprsUp() {
		return isGprsUp;
	}

	public void setGprsUp(boolean isGprsUp) {
		this.isGprsUp = isGprsUp;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public ObuStatus()
	{
		
	}
	
	public ObuStatus( AqLocation location, double speed, AqDriverId did, boolean isGprsUp )
	{
		this.location = new AqLocation( location );
		this.speed = (int) ( speed * 256 );
		this.driverId = new AqDriverId( did );
		this.isGprsUp = isGprsUp;
	}
	
	public byte[] encodeToByteArray()
	{
		ByteEncoder be = new ByteEncoder();
		
		be.writeLong( 8, timestamp );
		location.encodePackedData(be);
		be.writeInt( 2, speed );
		be.writeShortString( this.getShiftId() );
		driverId.encodePackedData("", be);
		int gprsFlag = 0;
		if( isGprsUp ) gprsFlag = 1;
		be.writeInt( 1, gprsFlag );

		return be.getContent();
	}
	
	public void decodeFromByteArray( byte[] b )
	{
		ByteDecoder bd = new ByteDecoder( b );
		try
		{
			 timestamp = bd.readLong( 8 );
			 location.decodePackedData(bd);
			 speed = bd.readInt( 2 );
			 
			 // fixup "unavailable speed".
			 if( speed > 0xFFF0 ) speed = 0xFFFF;
			 this.setShiftId( bd.readShortString() );
			 driverId.decodePackedData(bd);
			 int gprsFlag = bd.readInt(1);
			 if( 0x01 == (gprsFlag & 0x01) )
			 {
				 isGprsUp = true;
			 }
			 else
			 {
				 isGprsUp = false;
			 }
		}
		catch( Exception e )
		{
			AqLog.getInstance().error("Unable to read OBU Status", e );
		}
	}
}
