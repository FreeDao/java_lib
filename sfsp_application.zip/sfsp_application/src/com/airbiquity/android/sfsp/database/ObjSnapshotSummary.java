/**  
* @Title: ObjSnapshotSummary.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-12-3
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import java.io.UnsupportedEncodingException;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;
import android.util.Xml.Encoding;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class ObjSnapshotSummary {
	private int id = 0; // ID for local database
	
	private long timestamp = 0;
	private byte[] data = new byte[0];
	private boolean isLastShiftPeriod = false;
	private int sequence_num = 0;
	
	private String shift_id = "";
	private int vperf_message_version = 0;
	private long cfms_trans_id = 0;
	
	public ObjSnapshotSummary() {
		
	}
	
	/**
	 * Initialize with json string
	 * 
	 * @param String
	 *            json
	 */
	public ObjSnapshotSummary(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			init(obj);
		} catch (JSONException e) {
			Log.e("ObjSnapshotSummary", "Json error: ", e);
		}
	}
	
	/**
	 * Initialize with json object
	 * @param obj
	 */
	public ObjSnapshotSummary(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.timestamp = obj.optLong(IcsConstants.KEY_TIMESTAMP);
		
		String tmp_data = obj.optString(IcsConstants.KEY_REPORT_DATA);
		this.data = (tmp_data != null && !("null").equals(tmp_data)) ? tmp_data.getBytes() : new byte[0];
		
		this.isLastShiftPeriod = obj.optBoolean(IcsConstants.KEY_REPORT_IS_LAST);
		this.sequence_num = obj.optInt(IcsConstants.KEY_REPORT_SEQUENCE_NUM);
		
		this.shift_id = obj.optString(IcsConstants.KEY_SHIFT_ID);
		this.vperf_message_version = obj.optInt(IcsConstants.KEY_REPORT_MSG_VERSION);
		this.cfms_trans_id = obj.optLong(IcsConstants.KEY_REPORT_TRANS_ID);
	}

	/**
	 * 
	 * Check value of the message
	 * 
	 * @return boolean
	 */
	public boolean isValid(){
		boolean isValid = true;
		
		if (this.shift_id == null) {
			isValid = false;
		}
		
		return isValid;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the timestamp
	 */
	public long getTimestamp() {
		return timestamp;
	}
	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}
	/**
	 * @return the isLastShiftPeriod
	 */
	public boolean getIsLastShiftPeriod() {
		return isLastShiftPeriod;
	}
	/**
	 * @param isLastShiftPeriod the isLastShiftPeriod to set
	 */
	public void setIsLastShiftPeriod(boolean isLastShiftPeriod) {
		this.isLastShiftPeriod = isLastShiftPeriod;
	}
	/**
	 * @return the sequence_num
	 */
	public long getSequence_num() {
		return sequence_num;
	}
	/**
	 * @param sequence_num the sequence_num to set
	 */
	public void setSequence_num(int sequence_num) {
		this.sequence_num = sequence_num;
	}
	/**
	 * @return the shift_id
	 */
	public String getShift_id() {
		return shift_id;
	}
	/**
	 * @param shift_id the shift_id to set
	 */
	public void setShift_id(String shift_id) {
		this.shift_id = shift_id;
	}
	/**
	 * @return the vperf_message_version
	 */
	public int getVperf_message_version() {
		return vperf_message_version;
	}
	/**
	 * @param vperf_message_version the vperf_message_version to set
	 */
	public void setVperf_message_version(int vperf_message_version) {
		this.vperf_message_version = vperf_message_version;
	}
	/**
	 * @return the cfms_trans_id
	 */
	public long getCfms_trans_id() {
		return cfms_trans_id;
	}
	/**
	 * @param cfms_trans_id the cfms_trans_id to set
	 */
	public void setCfms_trans_id(long cfms_trans_id) {
		this.cfms_trans_id = cfms_trans_id;
	}
	
	/**
	 * Convert object to json object
	 * 
	 * @return String
	 */
	public JSONObject toJsonObj() {
		JSONObject json = new JSONObject();
		try {			
			json.put(IcsConstants.KEY_ID, this.id);
			
			json.put(IcsConstants.KEY_TIMESTAMP, this.timestamp);
			json.put(IcsConstants.KEY_REPORT_DATA, new String(this.data));
			json.put(IcsConstants.KEY_REPORT_IS_LAST, this.isLastShiftPeriod);
			
			json.put(IcsConstants.KEY_REPORT_SEQUENCE_NUM, this.sequence_num);
			json.put(IcsConstants.KEY_SHIFT_ID, this.shift_id);
			json.put(IcsConstants.KEY_REPORT_MSG_VERSION, this.vperf_message_version);
			
			json.put(IcsConstants.KEY_REPORT_TRANS_ID, this.cfms_trans_id);
		} catch (JSONException e) {
			Log.e("ObjSnapshotSummary", "Json error: ", e);
		}

		return json;
	}
	
	/**
	 * Convert object to json string
	 * 
	 * @return String
	 */
	public String toJsonString() {
		return toJsonObj().toString();
	}
}
