/**  
* @Title: Alert.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-9-24
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import org.json.JSONException;
import org.json.JSONObject;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

import android.util.Log;

public class ObjAlert {
	private long id = 0;
	private long cfmsId = 0;
	private String alert_type;
	private long timestamp = 0;
	private String shift_id;
	
	private int odometer;
	private float latitude;
	private float longitude;
	private String driver_id;
	
	private int driver_id_type;
	private float duration = -1;
	private float distance_travelled = -1;
	private float max_speed = -1;
	
	private int is_read = 0;
	
	public ObjAlert() {
		
	}
	
	public ObjAlert(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			init(obj);
		} catch (JSONException e) {
			Log.e("ObjAlert", "Json error: ", e);
		}
	}
	
	public ObjAlert(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.id = obj.optLong("id");
		this.alert_type = obj.optString(IcsConstants.KEY_ALERT_TYPE);
		this.timestamp = obj.optLong(IcsConstants.KEY_TIMESTAMP);
		this.shift_id = obj.optString(IcsConstants.KEY_SHIFT_ID);
		
		String tmp_latitude = obj.optString(IcsConstants.KEY_LATITUDE);
		String tmp_longitude = obj.optString(IcsConstants.KEY_LONGITUDE);
		
		this.odometer = obj.optInt(IcsConstants.KEY_ALERT_ODOMETER);
		this.latitude = (tmp_latitude != null && !("null").equals(tmp_latitude)) ? Float.parseFloat(tmp_latitude) : 0;
		this.longitude = (tmp_longitude != null && !("null").equals(tmp_longitude)) ? Float.parseFloat(tmp_longitude) : 0;
		this.driver_id = obj.optString(IcsConstants.KEY_DRIVER_ID);
		
		String tmp_duration = obj.optString(IcsConstants.KEY_ALERT_DURATION);
		String tmp_distance_travelled = obj.optString(IcsConstants.KEY_ALERT_DISTANCE_TRAVELLED);
		String tmp_max_speed = obj.optString(IcsConstants.KEY_ALERT_MAX_SPEED);
				
		this.driver_id_type = obj.optInt(IcsConstants.KEY_DRIVER_ID_TYPE);
		this.duration = (tmp_duration != null && !("null").equals(tmp_duration)) ? Float.parseFloat(tmp_duration) : -1;
		this.distance_travelled = (tmp_distance_travelled != null && !("null").equals(tmp_distance_travelled)) ? Float.parseFloat(tmp_distance_travelled) : -1;
		this.max_speed = (tmp_max_speed != null && !("null").equals(tmp_max_speed)) ? Float.parseFloat(tmp_max_speed) : -1;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the timestamp
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the shift_id
	 */
	public String getShift_id() {
		return shift_id;
	}

	/**
	 * @param shift_id the shift_id to set
	 */
	public void setShift_id(String shift_id) {
		this.shift_id = shift_id;
	}

	/**
	 * @return the odometer
	 */
	public int getOdometer() {
		return odometer;
	}

	/**
	 * @param odometer the odometer to set
	 */
	public void setOdometer(int odometer) {
		this.odometer = odometer;
	}

	/**
	 * @return the latitude
	 */
	public float getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public float getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the driver_id
	 */
	public String getDriver_id() {
		return driver_id;
	}

	/**
	 * @param driver_id the driver_id to set
	 */
	public void setDriver_id(String driver_id) {
		this.driver_id = driver_id;
	}

	/**
	 * @return the driver_id_type
	 */
	public int getDriver_id_type() {
		return driver_id_type;
	}

	/**
	 * @param driver_id_type the driver_id_type to set
	 */
	public void setDriver_id_type(int driver_id_type) {
		this.driver_id_type = driver_id_type;
	}

	/**
	 * @return the duration
	 */
	public float getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(float duration) {
		this.duration = duration;
	}

	/**
	 * @return the distance_travelled
	 */
	public float getDistance_travelled() {
		return distance_travelled;
	}

	/**
	 * @param distance_travelled the distance_travelled to set
	 */
	public void setDistance_travelled(float distance_travelled) {
		this.distance_travelled = distance_travelled;
	}

	/**
	 * @return the max_speed
	 */
	public float getMax_speed() {
		return max_speed;
	}

	/**
	 * @param max_speed the max_speed to set
	 */
	public void setMax_speed(float max_speed) {
		this.max_speed = max_speed;
	}

	// TODO
	public boolean isValid() {
		boolean isValid = true;
		
		if (this.shift_id.equals("")) {
			isValid = false;
		}
		
		return isValid;
	}

	/**
	 * @return the alert_type
	 */
	public String getAlert_type() {
		return alert_type;
	}

	/**
	 * @param alert_type the alert_type to set
	 */
	public void setAlert_type(String alert_type) {
		this.alert_type = alert_type;
	}
	
	
	public long getCfmsId() {
		return cfmsId;
	}

	public void setCfmsId(long cfmsId) {
		this.cfmsId = cfmsId;
	}

	/**
	 * Convert object to json object
	 * 
	 * @return String
	 */
	public JSONObject toJsonObj() {
		JSONObject json = new JSONObject();
		try {
			json.put(IcsConstants.KEY_ID, this.id);
			
			json.put(IcsConstants.KEY_ALERT_TYPE, this.alert_type);
			json.put(IcsConstants.KEY_TIMESTAMP, this.timestamp);
			json.put(IcsConstants.KEY_SHIFT_ID, this.shift_id);
			json.put(IcsConstants.KEY_ALERT_ODOMETER, this.odometer);
			
			json.put(IcsConstants.KEY_LATITUDE, this.latitude);
			json.put(IcsConstants.KEY_LONGITUDE, this.longitude);
			json.put(IcsConstants.KEY_DRIVER_ID, this.driver_id);
			
			json.put(IcsConstants.KEY_DRIVER_ID_TYPE, this.driver_id_type);
			json.put(IcsConstants.KEY_ALERT_DURATION, (int) this.duration);
			json.put(IcsConstants.KEY_ALERT_DISTANCE_TRAVELLED, String.format("%.1f", this.distance_travelled));
			json.put(IcsConstants.KEY_ALERT_MAX_SPEED, (int) this.max_speed);
			
			json.put(IcsConstants.KEY_MSG_READ, this.is_read);
		} catch (JSONException e) {
			Log.e("ObjAlert", "Json error: ", e);
		}

		return json;
	}
	
	/**
	 * Convert object to json string
	 * 
	 * @return String
	 */
	public String toJsonString() {
		return toJsonObj().toString();
	}

	/**
	 * @return the is_read
	 */
	public int getIs_read() {
		return is_read;
	}

	/**
	 * @param is_read the is_read to set
	 */
	public void setIs_read(int is_read) {
		this.is_read = is_read;
	}
}
