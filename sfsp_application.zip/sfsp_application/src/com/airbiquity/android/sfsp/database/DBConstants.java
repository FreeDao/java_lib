/**  
* @Title: DBConstant.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-9-24
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

public class DBConstants {
	public static final int DATABASE_VERSION = 1;
	public static final String DATABASE_NAME = "sfsp.db";
	public static final String TABLE_MESSAGE = "message";
	public static final String TABLE_CONFIG = "config";
	
	public static final String TABLE_REPLYWITH = "reply_with";
	public static final String TABLE_RELIABLE_MESSAGE = "reliable_message";
	public static final String TABLE_ALERT = "alert";
//	public static final String TABLE_DRIVER_REPORT = "driver_report";
	
	public static final String TABLE_SNAPSHOT_SUMMARY = "snapshot_summary";
	public static final String TABLE_SHIFT_ABSTRACT = "shift_abstract";
	public static final String TABLE_TIPS = "tips";
	
	public static final int OPTION_ON = 1;
	public static final int OPTION_OFF = 0;
	
	public static final String UNKNOWN_DRIVERID = "-1";
}
