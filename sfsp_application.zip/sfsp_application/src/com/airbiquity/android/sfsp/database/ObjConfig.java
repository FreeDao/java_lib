/**  
* @Title: Config.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-9-24
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class ObjConfig {
	private int id;
	
	private String driver_id = DBConstants.UNKNOWN_DRIVERID;
	private int driver_type = IcsConstants.DRIVER_ID_TYPE_UNKNOWN;
	private int is_eula_accepted = 0;
	private String language = "eng";
	
	private int audio = 1;
	private int show_high_msg = 1;
	private int show_high_alert = 1;
	
	public ObjConfig() {
		
	}
	
	/**
	 * Initialize with json string
	 * @param String json
	 */
	public ObjConfig(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			init(obj);
		} catch (JSONException e) {
			Log.e("ObjConfig", "Json error: ", e);
		}
	}
	
	/**
	 * Initialize with json object
	 * @param obj
	 */
	public ObjConfig(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.driver_id = obj.optString(IcsConstants.KEY_CFG_USERID);
		this.driver_type = obj.optInt(IcsConstants.KEY_CFG_DRIVERTYPE);
		this.is_eula_accepted = obj.optInt(IcsConstants.KEY_CFG_EULA);
		this.language = obj.optString(IcsConstants.KEY_CFG_LANGUAGE);
		
		this.audio = obj.optInt(IcsConstants.KEY_CFG_AUDIO);
		this.show_high_msg = obj.optInt(IcsConstants.KEY_CFG_MSG);
		this.show_high_alert = obj.optInt(IcsConstants.KEY_CFG_ALERT);
	}

	// TODO
	public boolean isValid() {
		boolean isValid = true;
		
		if (this.driver_id == null) {
			isValid = false;
		}
		
		return isValid;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * @return the driver_id
	 */
	public String getDriver_id() {
		return driver_id;
	}

	/**
	 * @param driver_id the driver_id to set
	 */
	public void setDriver_id(String driver_id) {
		this.driver_id = driver_id;
	}
	
	/**
	 * @return the driver_type
	 */
	public int getDriver_type() {
		return driver_type;
	}

	/**
	 * @param driver_type the driver_type to set
	 */
	public void setDriver_type(int driver_type) {
		this.driver_type = driver_type;
	}

	/**
	 * @return the is_eula_accepted
	 */
	public int getIs_eula_accepted() {
		return is_eula_accepted;
	}

	/**
	 * @param is_eula_accepted the is_eula_accepted to set
	 */
	public void setIs_eula_accepted(int is_eula_accepted) {
		this.is_eula_accepted = is_eula_accepted;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the audio
	 */
	public int getAudio() {
		return audio;
	}

	/**
	 * @param audio the audio to set
	 */
	public void setAudio(int audio) {
		this.audio = audio;
	}

	/**
	 * @return the show_high_msg
	 */
	public int getShow_high_msg() {
		return show_high_msg;
	}

	/**
	 * @param show_high_msg the show_high_msg to set
	 */
	public void setShow_high_msg(int show_high_msg) {
		this.show_high_msg = show_high_msg;
	}

	/**
	 * @return the show_high_alert
	 */
	public int getShow_high_alert() {
		return show_high_alert;
	}

	/**
	 * @param show_high_alert the show_high_alert to set
	 */
	public void setShow_high_alert(int show_high_alert) {
		this.show_high_alert = show_high_alert;
	}
	
	/**
	 * Convert object to json object
	 * 
	 * @return String
	 */
	public JSONObject toJsonObj() {
		JSONObject json = new JSONObject();
		try {
			json.put(IcsConstants.KEY_CFG_USERID, this.driver_id);
			json.put(IcsConstants.KEY_CFG_DRIVERTYPE, this.driver_type);
			json.put(IcsConstants.KEY_CFG_EULA, this.is_eula_accepted);
			json.put(IcsConstants.KEY_CFG_AUDIO, this.audio);
			json.put(IcsConstants.KEY_CFG_LANGUAGE, this.language);
			json.put(IcsConstants.KEY_CFG_MSG, this.show_high_msg);
			json.put(IcsConstants.KEY_CFG_ALERT, this.show_high_alert);
		} catch (JSONException e) {
			Log.e("ObjMessage", "Json error: ", e);
		}

		return json;
	}
	
	/**
	 * Convert object to json string
	 * 
	 * @return String
	 */
	public String toJsonString() {
		return toJsonObj().toString();
	}
}