/**  
* @Title: ObjTips.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-12-3
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class ObjTips {
	private int id = 0; // ID for local database
	
	private long tip_number = 0;
	private int tip_category = 0;
	private int tip_level = 0;
	private int tip_language = 0;
	
	private String tip_text = "";
	
	public ObjTips() {
		
	}
	
	/**
	 * Initialize with json string
	 * 
	 * @param String
	 *            json
	 */
	public ObjTips(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			init(obj);
		} catch (JSONException e) {
			Log.e("ObjTips", "Json error: ", e);
		}
	}
	
	/**
	 * Initialize with json object
	 * @param obj
	 */
	public ObjTips(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.tip_number = obj.optLong(IcsConstants.KEY_REPORT_TIP_NUMBER);
		this.tip_category = obj.optInt(IcsConstants.KEY_REPORT_TIP_CATEGORY);
		this.tip_level = obj.optInt(IcsConstants.KEY_REPORT_TIP_LEVEL);
		this.tip_language = obj.optInt(IcsConstants.KEY_REPORT_TIP_LANGUAGE);
		
		this.tip_text = obj.optString(IcsConstants.KEY_REPORT_TIP_TEXT);
	}
	
	public boolean isValid(){
		boolean isValid = true;
		
		if (this.tip_number < 0) {
			isValid = false;
		}
		
		return isValid;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the tip_number
	 */
	public long getTip_number() {
		return tip_number;
	}

	/**
	 * @param tip_number the tip_number to set
	 */
	public void setTip_number(long tip_number) {
		this.tip_number = tip_number;
	}

	/**
	 * @return the tip_category
	 */
	public int getTip_category() {
		return tip_category;
	}

	/**
	 * @param tip_category the tip_category to set
	 */
	public void setTip_category(int tip_category) {
		this.tip_category = tip_category;
	}

	/**
	 * @return the tip_level
	 */
	public int getTip_level() {
		return tip_level;
	}

	/**
	 * @param tip_level the tip_level to set
	 */
	public void setTip_level(int tip_level) {
		this.tip_level = tip_level;
	}

	/**
	 * @return the tip_language
	 */
	public int getTip_language() {
		return tip_language;
	}

	/**
	 * @param tip_language the tip_language to set
	 */
	public void setTip_language(int tip_language) {
		this.tip_language = tip_language;
	}

	/**
	 * @return the tip_text
	 */
	public String getTip_text() {
		return tip_text;
	}

	/**
	 * @param tip_text the tip_text to set
	 */
	public void setTip_text(String tip_text) {
		this.tip_text = tip_text;
	}
	
	/**
	 * Convert object to json object
	 * 
	 * @return String
	 */
	public JSONObject toJsonObj() {
		JSONObject json = new JSONObject();
		try {			
			json.put(IcsConstants.KEY_ID, this.id);
			
			json.put(IcsConstants.KEY_REPORT_TIP_NUMBER, this.tip_number);
			json.put(IcsConstants.KEY_REPORT_TIP_CATEGORY, this.tip_category);
			json.put(IcsConstants.KEY_REPORT_TIP_LEVEL, this.tip_level);
			json.put(IcsConstants.KEY_REPORT_TIP_LANGUAGE, this.tip_language);
			
			json.put(IcsConstants.KEY_REPORT_TIP_TEXT, this.tip_text);
		} catch (JSONException e) {
			Log.e("ObjTips", "Json error: ", e);
		}

		return json;
	}
	
	/**
	 * Convert object to json string
	 * 
	 * @return String
	 */
	public String toJsonString() {
		return toJsonObj().toString();
	}
}
