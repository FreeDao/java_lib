/**  
* @Title: Message.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-9-24
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class ObjMessage {
	private int id = 0; // ID for local database
	private long message_id = 0; // ID from server
	private long parent_message_id = 0;
	private int is_read = 0;
	private int is_require_response = 0;
	
	private int priority = 4;
	private int content_id = 2;
	private String language = "eng";
	private int encoding = 2;
	
	private int message_from_type;
	private String message_from = "";
	private int message_to_type;
	private String message_to = "";
	
	private long time = 0;
	private String subject = "";
	private String body = "";
	
	public ObjMessage() {
		
	}
	
	/**
	 * Initialize with json string
	 * 
	 * @param String
	 *            json
	 */
	public ObjMessage(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			init(obj);
		} catch (JSONException e) {
			Log.e("ObjMessage", "Json error: ", e);
		}
	}
	
	/**
	 * Initialize with json object
	 * @param obj
	 */
	public ObjMessage(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.message_id = obj.optLong(IcsConstants.KEY_MSG_ID);
		this.parent_message_id = obj.optLong(IcsConstants.KEY_MSG_PARENT_ID);
		this.is_read = obj.optInt(IcsConstants.KEY_MSG_READ);
		this.is_require_response = obj.optInt(IcsConstants.KEY_MSG_RESPONSE_REQUIRED);
		
		this.priority = obj.optInt(IcsConstants.KEY_PRIORITY);
		this.content_id = obj.optInt(IcsConstants.KEY_MSG_CONTENTID);
		this.language = obj.optString(IcsConstants.KEY_MSG_LANGUAGE);
		this.encoding = obj.optInt(IcsConstants.KEY_MSG_ENCODING);
		
		this.message_from_type = obj.optInt(IcsConstants.KEY_MSG_FROM_TYPE);
		this.message_from = obj.optString(IcsConstants.KEY_MSG_FROM);
		this.message_to_type = obj.optInt(IcsConstants.KEY_MSG_TO_TYPE);
		this.message_to = obj.optString(IcsConstants.KEY_MSG_TO);
		
		this.time = obj.optLong(IcsConstants.KEY_MSG_TIMESTAMP);
		
		this.subject = obj.optString(IcsConstants.KEY_MSG_SUBJECT);
		this.body = obj.optString(IcsConstants.KEY_MSG_DETAIL);
	}

	/**
	 * 
	 * Check value of the message
	 * 
	 * @return boolean
	 */
	public boolean isValid(){
		boolean isValid = true;
		
		// TODO, message id < 0?
//		if (this.message_id < 0 || this.message_from == null || 
//				this.message_to == null || this.subject == null || this.body == null) {
		if (this.message_from == null || this.subject == null
				|| this.body == null) {
//			Log.d("ObjMessage", "Message object is not valid: messageId - " + this.message_id
//					+ ", messageFrom - " + this.message_from + ", messageTo - "
//					+ this.message_to + ", subject - " + this.subject
//					+ ", body - " + this.body);
			isValid = false;
		}
		
		return isValid;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the message_id
	 */
	public long getMessage_id() {
		return message_id;
	}

	/**
	 * @param message_id the message_id to set
	 */
	public void setMessage_id(long message_id) {
		this.message_id = message_id;
	}
	
	/**
	 * @return the parent_message_id
	 */
	public long getParent_message_id() {
		return parent_message_id;
	}

	/**
	 * @param parent_message_id the parent_message_id to set
	 */
	public void setParent_message_id(long parent_message_id) {
		this.parent_message_id = parent_message_id;
	}

	/**
	 * @return the is_read
	 */
	public int getIs_read() {
		return is_read;
	}

	/**
	 * @param is_read the is_read to set
	 */
	public void setIs_read(int is_read) {
		this.is_read = is_read;
	}

	/**
	 * @return the is_require_response
	 */
	public int getIs_require_response() {
		return is_require_response;
	}

	/**
	 * @param is_require_response the is_require_response to set
	 */
	public void setIs_require_response(int is_require_response) {
		this.is_require_response = is_require_response;
	}

	/**
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * @param priority the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * @return the content_id
	 */
	public int getContent_id() {
		return content_id;
	}

	/**
	 * @param content_id the content_id to set
	 */
	public void setContent_id(int content_id) {
		this.content_id = content_id;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the encoding
	 */
	public int getEncoding() {
		return encoding;
	}

	/**
	 * @param encoding the encoding to set
	 */
	public void setEncoding(int encoding) {
		this.encoding = encoding;
	}

	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return the body
	 */
	public String getBody() {
		return body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(String body) {
		this.body = body;
	}

	/**
	 * @return the message_from
	 */
	public String getMessage_from() {
		return message_from;
	}

	/**
	 * @param message_from the message_from to set
	 */
	public void setMessage_from(String message_from) {
		this.message_from = message_from;
	}

	/**
	 * @return the message_to
	 */
	public String getMessage_to() {
		return message_to;
	}

	/**
	 * @param message_to the message_to to set
	 */
	public void setMessage_to(String message_to) {
		this.message_to = message_to;
	}

	/**
	 * @return the time
	 */
	public long getTime() {
		return time;
	}

	/**
	 * @param time the time to set
	 */
	public void setTime(long time) {
		this.time = time;
	}

	/**
	 * @return the message_from_type
	 */
	public int getMessage_from_type() {
		return message_from_type;
	}

	/**
	 * @param message_from_type the message_from_type to set
	 */
	public void setMessage_from_type(int message_from_type) {
		this.message_from_type = message_from_type;
	}

	/**
	 * @return the message_to_type
	 */
	public int getMessage_to_type() {
		return message_to_type;
	}

	/**
	 * @param message_to_type the message_to_type to set
	 */
	public void setMessage_to_type(int message_to_type) {
		this.message_to_type = message_to_type;
	}
	
	/**
	 * Convert object to json object
	 * 
	 * @return String
	 */
	public JSONObject toJsonObj() {
		JSONObject msgJson = new JSONObject();
		try {
			msgJson.put(IcsConstants.KEY_ID, this.id);
			msgJson.put(IcsConstants.KEY_MSG_ID, this.message_id);
			msgJson.put(IcsConstants.KEY_MSG_FROM, this.message_from);
			msgJson.put(IcsConstants.KEY_MSG_FROM_TYPE, this.message_from_type);
			msgJson.put(IcsConstants.KEY_MSG_TO, this.message_to);
			msgJson.put(IcsConstants.KEY_MSG_TO_TYPE, this.message_to_type);
			msgJson.put(IcsConstants.KEY_MSG_SUBJECT, this.subject);
			msgJson.put(IcsConstants.KEY_MSG_DETAIL, this.body);
			msgJson.put(IcsConstants.KEY_MSG_TIMESTAMP, this.time);
			msgJson.put(IcsConstants.KEY_MSG_READ, this.is_read);
			msgJson.put(IcsConstants.KEY_PRIORITY, this.priority);
		} catch (JSONException e) {
			Log.e("ObjMessage", "Json error: ", e);
		}

		return msgJson;
	}
	
	/**
	 * Convert object to json string
	 * 
	 * @return String
	 */
	public String toJsonString() {
		return toJsonObj().toString();
	}
}