/**  
* @Title: UpdateManager.java
* @Package com.airbiquity.android.sfsp
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-11-2
* @version V1.0  
*/
package com.airbiquity.android.sfsp;

import android.content.Context;
import android.content.Intent;
import android.os.Environment;

import com.airbiquity.util.SystemManager;

public class UpdateManager {
	private Context mContext;
	
	public UpdateManager(Context context) {
		this.mContext = context;
	}
	
	public void installUpdate() {
		String filePath = Environment.getExternalStorageDirectory()
				+ "/download/SFSP2.0.apk";
		installUpdate(filePath);
	}
	
	public void installUpdate(String filePath) {
		notifyUpdate();
		SystemManager.getInstance().execAsRoot("pm install -rf " + filePath, false);
	}
	
	private void notifyUpdate() {
		Intent intent = new Intent();
        intent.setAction("com.airbiquity.android.startSfspReceiver");
        intent.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        this.mContext.sendBroadcast(intent);
	}
}
