/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

import android.os.SystemClock;

/**
 * Provides a mock broker for testing the Choreo Messaging services.
 * 
 * @author Jack William Bell
 *
 */
public class MockBroker implements iCMessageBroker {
	static final int MSG_ID_ACK = 65;
	static final int MSG_ID_TEST = 64;
	
	static final int MSG_TRANSID_1 = 1;
	
	byte[] testMsgPayload = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

	long mMSecThen = 0;
	
	@Override
	public void initialize(String configurationString) {
		// TODO Allow for some kind of configuration, say the message IDs 
		// being created, each with a separate frequency of injection.
	}

	@Override
	public boolean start() throws NoTransportException {
		// Nothing to do here.
		return true;
	}
	
	@Override
	public boolean isConnected() {
		// Nothing to do here.
		return true;
	}
	
	@Override
	public CMessage process(CMessage dataToSend) throws NoTransportException, NoConnectionException {
		// Ack sent messages.
		if (dataToSend != null) {
			return new CMessage(MSG_ID_ACK, MSG_TRANSID_1);
		}
		
		// Inject test messages at one second intervals.
		long mSecNow = SystemClock.currentThreadTimeMillis();
		if (mSecNow > mMSecThen + 1000) {
			mMSecThen = mSecNow;
			return new CMessage(MSG_ID_TEST, testMsgPayload);
		}
		
		return null;
	}

	@Override
	public void stop() {
		// Nothing to do here.
	}

}
