/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

/**
 * Exception thrown when an invalid message ID is provided.
 * 
 * @author Jack William Bell
 */
public class InvalidChoreoMessageId extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5682065561260180703L;

	public InvalidChoreoMessageId() {
		super("Invalid Message ID: [Unknown]"); 
	}

	public InvalidChoreoMessageId(String msg) {
		super("Invalid Message ID: [Unknown] Message: " + msg); 
	}

	public InvalidChoreoMessageId(int messageId) {
		super("Invalid Message ID: " + messageId); 
	}

	public InvalidChoreoMessageId(int messageId, String msg) {
		super("Invalid Message ID: " + messageId + " Message: " + msg); 
	}
	
	
}
