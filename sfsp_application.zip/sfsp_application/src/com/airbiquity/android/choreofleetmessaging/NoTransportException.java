package com.airbiquity.android.choreofleetmessaging;

public class NoTransportException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1814855665664193305L;

	public NoTransportException() {
		super();
	}
	
	public NoTransportException(String msg) {
		super(msg);
	}

	public NoTransportException(Exception ex) {
		super(ex);
	}
}
