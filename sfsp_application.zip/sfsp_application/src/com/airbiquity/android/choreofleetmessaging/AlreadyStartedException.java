/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

/**
 * Exception thrown when trying to start the message broker service while
 * it is already running.
 * 
 * @author Jack William Bell
 */
public class AlreadyStartedException extends Exception {

	private static final long serialVersionUID = 724462213587787550L;

	public AlreadyStartedException() {
		super();
	}
	
	public AlreadyStartedException(String msg) {
		super(msg);
	}
	
	public AlreadyStartedException(Exception ex) {
		super(ex);
	}
}
