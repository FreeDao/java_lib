/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

import android.os.Handler;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Base64;
import android.util.Log;
import android.util.SparseArray;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import com.airbiquity.android.sfsp.database.DBInstance;
import com.airbiquity.android.sfsp.database.ObjReliableMessage;
import com.airbiquity.aqlog.AqLog;

/**
 * <p>Acts as a helper for accessing CMessageBrokerService functionality. CMessageBrokerService 
 * should not be started separately. All public methods and properties of the CMessageDispatcher
 * class are threadsafe and may be called at any time in any order, with the exception of the 
 * startup and shutdown lifetime management functions.</p>
 * 
 * <p>You use this class by calling the static startup() method once on app start. You then use  
 * the static getInstance() method to get the running instance of the class, which you can use to 
 * add message handlers or send messages. Message handlers are standard Android Handlers you 
 * implement for your own classes needing to be informed when messages arrive. Message handlers 
 * may be added only for specific messages or for all messages, based on message ID.</p>
 * 
 * <p>On app exit you must call the static shutdown() method once. Calling startup() again 
 * after the dispatcher has been shut down will result in undefined behavior.</p>
 * 
 * <p><b>TODO:</b> Consider adding service state change handlers. (JWB)</p>
 * 
 * <p><b>TODO:</b> Not currently handling message response codes (message.arg1). (JWB)</p>
 * 
 * @author Jack William Bell
 *
 */
public class CMessageDispatcher {
	
	//
	// Declarations.
	//
	
	private static final String TAG = "CMessageDispatcher";

	//
	// Local Storage.
	//
	
	private static CMessageDispatcher minstance = null;
	
	private ArrayList<Handler> mHandlers = new ArrayList<Handler>();
	private SparseArray<int[]> mAccepts = new SparseArray<int[]>();
	private Context mContext = null;
	private boolean mIsBound = false;
	private Messenger mService = null;
	private int mServiceState = CMessageBrokerService.STATE_NOT_STARTED;
	private DBInstance mDb = null;
	
	//
	// Static Functions.
	//

	private DBInstance getDb()
	{
		if( null == mDb )
		{
			mDb = DBInstance.getInstance(null);
		}
		return mDb;
	}
	
	/**
	 * Called to establish a Choreo Messaging connection. Should only be called once, globally,
	 * until shutdown() is called. 
	 * 
	 * @param context
	 * @return
	 * @throws AlreadyStartedException
	 */
	public static CMessageDispatcher startup(Context context) throws AlreadyStartedException {
		return startup(context, null, null);
	}
	
	/**
	 * Called to establish a Choreo Messaging connection. Should only be called once, globally,
	 * until shutdown() is called. 
	 * 
	 * @param context
	 * @param msgBrokerClassName
	 * @param msgBrokerConfiguration
	 * @return
	 * @throws AlreadyStartedException
	 */
	public static CMessageDispatcher startup(Context context, String msgBrokerClassName,
			String msgBrokerConfiguration) throws AlreadyStartedException {
		if (minstance != null) throw new AlreadyStartedException();
    	
    	Log.i(TAG, "Message Dispatcher starting up. Class/Config: " + 
    			msgBrokerClassName + " / " + msgBrokerConfiguration);
		
		minstance = new CMessageDispatcher(context, msgBrokerClassName, msgBrokerConfiguration);
		return minstance;
	}
	
	/**
	 * Called to shut down an already established Choreo Message Connection. 
	 */
	public static void shutdown() {
    	Log.i(TAG, "Message Dispatcher shutting down.");
    	
		if (minstance != null) {
			minstance.destroy();
			minstance = null;
		}
	}
	
	/**
	 * Returns the instance of the message dispatcher used to interact with an established
	 * Choreo Messsaging connection. 
	 * 
	 * @return The instance of the message dispatcher or null if no Choreo Messsaging connection
	 * has been established.
	 */
	public static CMessageDispatcher getInstance() {
		return minstance;
	}
	
	//
	// Constructors.
	//
		
	/**
	 * Private constructor. This constructor should never be called. See 
	 * CMessageDispatcher(broker) constructor.
	 */
	private CMessageDispatcher() {
		// TODO: Throw exception. (JWB)
	}

	/**
	 * Private constructor. This is a Singleton class and can not be 
	 * instantiated without calling the startup(broker) static function. You
	 * can retrieve the instance by calling the getInstance() static funcion.
	 */
	private CMessageDispatcher(Context context, String msgBrokerClassName, 
			String msgBrokerConfiguration) {

		// Clean up the arguments, if needed.
		if (context != null) mContext = context;
		if (msgBrokerClassName == null) {
			// TODO: Add broker autosensing and use the appropriate broker/configuration. (JWB)
			
			// TODO: Consider using factories and non-class name IDs. (JWB)
			
			// HACK: Currently defaults to the test broker. (JWB)
			msgBrokerClassName = MockBroker.class.getName();
		}
		if (msgBrokerConfiguration == null) msgBrokerConfiguration = "";
		
		// Bind the broker service, using the passed broker.
		doBindService(msgBrokerClassName, msgBrokerConfiguration);
	}
	
	//
	// Private Instance Methods.
	//
    
    /**
     * Handler of incoming messages from service.
     */
    static class BrokerHandler extends Handler {
		private WeakReference<CMessageDispatcher> mDispatcher;
		
		public BrokerHandler(CMessageDispatcher dispatcher) {
			mDispatcher = new WeakReference<CMessageDispatcher>(dispatcher);
		}
		
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case CMessageBrokerService.CMD_ERROR: {
            	// Set state to 'error' until where hear otherwise.
            	// NOTE: We are setting the state value using a weak reference. So 
            	// we suppress the warning because it is meaningless here. (JWB)
            	@SuppressWarnings("unused") 
            	CMessageDispatcher d = mDispatcher.get();
            	d.mServiceState = CMessageBrokerService.STATE_ERROR;
            	
            	// Log the error.
            	Log.e(TAG, msg.getData().getString("error_message"));
            	
            	// TODO: Ask the service what state it is actually in. (JWB)
            }
               break;
            case CMessageBrokerService.CMD_CHOREO_MESSAGE: {
            	// Get the message.
            	CMessage cMessage = new CMessage(msg.getData());
            	int mid = cMessage.getMessageId();
            	
            	// Log the message.
            	//Log.d(TAG, "Choreo Message arrived, ID: " + msg.arg2);
            	Log.d(TAG, "Choreo Message arrived, ID: " + mid );
            	
            	// Check for handlers that accept that message ID.
            	// NOTE: This code suffers from a severe case of 'belt and suspenders'
            	// for good reason. (JWB)
            	CMessageDispatcher d = mDispatcher.get();
            	Handler hdlr;
            	int[] a;
            	for (int i = 0;i < d.mAccepts.size(); i++) {
            		a = d.mAccepts.get(i);
            		// A null accepts means the handler gets all messages.
            		if (a == null || Arrays.binarySearch(a, mid) > -1) {
            			// Pass the message on to the handler.
            			hdlr = d.mHandlers.get(i);
            			if (hdlr != null) hdlr.handleMessage(msg);
            		}
            	}
            }
               break;
            case CMessageBrokerService.CMD_STATE_CHANGE_NOTIFICATION: 
            case CMessageBrokerService.CMD_STATE_REPORT: {
            	CMessageDispatcher d = mDispatcher.get();
            	d.mServiceState = msg.arg2;
            	
            	// Log the state change.
            	Log.i(TAG, "Broker service state changed to " + d.mServiceState);
            }
               break;
            default: {
                super.handleMessage(msg);            	
            }
            }
        }
    }  
    
    /**
     * Target we publish for clients to send messages to IncomingHandler.
     */
    final Messenger mBrokerReceiver = new Messenger(
    		new BrokerHandler(this));
	
    /**
     * Class for interacting with the main interface of the service.
     */
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className,
                IBinder service) {
        	Log.d(TAG, "Broker service connected.");
        	
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  We are communicating with our
            // service through an IDL interface, so get a client-side
            // representation of that from the raw service object.
            mService = new Messenger(service);

            // Handshake with the the service by providing a callback; in this case
            // the receiver for this instance.
            Message msg = Message.obtain(null, CMessageBrokerService.CMD_HANDSHAKE);
            msg.replyTo = mBrokerReceiver;
            try {
                mService.send(msg);
                
            } catch (RemoteException e) {
                // In this case the service has crashed before we could even
                // do anything with it; we can count on soon being
                // disconnected (and then reconnected if it can be restarted)
                // so there is no need to do anything here.
            }
        }

        public void onServiceDisconnected(ComponentName className) {
        	Log.d(TAG, "Broker service disconnected.");
        	
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
        	// TODO: Figure out how to handle this properly. (JWB)
            mService = null;
        }
    };

    private void doBindService(String msgBrokerClassName, String msgBrokerConfiguration) {
    	Log.d(TAG, "Binding Broker service.");
    	
    	// Create the Intent. We use an explicit
        // class name because there is no reason to be able to let other
        // applications replace our component.
    	Intent intent = new Intent(mContext, CMessageBrokerService.class);
    	
        // Specify what broker to use and provide appropriate configuration for that broker.
    	intent.putExtra("broker_class", msgBrokerClassName);
    	intent.putExtra("broker_configuration", msgBrokerConfiguration);

        // Establish a connection with the service.  
    	mContext.bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        mIsBound = true;
    }
    
    private void doUnbindService() {
    	Log.d(TAG, "Unbinding Broker service.");
    	
    	// Force the state to stopped.
    	mServiceState = CMessageBrokerService.STATE_STOPPED;
    	
        if (mIsBound) {
            // If we have received the service, and hence registered with
            // it, then now is the time to unregister.
            if (mService != null) {
                Message msg = Message.obtain(null, CMessageBrokerService.CMD_STOP);
                try {
                    mService.send(msg);
                } catch (RemoteException e) {
                    // There is nothing special we need to do if the service
                    // has crashed.
                }
            }
            
            // Detach our existing connection.
            mContext.unbindService(mConnection);
            mIsBound = false;
        }
        
        // Other cleanup.
        mService = null;
        mConnection = null;
    }
    
	private void destroy() {
		// Send a stop message.
        Message msg = Message.obtain(null, CMessageBrokerService.CMD_STOP);
        msg.replyTo = mBrokerReceiver;
        try {
            if(mService != null) mService.send(msg); // nikm
        } catch (RemoteException e) {
            // The service probably crashed. Ignore it.
        }			
		
		// Unbind from the broker service.
		if (mIsBound) doUnbindService();
		
		// Other cleanup.
		mHandlers = null;
		mAccepts = null;
		mContext = null;
	}	
	
	//
	// Public Instance Methods.
	//

    /**
     * Gets the current state of the Choreo Messaging connection.
     * 
     * @return Underlying broker service state as an integer value. 
     */
    public int getConnectionState() {
    	return this.mServiceState;
    }
    
	/**
	 * Sends a Choreo Message to the Broker Service for processing. The current broker 
	 * service state must be CMessageBrokerService.STATE_READY.
	 * 
	 * @param msgBundle The message to send as a Bundle object contain Choreo message values.
	 */
	private void sendChoreoMessage(Bundle msgBundle) throws RemoteException, NotReadyException {
		sendChoreoMessage(CMessage.extractMessagePacketFromBundle(msgBundle), 0, 0, 0 );
	}

	/**
	 * Sends a Choreo Message to the Broker Service for processing. The current broker 
	 * service state must be CMessageBrokerService.STATE_READY.
	 * 
	 * @param cMessage The message to send as a CMessage object.
	 */
	private void sendChoreoMessage(CMessage cMessage) throws RemoteException, NotReadyException {
		sendChoreoMessage(cMessage.packet, 0, 0, 0 );
	}

	/**
	 * Sends a Choreo Message to the Broker Service for processing. The current broker 
	 * service state must be CMessageBrokerService.STATE_READY.
	 * 
	 * @param messageData The message to send as a raw buffer of bytes.
	 */
//	public void sendChoreoMessage(byte[] messageData, int priority, int numRetries ) throws RemoteException, NotReadyException {
//		// sanity check and put into the database.
//		
//		DBInstance db = getDb();
//		if( null != db )
//		{
//
//			ObjReliableMessage rmsg = new ObjReliableMessage();
//			long transId = CMessage.extractMessageTransID( messageData );
//			String b64_payload = Base64.encodeToString(messageData, Base64.DEFAULT );	// 
//
//			rmsg.setTransaction_id( transId );
//			rmsg.setMessage_data( b64_payload );
//			rmsg.setPriority(priority);
//			rmsg.setRetries(numRetries);
//			
//			LinkedList<ObjReliableMessage> ll = new LinkedList<ObjReliableMessage>();
//			ll.add( rmsg );
//			db.addReliableMessage(ll);
//		}
//		else
//		{
//			AqLog.getInstance().error("Unable to get db instnace ... dropping data");
//		}
//
//	}
	
	
	/**
	 * Sends a Choreo Message to the Broker Service for processing. The current broker 
	 * service state must be CMessageBrokerService.STATE_READY.
	 * 
	 * @param messageData The message to send as a raw buffer of bytes.
	 */
	public void sendChoreoMessage(byte[] messageData, long refid, int priority, int numRetries ) throws RemoteException {

		CMessage cMsg = new CMessage( messageData,refid );

		int mid =  CMessage.extractMessageId(messageData);
    	Log.d(TAG, "Sending Choreo Message, ID: " + mid); 
    	
		// Is the service in a ready state?
    	Message msg = Message.obtain(null, CMessageBrokerService.CMD_CHOREO_MESSAGE);
    	msg.arg1 = priority;
    	msg.arg2 = numRetries;
    	msg.replyTo = mBrokerReceiver;
    	msg.setData(cMsg.toBundle());
    	try {
    		mService.send(msg);
    	} catch (RemoteException e) {
    		// Set the error state. (It might get cleared later.)
    		mServiceState = CMessageBrokerService.STATE_ERROR;
    		// Pass the exception up.
    		Log.e(TAG, "Error sending message via broker", e );
    		throw e;
    	}			
	}

	/** If there is a message in the outbound message queue which has the same transation id
	 *  of the given message, then delete the message.
	 * 
	 * @param m
	 */
	public void removeMessageFromOutboundQueue( CMessage cMsg ) throws RemoteException {

		int mid =  CMessage.extractMessageId(cMsg.packet);
		Log.d(TAG, "removing Choreo Message, ID: " + mid); 

		// Is the service in a ready state?
		Message msg = Message.obtain(null, CMessageBrokerService.CMD_REMOVE_CHOREO_MESSAGE);
		msg.arg1 = -1;
		msg.arg2 = mid;
		msg.replyTo = mBrokerReceiver;
		msg.setData(cMsg.toBundle());
		try {
			mService.send(msg);
		} catch (RemoteException e) {
			// Set the error state. (It might get cleared later.)
			mServiceState = CMessageBrokerService.STATE_ERROR;
			// Pass the exception up.
			Log.e(TAG, "Error sending message via broker", e );
			throw e;
		}
	}
	
	
	/**
	 * Adds a handler for Choreo Messages.
	 * 
	 * @param handler A handler to forward Choreo Messages to.
	 * @param accepts An array of Choreo Message IDs the handler will accept
	 * or null to indicate the handler accepts all Choreo Message IDs.
	 * @return True if successful, otherwise false.
	 */
	public boolean addChoreoMessageHandler(Handler handler, int[] accepts)
	{
		mHandlers.add(handler);
		int i = mHandlers.indexOf(handler);
		if (i > -1) {
			if (accepts != null) Arrays.sort(accepts); // Sort so we can binary search later.
			mAccepts.put(i, accepts);
			return true;
		}
		
		return false;
	}
	
	/**
	 * Removes a handler for Choreo Messages.
	 * 
	 * @param handler
	 */
	public void removeChoreoMessageHandler(Handler handler)
	{
		int i = mHandlers.indexOf(handler);
		if (i > -1) {
			mHandlers.remove(i);
			mAccepts.remove(i);
		}
	}
	
	public static boolean isExistReliableMsgWithMsgIdReferenceId( int msgId, long refId )
	{
		boolean retval = false;
		try
		{		
			retval = getInstance().getDb().isExistReliableMsgWithMsgIdReferenceId(msgId, refId);
		}
		catch( Exception e )
		{
			AqLog.getInstance().error("Unable to get mDb ... returning false", e );
		}
		return retval;
	}
}
