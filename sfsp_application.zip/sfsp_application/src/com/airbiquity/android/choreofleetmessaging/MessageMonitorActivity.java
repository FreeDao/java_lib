/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.airbiquity.android.R;
import com.airbiquity.android.fleet.ics.DummyHmi;
import com.airbiquity.android.fleet.ics.IcsDirector;
import com.airbiquity.android.sfsp.AppHostMain;

/**
 * Activity that monitors all messages and displays a list of them. Mostly used for 
 * software testing purposes, this Activity may also be used in the field by technical 
 * personnel.
 * 
 * @author Jack William Bell
 */
public class MessageMonitorActivity extends Activity implements Runnable {

	protected CMessageDispatcher mDispatcher = null;
	protected ArrayList<String> mMessages = new ArrayList<String>();
	protected ArrayAdapter<String> mMessageListAdapter;
	protected ListView mMessageList;
	protected Button mSendButton;
	protected Button mWebviewButton;
		
	// Create an anonymous implementation of OnClickListener
	private OnClickListener mBtnListener = new OnClickListener() {
	    public void onClick(View v) {
	    	try {
				mDispatcher.sendChoreoMessage(CMessage.buildMessagePacket(
						new byte[] {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}, 66, false), 0, 0, 0 );
			} catch (Exception e) {
				Log.e("MessageMonitorActivity","Error sending choreo message", e );
				// Ignore.
			}
	    }
	};
	
	// NOTE: This class is static and uses weak references to avoid creating 
	// memory leaks. (JWB)
	static class MessageHandler extends Handler {
		private WeakReference<MessageMonitorActivity> mMessageMonitorActivity;
		
		public MessageHandler(MessageMonitorActivity messageMonitorActivity)  {
			mMessageMonitorActivity = new WeakReference<MessageMonitorActivity>(messageMonitorActivity);
		}
		
        @Override
        public void handleMessage(Message msg) {
        	MessageMonitorActivity act = mMessageMonitorActivity.get();
        	if (act != null && act.mMessages != null && act.mMessageListAdapter != null) {
        		// Add the message to the array list.
            	CMessage m = new CMessage(msg.getData());
        		act.mMessages.add(m.headerToString());
            	
            	// Force the screen to update.
        		act.mMessageListAdapter.notifyDataSetChanged();
        	}        	
        }
	} 
	
	DummyHmi dhmi = null;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.messagemonitor);
        mMessageList = (ListView)findViewById(R.id.listView1);
        mSendButton = (Button)findViewById(R.id.btnSend);
        mSendButton.setOnClickListener(mBtnListener);

        // nikm
        mWebviewButton = (Button)findViewById(R.id.btnWebView);
        mWebviewButton.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				startActivity(new Intent(MessageMonitorActivity.this, AppHostMain.class));
			}
        	
        });
        
        // Start the dispatcher and get an instance to it.
        try {
        	// TODO: Get broker class name from configuration. (JWB)
			//CMessageDispatcher.startup(this);
			CMessageDispatcher.startup(this, "com.airbiquity.android.choreofleetmessaging.NetServerBroker", null);
		} catch (AlreadyStartedException e) {
			// TODO Ignore if already started? (JWB)
			e.printStackTrace();
		}
        mDispatcher = CMessageDispatcher.getInstance();
        
        // Register the handler for all messages.
        mDispatcher.addChoreoMessageHandler(new MessageHandler(this), null);
        
        // FIXME -- initialize the director and dummy HMI ... this needs to be real!
        IcsDirector.getInstance(); dhmi = new DummyHmi();
       
		IcsDirector.getInstance().addDirectorToHmiEventListener( dhmi );
        
        Thread t = new Thread( this );
        t.start();
    }
    
    public void run() {
    	// TODO Auto-generated method stub
    	Process process;
//    	try {
//    		process = Runtime.getRuntime().exec("/system/bin/su");
//    	} catch (IOException e) {
//    		// TODO Auto-generated catch block
//    		e.printStackTrace();
//    	}
//    	try {
//    		process = Runtime.getRuntime().exec("/system/bin/ls /data/dalvik-cache > /data/local");
//    	} catch (IOException e) {
//    		// TODO Auto-generated catch block
//    		e.printStackTrace();
//    	}
    	
    	try {
			process = Runtime.getRuntime().exec(
					new String[] { "/system/bin/su", "-c", "system/bin/sh" });
			DataOutputStream os = new DataOutputStream(
					process.getOutputStream());
			// from here all commands are executed with su permissions
			os.writeBytes("/system/bin/ls /data/dalvik-cache > /data/local");
			os.flush();
			os.close();
			process.destroy();
    	} catch (Exception e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    }
    
	@Override
	protected void onDestroy() {
		// Release the dispatcher instance and stop it.
		mDispatcher = null;
		CMessageDispatcher.shutdown();
		
		super.onDestroy();
	}


	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}


	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onPostCreate(savedInstanceState);
	}


	@Override
	protected void onPostResume() {
		// TODO Auto-generated method stub
		super.onPostResume();
	}


	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	
        mMessageListAdapter = new ArrayAdapter<String>(this, 
        		android.R.layout.simple_list_item_1, mMessages);
        mMessageList.setAdapter(mMessageListAdapter);  
	}


	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
	}


	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}


	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}

}