package com.airbiquity.android.fleet.ics;

//import java.lang.ref.WeakReference;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;

import com.airbiquity.android.choreofleetmessaging.CMessage;
import com.airbiquity.android.choreofleetmessaging.CMessageDispatcher;
import com.airbiquity.android.fleet.icsobjs.DriverConfiguration;
import com.airbiquity.android.fleet.icsobjs.DriverId;
import com.airbiquity.android.fleet.icsobjs.IcsConstants;
import com.airbiquity.android.fleet.icsobjs.UserIdTranslator;
import com.airbiquity.android.sfsp.database.DBInstance;
import com.airbiquity.android.sfsp.database.ObjAlert;
import com.airbiquity.android.sfsp.database.ObjConfig;
import com.airbiquity.android.sfsp.database.ObjMessage;
import com.airbiquity.aqlog.AqLog;
import com.airbiquity.cfms.GenericNotification;
import com.airbiquity.cfms.IcsEvent;
import com.airbiquity.cfms.TextMessageRequest;
import com.airbiquity.cfms.TextMessageStatusUpdate;
import com.airbiquity.exception.AqDataNotAvailableException;
import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.AqConsts;
import com.airbiquity.util.AqUtils;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;
import com.airbiquity.util.DriverIdSource;

/** This class implements the IcsHmiPortalInterface running on the android target.  Please see
 *  the interface documentation for further details.
 * 
 * @author DQuimby
 *
 */
public class IcsDirector implements IcsDirectorInterface {
	private Handler mWebviewServiceHandler = null;
	private static IcsDirector instance = null;
	private static final Integer lock = new Integer( 0 );

	// DriverId hasn't been set yet.
	
	private DBInstance dbInstance;

	private int currentDriverType = -1;
	private String currentDriverId = "";

	
	public static IcsDirector getInstance()
	{
		synchronized( lock )
		{
			if( null == instance )
			{
				instance = new IcsDirector();

				CMessageDispatcher cmd = CMessageDispatcher.getInstance();
				cmd.addChoreoMessageHandler(new MessageHandler(instance), null);
				AqLog.getInstance().debug("IcsDirectorInstance created");
			}
		}
		return instance; 
	}

	/** Queue the message to the outbound message queue.
	 * 
	 * @param payload
	 * @param cfmsMsgId The idetifier for the CFMS message.  Currently defined messages are in the range 0 ..  127;
	 * @param priority not used yet
	 * @param maxRetries Not used yet
	 */
	private static void sendChoreoMessage( byte[] payload, int cfmsMsgId, int priority, int maxRetries )
	{
		sendChoreoMessage( payload, cfmsMsgId, 0, priority, maxRetries );
	}
	
	private static void sendChoreoMessage( byte[] payload, int cfmsMsgId, long refid, int priority, int maxRetries )
	{
		try {
			// TODO -- pass priority and maxRetries to CMessageDispatcher
			AqLog.getInstance().debug("IcsDirector.sendChoreoMessage() transId: " + Long.toString( CMessage.extractMessageId( payload ), 16 ) );
			CMessageDispatcher.getInstance().sendChoreoMessage( CMessage.buildMessagePacket( payload, cfmsMsgId, false), refid, priority, maxRetries );
		} catch (RemoteException e) {
			AqLog.getInstance().error("Unable to create choreo message", e );
		} catch ( Exception e ) {
			AqLog.getInstance().error("Unable to create choreo message", e );
		}
	}
	
	/** Send an ACK to the OBU.
	 * 
	 * @param payload The payload that should be in the ACK (usually empty.  may use null or 0 byte array).
	 * @param cfmsMsgId The CFMS message id to use in creation of the ACK
	 * @param m The CMessage to reference in the ACK.  The ACK will have the same transaction id of the referenced CMessage.
	 */
	private static void sendAckToObu( byte[] payload, int cfmsMsgId, CMessage m )
	{
		try {
			CMessageDispatcher.getInstance().sendChoreoMessage( CMessage.buildMessagePacket( payload, cfmsMsgId, false, m.getTransId() ), 
																0, CMessage.PRIORITY_ACK, 1 );
		} catch (Exception e) {
			AqLog.getInstance().error("Unable to ACK OBU", e );
		}		
	}
	

	/** If there is a CMessage in the outbound message queue that has the same tranaction ID
	 *  as the given CMessage, remove the matching message from the Outbound message queue.
	 *  This will be called after processing a message that was received as a result of a request from the ICS to Choreo.
	 *  Failrue to delete the associated request will cause the outbound message queue to get log jammed on the
	 *  associated request message.
	 * 
	 * @param m A CMessage that whose transaction id will be referenced for the delete operation.
	 */
	private static void removeMessageFromOutboundQueue( CMessage m )
	{
		try 
		{
			CMessageDispatcher.getInstance().removeMessageFromOutboundQueue(m);
		} 
		catch (RemoteException e) 
		{
			AqLog.getInstance().warn("Unable to remvoe message from outbound queue");
		}
	}
	
	// NOTE: This class is static and uses weak references to avoid creating 
	// memory leaks. (JWB)
	static class MessageHandler extends Handler {
		//private WeakReference<IcsDirector> mIcsDirector;
		private IcsDirector mIcsDirector;
		
		public MessageHandler(IcsDirector icsDirector)  {
			//mIcsDirector = new WeakReference<IcsDirector>(icsDirector);
			mIcsDirector = icsDirector;
		}
		
        @Override
        public void handleMessage(Message msg) {
        	
        	try
        	{
        		IcsDirector id = IcsDirector.getInstance();
        		if (id != null ) {
        			// Add the message to the array list.
        			CMessage m = new CMessage(msg.getData());

        			// TODO: Act on said received messages!
        			int msgId = m.getMessageId();
        			AqLog.getInstance().debug("IcsDirector.handleMesasge.  msgId: " + Integer.toString( msgId, 16 ) );


        			switch( msgId )
        			{

        			case AqConsts.ATP_GENERIC_NOTIFICATION:
        				mIcsDirector.handleGenericNotification( m );
        				// No need to remove ... fire/forget
        				break;

        			case AqConsts.ATP_TEXT_MESSAGE:
        				//mIcsDirector.get().handleTextMessage(m);
        				mIcsDirector.handleTextMessage(m);
        				removeMessageFromOutboundQueue( m );
        				break;

        			case AqConsts.ATP_TEXT_MESSAGE_STATUS_UPDATE_RESPONSE:
        				//mIcsDirector.get().handleTextMessageStatusUpdateResponse(m);
        				removeMessageFromOutboundQueue( m );
        				break;

        			case AqConsts.ATP_OBU_STATUS:
        				mIcsDirector.handleObuStatus(m);
        				// No need to remove as this message is sent "fire/forget" from the OBU.
        				break;

        			case AqConsts.ATP_ICS_EVENT_RESPONSE:
        				//mIcsDirector.get().handleIcsEventResponse(m);
        				removeMessageFromOutboundQueue( m );
        				break;

        			case AqConsts.ATP_TEXT_MESSAGE_STATUS_UPDATE:
        				// Indicator that choreo get TextMessage sent by the ICS
        				// remove it from the queue ... ICS doesn't care about 
        				// "message has been read" status at this time
        				removeMessageFromOutboundQueue( m );
        				break;

        			case AqConsts.ATP_CFMS_ALERT_REQ:
        				mIcsDirector.handleAlert(m);
        				break;
        				
        				// These should not be in the OBU->ICS direction ... ignore 
        			case AqConsts.ATP_OBU_STATUS_RESPONSE:
        			case AqConsts.ATP_ICS_EVENT:
        			case AqConsts.ATP_TEXT_MESSAGE_REQUEST:
        				//mIcsDirector.get().handleTextMessageRequest( m );
        				//mIcsDirector.handleTextMessageRequest( m );
        				//break;
        				removeMessageFromOutboundQueue( m );
        				break;

        			default:
        				removeMessageFromOutboundQueue( m );
        				break;
        			}
        		}
        	}
        	catch( Exception e)
        	{
        		AqLog.getInstance().error("Error while handling CMessage", e );
        	}
        }
	} 

	private boolean sendMsgTomWebviewService( int what, String JSON )
	{
		boolean retval = false;
		if( null != this.mWebviewServiceHandler )
		{
			Message msg = mWebviewServiceHandler.obtainMessage(what, 0, 0, JSON );
			retval = mWebviewServiceHandler.sendMessage(msg);
		}
		else
		{
			AqLog.getInstance().debug("mWebviewServiceHandler is null while attempting to send: " + JSON );
		}
		return retval;
	}

	
	private void handleGenericNotification( CMessage m ) 
	{
		AqLog.getInstance().debug("IcsDirector.handleGenericNotification");
		GenericNotification bNotify = new GenericNotification();
		long transId = m.getTransId();
		
		
		if( CMessageDispatcher.isExistReliableMsgWithMsgIdReferenceId(AqConsts.ATP_TEXT_MESSAGE_REQUEST, transId) )
		{
			AqLog.getInstance().debug("ATP_TEXT_MESSAGE_REQUEST with transactionId: " + Long.toString( transId, 16 ) + " already pending");
		}
		else
		{
			// decode the binary message
			try {
				//dbInstance.displayObjReliableMessage();
				bNotify.decodePackedData( transId, m.getPayloadBytes() );

				if(	(GenericNotification.DEVICE_ICS == bNotify.getDestDevice() ) &&
					(GenericNotification.TEXT_MESSAGE_PENDING == bNotify.getNotificationtype() ) )
				{
					TextMessageRequest tmr = new TextMessageRequest();
					tmr.setNotificationId( bNotify.getNotificationId() );

					// Retry once ... Choreo will re-send the notify if we don't fetch the message ... todo, add logic 
					// to see if text message request is already pending in outbound queue and don't re-create.  Then make 
					// Text message request retries MAX.
					AqLog.getInstance().debug("IcsDirector.handleGenericNotification() transId: " + Long.toString( transId, 16 ));
					sendChoreoMessage( tmr.encodePackedData(), AqConsts.ATP_TEXT_MESSAGE_REQUEST, transId, CMessage.PRIORITY_TO_CHOREO_TXT_MSG_REQUEST, 1 );
				}
			} catch (AqErrorException e) {
				AqLog.getInstance().error("Error creating TextMessageRequest", e );
			}
		}
	}
	

	private void handleTextMessage( CMessage m )
	{
		AqLog.getInstance().debug("IcsDirector.handleTextMessage");
		com.airbiquity.cfms.TextMessage bTxtMsg = new com.airbiquity.cfms.TextMessage();
		com.airbiquity.android.fleet.icsobjs.TextMessage jTxtMsg = new com.airbiquity.android.fleet.icsobjs.TextMessage();
		
		// decode the binary message
		ByteDecoder bd = new ByteDecoder( m.getPayloadBytes() );
		bTxtMsg.decodePackedData(bd);
		long cfmsMessageId = bTxtMsg.getMessageId();
		
		if (this.dbInstance != null) {
			// See if the message is already in the database.
			if( dbInstance.isMessageExistByCfmsId( cfmsMessageId ) )
			{
				AqLog.getInstance().info("Already received CFMS Text Message don't re-send to HMI");
			}
			else
			{
				// Message doesn't exist yet, thus we can populate the DB and send to the HMI.
				
				// translate to the ics object
				jTxtMsg.setTimestamp( m.getMessageTime() );
				jTxtMsg.setParentMessageId( bTxtMsg.getParentMessageId() );

				// Don't populate json message's message_id with cfms message Id .. use id instead
				// jTxtMsg.setMessageId( bTxtMsg.getMessageId() );

				String lang = StandardMessageTranslator.getTargetLanguage( bTxtMsg.getLanguage() );
				
				jTxtMsg.setMessageCodingScheme( bTxtMsg.getMessageCodingScheme() );
				int contentId = bTxtMsg.getMessageContentId();
				jTxtMsg.setMessageContentId( contentId );
				jTxtMsg.setPriority( bTxtMsg.getPriority() );
				jTxtMsg.setResponseRequired( bTxtMsg.isResponseRequired() );

				UserIdTranslator ftranslator = new UserIdTranslator( bTxtMsg.getMessageFromType(), bTxtMsg.getMessageFromRaw() ); 
				jTxtMsg.setMessageFromType( ftranslator.getJsonToFromType() );
				jTxtMsg.setMessageFrom( ftranslator.getJsonId() );


				UserIdTranslator ttranslator = new UserIdTranslator( bTxtMsg.getMessageToType(), bTxtMsg.getMessageToRaw() ); 
				jTxtMsg.setMessageToType( ttranslator.getJsonToFromType() );
				jTxtMsg.setMessageTo( ttranslator.getJsonId());
				String body = bTxtMsg.getMessageBody();
				String subject = bTxtMsg.getSubject();

				// Translate standard messages to driver's configured language.
				if( ( contentId >= 1 ) && ( contentId <= 5 ) )
				{
					AqLog.getInstance().debug(" ************************ STANDARD MESSAGE ******************************************* ");
					ObjConfig cfg;
					int toFromType = ttranslator.getJsonToFromType(); 
					// Determine language based upon target driver if message is to driver.  Otherwise 
					// choose language preference for currently logged in driver
					AqLog.getInstance().debug("toFromType: " + toFromType + ", currentDriverId: " + currentDriverId );
					if(  IcsConstants.ID_TYPE_VEHICLE == toFromType )
					{
						cfg = dbInstance.getConfig( currentDriverId );
						AqLog.getInstance().debug(" dest vehicle ");
					}
					else
					{
						cfg = dbInstance.getConfig( ttranslator.getJsonId() );
						AqLog.getInstance().debug(" dest driver ");
					}
					
					lang = cfg.getLanguage();
					AqLog.getInstance().debug("lang: " + lang );

					subject = StandardMessageTranslator.getStandardMessageSubjectTranslation( contentId, lang );
					body = StandardMessageTranslator.getStandardMessageBodyTranslation( contentId, lang );

					AqLog.getInstance().debug(" ************************ END STANDARD MESSAGE ******************************************* ");
				}
				else
				{
				}

				jTxtMsg.setLanguage( lang );
				jTxtMsg.setSubject( subject );
				jTxtMsg.setMessageBody( body );
				
				// add message into database
				ArrayList<ObjMessage> msgs = new ArrayList<ObjMessage>();
				ObjMessage dbMsg = new ObjMessage();

				dbMsg.setMessage_id( cfmsMessageId );
				dbMsg.setParent_message_id(bTxtMsg.getParentMessageId());
				dbMsg.setIs_read(0);
				dbMsg.setIs_require_response((bTxtMsg.isResponseRequired()) ? 1 : 0);

				dbMsg.setPriority(bTxtMsg.getPriority());
				dbMsg.setContent_id(bTxtMsg.getMessageContentId());
				dbMsg.setLanguage( lang );
				dbMsg.setEncoding(bTxtMsg.getMessageCodingScheme());

				dbMsg.setMessage_from_type(ftranslator.getJsonToFromType());
				dbMsg.setMessage_from(ftranslator.getJsonId());
				dbMsg.setMessage_to_type(ttranslator.getJsonToFromType());
				dbMsg.setMessage_to(ttranslator.getJsonId());

				dbMsg.setTime(m.getMessageTime());
				dbMsg.setSubject( subject );
				dbMsg.setBody( body );

				msgs.add(dbMsg);
				long id = this.dbInstance.addMessage(msgs);

				jTxtMsg.setId(id);

				// Have the HMI reference by our internal DB id rather than the cfmsMessage id
				// This is to prevent js long overrun of js number type (i.e. double).  Code that 
				// receives message requests/status updates will look cfms message id from the 
				// referenced message id.
				jTxtMsg.setMessageId( id );

			}
			// send to the HMIs
			this.sendMsgTomWebviewService( IcsDirectorInterface.MSG_HANDLE_TEXT_MESSAGE, jTxtMsg.toString() );
		}		

		// send the response
		TextMessageStatusUpdate su = new TextMessageStatusUpdate(); 
		su.setMessageId( cfmsMessageId );
		su.setIsRxByIcs( true );
		
		sendChoreoMessage( su.encodePackedDataToBytes(), AqConsts.ATP_TEXT_MESSAGE_STATUS_UPDATE, CMessage.PRIORITY_TO_CHOREO_NORMAL, Integer.MAX_VALUE );

		// yada yada yada
		
	}


	private void handleAlert( CMessage m )
	{
		AqLog.getInstance().debug("IcsDirector.handleAlert");

		if (this.dbInstance != null)
		{
			// See if the message is already in the database.
			long cfmsTransId = m.getTransId();
			if( dbInstance.isAlertExistByCfmsId( cfmsTransId ) ) // FIXME
			{
				AqLog.getInstance().info("Already received alert don't re-send to HMI");
			}
			else
			{
				com.airbiquity.cfms.AqEventAlert bAlert = new com.airbiquity.cfms.AqEventAlert(0);
				com.airbiquity.android.fleet.icsobjs.ObuAlert jAlert = new com.airbiquity.android.fleet.icsobjs.ObuAlert();
				ByteDecoder bd = new ByteDecoder( m.getPayloadBytes() );
				try {
					bAlert.decodePackedData(bd, true, true );
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (AqErrorException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				jAlert.setAlertTypeId( bAlert.getEventId() );
				jAlert.setTimestamp( bAlert.getTimeInMs() / 1000 );
				jAlert.setShiftId( bAlert.getShiftId() );
				jAlert.setOdometer( bAlert.getOdometer() );

				double lat;
				double lon;
				try {
					lat = bAlert.getLatitude();
				} catch (Exception e) {
					lat = 0;
				}
				try {
					lon = bAlert.getLongitude();
				} catch (Exception e) {
					lon = 0;
				}

				jAlert.setLatitude( lat );
				jAlert.setLongitude( lon );
				UserIdTranslator t = new UserIdTranslator( bAlert.getDriverId() );
				jAlert.setDriverIdType( t.getJsonToFromType() );
				jAlert.setDriverId( t.getJsonId() );

				jAlert.setDuration( bAlert.getDuration() );
				jAlert.setDistance( bAlert.getDistance() );
				jAlert.setMaxSpeed( bAlert.getOneByteParam() );

				AqLog.getInstance().debug("jAlert: " + jAlert.toString() );
				ObjAlert dbAlert = new ObjAlert( jAlert.toString() );
				dbAlert.setCfmsId(cfmsTransId);
				ArrayList<ObjAlert> dbAlerts = new ArrayList<ObjAlert>();
				dbAlerts.add( dbAlert );
				
				long id = this.dbInstance.addAlert(dbAlerts);
				//jAlert.setId(id);
				dbAlert.setId(id);
				
				this.sendMsgTomWebviewService( IcsDirectorInterface.MSG_HANDLE_ALERT, dbAlert.toJsonString() );
			}
			
			sendAckToObu( null, AqConsts.ATP_CFMS_ALERT_ACK, m );			
		}
	}

	private void handleObuStatus( CMessage m )
	{
		AqLog.getInstance().debug("IcsDirector.handleStatusMessage");
		com.airbiquity.cfms.ObuStatus bStatusMsg = new com.airbiquity.cfms.ObuStatus();
		com.airbiquity.android.fleet.icsobjs.ObuStatus jStatusMsg = new com.airbiquity.android.fleet.icsobjs.ObuStatus();

		
		// decode the binary message
		bStatusMsg.decodeFromByteArray( m.getPayloadBytes() );
				
		// translate to the ics object
		jStatusMsg.setTimestamp( bStatusMsg.getTimestamp() );

		UserIdTranslator translator = new UserIdTranslator( bStatusMsg.getDriverId() );
		jStatusMsg.setShiftId( bStatusMsg.getShiftId() );
		jStatusMsg.setDriverIdType( translator.getJsonToFromType() );
		jStatusMsg.setDriverId( translator.getJsonId() );
		jStatusMsg.setLatitude( bStatusMsg.getLatitude() );
		jStatusMsg.setLongitude( bStatusMsg.getLongitude() );
		jStatusMsg.setVehicleSpeed( bStatusMsg.getSpeedInKph() );
		jStatusMsg.setGprsUp( bStatusMsg.isGprsUp() );
		
		this.sendMsgTomWebviewService( IcsDirectorInterface.MSG_HANDLE_OBU_STATUS, jStatusMsg.toString() );

		// see if the current driver is the same driver from the current status.
		int driverType =  translator.getJsonToFromType();
		String driverId = translator.getJsonId();
		if( null == driverId ) driverId = "";
		if( ( currentDriverType != driverType ) ||
			 ( ! driverId.equals(currentDriverId) ) )
		{
			// Looks like driver has changed.  Update module variables and send reset
			// to the HMI.
			currentDriverType = driverType;
			currentDriverId = driverId;
			
			DriverId did = new DriverId();
			did.setDriverIdType( driverType );
			did.setDriverId( driverId );
			this.sendMsgTomWebviewService( IcsDirectorInterface.MSG_RESET, did.toString() );
		}
	}

	@Override
	public boolean sendTextMessageToChoreo(String jsonTextMessage) {
		if (jsonTextMessage != null) { // TODO
			
			
			
			AqLog.getInstance().debug("IcsDirector.sendTextMessage: " + jsonTextMessage );
			com.airbiquity.cfms.TextMessage bTxtMsg = new com.airbiquity.cfms.TextMessage();
			com.airbiquity.android.fleet.icsobjs.TextMessage jTxtMsg = new com.airbiquity.android.fleet.icsobjs.TextMessage();

			jTxtMsg.fromJsonString( jsonTextMessage );
			
			// Generate a unique id for this message
			bTxtMsg.setMessageId( AqUtils.getGuid() );
			
			long parentMsgId = jTxtMsg.getParentMessageId();
			long cfmsParentMsgId = 0;
			if( (0 != parentMsgId ) && (null != dbInstance ) )
			{
				// Fetch the CFMS messageId via DB de-reference
				ObjMessage msg = dbInstance.getMessage(parentMsgId);
				cfmsParentMsgId = msg.getMessage_id();
			}

			bTxtMsg.setParentMessageId( cfmsParentMsgId );
			
			UserIdTranslator translator = new UserIdTranslator( jTxtMsg.getMessageFromType(), jTxtMsg.getMessageFrom() ); 
			bTxtMsg.setMessageFromType( translator.getCfmsMsgToFromType() );
			bTxtMsg.setMessageFromRaw( translator.getRawBytes() );
			
			translator = new UserIdTranslator( jTxtMsg.getMessageToType(), jTxtMsg.getMessageTo() ); 
			bTxtMsg.setMessageToType( translator.getCfmsMsgToFromType() );
			bTxtMsg.setMessageToRaw( translator.getRawBytes() );

			
			bTxtMsg.setPriority( jTxtMsg.getPriority() );
			bTxtMsg.setLanguage( jTxtMsg.getLanguage() );

			bTxtMsg.setSubject( jTxtMsg.getSubject() );
			bTxtMsg.setMessageBody( jTxtMsg.getMessageBody() );
			
			ByteEncoder be = new ByteEncoder();
			byte[] payload = null;
			try {
				bTxtMsg.encodePackedData(be);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (AqErrorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			payload = be.getContent();
			if( null != payload )
			{
				sendChoreoMessage( payload, AqConsts.ATP_TEXT_MESSAGE, CMessage.PRIORITY_TO_CHOREO_NORMAL, Integer.MAX_VALUE );
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean setMessageIsReadStatus(long messageId) {
		if (messageId != 0) { 
			TextMessageStatusUpdate su = new TextMessageStatusUpdate(); 
			su.setMessageId( messageId );
			su.setIsRxByIcs( true );
			su.setIsReadByDriver( true );
			sendChoreoMessage( su.encodePackedDataToBytes(), AqConsts.ATP_TEXT_MESSAGE_STATUS_UPDATE, CMessage.PRIORITY_TO_CHOREO_NORMAL, Integer.MAX_VALUE );
			return true;
		}
		return false;
	}

	@Override
	public boolean validatePin(String pin) {
		boolean retval = false;
		if ( (pin != null) && ( 6 == pin.length() ) ) { 
			retval = DriverIdSource.getInstance().checkId(pin);
			if( retval )
			{
				IcsEvent pinAccepted = new IcsEvent(AqUtils.getRtcTimeInMs(), IcsEvent.ICS_PIN_ASSERTED_EVENT, pin );
				sendChoreoMessage( pinAccepted.encodeToByteArray(), AqConsts.ATP_ICS_EVENT, 1, Integer.MAX_VALUE );
			}
		}
		return retval;
	}

	@Override
	public boolean eulaIsAcceptedBy(byte driverIdType, String driverId) {
		if ( driverId != null) { // TODO
			return true;
		}
		return false;
	}

	@Override
	public void addDirectorToHmiEventListener(
			DirectorToHmiEventListener listener) {
	}

	@Override
	public DriverConfiguration getDriverConfiguration(byte driverIdType,
			String driverId) {
		if ( driverId != null) { // TODO
			
			return new DriverConfiguration();
		}
		return null;
	}

	@Override
	public boolean setDriverConfiguration(byte driverIdType, String driverId,
			DriverConfiguration configuration) {
		if ( driverId != null) { // TODO
			return true;
		}
		return false;
	}

	@Override
	public String getPredefinedTextMessage(String language, int preDefindeMsgId) {
		if ( preDefindeMsgId > 0) { // TODO
			return "";
		}
		return null;
	}

	@Override
	public String getDrivingTip(int category, String language, int level) {
		// TODO Auto-generated method stub
		if ( level > 0) { // TODO
			return "";
		}
		return null;
	}

	@Override
	public String getTextMessagesForVehicleAndCurrentDriver() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public synchronized void setWebviewServiceHandler(Handler handler) {
		mWebviewServiceHandler = handler;		
	}
	
	public synchronized void setDbInstance(DBInstance _db) {
		this.dbInstance = _db;
	}

	@Override
	public String getDriverReport(int driverIdType, String driverId) {
		
		return null;
	}
}

