package com.airbiquity.android.fleet.ics;

import java.util.Locale;

import android.util.Log;

public class StandardMessageTranslator {

	private static final String[][] standardMessageBodies = 
	{
		{ 
			/* English */
			"Delivery Job change � call the office, when safe to do so",
			"Major Traffic Jam - call the office, when safe to do so",
			"Black Spot Area entered � call the office, when safe to do so",
			"Delivery address - call the office, when safe to do so",
			"Delivery hours change - call the office, when safe to do so"
		},
		{ 
			/* German */
			"�nderung des Lieferauftrags � Rufen Sie das B�ro an, wenn es die Sicherheitsmassnahmen zulassen.",
			"Langer Verkehrsstau � Rufen Sie das B�ro an, wenn es die Sicherheitsmassnahmen zulassen.",
			"Einfahrt in Black-Spot-Bereich � Rufen Sie das B�ro an, wenn es die Sicherheitsmassnahmen zulassen.",
			"Lieferadresse � Rufen Sie das B�ro an, wenn es die Sicherheitsmassnahmen zulassen.",
			"�nderung der Lieferzeiten � Rufen Sie das B�ro an, wenn es die Sicherheitsmassnahmen zulassen."
		},
		{ 
			/* French */
			"Changement de la livraison - appeler le bureau, d�s que cela est possible en toute s�curit�.",
			"Embouteillage important - appeler le bureau, d�s que cela est possible en toute s�curit�.",
			"Entr�e dans une zone de circulation importante - appeler le bureau, d�s que cela est possible en toute s�curit�.",
			"Adresse de livraison - appeler le bureau, d�s que cela est possible en toute s�curit�.",
			"Changement des horaires de livraison - appeler le bureau, d�s que cela est possible en toute s�curit�."
		},
	};

	private static final String[][] standardMessageSubjects = 
	{
		{ 
			/* English */
			"Standard message one",
			"Standard message two",
			"Standard message three",
			"Standard message four",
			"Standard message five"
		},
		{ 
			/* German */
			"Standard-Nachricht ein",
			"Standard-Nachricht zwei",
			"Standard-Nachricht drei",
			"Standard-Nachricht vier",
			"Standard-Nachricht f�nf"
		},
		{ 
			/* French */
			"Standard d'un message d'",
			"Un message standard � deux",
			"Un message standard � trois",
			"Un message standard � quatre",
			"Un message standard de cinq"
		},
	};
	
	private static String[] supportedLanguages = {
		"eng", "deu", "fra" /* , "ned", "pol", "hun", "nor", "dan", "ita" */
	};
	
	private static String[] supportedLocales = {
		"en", "de", "fr" /* , "nl", "pl", "hu", "no", "da", "it" */
	};
	
	private static int getLanguageIndex( String lang )
	{
		String lcLang = lang;
		if( null == lang ) lcLang = "eng";
		lcLang = lcLang.toLowerCase();
		
		int i;
		int target = 0;;
		for(i=0;i<5;i++)
		{
			if( supportedLanguages[i].equals(lcLang))
			{
				target = i;
				break;
			}
		}
		Log.d("TAG", "lang: " + lang + ", lcLang: " + lcLang + ", target: " + target );
		return target;
	}
	
	public static String getTargetLanguage( String lang )
	{
		return supportedLanguages[getLanguageIndex(lang)];
	}
	
	private static String getStandardTranslation( int standardMessageId, String targetLanguage, String [][] translations )
	{
		String translated = "";

		if( ( standardMessageId >= 1) && ( standardMessageId <= 5 ) )
		{
			translated = translations[getLanguageIndex(targetLanguage)][standardMessageId - 1];
		}
		return translated;
	}
	
	public static String getStandardMessageSubjectTranslation( int standardMessageId, String targetLanguage )
	{
		return getStandardTranslation( standardMessageId, targetLanguage, standardMessageSubjects );
	}
	
	public static String getStandardMessageBodyTranslation( int standardMessageId, String targetLanguage )
	{
		return getStandardTranslation( standardMessageId, targetLanguage, standardMessageBodies );
	}
	
	public static Locale getLocale( String targetLanguage )
	{	
		String junk = ""; 
		Locale loc;
		if( "deu".equals(targetLanguage) )
		{
			loc = Locale.GERMAN;
			junk = "Locale.GERMAN";
		}
		else if( "fra".equals(targetLanguage ) )
		{
			loc = Locale.FRENCH;
			junk = "Locale.FRENCH";
		}
		else
		{
			loc = Locale.ENGLISH;
			junk = "Locale.ENGLISH";
		}
		
		Log.d("tag", "targetLanguage: " + targetLanguage + ", junk: " + junk );
		return loc;
	}
}
