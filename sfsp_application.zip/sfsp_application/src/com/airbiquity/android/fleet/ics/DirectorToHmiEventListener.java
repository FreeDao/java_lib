package com.airbiquity.android.fleet.ics;

import com.airbiquity.android.fleet.icsobjs.ObuAlert;
import com.airbiquity.android.fleet.icsobjs.TextMessage;


/** This interface will be implemented by the HMI application which will facilitate communcations between 
 * the underlying system objects and the web app running in the WebKit.  The HMI will need to create javascript 
 * interfaces into each of access methods so that the java application can send events and ojbect data asynchronously to the web application.
 * 
 * @author DQuimby
 *
 */
public interface DirectorToHmiEventListener {
	
	/** The Director will call this method for the registered HMI event listener when an Text message arrives from Choreo.
	 * 
	 * @param jsonTextMessage A text message which is encoded as a JSON object.
	 */
	void handleTextMessage( String jsonTextMessage );

	/** The Director will call this method for the registered HMI event listener when an Alert is received from the OBU.
	 * 
	 * @param jsonAlert An alert which is encoded as a JSON object.
	 */
	void handleObuAlert( String jsonAlert );
	
	/** The Director will call this method for the registered HMI event listener when an Event is received  from the OBU.
	 *  Currently the only 2 events passed via this interface will be the ObuLogonEvent and ObuLogoffEvent
	 * 
	 * @param jsonEvent object that was received from the OBU.
	 */
	void handleObuEvent( String jsonEvent );
	
	/** The Director will call this method for the registered HMI event listener whenever OBU status is received.  The OBU
	 *  status will be generated periodcally by the OBU.  The target interval for the report is 1 second.  Optimization of
	 *  the target rate may need to be optimized based upon the physical interface between the OBU and ICS. 
	 * 
	 * @param jsonObuStatus The status object that was received from the OBU.
	 */
	void handleObuStatus( String jsonObuStatus );
	
	/** The Director will call this method for the registered HMI upon a new logon event.  This will cause all data from previous
	 *  shift to be flushed from the HMI's object cache.  After the flush returns, the director will pre-load objects for the 
	 *  current shift (i.e. historical reports for current driver, and historical text messages for the current driver).
	 */
	void reset();
}
