package com.airbiquity.android.fleet.icsobjs;


import java.io.IOException;
import org.json.JSONObject;
import com.airbiquity.android.choreofleetmessaging.CMessage;
import com.airbiquity.aqlog.AqLog;
import com.airbiquity.cfms.AqDriverId;
import com.airbiquity.exception.AqErrorException;import com.airbiquity.util.AqConsts;
import com.airbiquity.util.AqUtils;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;
import com.airbiquity.util.JsonHelper;

/** This class is used to exchange text messages between the IcsDirector and the HMI.  
 * 
 * @author DQuimby
 *
 */
public class TextMessage extends IcsHmiExchangeObject
{
	public static final int CODING_SCHEME_ASCII = 0;
	public static final int CODING_SCHEME_ISO_8859_1 = 1;
	public static final int CODING_SCHEME_UTF_8 = 2;
	public static final int CODING_SCHEME_UTF_16 = 3;
	public static final int CODING_SCHEME_UTF_32 = 4;
	public static final int CODING_SCHEME_AMR = 5;
	
	public static final int CODING_SCHEME_MIN = CODING_SCHEME_ASCII;
	public static final int CODING_SCHEME_MAX = CODING_SCHEME_AMR;
	public static final int CODING_SCHEME_DEFAULT = CODING_SCHEME_UTF_8;

	
	// private member variables
	private long id = 0; // ID for local database
    private long messageId = 0; // ID from server
    private long parentMessageId = 0;
    private int messageFromType = IcsConstants.ID_TYPE_CORE;
    private String messageFrom = "";
    private int messageToType = IcsConstants.DRIVER_ID_TYPE_UNKNOWN;
    private String messageTo = "";
	private boolean isResponseRequired = false;
    private int Priority = 0;
    private int MessageContentId = 0;
    private String language = "eng";
    private int MessageCodingScheme = CODING_SCHEME_DEFAULT;
    private String subject = "";
    private String messageBody = "";
    private long timestamp = 0;

    // Constructors
    public TextMessage()
    {
    }
    
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
    
    // Public Accessors
    
    /** Get the timestamp for this message.  The timestamp is represented as number of seconds since midnight Janurary 1, 1970.
     * 
     * @return This messages timestamp which should correlate with when the message was created.
     */
    public long getTimestamp() {
		return timestamp;
	}

    /** Set the timestamp for this message.  The timestamp is represented as number of seconds since midnight Janurary 1, 1970.
     * 
     * @param timestamp The timestamp for this message which should correlate to the message creation time.
     */
    public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

    /** Get the "message to" type for the JSON domain.  The proper types are:
     * 
     * <pre>
     * IcsConstant.ID_TYPE_VEHICLE
     * IcsConstant.ID_TYPE_CORE
     * IcsConstant.DRIVER_ID_TYPE_UNKNOWN
     * IcsConstant.DRIVER_ID_TYPE_DTCO
     * IcsConstant.DRIVER_ID_TYPE_IBUTTON
     * IcsConstant.DRIVER_ID_TYPE_KEYPAD
     * </pre> 
     * 
     * @return The message to type for the current TextMessage object
     */
    public int getMessageToType() {
		return messageToType;
	}

    /** Set the "message to" type for the JSON domain.  The proper types are:
     * 
     * <pre>
     * IcsConstant.ID_TYPE_VEHICLE
     * IcsConstant.ID_TYPE_CORE
     * IcsConstant.DRIVER_ID_TYPE_UNKNOWN
     * IcsConstant.DRIVER_ID_TYPE_DTCO
     * IcsConstant.DRIVER_ID_TYPE_IBUTTON
     * IcsConstant.DRIVER_ID_TYPE_KEYPAD
     * </pre> 
     * 
     * @return
     */
	public void setMessageToType(int messageToType) {
		this.messageToType = messageToType;
	}

    /** Get the id of the TextMessageObject 
     * 
     *  Identifier of this messge (must be unique per OBU.  If MS Bit is set then originated by choreo.  
     *  If 2nd MS Bit set then originated from ICS.  If the message originated from Choreo, the 
     *  most significant bit will be set.
     * 
     * @return the message id
     */
    public long getMessageId() {
		return messageId;
	}
    
    /** Set the Message Id of the text message.
     * 
     *  Identifier of this messge (must be unique per OBU.  If MS Bit is set then originated by choreo.  
     *  If 2nd MS Bit set then originated from ICS.  If the message originated from Choreo, the 
     *  most significant bit will be set.  The responsiblity for setting the message id for outbound messages will
     *  be left to the IcsDirector.  When the IcsDirector receives a message from the HMI it will generate a unique message id
     *  and call this method prior to transforming the text messae to a CMessage object.
     *
     * @param messageId The for the text message object
     */
	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}
	
	/** Get the Identifier of parent message.  If there is no parent, set to 0 
	 * 
	 * @return The parent message's id
	 */
	public long getParentMessageId() {
		return parentMessageId;
	}

	/** Set the Identifier of parent message.  If there is no parent, set to 0 
	 * 
	 * @param parentMessageId the parent's id.
	 */
	public void setParentMessageId(long parentMessageId) {
		this.parentMessageId = parentMessageId;
	}
	
	/** What type of person composed the message?
	 * 
	 * <pre>
	 * IcsConstants.DRIVER_ID_TYPE_DTCO     = 0x00
	 * IcsConstants.DRIVER_ID_TYPE_UNKNOWN  = 0x20;
	 * IcsConstants.DRIVER_ID_TYPE_IBUTTON  = 0s60;
	 * IcsConstants.DRIVER_ID_TYPE_KEYPAD   = 0x40;
	 * IcsConstants.ID_TYPE_NONE            = 0xB0;
	 * IcsConstants.ID_TYPE_CORE            = 0xC0; 
	 * </pre>
	 * 
	 * @return the user type that composed the message.
	 */
 	public int getMessageFromType() {
		return messageFromType;
	}
	public void setMessageFromType(int messageFromType) {
		this.messageFromType = messageFromType;
	}
	
	/** The data associated with the sender's identification.
	 * 
	 * core user: short string (1 byte string size + string size bytes of id data)
	 *
	 * vehicle/driver: Same as AqDriverId encoding in DriverId_t.  The vehicle will be identified by the OBU id in the CFMS message header
	 * 
	 * @return The data blob which identifies the sender.  This must be decoded per the sender's type. 
	 */
	public String getMessageFrom() {
		return messageFrom;
	}
	
	/** The data associated with the sender's identification.
	 * 
	 * @param messageFrom The data blob used to identify the sender based upon the sender's type.
	 */
 	public void setMessageFrom( String messageFrom) {
		this.messageFrom = messageFrom;
	}
	
	/** Get the raw data the coorelates to the message recipient identifier.
	 * 
	 * core user: short string (1 byte string size + string size bytes of id data)
	 * 
	 * vehicle/driver: Same as AqDriverId encoding in DriverId_t.  The vehicle will be identified by the OBU id in the CFMS message header
	 *
	 * @return
	 */
	public String getMessageTo() {	// 
		return messageTo;	// 
	}	// 
	
	/** Set the raw data the coorelates to the message recipient identifier.
	 * 
	 * @param messageTo
	 */
 	public void setMessageTo( String messageTo) {
		this.messageTo = messageTo;
	}
	
	/** Get the flag which indicates that this message must be responded to.
	 * 
	 * @return <code>true</code> indicates that the message must be responded to.  The HMI will nag the driver until a response composed.
	 */
	public boolean isResponseRequired() {
		return isResponseRequired;
	}
	
	/** Set the flag which indicates that this message must be responded to.
	 * 
	 * @param isResponseRequired 
	 */
	public void setResponseRequired(boolean isResponseRequired) {
		this.isResponseRequired = isResponseRequired;
	}
	
	/** Get the message priority
	 *
	 * <pre>
	 * For Current requirements only two prority levels are defined.  Normal (4) and high (6). 
	 *
	 * 0: lowest
	 * 4: normal
	 * 6: high priority (as used in R8.1 specifications).
	 * 7:highest	 
	 * </pre>
	 *  
	 * @return The message priority
	 */
	public int getPriority() {
		return Priority;
	}
	/** Set the message priority
	 * 
	 * @param priority The priority
	 */
	public void setPriority(int priority) {
		Priority = priority;
	}
	
	public String getPriorityAsString()
	{
		return ( this.getPriority() < 5 ) ? "normal" : "high";
	}
	
	/** Set the current messages priority based upon the input string provided.  If the given string
	 *  equals "high", then the meessage priority is set to 6 (high), otherwise it will be set to 4 (normal).
	 * 
	 * @param pri The priority string used to determine which numerical priority to set this message to.
	 */
	public void setPriorityFromString( String pri )
	{
		if( "high".equals(pri))
		{
			this.setPriority( 6 );
		}
		else
		{
			this.setPriority( 4 );
		}
	}
	/** Get the message content id as described below.
	 * 
	 * <pre>
	 * 0: Free form (message will have subject and body)
	 * 
	 * The following "pre-defined" messages have no subject/body
	 * 1: Standard message 1
	 * 2: Standard message 2
	 * 3: Standard message 3
	 * 4: Standard message 4
	 * 5: Standard message 5
	 * 6-255: reserved
	 * </pre>
	 * 
	 * @return The message content id
	 */
	public int getMessageContentId() {
		return MessageContentId;
	}
	
	
	/** Set the message content id.
	 * 
	 * @param messageContentId the content id as described in getContentId()
	 */
	public void setMessageContentId(int messageContentId) {
		MessageContentId = messageContentId;
	}
	
	/** Get the language code for this message
	 * 
	 * 3 alpha chars as defined by ISO 639-2.  http://www.loc.gov/standards/iso639-2/php/code_list.php.  
	 * NOTE:  Supported languages for this program include "eng", "deu", "nld", "pol", "hun", "nor", 
	 * "dan", "fra", and "ita".  The proof of concept will only include "eng", "deu".  If Charlie gets his way the PoC will include "Ita" and "nld" too. 
	 * 
	 * @return The language code for this message.
	 */
	public String getLanguage() {
		return language;
	}
	
	/** Set the language code for this message
	 * 
	 * @param language The ISO 639-2 language code.
	 */
	public void setLanguage(String language) {
		this.language = language;
	}
	
	/** Get the machine coding scheme used to encode the subject and message body of the text message.
	 * 
	 * <pre>
	 * The specified message coding scheme will be applied to both the Subject and message body.
	 * 
	 * 0: ASCII
	 * 1: ISO-8859-1 (Latin 1)
	 * 2: UTF-8
	 * 3: UTF-16
	 * 4: UTF-32
	 * 5: AMR (future maybe -- are there patent issues for producing files in .amr format?)
	 * 6-255: Reserved
	 * </pre>
	 * 
	 * 
	 * @return The code corresponding to the coding scheme.
	 */
	public int getMessageCodingScheme() {
		return MessageCodingScheme;
	}
	
	/** Set the machine coding scheme used to encode the subject and message body of the text message.
	 * 
	 * @param messageCodingScheme The coding scheme as specified in getMessageCodingScheme()
	 */
	public void setMessageCodingScheme(int messageCodingScheme) {
		MessageCodingScheme = messageCodingScheme;
	}
	
	/** Get the subject of the text message.
	 * 
	 * @return The message subject.
	 */
	public String getSubject() {
		return subject;
	}
	
	
	/** Set the subject of the text message.
	 * 
	 * @param subject The subject of this text message.
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	/** Get the message body of this text message.
	 * 
	 * @return The text which makes up the message body.
	 */
	public String getMessageBody() {
		return messageBody;
	}

	/** Set the message body of this text message.
	 * 
	 * @param mesasgeBody The text which makes up the message body.
	 */
	public void setMessageBody(String mesasgeBody) {
		this.messageBody = mesasgeBody;
	}
	
	
	/** Convert this text message object into a JSON string */
	public String toString()
	{
		String retval = null;
		try
		{
			JSONObject msgJson = new JSONObject();
			msgJson.put("id", this.getId()); // ID for local database
			msgJson.put( IcsConstants.KEY_MSG_ID, this.getMessageId() ); 
			msgJson.put( IcsConstants.KEY_MSG_PARENT_ID, this.getParentMessageId()); 
			msgJson.put( IcsConstants.KEY_MSG_FROM_TYPE, this.getMessageFromType() );
			msgJson.put( IcsConstants.KEY_MSG_FROM, this.messageFrom );
			msgJson.put( IcsConstants.KEY_MSG_TO_TYPE,  this.messageToType );
			msgJson.put( IcsConstants.KEY_MSG_TO,  this.messageTo );
			msgJson.put( IcsConstants.KEY_MSG_SUBJECT, this.getSubject() );
			msgJson.put( IcsConstants.KEY_MSG_DETAIL, this.getMessageBody() );
			msgJson.put( IcsConstants.KEY_MSG_TIMESTAMP, this.getTimestamp() );
			//msgJson.put( IcsConstants.KEY_MSG_READ, false );
			msgJson.put(IcsConstants.KEY_MSG_READ, 0);
			//msgJson.put( IcsConstants.KEY_MSG_PRIORITY, this.getPriorityAsString() );
			msgJson.put(IcsConstants.KEY_PRIORITY, this.getPriority());
			msgJson.put( IcsConstants.KEY_MSG_RESPONSE_REQUIRED, this.isResponseRequired() );
			msgJson.put( IcsConstants.KEY_MSG_LANGUAGE, this.getLanguage() );
			retval = msgJson.toString();
		}
		catch( Exception e )
		{
			
		}
		return retval;
	}

	/** Populate the contents of this text messae object with the data specified in the given JSON string.
	 * 
	 * @param jsonString The json string that is to be used to populate this object.
	 * @return <code>true</code> if the object was successfully populated.
	 */
    public boolean fromJsonString( String jsonString )
    {
    	boolean retval = false;
    	try
    	{
    		JSONObject  json =  new JSONObject( jsonString );

    		// Default values assume the message is travelling from the ICS to Core.
    		this.setTimestamp( JsonHelper.getLong(json, IcsConstants.KEY_MSG_TIMESTAMP, AqUtils.getRtcTimeInMs() ) );
    		this.setMessageId( JsonHelper.getLong( json, IcsConstants.KEY_MSG_ID, AqUtils.getGuid() ) );
    		this.setParentMessageId( JsonHelper.getLong( json, IcsConstants.KEY_MSG_PARENT_ID, 0 ) );
    		
    		this.setMessageFromType( JsonHelper.getInt( json, IcsConstants.KEY_MSG_FROM_TYPE, IcsConstants.DRIVER_ID_TYPE_UNKNOWN ) ); 
    		this.setMessageFrom( JsonHelper.getString( json, IcsConstants.KEY_MSG_FROM, "" ) );    				

			this.setMessageToType( JsonHelper.getInt( json, IcsConstants.KEY_MSG_TO_TYPE, IcsConstants.ID_TYPE_CORE ));
			if( IcsConstants.ID_TYPE_CORE != this.messageToType )
			{
				AqLog.getInstance().warn("Fixing up message to type.  Was: " + this.messageToType );
				this.messageToType = IcsConstants.ID_TYPE_CORE;
			}
			this.setMessageTo( JsonHelper.getString(json, IcsConstants.KEY_MSG_TO, "default_user" ) );
			
			this.setSubject( JsonHelper.getString( json, IcsConstants.KEY_MSG_SUBJECT, "[No Subject]" ) );
			this.setMessageBody( JsonHelper.getString( json, IcsConstants.KEY_MSG_DETAIL, "[No Message Detail]" ) );

			this.setPriorityFromString( JsonHelper.getString(json, IcsConstants.KEY_PRIORITY, "normal" ) );
			this.setResponseRequired( JsonHelper.getBoolean( json, IcsConstants.KEY_MSG_RESPONSE_REQUIRED, false ) );

			this.setLanguage( JsonHelper.getString(json, IcsConstants.KEY_MSG_LANGUAGE, "eng" ) );

			retval = true;
    	}
    	catch( Exception e )
    	{
    		AqLog.getInstance().debug("Error populating Text message from JSON object", e );
    	}
    	return retval;
    }
}