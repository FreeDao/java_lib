package com.airbiquity.android.fleet.icsobjs;

/**  This object is used to pass an ObuLogon event from the IcsDirector to the HMI.  The
 *   director will also fill in the EULA details for the driver associated with this shift before
 *   forwarding the logn to the HMI.  
 * 
 * @author DQuimby
 *
 */
public class ObuLogonEvent extends ObuShiftEvent {
	private boolean isEulaAccepted = false;

	/** Indicates if the driver associated with this logon has previously accepted the EULA.
	 * 
	 * @return indication of drivers previous acceptance of the EULA.  <code>true</code> if already accepted.
	 */
	public boolean isEulaAccepted() {
		return isEulaAccepted;
	}

	/** Set this to true if the driver associated with this logon has previously accepted the EULA.
	 * 
	 * @param isEulaAccepted The current driver's acceptance/non-acceptance of the EULA.  Set to <code>true</code> if this
	 *                       driver has already accepted the EULA.
	 */
	public void setEulaAccepted(boolean isEulaAccepted) {
		this.isEulaAccepted = isEulaAccepted;
	}
}
