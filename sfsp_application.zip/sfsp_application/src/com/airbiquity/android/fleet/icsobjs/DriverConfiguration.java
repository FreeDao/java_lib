package com.airbiquity.android.fleet.icsobjs;

/** This class is used to fetch/store driver specific configuration from/to non-volotile storage.  This
 *  class support the parameters specified in v0.9 of the In-Cab Screen requirements.  
 *   
 * 
 * @author DQuimby
 *
 */
public class DriverConfiguration extends IcsHmiExchangeObject {
	boolean isAudioOn = false;
	boolean isHighPriorityInMotionMessageDisplay = false;
	boolean isHighPriorityAlertInMotionDisplay = false;
	
	/** Returns the driver's preference for audio alerts and notifications.
	 * 
	 * @return <code>true</code> indicates audio alerts and notifications are on.  <code>false</code> indicates that audio alerts and notifications are off.
	 */
	public boolean isAudioOn() {
		return isAudioOn;
	}
	
	/** Set the value for the driver's audio alert and notification.
	 * 
	 * @param isAudioOn <code>true</code> to turn on this feature, <code>false</code> to disable.
	 */
	public void setAudioOn(boolean isAudioOn) {
		this.isAudioOn = isAudioOn;
	}
	/** Get the driver's preference for seeing high priority Message notifications when the vehicle is moving.
	 * 
	 * @return <code>true</code> indicates the driver wants to see high priority message notifications while the vehicle is moving.  <code>false</code> don't show them!.
	 */
	public boolean isHighPriorityInMotionMessageDisplay() {
		return isHighPriorityInMotionMessageDisplay;
	}
	/** Set the driver's preference for seeing high priority Message notifications when the vehicle is moving.
	 * 
	 * @param isHighPriorityInMotionMessageDisplay <code>true</code> to turn on this feature, <code>false</code> to disable. 
	 */
	public void setHighPriorityInMotionMessageDisplay(
			boolean isHighPriorityInMotionMessageDisplay) {
		this.isHighPriorityInMotionMessageDisplay = isHighPriorityInMotionMessageDisplay;
	}
	/** Get the driver's preference for seeing high priority alert notifications while the vehicle is moving. 
	 * 
	 * @return <code>true</code> indicates that the driver prefers to see the high priority alert notifications while the vehicle is moving.  
	 *         <code>false</code> don't show the high priority alert notifications while the vehicle is moving..
	 */
	public boolean isHighPriorityAlertInMotionDisplay() {
		return isHighPriorityAlertInMotionDisplay;
	}
	/** Set the driver's preference for seeing high priority alert notifications while the vehicle is moving. 
	 * 
	 * @param isHighPriorityAlertInMotionDisplay <code>true</code> to turn on this feature, <code>false</code> to disable.
	 */
	public void setHighPriorityAlertInMotionDisplay(
			boolean isHighPriorityAlertInMotionDisplay) {
		this.isHighPriorityAlertInMotionDisplay = isHighPriorityAlertInMotionDisplay;
	}
}
