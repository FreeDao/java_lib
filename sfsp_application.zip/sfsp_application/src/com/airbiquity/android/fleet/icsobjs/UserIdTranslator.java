package com.airbiquity.android.fleet.icsobjs;
	
import com.airbiquity.aqlog.AqLog;
import com.airbiquity.cfms.AqDriverId;
import com.airbiquity.util.AqUtils;

public class UserIdTranslator {
	
	int jsonType = IcsConstants.DRIVER_ID_TYPE_UNKNOWN;
	String jsonId = "";
	int cfmsMsgToFromType = 0;
	byte[] rawBytes = null;

	// This constructor to populate the translator from a binary message.
	public UserIdTranslator( int cfmsMsgToFromType, byte[] raw )
	{
		this.cfmsMsgToFromType = cfmsMsgToFromType;
		rawBytes = raw;
		switch( cfmsMsgToFromType )
		{
		case 0:
			jsonType = IcsConstants.ID_TYPE_CORE;
			jsonId = AqUtils.shortStringFromRawBytes( raw );
			break;
			
		case 1:
		case 3:
			// The destination is a driver or (driver and vehicle)
			AqDriverId did = null;
			
			try 
			{
				did = AqDriverId.decodeRawBytes(raw);
			} 
			catch (Exception e) 
			{
				AqLog.getInstance().debug("Error decoding raw driver id bytes", e );
			}
			
			if( null != did )
			{
				this.jsonType = did.getDriverIdSrc();
				this.jsonId = did.getDriverId();
			}
			else
			{
				this.jsonType = IcsConstants.DRIVER_ID_TYPE_UNKNOWN;
				this.jsonId = "";
			}
			break;
		
		case 2:
			this.jsonType = IcsConstants.ID_TYPE_VEHICLE;
			this.jsonId = "";
			break;
		}
		
	}
	
	public UserIdTranslator( AqDriverId did )
	{
		this.cfmsMsgToFromType = 1;
		if( null == did ) did = new AqDriverId();
		this.jsonType = did.getDriverIdSrc();
		this.jsonId = did.getDriverId();
	}
	
	// this translator to populate from a json message.
	public UserIdTranslator( int jsonType, String jsonId )
	{
		this.jsonType = jsonType;
		this.jsonId = jsonId;
		
		if( IcsConstants.ID_TYPE_VEHICLE == jsonType )
		{
			rawBytes = AqUtils.stringToShortStringRawBytes( "" );
			cfmsMsgToFromType = 2;				
		}
		else if( IcsConstants.ID_TYPE_CORE == jsonType )
		{
			rawBytes = AqUtils.stringToShortStringRawBytes( jsonId );
			cfmsMsgToFromType = 0;
		}
		else
		{
			int t = ( jsonType & AqDriverId.ID_TYPE_MASK );
			AqDriverId did = new AqDriverId();
			did.setDriverIdSrc( (byte) t );
			did.setDriverId( jsonId );
			rawBytes = did.encodeRawBytes();
			cfmsMsgToFromType = 1;
		}
	}
	
	public byte[] getRawBytes()
	{
		return rawBytes; 
	}
	
	public int getCfmsMsgToFromType()
	{
		return this.cfmsMsgToFromType;
	}
	
	public int getJsonToFromType()
	{
		return this.jsonType;
	}
	
	public String getJsonId()
	{
		return this.jsonId;
	}
}
