package com.airbiquity.android.fleet.icsobjs;


/** This object is a place holder for any common code that needs to be available to the HMI objects which exist in the JSON domain.
 *  The original intent was to use this base class and a generic JSON serializer/deserializer.  However, consideration was given
 *  to keep the depth of the JSON serialization simple (no complex multiple layers of JSON types in the data exchanged between
 *  the HMI and director).  Thus, this base class currently doesn't define any properties or methods.
 * 
 * @author DQuimby
 *
 */
public class IcsHmiExchangeObject {

}

