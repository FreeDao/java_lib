package com.airbiquity.android.fleet.icsobjs;

import com.airbiquity.android.choreofleetmessaging.CMessage;
import com.airbiquity.util.ByteEncoder;

/** This object is to notify the sender of a text message when the stauts of 
 *  the said message has changed.  Currently this object only tracks if the 
 *  text message has been received by the receiving device and if the message
 *  has been read by the intended recipient.
 *  
 *  This Object is intended to be passed between the ICS android layer
 *  and the HMI running within the WebKit.
 *  
 * @author DQuimby
 *
 */

public class TextMessageStatusUpdate extends IcsHmiExchangeObject {
	private boolean isRead = false;
	private boolean isRxByIcs = true;
	private long messageId = 0;
	
	public TextMessageStatusUpdate()
	{
		
	}
	
	// TODO FIXME
	public TextMessageStatusUpdate( CMessage cm )
	{
		
	}

	public TextMessageStatusUpdate( String json )
	{
		
	}
	
	/** Query the "message has been read" indicator.
	 * 
	 * @return <code>true</code> == message has been read.
	 */
	public boolean isRead() {
		return isRead;
	}

	/** Set the "message has been read" indicator.
	 * 
	 * @param isRead Set this parameter to true if the message has been read.  False (the object's default) otherwise.
	 */
	public void setRead(boolean isRead) {
		this.isRead = isRead;
	}

	/** Query the "message has been received by the In-Cab Screen" indicator
	 * 
	 * @return <code>true</code> == the message has been received by the ICS.  false otherwise.
	 * 
	 */
	public boolean isRxByIcs() {
		return isRxByIcs;
	}

	
	/** Set the "message has been read" indicator.
	 * 
	 * @param isRead Set this parameter to true if the message has been received
	 */
	public void setRxByIcs(boolean isRxByIcs) {
		this.isRxByIcs = isRxByIcs;
	}

	/** Get the id of the message which this status report refers to.
	 * 
	 * @return The message id of the message that the status is associated with.
	 */
	public long getMessageId() {
		return messageId;
	}

	/** Set the id of the message that this status report refers to.
	 * 
	 * @param messageId
	 */
	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}

	// TODO FIXME
	public CMessage toCMessage()
	{
		CMessage cm = null;
		ByteEncoder bd = new ByteEncoder();
//		
		bd.writeLong( 8, messageId );
//		
		int bits = 0;
//		
		if( isRead ) bits |= 0x02;
		if( isRxByIcs ) bits |= 0x01;
		bd.writeInt( 1, bits );
//		
		//FIXME message id isn't 0xff
		cm = new CMessage( CMessage.buildMessagePacket( bd.getContent(), 0xff, false ));
//		
		return cm;
	}
}
