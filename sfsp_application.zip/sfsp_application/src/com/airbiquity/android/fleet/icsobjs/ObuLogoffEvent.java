package com.airbiquity.android.fleet.icsobjs;

/** This event is used to pass an OBU logoff event from the IcsDirector to the HMI.
 * 
 * @author DQuimby
 *
 */
public class ObuLogoffEvent extends ObuShiftEvent {

}
