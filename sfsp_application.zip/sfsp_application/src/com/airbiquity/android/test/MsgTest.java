package com.airbiquity.android.test;


import com.airbiquity.android.choreofleetmessaging.PatternExtractor;
import com.airbiquity.util.AqUtils;
import com.airbiquity.util.CRC32;

import android.app.Activity;
//import android.content.Intent;
//import android.database.Cursor;
//import android.net.Uri;
//import android.os.Bundle;
//import android.provider.ContactsContract;
//import android.util.Log;
//import android.view.View;
//import android.widget.Button;
//import android.widget.CheckBox;
//import android.widget.CompoundButton;
//import android.widget.CompoundButton.OnCheckedChangeListener;
//import android.widget.ListView;
//import android.widget.SimpleCursorAdapter;



public class MsgTest extends Activity {


	public static void stuff()
	{
 		PatternExtractor pe = new PatternExtractor();
		pe.initialize("");
		
		byte[] syncPattern = {'s','Y','n','C'};
		byte[] pktHdr1 = {0,0,0,0,0,0,0,0,0,0};
		byte[] pktData1 = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		byte[] pktHdr2 = {0,0,0,0,0,0,0,0,0,0};
		byte[] pktData2 = {0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9};
		byte[] pktData3 = {100, 101, 102, 103, 104, 105, 106, 107, 108, 109};
		byte[] pkt1, pkt2, pkt3;
		byte[] len; 
		byte[] crc; 
		byte[] giantPkt; 
				
		len = AqUtils.unsignedIntToByteArray(pktData1.length);
		System.arraycopy(len, 0, pktHdr1, 0, 2);
		
		len = AqUtils.unsignedIntToByteArray(pktData2.length);
		System.arraycopy(len, 0, pktHdr2, 0, 2);
		
		CRC32 c = new CRC32();
		
		c.reset();
		c.update(pktData1);
		//System.out.println("pkt1 CRC: " + c.getValue());
		crc = AqUtils.unsignedLongToByteArray(c.getValue());
		//printByteArray(crc);
		System.arraycopy(crc, 0, pktHdr1, 2, 8);
		
		c.reset();
		c.update(pktData2);
		//System.out.println("pkt2 CRC: " + c.getValue());
		crc = AqUtils.unsignedLongToByteArray(c.getValue());
		//printByteArray(crc);
		System.arraycopy(crc, 0, pktHdr2, 2, 8);
		
		//System.out.println();
		//printByteArray(pktHdr1);
		//printByteArray(pktHdr2);
		//System.out.println();
		
		//System.out.println();
		pkt1 = AqUtils.concatByteArrays(pktHdr1, pktData1);
		//printByteArray(pkt1);
		pkt2 = AqUtils.concatByteArrays(pktHdr2, pktData2);
		//printByteArray(pkt2);
		//System.out.println();
		pkt3 = pe.prepareMessagePacket(pktData3);
		//printByteArray(pkt3);
		//System.out.println();
		
		giantPkt = AqUtils.concatByteArrays(syncPattern, pkt2);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		giantPkt = AqUtils.concatByteArrays(giantPkt, pkt1);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		
		System.out.println();
		int pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt2);
		//pr = pe.addChunk(pkt1); // Was being picked up twice!
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktHdr2);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktData2);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktHdr1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktData2);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(null);
		//pr = pe.addChunk(syncPattern);
		pr = pe.addChunk(giantPkt);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt3);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt3);
		//System.out.println("addChunk Result: " + pr);
		
		System.out.println();
		System.out.println("Message count: " + pe.validMessagePacketCount()); // 7.
		System.out.println("Error count: " + pe.errorMessagePacketCount()); // 3.
		System.out.println();
		
		int pc = pe.validMessagePacketCount();
		for (int i = 1;i <= pc;i++) {
			pkt1 = pe.pullMessagePacket();
			System.out.print("Message Packet " + i + ": ");
			System.out.println("pkt1: " + AqUtils.getHexData(pkt1,0,pkt1.length) );
		}
	}
}

