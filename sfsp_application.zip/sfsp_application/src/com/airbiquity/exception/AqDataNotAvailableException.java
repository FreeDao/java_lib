/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2009 by Airbiquity.  All rights reserved.
 *
 * ***************************************************************************
 */

package com.airbiquity.exception;
import java.lang.Exception;

public class AqDataNotAvailableException extends AqErrorException
{
    public static final int EXCEP_NONE = 0;
    public static final int EXCEP_DATA_NOT_AVAILABLE = 1;
    public static final int EXCEP_ILLEGAL_ARGUMENT = 2;
    public static final int EXCEP_CONSTRAINT = 3;
    public static final int EXCEP_ENCODER = 4;
    public static final int EXCEP_OVERFLOW = 5;
    public static final int EXCEP_IO = 6;
    
    public AqDataNotAvailableException()
    {

    }
    
    public AqDataNotAvailableException( String s )
    {
        super( s );
    }
}
