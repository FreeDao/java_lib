/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2009 by Airbiquity.  All rights reserved.
 *
 * ***************************************************************************
 */

package com.airbiquity.exception;
import java.lang.Exception;

public class AqErrorException extends Exception
{
    public AqErrorException()
    {

    }
    
    public AqErrorException( String s )
    {
        super( s );
    }
    
}
