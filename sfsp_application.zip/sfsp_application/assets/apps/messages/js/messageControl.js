//message frame
var Message = can.Control({
    init: function(){
        var _this = this;
        _this.element.html(can.view('apps/messages/views/msgMain.ejs', {}));
        homeInstance.clearOtherActive();
        util.btnActive("message_btn");
        if (_this.options.boolGetMsg == true) {
            _this.getMsg();
        }
        else 
            if (_this.options.boolGetMsg == false) {
                _this.show(_this.options.msgData);
            }
    },
    show: function(msg){
        $("#temp_main").remove();
        $(".main").append($("<div>").attr("id", "temp_main"));
        new MessageList('#temp_main', {
            msgObj: msg
        });
        homeInstance.updateNotify();
    },
    getMsg: function(){
        var _this = this;
        MessageData.test();
        messageList = MessageData.getMessage();
        util.showLog("-----HMI----messageList:" + JSON.stringify(messageList));
        _this.show(messageList);
    },
    '#showAddressBook click': function(){
        if (!$(".top_pencil").hasClass("top_pencil_active")) {
            util.btnPressed("top_pencil", function(){
                $(".address_book_container").show();
                $("#temp_address_book_container").remove();
                $(".address_book_container").append($("<div>").attr("id", "temp_address_book_container"));
                new AddressBook('#temp_address_book_container', {});
            });
        }
        else 
            if ($(".top_pencil").hasClass("top_pencil_active")) {
                util.btnPressed("top_pencil", function(){
                    $("#temp_address_book_container").remove();
                    $(".address_book_container").hide();
                    $(".top_pencil").removeClass("top_pencil_active");
                });
            }
    }
});

// message list
var MessageList = can.Control({
    init: function(){
        this.show(this.options.msgObj);
        $(".message_container_content_item_right").addClass("row_selected");
        $(".message_filter_date").addClass("message_filter_date_active");
    },
    'show': function(msg){
        this.element.html(can.view('apps/messages/views/msgList.ejs', {
            msgObj: msg
        }));
    },
    
    '[messageIndex] click': function(el, ev){
        var msgIndex = el.attr('messageIndex');
        if (el.parent().hasClass("message_container_content_item_noread")) {
            MessageData.updateMessage(messageList[msgIndex]);
            homeInstance.updateNotify();
        }
        $("#temp_right_side_content").remove();
        $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
        new MessageDetail('#temp_right_side_content', {
            msgIndex: msgIndex,
            msgObj: messageList
        });
    },
    
    '.message_filter_noread click': function(){
        this.clearOtherActive();
        util.btnPressed("message_filter_noread", function(){
            $(".message_container_content_item_dotdiv").addClass("row_selected");
        });
        // TODO this.show(obj);var array = this.options.msgObj;
    },
    '.message_filter_from click': function(){
        this.clearOtherActive();
        util.btnPressed("message_filter_from", function(){
            $(".message_container_content_item_from").addClass("row_selected");
        });
    },
    '.message_filter_to click': function(){
        this.clearOtherActive();
        util.btnPressed("message_filter_to", function(){
            $(".message_container_content_item_to").addClass("row_selected");
        });
    },
    '.message_filter_priority click': function(){
        this.clearOtherActive();
        util.btnPressed("message_filter_priority", function(){
            $(".message_container_content_item_priority").addClass("row_selected");
        });
    },
    '.message_filter_subject click': function(){
        this.clearOtherActive();
        util.btnPressed("message_filter_subject", function(){
            $(".message_container_content_item_subject").addClass("row_selected");
        });
    },
    '.message_filter_date click': function(){
        this.clearOtherActive();
        util.btnPressed("message_filter_date", function(){
            $(".message_container_content_item_right").addClass("row_selected");
            
        });
    },
    clearOtherActive: function(){
        var btnArray = new Array("message_filter_noread", "message_filter_from", "message_filter_to", "message_filter_priority", "message_filter_subject", "message_filter_date");
        util.clearOtherBtnActive(btnArray);
        $(".row_selected").removeClass("row_selected");
    }
});
// message detail
var MessageDetail = can.Control({
    show: function(index, obj){
        this.element.html(can.view('apps/messages/views/msgDetail.ejs', {
            msgIndex: index,
            msgObj: obj
        }));
    },
    init: function(){
        messageDetailHandle = this;
        this.show(this.options.msgIndex, this.options.msgObj);
    },
    '#showNextMessage click': function(){
        var _this = this;
        util.btnPressed("message_next", function(){
            if (_this.options.msgIndex < messageList.length - 1) {
                _this.options.msgIndex++;
                _this.show(_this.options.msgIndex, messageList);
                MessageData.updateMessage(messageList[_this.options.msgIndex]);
            }
            // change icon
            homeInstance.updateNotify();
        });
    },
    '#showPreviousMessage click': function(){
        var _this = this;
        util.btnPressed("message_previous", function(){
            if (_this.options.msgIndex > 0) {
                _this.options.msgIndex--;
                _this.show(_this.options.msgIndex, messageList);
                MessageData.updateMessage(messageList[_this.options.msgIndex]);
            }
            // change icon
            homeInstance.updateNotify();
        });
    },
    '#deleteMessage click': function(el, ev){
        var _this = this;
        var _msgIndex = _this.options.msgIndex;
        util.btnPressed("message_delete", function(){
            MessageData.deleteMessage(messageList[_msgIndex], _msgIndex);
            if (messageList.length > 0) {
                if (_this.options.msgIndex < messageList.length) {
                    // _this.options.msgIndex++;
                    _this.show(_this.options.msgIndex, messageList);
                }
                else 
                    if (_this.options.msgIndex == (messageList.length) &&
                    _this.options.msgIndex > 0) {
                        _this.options.msgIndex--;
                        _this.show(_this.options.msgIndex, messageList);
                    }
                MessageData.updateMessage(messageList[_this.options.msgIndex]);
                // change icon
                homeInstance.updateNotify();
            }
            else {
                new Message('#temp_right_side_content', {
                    boolGetMsg: false,
                    msgData: messageList
                });
            }
        });
    },
    '#replyMessage click': function(){
        if (!$(".message_reply").hasClass("message_reply_active")) {
            util.btnPressed("message_reply", function(){
                var currentMsg = messageDetailHandle.options.msgObj[messageDetailHandle.options.msgIndex];
                $(".reply_container").show();
                $("#temp_reply_container").remove();
                $(".reply_container").append($("<div>").attr("id", "temp_reply_container"));
                
                new ReplyWith('#temp_reply_container', {
                    currentMsg: currentMsg
                });
            });
        }
        else 
            if ($(".message_reply").hasClass("message_reply_active")) {
                util.btnPressed("message_reply", function(){
                    $("#temp_reply_container").remove();
                    $(".reply_container").hide();
                    $(".message_reply").removeClass("message_reply_active");
                });
            }
    }
});

// address book
var AddressBook = can.Control({
    init: function(){
        this.element.html(can.view('apps/messages/views/addressBook.ejs', {}));
    },
    '.address_book_item click': function(el, ev){
        $("#temp_address_book_container").remove();
        $(".address_book_container").hide();
        $(".top_pencil").removeClass("top_pencil_active");
        var sendTo = el.children().first().attr("value");
        $("#message_send_content").remove();
        $(".body_content").append($("<div>").attr("id", "message_send_content"));
        new SendMessageSub('#message_send_content', {
            sendTo: sendTo
        });
    }
});

// reply screen
var ReplyWith = can.Control({
    init: function(){
        this.element.html(can.view('apps/messages/views/replyWith.ejs', {}));
        $("#options_accepted").children().last().addClass("reply_content_radio_selected");
        this.replyValue = $("#options_accepted").children().first().attr("value");
    },
    replyValue: null,
    '.reply_content_options click': function(el, ev){
        var _this = this;
        if (el.children().last().hasClass("reply_content_radio_selected") ==
        false) {
            $(".reply_content_radio").removeClass("reply_content_radio_selected");
            el.children().last().addClass("reply_content_radio_pressed");
            setTimeout(function(){
                el.children().last().removeClass("reply_content_radio_pressed")
                el.children().last().addClass("reply_content_radio_selected");
            }, 100);
            _this.replyValue = el.children().first().attr("value");
        }
        else 
            if (el.children().last().hasClass("reply_content_radio_selected") ==
            true) {
                el.children().last().addClass("reply_content_radio_selected_pressed");
                setTimeout(function(){
                    el.children().last().removeClass("reply_content_radio_selected_pressed")
                }, 100);
                _this.replyValue = el.children().first().attr("value");
            }
    },
    '.reply_ok click': function(){
        var _this = this;
        util.btnPressed("reply_ok", function(){
            messageDetailHandle['#replyMessage click']();
            if (_this.replyValue == null) {
            }
            else 
                if (_this.replyValue == "Custom") {
                    $("#message_send_content").remove();
                    $(".body_content").append($("<div>").attr("id", "message_send_content"));
                    new CustomReply('#message_send_content', {
                        currentMsg: _this.options.currentMsg
                    });
                }
                else {
                    var userId = ConfigurationData.getConf().user_id;
                    var driver_type = ConfigurationData.getConf().driver_type;
                    var parentId = _this.options.currentMsg.id;
                    var sendTo = _this.options.currentMsg.from;
                    var to_type = _this.options.currentMsg.to_type;
                    var language = ConfigurationData.getConf().language_preference;
                    var subject = _this.options.currentMsg.subject;
                    var message = _this.replyValue;
                    var replyMsg = {
                        "from": userId,
                        "from_type": driver_type,
                        "to": sendTo,
                        "to_type": to_type,
                        "parent_id": parentId,
                        "language": language,
                        "subject": subject,
                        "detail": message
                    };
                    MessageData.sendMsg(JSON.stringify(replyMsg));
                }
        });
    }
});

// custom reply
var CustomReply = can.Control({
    init: function(){
        this.element.html(can.view('apps/messages/views/customReply.ejs', {}));
    },
    '.message_send_cancel click': function(){
        util.btnPressed("message_send_cancel", function(){
            $("#message_send_content").remove();
        });
    },
    '.message_send_send click': function(){
        var userId = ConfigurationData.getConf().user_id;
        var parentId = this.options.currentMsg.message_id;
        var to_type = this.options.currentMsg.to_type;
        var language = ConfigurationData.getConf().language_preference;
        var driver_type = ConfigurationData.getConf().driver_type;
        var sendTo = this.options.currentMsg.from;
        var subject = this.options.currentMsg.subject;
        var message = $("#msgSend_reply").val();
        var replyMsg = {
            "from": userId,
            "from_type": driver_type,
            "to": sendTo,
            "to_type": to_type,
            "parent_id": parentId,
            "language": language,
            "subject": subject,
            "detail": message
        };
        
        util.btnPressed("message_send_send", function(){
            $("#message_send_content").remove();
            MessageData.sendMsg(JSON.stringify(replyMsg));
        });
    }
});

var SendMessageSub = can.Control({
    init: function(){
        this.element.html(can.view('apps/messages/views/msgSend_subject.ejs', {}));
    },
    '.message_send_cancel click': function(){
        util.btnPressed("message_send_cancel", function(){
            $("#message_send_content").remove();
        });
    },
    '.message_send_send click': function(){
        var sendTo = this.options.sendTo;
        var msgSub = $("#msgSend_sub").val();
        util.btnPressed("message_send_send", function(){
            $("#message_send_msg_content").remove();
            $(".body_content").append($("<div>").attr("id", "message_send_msg_content"));
            new SendMessageMsg('#message_send_msg_content', {
                sendTo: sendTo,
                subject: msgSub
            });
        });
    }
});

var SendMessageMsg = can.Control({
    init: function(){
        this.element.html(can.view('apps/messages/views/msgSend_message.ejs', {}));
    },
    '.message_send_cancel click': function(){
        util.btnPressed("message_send_cancel", function(){
            $("#message_send_msg_content").remove();
        });
    },
    '.message_send_send click': function(){
        var userId = ConfigurationData.getConf().user_id;
        var driver_type = ConfigurationData.getConf().driver_type;
        var sendTo = this.options.sendTo;
        var to_type = 0;
        var language = ConfigurationData.getConf().language_preference;
        var subject = this.options.subject;
        var message = $("#msgSend_msg").val();
        var sendMsg = {
            "from": userId,
            "from_type": driver_type,
            "to": sendTo,
            "to_type": to_type,
            "parent_id": 0,
            "language": language,
            "subject": subject,
            "detail": message
        };
        util.btnPressed("message_send_send", function(){
            $("#message_send_content").remove();
            $("#message_send_msg_content").remove();
            $(".top_sending").show();
            util.process("sending_process");
            MessageData.sendMsg(JSON.stringify(sendMsg));
            setTimeout(function(){
                $(".top_sending").hide();
            }, 2000);
        });
    }
});
