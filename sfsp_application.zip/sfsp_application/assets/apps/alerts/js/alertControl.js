/**
 *
 */
var Alert = can.Control({
    init: function(){
        var _this = this;
        _this.element.html(can.view('apps/alerts/views/alertMain.ejs', {}));
        homeInstance.clearOtherActive();
        util.btnActive("alert_btn");
        if (_this.options.boolGetAlt == true) {
            _this.getAlt();
        }
        else 
            if (_this.options.boolGetAlt == false) {
                _this.show(_this.options.altData);
            }
    },
    show: function(alt){
        $("#temp_main").remove();
        $(".main").append($("<div>").attr("id", "temp_main"));
        new AlertList('#temp_main', {
            altObj: alt
        });
        homeInstance.updateNotify();
    },
    
    getAlt: function(){
        var _this = this;
        alertList = AlertData.getAlert();
        _this.show(alertList);
    }
});

var AlertList = can.Control({
    init: function(){
        this.show(this.options.altObj);
    },
    'show': function(alt){
        this.element.html(can.view('apps/alerts/views/alertList.ejs', {
            altObj: alt
        }));
    },
    '.alert_container_item click': function(el, ev){
        var _this = this;
        var altIndex = el.attr('alertIndex');
        if (alertList[altIndex].read == 0) {
            var unread_type = alertList[altIndex].alert_type;
            el.children().first().children().removeClass(alertList[altIndex].alert_type + "_unread");
            AlertData.updateAlert(alertList[altIndex]);
            homeInstance.updateNotify();
        }
    }
    
});
