var reportList;
var REPORT = [{
    "category": "Grade",
    "max": 100,
    "objective": 80,
    "score": 82,
    "unit_name": "%",
    "qualified": 1,
    "tip": "aksjdhfjhsdjkhfkshfhkasdkfhksadhf",
    "detail": [{
        "column": "Fleet",
        "average": 82,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 82
        }, {
            "date": "Jan.31",
            "score": 82
        }, {
            "date": "Feb.1",
            "score": 82
        }, {
            "date": "Feb.2",
            "score": 82
        }, {
            "date": "Today",
            "score": 82
        }]
    }, {
        "column": "Division",
        "average": 82,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 82
        }, {
            "date": "Jan.31",
            "score": 82
        }, {
            "date": "Feb.1",
            "score": 82
        }, {
            "date": "Feb.2",
            "score": 82
        }, {
            "date": "Today",
            "score": 82
        }]
    }, {
        "column": "Depot",
        "average": 82,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 82
        }, {
            "date": "Jan.31",
            "score": 82
        }, {
            "date": "Feb.1",
            "score": 82
        }, {
            "date": "Feb.2",
            "score": 82
        }, {
            "date": "Today",
            "score": 82
        }]
    }, {
        "column": "Vehicle Group",
        "average": 82,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 82
        }, {
            "date": "Jan.31",
            "score": 82
        }, {
            "date": "Feb.1",
            "score": 82
        }, {
            "date": "Feb.2",
            "score": 82
        }, {
            "date": "Today",
            "score": 82
        }]
    }]
}, {
    "category": "Idling Time",
    "max": 100,
    "objective": 5,
    "score": 15,
    "unit_name": "% time",
    "qualified": 0,
    "tip": "aksjdhfjhsdjkhfkshfhkasdkfhksadhf",
    "detail": [{
        "column": "Fleet",
        "average": 15,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 15
        }, {
            "date": "Jan.31",
            "score": 15
        }, {
            "date": "Feb.1",
            "score": 15
        }, {
            "date": "Feb.2",
            "score": 15
        }, {
            "date": "Today",
            "score": 15
        }]
    }, {
        "column": "Division",
        "average": 15,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 15
        }, {
            "date": "Jan.31",
            "score": 15
        }, {
            "date": "Feb.1",
            "score": 15
        }, {
            "date": "Feb.2",
            "score": 15
        }, {
            "date": "Today",
            "score": 15
        }]
    }, {
        "column": "Depot",
        "average": 15,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 15
        }, {
            "date": "Jan.31",
            "score": 15
        }, {
            "date": "Feb.1",
            "score": 15
        }, {
            "date": "Feb.2",
            "score": 15
        }, {
            "date": "Today",
            "score": 15
        }]
    }, {
        "column": "Vehicle Group",
        "average": 15,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 15
        }, {
            "date": "Jan.31",
            "score": 15
        }, {
            "date": "Feb.1",
            "score": 15
        }, {
            "date": "Feb.2",
            "score": 15
        }, {
            "date": "Today",
            "score": 15
        }]
    }]
}, {
    "category": "Over Rev",
    "max": 10,
    "objective": 3,
    "score": 2,
    "unit_name": "m/km",
    "qualified": 1,
    "tip": "aksjdhfjhsdjkhfkshfhkasdkfhksadhf",
    "detail": [{
        "column": "Fleet",
        "average": 2,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 2
        }, {
            "date": "Jan.31",
            "score": 2
        }, {
            "date": "Feb.1",
            "score": 2
        }, {
            "date": "Feb.2",
            "score": 2
        }, {
            "date": "Today",
            "score": 2
        }]
    }, {
        "column": "Division",
        "average": 2,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 2
        }, {
            "date": "Jan.31",
            "score": 2
        }, {
            "date": "Feb.1",
            "score": 2
        }, {
            "date": "Feb.2",
            "score": 2
        }, {
            "date": "Today",
            "score": 2
        }]
    }, {
        "column": "Depot",
        "average": 2,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 2
        }, {
            "date": "Jan.31",
            "score": 2
        }, {
            "date": "Feb.1",
            "score": 2
        }, {
            "date": "Feb.2",
            "score": 2
        }, {
            "date": "Today",
            "score": 2
        }]
    }, {
        "column": "Vehicle Group",
        "average": 2,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 2
        }, {
            "date": "Jan.31",
            "score": 2
        }, {
            "date": "Feb.1",
            "score": 2
        }, {
            "date": "Feb.2",
            "score": 2
        }, {
            "date": "Today",
            "score": 2
        }]
    }]
}, {
    "category": "Harsh Throttle",
    "max": 10,
    "objective": 4,
    "score": 4,
    "unit_name": "m/km",
    "qualified": 1,
    "tip": "aksjdhfjhsdjkhfkshfhkasdkfhksadhf",
    "detail": [{
        "column": "Fleet",
        "average": 4,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 4
        }, {
            "date": "Jan.31",
            "score": 4
        }, {
            "date": "Feb.1",
            "score": 4
        }, {
            "date": "Feb.2",
            "score": 4
        }, {
            "date": "Today",
            "score": 4
        }]
    }, {
        "column": "Division",
        "average": 4,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 4
        }, {
            "date": "Jan.31",
            "score": 4
        }, {
            "date": "Feb.1",
            "score": 4
        }, {
            "date": "Feb.2",
            "score": 4
        }, {
            "date": "Today",
            "score": 4
        }]
    }, {
        "column": "Depot",
        "average": 4,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 4
        }, {
            "date": "Jan.31",
            "score": 4
        }, {
            "date": "Feb.1",
            "score": 4
        }, {
            "date": "Feb.2",
            "score": 4
        }, {
            "date": "Today",
            "score": 4
        }]
    }, {
        "column": "Vehicle Group",
        "average": 4,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 4
        }, {
            "date": "Jan.31",
            "score": 4
        }, {
            "date": "Feb.1",
            "score": 4
        }, {
            "date": "Feb.2",
            "score": 4
        }, {
            "date": "Today",
            "score": 4
        }]
    }]
}, {
    "category": "Braking",
    "max": 20,
    "objective": 10,
    "score": 8,
    "unit_name": "m/km",
    "qualified": 1,
    "tip": "aksjdhfjhsdjkhfkshfhkasdkfhksadhf",
    "detail": [{
        "column": "Fleet",
        "average": 8,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 8
        }, {
            "date": "Jan.31",
            "score": 8
        }, {
            "date": "Feb.1",
            "score": 8
        }, {
            "date": "Feb.2",
            "score": 8
        }, {
            "date": "Today",
            "score": 8
        }]
    }, {
        "column": "Division",
        "average": 8,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 8
        }, {
            "date": "Jan.31",
            "score": 8
        }, {
            "date": "Feb.1",
            "score": 8
        }, {
            "date": "Feb.2",
            "score": 8
        }, {
            "date": "Today",
            "score": 8
        }]
    }, {
        "column": "Depot",
        "average": 8,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 8
        }, {
            "date": "Jan.31",
            "score": 8
        }, {
            "date": "Feb.1",
            "score": 8
        }, {
            "date": "Feb.2",
            "score": 8
        }, {
            "date": "Today",
            "score": 8
        }]
    }, {
        "column": "Vehicle Group",
        "average": 8,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 8
        }, {
            "date": "Jan.31",
            "score": 8
        }, {
            "date": "Feb.1",
            "score": 8
        }, {
            "date": "Feb.2",
            "score": 8
        }, {
            "date": "Today",
            "score": 8
        }]
    }]
}, {
    "category": "Cruise Control",
    "max": 100,
    "objective": 5,
    "score": 5,
    "unit_name": "% time",
    "qualified": 1,
    "tip": "aksjdhfjhsdjkhfkshfhkasdkfhksadhf",
    "detail": [{
        "column": "Fleet",
        "average": 5,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 5
        }, {
            "date": "Jan.31",
            "score": 5
        }, {
            "date": "Feb.1",
            "score": 5
        }, {
            "date": "Feb.2",
            "score": 5
        }, {
            "date": "Today",
            "score": 5
        }]
    }, {
        "column": "Division",
        "average": 5,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 5
        }, {
            "date": "Jan.31",
            "score": 5
        }, {
            "date": "Feb.1",
            "score": 5
        }, {
            "date": "Feb.2",
            "score": 5
        }, {
            "date": "Today",
            "score": 5
        }]
    }, {
        "column": "Depot",
        "average": 5,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 5
        }, {
            "date": "Jan.31",
            "score": 5
        }, {
            "date": "Feb.1",
            "score": 5
        }, {
            "date": "Feb.2",
            "score": 5
        }, {
            "date": "Today",
            "score": 5
        }]
    }, {
        "column": "Vehicle Group",
        "average": 5,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 5
        }, {
            "date": "Jan.31",
            "score": 5
        }, {
            "date": "Feb.1",
            "score": 5
        }, {
            "date": "Feb.2",
            "score": 5
        }, {
            "date": "Today",
            "score": 5
        }]
    }]
}, {
    "category": "Coasting",
    "max": 100,
    "objective": 15,
    "score": 14,
    "unit_name": "% time",
    "qualified": 1,
    "tip": "aksjdhfjhsdjkhfkshfhkasdkfhksadhf",
    "detail": [{
        "column": "Fleet",
        "average": 14,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 14
        }, {
            "date": "Jan.31",
            "score": 14
        }, {
            "date": "Feb.1",
            "score": 14
        }, {
            "date": "Feb.2",
            "score": 14
        }, {
            "date": "Today",
            "score": 14
        }]
    }, {
        "column": "Division",
        "average": 14,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 14
        }, {
            "date": "Jan.31",
            "score": 14
        }, {
            "date": "Feb.1",
            "score": 14
        }, {
            "date": "Feb.2",
            "score": 14
        }, {
            "date": "Today",
            "score": 14
        }]
    }, {
        "column": "Depot",
        "average": 14,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 14
        }, {
            "date": "Jan.31",
            "score": 14
        }, {
            "date": "Feb.1",
            "score": 14
        }, {
            "date": "Feb.2",
            "score": 14
        }, {
            "date": "Today",
            "score": 14
        }]
    }, {
        "column": "Vehicle Group",
        "average": 14,
        "last_5_scores": [{
            "date": "Jan.30",
            "score": 14
        }, {
            "date": "Jan.31",
            "score": 14
        }, {
            "date": "Feb.1",
            "score": 14
        }, {
            "date": "Feb.2",
            "score": 14
        }, {
            "date": "Today",
            "score": 14
        }]
    }]
}];

var ReportData = can.Model({
    test: function(){
        alert(1111);
    },
    getReport: function(){
        var userId = ConfigurationData.getConf().user_id;
        var reportReq = {
            "user_id": userId
        };
        var report;
        if (false) {
            report = Android.getReport(JSON.stringify(reportReq));
            if (report != "") {
                report = JSON.parse(Android.getReport(JSON.stringify(reportReq)));
            }
            else {
                report = JSON.parse("[]");
            }
        }
        else {
            report = REPORT;
        }
        util.showLog("-----HMI----msg:" + JSON.stringify(report));
        report = new can.Observe.List(report);
        return report;
    }
}, {});

