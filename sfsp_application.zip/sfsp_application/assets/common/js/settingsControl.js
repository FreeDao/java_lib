var Settings = can.Control({
    init: function(obj){
        this.element.html(can.view('common/views/settings_body.ejs', {}));
        $(".setting").show();
        $("#settings").removeClass("setting_icon");
        $("#settings").unbind();
        settingExits = false;
        
        /*
         * get and set driver settings' preferences
         */
        if (configuration.audio_sounds == 1) {
            $(".check_audios").removeClass("check_audios_hide");
        }
        else 
            if (configuration.audio_sounds == 0) {
                $(".check_audios").addClass("check_audios_hide");
            }
        
        if (configuration.display_high_priority_message == 1) {
            $(".check_messages").removeClass("check_messages_hide");
        }
        else 
            if (configuration.display_high_priority_message == 0) {
                $(".check_messages").addClass("check_messages_hide");
            }
        if (configuration.display_high_priority_alert == 1) {
            $(".check_alerts").removeClass("check_alerts_hide");
        }
        else 
            if (configuration.display_high_priority_alert == 0) {
                $(".check_alerts").addClass("check_alerts_hide");
            }
    },
    '.button_language click': function(){
        util.btnPressed("button_language", function(){
            $("#temp_custom_popup").remove();
            $(".custom_popup").append($("<div>").attr("id", "temp_custom_popup"));
            new SetLanguage('#temp_custom_popup', {
                applyLanguage: false
            })
            $(".custom_popup").show();
        });
    },
    '.button_cancel click': function(){
        util.btnPressed("button_cancel", function(){
            util.hideSetting();
        });
    },
    
    '.button_accept click': function(){
        util.btnPressed("button_accept", function(){
            if ($(".check_audios").last().hasClass("check_audios_hide")) {
                configuration.audio_sounds = 0;
            }
            else {
                configuration.audio_sounds = 1;
            }
            
            if ($(".check_messages").last().hasClass("check_messages_hide")) {
                configuration.display_high_priority_message = 0;
            }
            else {
                configuration.display_high_priority_message = 1;
            }
            
            if ($(".check_alerts").last().hasClass("check_alerts_hide")) {
                configuration.display_high_priority_alert = 0;
            }
            else {
                configuration.display_high_priority_alert = 1;
            }
            
            // TODO, language_preference?
            // alert("lng: " + (language_preference == null));
            // nikm added
            if (language_preference != null) {
                configuration.language_preference = language_preference;
            }
            
            //when click accept button,setting preferences should be applied
            util.applySetting(configuration);
            util.hideSetting();
            $("#message_send_content").remove();
            $("#message_send_msg_content").remove();
            $("#temp_body_content").remove();
            $(".body_content").append($("<div>").attr("id", "temp_body_content"));
            new Home('#temp_body_content', {
                boolGetMsg: true
            });
        });
    },
    
    '.check_audios click': function(){
        util.checkBtnPressed("check_audios", null);
        
    },
    
    '.check_messages click': function(el, ev){
        util.checkBtnPressed("check_messages", null);
    },
    
    '.check_alerts click': function(el, ev){
        util.checkBtnPressed("check_alerts", null);
    }
});

var SetLanguage = can.Control({
    init: function(){
        this.element.html(can.view('common/views/settings_language.ejs', {}));
        language_preference = configuration.language_preference;
        $("#" + language_preference).addClass("language_uncheck_selected");
    },
    '.popup_close click': function(){
        var _this = this;
        util.btnPressed("popup_close", function(){
            language_preference = $(".language_uncheck_selected").attr("id");
            if (_this.options.applyLanguage) {
                configuration.language_preference = language_preference;
                util.applySetting(configuration);
            }
            $("#temp_custom_popup").remove();
            $(".custom_popup").hide();
        });
    },
    '.language_rope click': function(el, ev){
        if (!el.children().last().hasClass("language_uncheck_selected")) {
            $(".language_uncheck").removeClass("language_uncheck_selected");
            el.children().last().addClass("language_uncheck_pressed");
            
            setTimeout(function(){
                el.children().last().removeClass("language_uncheck_pressed")
                el.children().last().addClass("language_uncheck_selected");
            }, 100);
            
        }
        else 
            if (el.children().last().hasClass("language_uncheck_selected")) {
                el.children().last().addClass("language_uncheck_selected_pressed");
                
                setTimeout(function(){
                    el.children().last().removeClass("language_uncheck_selected_pressed")
                }, 100);
            }
    }
});
