var boolBackNotifyExist = false;
var highPriorityMessageInmotion = false;
var alertInmotionExist = false;
var message_popupExist = false;//navigation conflict
var alert_popupExist = false;
//problems: not move,click view,how to deal with navigation page 
var Notify = can.Control({
	init : function() {
		$(".notify").show();
		this.element.html(can.view('common/views/notify.ejs', {
			notify_type : this.options.notify_type,
			notify_count : this.options.notify_count,
			data : this.options.data,
			item : this.options.item
		}));

		if (this.options.notify_type == "message_priority_high") {
			boolBackNotifyExist = true;
		}
	},
	'.popup_dismiss_btn click' : function() {
		var _this = this;
		util.btnPressed("popup_dismiss_btn", function() {
			$("#temp_notify").remove();
			$(".notify").hide();
			$("#temp_drive_mode").remove();
			$(".drive_mode").hide();
			if (_this.options.notify_type == "Error_PIN_CODE") {
				$(".notify").hide();
				$("#temp_notify").remove();
				$(".password_group input").val('');
				$(".password_group input").attr("val", '');
				$(".password_group input").parent().removeClass("pot_cover");
			}
			// TODO
			if (_this.options.notify_type == "message_priority_high"
					|| _this.options.notify_type == "message_priority_normal") {
				$(".notify").hide();
				$("#temp_notify").remove();
				if (testFlag) {
					Android.cancelSoundNotification();
				}
				message_popupExist = false;
		if(navigationSelected){
					//TODO show navigation
			Android.openNavigation(JSON.stringify({
	            "geo": "47.604819,-122.33801"
	        }));
		}
			}
			if (settingExits) {
				util.bindSetting();
			}
		});
//		Android.showTips("--- " + navigationSelected);
		
	},
	'.popup_view_btn click' : function() {
		var _this = this;
		util.btnPressed("popup_view_btn", function() {
			$("#temp_notify").remove();
			$(".notify").hide();
			$("#alert_temp_notify").remove();
			$(".alert_notify").hide();
			$("#message_send_content").remove();
			$("#message_send_msg_content").remove();
			if (_this.options.notify_type == "message_priority_high"
					|| _this.options.notify_type == "message_priority_normal") {
				$("#temp_body_content").remove();
				message_popupExist = false;//message popup = false
				$(".body_content").append(
						$("<div>").attr("id", "temp_body_content"));
				new Home('#temp_body_content', {
					boolGetMsg : false,
					boolGetAlt : false,
				});
				$("#temp_right_side_content").remove();
				$(".right_side_content").append(
						$("<div>").attr("id", "temp_right_side_content"));
				new Message('#temp_right_side_content', {
					boolGetMsg : false,
					msgData : _this.options.data
				});
				if (testFlag) {
					Android.cancelSoundNotification();
				}
			} else if (_this.options.notify_type == "Error_PIN_CODE") {
				$(".password_group input").val('');
				$(".password_group input").attr("val", '');
				$(".password_group input").parent().removeClass("pot_cover");
			} 
			if (settingExits) {
				util.bindSetting();
			}

		});
	},
	destroy : function(){
		messagePopup = null;
	}
});

var AlertNotify = can.Control({
	init : function() {
		$(".alert_notify").show();
		this.element.html(can.view('common/views/notify.ejs', {
			notify_type : this.options.notify_type,
			notify_count : this.options.notify_count,
			data : this.options.data,
			item : this.options.item
		}));
	},
	'.alert_popup_dismiss_btn click' : function() {
		var _this = this;
		util.btnPressed("alert_popup_dismiss_btn", function() {
			$("#alert_temp_notify").remove();
			$(".alert_notify").hide();
			alert_popupExist = false;
			// TODO wether had implict on message popup???
			$("#temp_drive_mode").remove();
			$(".drive_mode").hide();
			if (testFlag) {
				Android.cancelSoundNotification();
			}
			if (settingExits) {
				util.bindSetting();
			}
		});
		
		
		if(!messagePopup){
		if(navigationSelected){
				//TODO show navigation
				
			Android.openNavigation(JSON.stringify({
	            "geo": "47.604819,-122.33801"
	        }));
		}
		}
		
	},
	'.alert_popup_view_btn click' : function() {
		var _this = this;
		util.btnPressed("alert_popup_view_btn", function() {
			$("#alert_temp_notify").remove();
			$(".alert_notify").hide();
			alert_popupExist = false;
			$("#temp_notify").remove();
			$(".notify").hide();
			$("#message_send_content").remove();
			$("#message_send_msg_content").remove();
			$("#temp_drive_mode").remove();
			$(".drive_mode").hide();
			clearTimeout(alertNotifyTimer);
			$("#temp_body_content").remove();
			$(".body_content").append(
					$("<div>").attr("id", "temp_body_content"));
			new Home('#temp_body_content', {
				boolGetMsg : false,
				boolGetAlt : false,
				viewType : "alerts"
			});
			homeInstance.clearOtherActive();
			$("#temp_right_side_content").remove();
			$(".right_side_content").append(
					$("<div>").attr("id", "temp_right_side_content"));
			new Alert('#temp_right_side_content', {
				boolGetAlt : false,
				altData : _this.options.data
			});
			if (testFlag) {
				Android.cancelSoundNotification();
			}
			if (settingExits) {
				util.bindSetting();
			}
		});
	},
	destroy : function(){
		alertPopup = null;
	}

});


var InMotionNotify = can.Control({
	init : function() {
		$(".in_motion_notify").show();
		this.element.html(can.view('common/views/in_motion_notify.ejs', {
			notify_type : this.options.notify_type,
			notify_count : this.options.notify_count,
			data : this.options.data,
			item : this.options.item
		}));
	},
	'.popup_in_motion_dismiss_btn click' : function() {
		var _this = this;
		util.btnPressed("popup_in_motion_dismiss_btn", function() {
			$("#temp_in_motion_notify").remove();
			$(".in_motion_notify").hide();
			$("#temp_drive_mode").remove();
			$(".drive_mode").hide();
			highPriorityMessageInmotion = false;
			if (boolBackNotifyExist) {
				$("#temp_notify").remove();
				$(".notify").hide();
			}
			if (testFlag) {
				Android.cancelSoundNotification();
			}
		});
		if(navigationSelected){
			//TODO show navigation
			Android.openNavigation(JSON.stringify({
	            "geo": "47.604819,-122.33801"
	        }));
		}
	},

	'.popup_in_motion_view_btn click' : function() {
		var _this = this;
		util.btnPressed("popup_in_motion_view_btn", function() {
			$("#temp_in_motion_notify").remove();
			$(".in_motion_notify").hide();
//			if(!alertInmotionExist){
				$("#temp_drive_mode").remove();
				$(".drive_mode").hide();
//			}
			
			if (_this.options.notify_type == "message_priority_high_inmotion") {
				if (boolBackNotifyExist) {
					$("#temp_notify").remove();
					$(".notify").hide();
				}
				highPriorityMessageInmotion = false;
				var text = "";
				var lang = "";
				messageList.each(function(item, index) {
					if (item.read == 0) {
						if (item.priority > 5) {
							text += item.from + " said " + item.subject + " "
									+ item.detail + " ";
							lang = item.language;
							MessageData.updateMessage(messageList[index]);
							homeInstance
									.updateNotify(UPDATE_NOTIFY_TYPE.MESSAGE);
							$("#message_id" + item.id).removeClass(
									"message_container_content_item_noread");
							$("#dot_" + item.id).children().remove();
						}
					}
				});
				util.textToSpeach(text, lang);
			}
			if (testFlag) {
				Android.cancelSoundNotification();
			}
		});
		if(navigationSelected){
			//TODO show navigation
			Android.openNavigation(JSON.stringify({
	            "geo": "47.604819,-122.33801"
	        }));
		}
	},
	destroy : function(){
		messageInmotionPopup = null;
	}
});

var AlertInMotionNotify = can.Control({
	init : function() {
		$(".alert_in_motion_notify").show();
		this.element.html(can.view('common/views/in_motion_notify.ejs', {
			notify_type : this.options.notify_type,
			notify_count : this.options.notify_count,
			data : this.options.data,
			item : this.options.item
		}));
	},
	'.alert_popup_in_motion_dismiss_btn click' : function() {
		var _this = this;
		util.btnPressed("alert_popup_in_motion_dismiss_btn", function() {
			$("#alert_temp_in_motion_notify").remove();
			$(".alert_in_motion_notify").hide();
			$("#alert_temp_notify").remove();
			$(".alert_notify").hide();
			if(!highPriorityMessageInmotion){
				$("#temp_drive_mode").remove();
				$(".drive_mode").hide();
			}
			alertInmotionExist = false;
		});
		if (testFlag) {
			Android.cancelSoundNotification();
		}
		
		if(!messageInmotionPopup){
		if(navigationSelected){
				//TODO show navigation
			Android.openNavigation(JSON.stringify({
	            "geo": "47.604819,-122.33801"
	        }));
		}
		}
		
	},
	'.alert_popup_in_motion_view_btn click' : function() {
		var _this = this;
		util.btnPressed("alert_popup_in_motion_view_btn", function() {
			$("#alert_temp_in_motion_notify").remove();
			$(".alert_in_motion_notify").hide();
			$("#alert_temp_notify").remove();
			$(".alert_notify").hide()
			if(!highPriorityMessageInmotion){
				$("#temp_drive_mode").remove();
				$(".drive_mode").hide();
			}
			if (testFlag) {
				Android.cancelSoundNotification();
			}
			alertInmotionExist = false;
				var text = "";
				var lang = "";
				alertList.each(function(item, index) {
					if (item.read == 0) {
						AlertData.updateAlert(alertList[index]);
						homeInstance.updateNotify(UPDATE_NOTIFY_TYPE.ALERT);
						$("#alert_id"+item.id).children().first().children().removeClass(alertList[index].alert_type + "_unread");
						lang = item.language;
						if(item.alert_type == "SPEEDING"){
							text += t.alerts.speed_text_to_speach;
						}else if(item.alert_type == "DRIVER_HRS"){
							text += t.alerts.dht_text_to_speach;
						}
					}
				});
				util.textToSpeach(text, lang);
		});
		if(!messageInmotionPopup){
		if(navigationSelected){
				//TODO show navigation
			Android.openNavigation(JSON.stringify({
	            "geo": "47.604819,-122.33801"
	        }));
		}
	}
	},
	destroy : function(){
		alertInmotionPopup = null;
	}
});

