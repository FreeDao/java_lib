var configuration;

var CONFIGURATION = {
    "display_high_priority_message": 1,
    "user_id": "-1",
    "language_preference": "eng",
    "driver_type": 3,
    "audio_sounds": 1,
    "display_high_priority_alert": 1,
    "is_eula_accepted": 0
};

var ConfigurationData = can.Model({
    setConf: function(obj){
        //alert(JSON.stringify(obj._data));
        //alert(JSON.stringify(configuration));
        if (testFlag) {
            // TODO, why obj._data?
            // nikm added
            //Android.setSetting(JSON.stringify(obj._data));
            Android.setSetting(JSON.stringify(obj));
        }
        else {
            CONFIGURATION = obj._data;
        }
    },
    getConf: function(){
        var userInfo = {
            "user_id": "-1"
        };
        
        if (configuration != null) 
            userInfo.user_id = configuration.user_id;
        
        var conf;
        if (testFlag) {
            conf = JSON.parse(Android.getSetting(JSON.stringify(userInfo)));
        }
        else {
            conf = CONFIGURATION;
        }
        conf = new can.Observe(conf);
        return conf;
    }
}, {});
