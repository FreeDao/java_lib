var LoginData = can.Model({
    verifyPin: function(pinCode){
        var loginStatus;
        var loginReq = {
            "PIN": pinCode
        };
        if (testFlag) {
            loginStatus = JSON.parse(Android.login(JSON.stringify(loginReq)));
        }
        else {
            loginStatus = RESPONSE_STATUS;
        }
        return loginStatus;
    },
    acceptEula: function(){
        var acceptStatus;
        var userId = ConfigurationData.getConf().user_id;
        var eulaReq = {
            "user_id": userId
        };
        if (testFlag) {
            acceptStatus = JSON.parse(Android.acceptEula(JSON.stringify(eulaReq)));
        }
        else {
            acceptStatus = RESPONSE_STATUS;
        }
        // TODO
        return acceptStatus;
    }
}, {});
