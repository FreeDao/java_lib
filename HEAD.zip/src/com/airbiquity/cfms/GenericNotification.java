package com.airbiquity.cfms;

import java.io.IOException;

import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;

/** CFMS domain object for handling notification events from Choreo.  The destination of the event
 *  will determine how to act based upon the notification type indicated.  The primary motivator
 *  for this class is so that Choreo can notify the ICS of pending Text messages.  In that 
 *  specific scenereo, the ICS will then send a text message request to Choreo to fetch
 *  the message which is associated with the notification ID.
 * 
 * @author DQuimby
 *
 */
public class GenericNotification {
	public static final int DEVICE_OBU=0X00;
	public static final int DEVICE_ICS=0X01;
	public static final int TEXT_MESSAGE_PENDING = 0x00;
	
	private int destDevice = DEVICE_ICS;
	public  int notificationType=TEXT_MESSAGE_PENDING;

	// This will be extracted from the CFMS header of the notification message
	private long notificationId = 0;
	
	/** Fetch the device that is associated with the notification.  Currently, it could be either
	 * the ICS or the OBU.  More may be added in the future.
	 * 
	 * @return The device type that is the target of this notification message.
	 */
	public int getDestDevice() {
		return destDevice;
	}

	/** Set the device that is associated with the notification.
	 * 
	 * @param destDevice The device type that is the target of this notification message.
	 */
	public void setDestDevice(int destDevice) {
		this.destDevice = destDevice;
	}

	/** Get the type of notification being indicated by Choreo.  Currently the only
	 *  notification type defined is for a "text message pending" on Choreo which
	 *  needs to be downloaded by the ICS.  More types may be defined in the future.
	 * 
	 * @return The notification type being indicated by this message.
	 */
	public int getNotificationtype() {
		return notificationType;
	}
	
	/** Set the type of notification being indicated by Choreo.  Currently the only
	 *  notification type defined is for a "text message pending" on Choreo which
	 *  needs to be downloaded by the ICS.  More types may be defined in the future.
	 * 
	 * @return The notification type being indicated by this message.
	 */
	public void setNotificationtype( int notificationType ) {
		this.notificationType = notificationType;
	}

	/** Get the notificiation ID assiciated with this message.  This is the handle that will
	 *  get passed back to Choreo in order to fetch the data that is associated with this
	 *  notification message.
	 * 
	 * @return The notification id needed to fetch any associated reference data from Choreo.
	 */
	public long getNotificationId()
	{
		return notificationId;
	}

	/** Build a CFMS binary payload for a Generic Notification 
	 * 
	 * @return The binary payload for the CFMS generic notification.  If an error occurs while
	 *         preparing the payload, null will be returned instead.
	 */
	public byte[] encodePackedData() 
	{
		byte[] retval = null;
		
		ByteEncoder be = new ByteEncoder();
		be.writeInt( 1, this.destDevice );
		be.writeInt( 1, this.notificationType );
		retval = be.getContent();
		return retval;
	}
	
	/** Populate this object with the given notification id and byte array which contains
	 *  the CFMS generic notification payload.
	 * 
	 * @param notificationId The id associated with this generic notification.
	 * @param packed The CFMS payload associated with this generic Notification.
	 * @throws AqErrorException If any error occurs while unpacking notification.
	 */
	public void decodePackedData( long notificationId, byte[] packed ) throws AqErrorException 
	{
		try
		{
			ByteDecoder bd = new ByteDecoder( packed );
			this.notificationId = notificationId;
			this.destDevice = bd.readInt( 1 );
			this.notificationType = bd.readInt(1);
		}
		catch( Exception e )
		{
			throw new AqErrorException( "Error decoding Generic notification");
		}
	}
}
