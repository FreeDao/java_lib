package com.airbiquity.cfms;

import com.airbiquity.aqlog.AqLog;
import com.airbiquity.util.AqUtils;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;

/** This class is used by the ICS to construct ICS event to be consumed by lower layers of the OBU.  This class is
 *  purposfully un-aware of  the JSON encoding in order to insure that the OBU doesn't require a JSON .jar file be
 *  included as a as part of its build (and associated SW update).  Also, any maintenence of this class needs to consider
 *  that it must still be capable of running on J2ME and J2EE platforms (i.e. don't use Annotations or other nice new features)!
 * 
 * @author DQuimby
 *
 */
public class IcsEvent {

	
	public static final int ICS_PIN_ASSERTED_EVENT = 0;
	public static final int ICS_LOGOFF_ASSERTED_EVENT = 1;
	
	private int evtType = 0;
	private String evtData = "";
	private long timestamp = 0;
	
	public IcsEvent( long timestamp, int evtType, String evtData )
	{
		this.setTimestamp(timestamp);
		this.setEvtType(evtType);
		this.setEvtData(evtData);
	}

	public IcsEvent( long timestamp, int evtType )
	{
		this( timestamp, evtType, "" );
	}

	public IcsEvent()
	{
		
	}
	
	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public int getEvtType() {
		return evtType;
	}

	public void setEvtType(int evtType) {
		this.evtType = evtType;
	}

	public String getEvtData() {
		return evtData;
	}

	public void setEvtData(String evtData) {
		this.evtData = evtData;
	}

	public byte[] encodeToByteArray()
	{
		ByteEncoder be = new ByteEncoder();
		be.writeLong( 8, timestamp );
		be.writeInt( 1, evtType );
		be.writeShortString( evtData );

		return be.getContent();
	}
	
	public void decodeFromByteArray( byte[] b )
	{
		ByteDecoder bd = new ByteDecoder( b );
		try
		{
			 timestamp = bd.readLong( 8 );
			 evtType = bd.readInt( 1 );
			 evtData = bd.readShortString();
		}
		catch( Exception e )
		{
			AqLog.getInstance().error("Unable to read OBU Status", e );
		}
	}
}
