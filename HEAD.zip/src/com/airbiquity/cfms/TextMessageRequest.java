package com.airbiquity.cfms;

import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;

/** CFMS domain object for requesting a TextMessage object from Choreo.  This object
 *  will be created by the ICS when handling a GenericNotification which specifies 
 *  device=ICS and notificationType=TextMessage. 
 * 
 * @author DQuimby
 *
 */
public class TextMessageRequest {
	private long notificationId = 0;

	/** Get the notification id which was specified by Choeo in the GenericNotification.
	 * 
	 * @return The notification id.
	 */
	public long getNotificationId() {
		return notificationId;
	}

	/** Set the notification id which was specified by Choeo in the GenericNotification.
	 * 
	 * @param notificationId
	 */
	public void setNotificationId(long notificationId) {
		this.notificationId = notificationId;
	}

	/** Create the CFMS payload for this TextMessageRequest
	 * 
	 * @return The CFMS payload as an array of bytes.
	 */
	public byte[] encodePackedData()
	{
		ByteEncoder be = new ByteEncoder();
		be.writeLong( 8, this.getNotificationId() );
		return be.getContent();
	}
	
	/** Decode the CFMS payload for a TextMessageRequest and populate the 
	 *  attributes of this object.
	 * 
	 * @param packed The packed data from the CFMS message payload.
	 * @throws AqErrorException Upon any error during the decoding of the CFMS payload.
	 */
	public void decodePackedData( byte[] packed ) throws AqErrorException
	{
		ByteDecoder bd = new ByteDecoder( packed );
		
		try
		{
			this.notificationId = bd.readLong(8);
		}
		catch( Exception e )
		{
			throw new AqErrorException("Error decoding TextMessageRequest");
		}
	}
}
