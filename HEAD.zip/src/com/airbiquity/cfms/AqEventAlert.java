/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2011 by Airbiquity.  All rights reserved.
 *
 * ***************************************************************************
 */
//@@AL=AqEventAlert.java


package com.airbiquity.cfms;

import java.io.IOException;
import java.util.Date;

import com.airbiquity.exception.AqDataNotAvailableException;
import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.AqUtils;
import com.airbiquity.util.ByteEncoder;
import com.airbiquity.util.ByteDecoder;

import java.util.Stack;

public class AqEventAlert
{
	
	// isReplay is set to true prior to replaying historical snapshot data
	// upon a poweron or wake up from sleep mode restore.  When replay is on
	// no alerts will be queued.  Events also won't be written to the snapshot
	// log (per handling of AqSnapshotStore.writeEvent()).
	private static boolean isReplay = false;
	
    public static final float ALTITUDE_MIN = (float) -100.0;
    public static final float ALTITUDE_MAX = (float) 1000.0;
    public static final float ALTITUDE_RES = (float) 1.0;

    public static final float SPEED_MIN = (float) 0.0;
    public static final float SPEED_MAX = (float) 180.0;
    public static final float SPEED_RES = (float) 1.0;

    public static final float HEADING_MIN = (float) 0.0;
    public static final float HEADING_MAX = (float) 360.0;
    public static final float HEADING_RES = (float) 1.0;

    public static final float FUEL_LEVEL_MIN = (float) 0.0;

    // FIXME slop to prevent minor averaging error to throw encoder off
    // consider adding resolution / 2 slop math to float encoding
    // routine in order to make more global....Or is it best to leave
    // isolated to this ??
    public static final float FUEL_LEVEL_MAX = (float) 100.04;
    public static final float FUEL_LEVEL_RES = (float) 0.1;
    
    public static final int DRIVER_LOGON_EVENT_ID = 1;
    public static final int DRIVER_LOGOFF_EVENT_ID = 2;
    public static final int IGNITION_ON_EVENT_ID = 3;
    public static final int IGNITION_OFF_EVENT_ID = 4;
    public static final int FUEL_FILL_EVENT_ID = 5;
    /* Was Feul drop event 0x06 */
    public static final int STOP_OVER_EVENT_ID = 7;
    public static final int MIN_EVENT_ID = DRIVER_LOGON_EVENT_ID;
    public static final int MAX_EVENT_ID = STOP_OVER_EVENT_ID;


    private static Stack pendingAlerts = new Stack();
    private static final int ALERT_VERSION_ID = 3;

    public static final int EVENT_TYPE_MASK = 0xC0;
    public static final int OP_EVENT_FLAG_MASK = 0x00;
    public static final int HLTH_EVENT_FLAG_MASK = 0x80;
    public static final int ALERT_FLAG_MASK = 0x40;
    
    // Used to encode / decode state machine updates to the snapshot file.  The most recent of any state machine needs to be carried
    // over when the snapshot file is rolled over.
    public static final int STATE_EVENT_FLAG_MASK = 0xC0;  
    
    
    public static final int ALERT_BATT_POWER_LOSS = 0x41;
    public static final int ALERT_COLLISTION = 0x42;
    public static final int ALERT_FUEL_TANK_DROP = 0x43;
    public static final int ALERT_TAMPER = 0x44;
    public static final int ALERT_DRIVE_WITHOUT_BREAK = 0x45;
    public static final int ALERT_SPEEDING = 0x46;
    public static final int ALERT_IDLING = 0x47;
    public static final int ALERT_PTO = 0x48;
    public static final int ALERT_CRASH_BUFFER_SAVED = 0x49;
    public static final int ALERT_UPLOAD_DCF = 0x4B;	//4A used by Choreo for GF transgression
    public static final int ALERT_DRIVER_HOURS_WARNING = 0x4C;
    
    // sub types for tamper alert
    public static final int TAMPER_SERVICE_COVER = 1;
    public static final int TAMPER_SIM = 2;
    public static final int TAMPER_TYPE_MAX = TAMPER_SIM;
    
    public static final int HLTH_EVT_TAMPER = 0x81;
    public static final int HLTH_EVT_UNSCH_REBOOT = 0x82;
    public static final int HLTH_EVT_SCH_REBOOT = 0x83;
    public static final int HLTH_EVT_TIME_SYNC = 0x84;
    public static final int HLTH_EVT_SELF_MONITOR = 0x85;
    public static final int HLTH_EVT_POWER_RESTORE = 0x86;
    public static final int HLTH_EVT_GPRS = 0x87;
    public static final int HLTH_EVT_GPS = 0x88;
    private static final int HLTH_EVT_MIN = HLTH_EVT_TAMPER; 
    private static final int HLTH_EVT_MAX = HLTH_EVT_GPS;
    
    public static final int STATE_EVT_STOP_OVER = 0xC0;
    public static final int STATE_EVT_MIN = STATE_EVT_STOP_OVER;
    public static final int STATE_EVT_MAX = STATE_EVT_STOP_OVER;
    
    public static final byte GPRS_DETACHED = 0;
    public static final byte GPRS_ATTACHED = 1;
    public static final byte GPS_FIX_NOT_AVAILABLE = 0;
    public static final byte GPS_FIX_AVAILABLE = 1;
    public static final byte TIME_SYNC_PROBLEM = 0;
    public static final byte TIME_SYNC_OK = 1;
    
    public static final byte UNSCH_REBOOT_REASON_CFMS_REQ = 0;
    public static final byte UNSCH_REASON_WATCHDOG = 1;
    public static final byte UNSCH_REASON_POWER_FAIL = 2;

    public static final byte SCH_REBOOT_REASON_CFMS_REQ = 0;
    public static final byte SCH_REBOOT_REASON_SOFTWARE_UPDATE = 1;
    
    private static final int ALERT_MIN = ALERT_BATT_POWER_LOSS;
    private static final int ALERT_MAX = ALERT_UPLOAD_DCF;

    // Encoder/decoder fields.  These are the fields which are
    // sent OTA for events and alerts, but are dependent
    // upon the type of alert or event if these fields
    // get sent.
    private static final short ENC_DEC_FIELDS_NONE              = 0x0000;
    private static final short ENC_DEC_FIELDS_DRIVERID			= 0x0001;
    private static final short ENC_DEC_FIELDS_FUEL_LEVEL_BEFORE = 0x0002;
    private static final short ENC_DEC_FIELDS_FUEL_LEVEL_AFTER  = 0x0004;
    private static final short ENC_DEC_FIELDS_TOTAL_FUEL_BEFORE = 0x0008;
    private static final short ENC_DEC_FIELDS_TOTAL_FUEL_AFTER  = 0x0010;
    private static final short ENC_DEC_FIELDS_ONE_BYTE_VAL      = 0x0020;
    private static final short ENC_DEC_FIELDS_DISTANCE          = 0x0040;
    private static final short ENC_DEC_FIELDS_DURATION          = 0x0080;
    private static final short ENC_DEC_FIELDS_SHORT_STRING_1    = 0x0100;
    private static final short ENC_DEC_FIELDS_SHORT_STRING_2_3  = 0x0200;
    private static final short ENC_DEC_FIELDS_REFID             = 0x0400;
    private static final short ENC_DEC_FIELDS_STAGE             = 0x0800;
    private static final short ENC_DEC_FIELDS_FUEL_LEVEL_CONFIRM = 0x1000;
    private static final short ENC_DEC_FIELDS_SECONDARY_TIMESTAMP = 0x2000;
    

    // The logon event borrows the "oneByteParameter" to indicate the GPS/GPRS status
    // at the time logon occured.
    public static final byte LOGON_GPS_AVAILABLE = 0x01;
    public static final byte LOGON_GPRS_ATTACHED = 0x02;
    
    
    protected static void replayOn()
    {
    	isReplay = true;
    }
    
    protected static void replayOff()
    {
    	isReplay = false;
    }
    private static final short[] eventEncodeDecodeFields =
    {
        /* Logon Event 0x01 */
    	ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_FUEL_LEVEL_AFTER,

        /* Logoff Event 0x02 */
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_FUEL_LEVEL_AFTER,

        /* Ignition Off Event 0x03 */
        ENC_DEC_FIELDS_NONE,

        /* Ignition On Event 0x04 */
        ENC_DEC_FIELDS_NONE,

        /* Fuel Fill Event 0x05 */
        ENC_DEC_FIELDS_FUEL_LEVEL_BEFORE |
        ENC_DEC_FIELDS_FUEL_LEVEL_AFTER |
        ENC_DEC_FIELDS_TOTAL_FUEL_AFTER | /* A.K.A. TotalFuelConsumed() on Choreo's decoder */
        ENC_DEC_FIELDS_REFID |
        ENC_DEC_FIELDS_STAGE,
        
        /* fuel drop event 0x06 */
        0,
        
        /* Stop Over Event 0x07 */
        ENC_DEC_FIELDS_TOTAL_FUEL_BEFORE |
        ENC_DEC_FIELDS_TOTAL_FUEL_AFTER |
        ENC_DEC_FIELDS_DURATION

    };

    public int getRefId() {
		return refId;
	}

	public void setRefId(int refId) {
		this.refId = refId;
	}

	public int getStage() {
		return stage;
	}

	public void setStage(int stage) {
		this.stage = stage;
	}

	public static short getEncDecFieldsStage() {
		return ENC_DEC_FIELDS_STAGE;
	}
	private static final short[] alertEncodeDecodeFields =
    {
        /* Battery Power Loss 0x41 */
        ENC_DEC_FIELDS_DRIVERID,
        
        /* Collision 0x42 */
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_NONE,
        
        /* Fuel Tank Drop Alert 0x43 */
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_FUEL_LEVEL_BEFORE |
        ENC_DEC_FIELDS_FUEL_LEVEL_AFTER |
        ENC_DEC_FIELDS_TOTAL_FUEL_BEFORE |
        ENC_DEC_FIELDS_TOTAL_FUEL_AFTER |
        ENC_DEC_FIELDS_FUEL_LEVEL_CONFIRM,
        
        /* Tamper Alert 0x44 */   
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_ONE_BYTE_VAL,
        
        /* Drive Hours 0x45 */ 
        ENC_DEC_FIELDS_DRIVERID,

        /* Speeding  0x46 */
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_ONE_BYTE_VAL |
        ENC_DEC_FIELDS_DISTANCE |
        ENC_DEC_FIELDS_DURATION,

        /* Idling 0x47 */
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_DURATION,

        /* Pto 0x48 */
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_DISTANCE |
        ENC_DEC_FIELDS_DURATION,

        /* Crash Buff Saved 0x49 */
        ENC_DEC_FIELDS_DRIVERID,
        
        /* Geo-Fence Transgression (populated by Choreo .. need a place holder here though  0x4A */
        ENC_DEC_FIELDS_NONE,
        
        /* Upload DCF Failed Alert 0x4B */
        ENC_DEC_FIELDS_DRIVERID |
        ENC_DEC_FIELDS_SHORT_STRING_1 |
        ENC_DEC_FIELDS_SHORT_STRING_2_3,
        
        /* Driver hours warning alert 0x4C*/
        ENC_DEC_FIELDS_NONE
        
    };

    private static final short[] healthEvtEncodeDecodeFields =
    {
    	/* HLTH_EVT_TAMPER = 0x81; */
    	ENC_DEC_FIELDS_ONE_BYTE_VAL, 
    	
    	/* HLTH_EVT_UNSCH_REBOOT = 0x82; */
    	ENC_DEC_FIELDS_ONE_BYTE_VAL, 
    	
    	/* HLTH_EVT_SCH_REBOOT = 0x83; */
    	ENC_DEC_FIELDS_ONE_BYTE_VAL, 

    	/* HLTH_EVT_TIME_SYNC = 0x84; */
    	ENC_DEC_FIELDS_ONE_BYTE_VAL, 

    	/* HLTH_EVT_SELF_MONITOR = 0x85; */
    	ENC_DEC_FIELDS_SHORT_STRING_1 | ENC_DEC_FIELDS_SHORT_STRING_2_3,

    	/* HLTH_EVT_POWER_RESTORE = 0x86; */
    	ENC_DEC_FIELDS_NONE,
    	
    	/* HLTH_EVT_GPRS = 0x87; */
    	ENC_DEC_FIELDS_ONE_BYTE_VAL | ENC_DEC_FIELDS_SHORT_STRING_1, 

    	/* HLTH_EVT_GPS = 0x88; */
    	ENC_DEC_FIELDS_ONE_BYTE_VAL
    };
    
    private static final short[] stateEventEncoderDecoderFields = 
   	{
    	/* STATE_EVENT_FLAG_MASK 0xC0 */
    	ENC_DEC_FIELDS_STAGE | 
        ENC_DEC_FIELDS_TOTAL_FUEL_BEFORE |
    	ENC_DEC_FIELDS_SECONDARY_TIMESTAMP,

    	/* STATE_EVENT_PLACEHOLDER = 0xC1; */
    	ENC_DEC_FIELDS_NONE
   	};
    
    private static short getEncodeDecodeFields( int eventId )
    {
        short retval = ENC_DEC_FIELDS_NONE;
        if( ( eventId >= MIN_EVENT_ID ) && ( eventId <= MAX_EVENT_ID ) )
        {
            retval = eventEncodeDecodeFields[eventId - MIN_EVENT_ID];
        }
        else if( ( eventId >= ALERT_MIN ) && ( eventId <= ALERT_MAX ) ) 
        {
            retval = alertEncodeDecodeFields[eventId - ALERT_MIN];
        }
        else if( (eventId >= HLTH_EVT_MIN ) && ( eventId <= HLTH_EVT_MAX ))
        {
        	retval = healthEvtEncodeDecodeFields[eventId - HLTH_EVT_MIN];
        }
        else if( (eventId >= STATE_EVT_MIN ) && ( eventId <= STATE_EVT_MAX ))
        {
        	retval = stateEventEncoderDecoderFields[ eventId - STATE_EVT_MIN];
        }
        return retval;
    }
    
    CfmsConfigManifest cfgManifest = null;
    private AqDriverId driverId = null;
    
    public AqDriverId getDriverId() {
		return driverId;
	}

	public void setDriverId(AqDriverId driverId) {
            this.driverId = new AqDriverId( driverId );
	}

	protected AqLocation location = null;
    protected int eventId = 0;
    protected int odometer = 0;
    protected long timeInMs = 0;
    protected long secondaryTimeInMs = 0;
    protected float fuelLevelBefore = 0;
    protected float fuelLevelAfter = 0;
    protected float fuelLevelConfirm = 0;
    protected long totalFuelConsumedBefore = 0;
    protected long totalFuelConsumedAfter = 0;
    protected float distance = 0;
    protected int duration = 0;
    //private static int alertMask = AqProperties.getIntConfig(AqProperties.ALERT_SUPPRESSION_MASK);	//it is for alert suppression, 0 for no, 1 for yes
    protected int refId = 0;
    protected int stage = 0;
    protected String shiftId = "";

    /* What this variable represents depends upon which event or alert it is 
     * associated with.  
     * 
     * TamperAlert: Tamper type (cover or sim)
     * SpeedingAlert: Max speed attained during alert period.
     * 
     * Health Report events:
     * 		Tamperevent: tamper type (SIM, cover, none)
     * 		UnschRebootEvent: reboot reason (CFMS requested, watchdog, powerfail )
     * 		SchedRebootEvent: reboot reason (CMFS Requested, SW update )
     * 		TimeSyncEvent: indication (time sync problem, time sync ok)
     * 		GprsEvent: indication (GPRS detached, GPRS attached)
     * 		GpsEvent: indication (GPS fix available, GPS fix not available)
     */
    protected int oneByteParam = 0;

    /* Both the GPRS event and the self monitor event require an array of strings.  
     * The GPRS uses a single string whereas the self monitor event requires 3
     */
    protected String evtStringData[] = null;
    
    public String getEvtStringData( int idx )
    {
    	String retval = null;
    	if( ( null != evtStringData ) && ( idx < evtStringData.length ) )
    	{
    		retval = evtStringData[idx];
    	}
    	return retval;
    }
    
    public void setEvtStringData( String s1, String s2, String s3 )
    {
    	evtStringData = new String[3];
    	evtStringData[0] = s1;
    	evtStringData[1] = s2;
    	evtStringData[2] = s3;
    }
    
    public long getTotalFuelConsumedBefore() {
		return totalFuelConsumedBefore;
	}

	public void setTotalFuelConsumedBefore(long totalFuelConsumedBefore) {
		this.totalFuelConsumedBefore = totalFuelConsumedBefore;
	}

	public long getTotalFuelConsumedAfter() {
		return totalFuelConsumedAfter;
	}

	public void setTotalFuelConsumedAfter(long totalFuelConsumedAfter) {
		this.totalFuelConsumedAfter = totalFuelConsumedAfter;
	}

	public float getDistance() {
		return distance;
	}

	public void setDistance(float distance) {
		this.distance = distance;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getOneByteParam() {
		return oneByteParam;
	}

	/** Set the "one byte parameter" member of this object.  The value
	 *  is stored within the object as an integer.  However, it is stored 
	 *  to flash and transmitted as a single unsigned byte value.  Thus
	 *  the range should be limited to 0 .. 250.  However, there is no
	 *  exception thrown for a value outside this range.  The out of 
	 *  range values will be limited to the extreme allowed.
	 * 
	 * @param oneByteParam The value to store in the local object.
	 * 
	 */
	public void setOneByteParam(int oneByteParam) {
		this.oneByteParam = oneByteParam;
	}

	private AqEventAlert()
    {
    }

    public void reset()
    {
        location.reset();
    }

    public AqEventAlert( int evtId )
    {
    }

//    public AqEventAlert( int evtId )
//    {
//        this.eventId = evtId;
//        this.location = AqSnapshotConsumer.getLocation();
//        this.odometer = AqSnapshotConsumer.getOdometer();
//        this.driverId = AqSnapshotConsumer.getDriverId();
//        this.timeInMs = AqSnapshotConsumer.getTime();
//        this.fuelLevelBefore = 0;
//        this.fuelLevelAfter = FuelLevelAnalytics.getBestFuelLevel();
//        this.totalFuelConsumedBefore = 0;
//        //this.totalFuelConsumedAfter = AqSnapshotConsumer.getFuelUsedCtr();
//        this.oneByteParam = 0;
//        this.distance = 0;
//        this.duration = 0;
//    }
//    
//    public AqEventAlert( int evtId, int oneByteParam )
//    {
//    	this( evtId );
//    	this.setOneByteParam( oneByteParam );
//    }

    // OBU 2.2   Fuel Filling Event  -- aggregate   
    // OBU 2.3   Fuel Theft Event    -- aggregate   
    // OBU 2.4   Driver Logon Event  -- aggregate   
    // OBU 2.5   Driver Logoff Event -- aggregate   <-- This is an alert rather than event
    // OBU 2.6   Ignition on Event   -- aggregate   
    // OBU 2.7   Ignition off Event  -- aggregate   
    public int getEventId()
    {
        return eventId;
    }

    protected void setEventId( int evtId )
    {
        eventId = evtId;
    }

    // OBU 2.x.1 Odometer            -- aggregate   
    public int getOdometer()
    {
        return odometer;
    }
    
    public long getTimeInMs()
    {
        return timeInMs;
    }

    public Date getLocationTime() throws AqDataNotAvailableException
    {
        return location.getTime();
    }
    
    // OBU 2.x.4 Location lat/lon    -- aggregate   
    public double getLatitude() throws AqDataNotAvailableException
    {
        return location.getLatitude();
    }

    public double getLongitude() throws AqDataNotAvailableException
    {
        return location.getLongitude();
    }
    
    // OBU 2.x.4 and higher (if they exist) are defined by event sub-classes 
    

    // OBU 2.x.? Not defined by TSP requirements
    // altitude, heading and speed but they show up in XSD.
    public float getAltitudeInMeters() throws AqDataNotAvailableException
    {
        return location.getAltitudeInMeters();
    }

    public float getHeadingInDegrees() throws AqDataNotAvailableException
    {
        return location.getHeadingInDegrees();
    }

    public float getSpeedInKph() throws AqDataNotAvailableException
    {
        return location.getSpeedInKph();
    }
    

    // Protected accessors
    // OBU 2.x.1 Odometer            -- aggregate   
    protected void setOdometer( int odo )
    {
        odometer = odo;
    }
    
    // OBU 2.x.2 Date                -- aggregate   
    // OBU 2.x.3 Time                -- aggregate   
    protected void setTimeInMs( long ms )
    {
        location.setTimeInMs( ms );
        timeInMs = ms;
    }
    
    // OBU 2.x.4 Location lat/lon    -- aggregate   
    protected void setLongitude( double lon )
    {
        location.setLongitude( lon );
    }

    protected void setLatitude( double lat )
    {
        location.setLatitude( lat );
    }

    // OBU 2.x.4 and higher (if they exist) are defined by event sub-classes 

    

    // OBU 2.x.? Not defined by TSP requirements
    // altitude, heading and speed but they show up in XSD.
    protected void setLocation( AqLocation loc )
    {
        location = loc;
    }

    protected void setAltitudeInMeters( float alt )
    {
        location.setAltitudeInMeters( alt );
    }
    
    protected void setAltitudeInMeters( double alt )
    {
    	location.setAltitudeInMeters( alt );
    }

    protected void setHeadingInDegrees( float degrees )
    {
    	location.setHeadingInDegrees( degrees );
    }

    protected void setHeadingInDegrees( double degrees )
    {
    	location.setHeadingInDegrees( degrees );
    }

    // Aq location standard
    protected void setSpeedInKph( float kph )
    {
    	location.setSpeedInKph( kph );
    }

    // Another standard used by some HW manufacturers
    protected void setSpeedInMetersPerSecond( double mPs )
    {
    	float kph = (float) ( mPs * (float) 3.6 );
    	location.setSpeedInKph( kph );
    }

    public float getFuelLevelBefore() throws AqDataNotAvailableException
    {
        return fuelLevelBefore;
    }

    protected void setFuelLevelBefore( float fl )
    {
        fuelLevelBefore = fl;
    }

    public float getFuelLevelAfter() 
    {
        return fuelLevelAfter;
    }

    protected void setFuelLevelAfter( float fl )
    {
        fuelLevelAfter = fl;
    }

    public float getFuelLevel() throws AqDataNotAvailableException
    {
        return fuelLevelAfter;
    }

    protected void setFuelLevel( float fl )
    {
        fuelLevelAfter = fl;
    }

    public float getFuelLevelConfirm() throws AqDataNotAvailableException
    {
        return fuelLevelConfirm;
    }

    protected void setFuelLevelConfirm( float fl )
    {
        fuelLevelConfirm = fl;
    }
    
    
    protected long getSecondaryTimeInMs() {
		return secondaryTimeInMs;
	}

	protected void setSecondaryTimeInMs(long secondaryTimeInMs) {
		this.secondaryTimeInMs = secondaryTimeInMs;
	}

	protected AqLocation getLocation() {
		return location;
	}

    public String getShiftId() {
		return shiftId;
	}

	public void setShiftId(String shiftId) {
		this.shiftId = shiftId;
	}
    
    // null Alert not queued either due to alert suppression, or due to 
    // replay flag being asserted.
//    public static String queueAlert( AqEventAlert alert )
//    {
//    	String retval = null;
//    	if( ! isReplay )
//    	{
//    		//^^AL1=queueAlert
//    		AqLog.getInstance().info("^^AL1");
//    		// System.out.println("queueAlert.  Alert: " + alert.toString() );
//    		if( null != alert )
//    		{
//    			if( null == alert.location )
//    			{
//    				pendingAlerts.push( alert );
//    				//^^AL2=Alert pending location update
//    				AqLog.getInstance().info( "^^AL2" ); 
//    				// System.out.println( "Alert pending location update" );
//    			}
//    			else
//    			{
//    				if ( 0 != ((1 << (alert.eventId - ALERT_BATT_POWER_LOSS)) & alertMask) )
//    				{
//    					//^^ALC=Alert is suppressed.  alertId,alertMask:
//    					AqLog.getInstance().info("^^ALC" + alert.eventId + "," + alertMask );
//    				}
//    				else
//    				{
//    					try
//    					{
//    						String s;
//    						ByteEncoder be = null;
//
//    						try
//    						{
//    							be = new ByteEncoder();
//    						}
//    						catch( Exception e )
//    						{
//    							//^^AL3=queueAlert() --- Error creating byte encoder
//    							AqLog.getInstance().info( "^^AL3" );
//    							throw e;
//    						}
//
//    						try
//    						{
//    							alert.encodePackedData( "Alert", be );
//    						}
//    						catch( Exception e )
//    						{
//    							//^^AL5=queueAlert() --- Exception packing alert
//    							AqLog.getInstance().info( "^^AL5" + e.toString() );
//    							// System.out.println( "queueAlert() --- Exception packing alert" + e.toString() );
//    							throw e;
//    						}
//
//    						try
//    						{
//    							String outpath = AqConsts.PREPPED_OUTBOUND_CFMS;
//
//    							// send newer alerts via UDP
//    							if( alert.getEventId() > ALERT_DRIVE_WITHOUT_BREAK )
//    							{
//    								outpath = AqConsts.PREPPED_UDP;
//    							}
//
//    							s = AqUtils.prepareFile( be.getContent(), outpath, AqConsts.ATP_CFMS_ALERT_REQ, false, 3 );
//    							// s = AqUtils.prepareFile( be.getContent(), outpath, AqConsts.ATP_CFMS_ALERT_REQ );
//    						}
//    						catch( Exception e )
//    						{
//    							//^^AL6=queueAlert() --- Exception preparing file
//                                                        AqLog.getInstance().info( "^^AL6",e );
//    							throw e;
//    						}                        
//
//    						// System.out.println( "Queing alert to netork task.  File: " + s );
//    						//^^AL7=Queing alert to netork task.  File: 
//    						//AqLog.getInstance().info( "^^AL7" + s );
//    						//retval = s;
//    						//AqUtils.broadcastEvent( EventListener.ALERT_QUEUED_TO_NETWORK, 0, null, alert );
//    					}
//    					catch( Exception ee )
//    					{
//    						//^^AL8=Unable to queue alert to network task.
//    						AqLog.getInstance().error("^^AL8" + alert.toString() );
//    						// System.out.println( "Unable to queue alert to network task." + alert.toString() );
//    					}
//    				}
//    			}
//    		}
//    	}
//    	return retval;
//    }
    
//     public String toString(String prefix)
//     {
//         String s = new String();

//         s = prefix
//             + "EvtId: 0x" + Integer.toString( eventId, 16 )
//             + ", Odometer(km): " + getOdometer()
//             + ", Time: " + (new Date( timeInMs ) ).toString()
//             + ", Fuel Level: " + fuelLevelAfter
//             + ", " + location.toString()
//             ;
//         return s;
//     }    

    
	// fills in the base class fields ... derived classes responsible for rest.
    // EVT:, evtName, odometer, time, loc.lat, loc.lon, loc.time, loc.altitude, loc.speed, loc.heading ...
    public String toCsv()
    {
        String retval = 
        	"EVT:" + ", 0x"
            + AqUtils.rightString("00" + Integer.toString( eventId, 16 ).toUpperCase(), 2 ) + ", "
            + getOdometer() + ", "
            + timeInMs + ", "
            + location.toCsv() + ", "
            + fuelLevelBefore + ", "
            + fuelLevelAfter + ", "
            + totalFuelConsumedBefore + ", "
            + totalFuelConsumedAfter + ", "
            + oneByteParam + ", "
            + distance + ", " 
            + duration + ", " 
            + stage;
        return retval;
    }

//     public String toString()
//     {
//         return this.toString("");
//     }
    
    /** Consumes the bytes for the given byte stream to initialize the object */
    public void decodePackedData( ByteDecoder bd, boolean isAlert, boolean isShiftIdPresent ) throws IOException, AqErrorException
    {
    	if( isAlert )
        {
            int alertVersion = bd.readInt( 1 );
            //^^ALD=alertVersion != ALERT_VERSION_ID
            if( ALERT_VERSION_ID != alertVersion ) throw new AqErrorException("^^ALD");
            //bd.setCfmsProtocolVersion( ALERT_VERSION_ID );
               
            CfmsConfigManifest cfg = new CfmsConfigManifest( false );
            cfg.decodePackedData( bd );
            
            if( isShiftIdPresent )
            {
            	this.setShiftId( bd.readShortString() );
            }
        }
        eventId = bd.readInt( 1 );

        if( HLTH_EVENT_FLAG_MASK != ( eventId & EVENT_TYPE_MASK ))
        {
        	odometer = bd.readInt( 4 );
        }
        
        timeInMs = bd.readLong( 4 ) * 1000;
        
        location = new AqLocation();
        location.decodePackedData( bd );

        // now the alert/event conditional fields
        short encFields = getEncodeDecodeFields( eventId );

        if( 0 != ( ENC_DEC_FIELDS_DRIVERID & encFields ) )
        {
        	driverId = new AqDriverId();
        	driverId.decodePackedData(bd);
        }
        
        if( 0 != ( ENC_DEC_FIELDS_REFID & encFields ) )
        {
        	refId = bd.readInt( 4 );
        }
        
        if( 0 != ( ENC_DEC_FIELDS_STAGE & encFields ) )
        {
        	stage = bd.readInt(1);
        }
        
        if( 0 != ( ENC_DEC_FIELDS_FUEL_LEVEL_BEFORE & encFields ) )
        {
            if( ALERT_FLAG_MASK == ( EVENT_TYPE_MASK & eventId  ) )
            {
                // alerts use FMS 0.4% per bit encoding
                fuelLevelBefore = bd.readInt( 1 ) * 0.4f;
            }
            else
            {
                // events use 2 byte encoding with 2 decimal resolution.  i.e. 0.0 .. 100.0
                fuelLevelBefore = bd.checkedReadFloat(FUEL_LEVEL_MIN, FUEL_LEVEL_RES, 2, -1 );
            }
        }
        if( 0 != ( ENC_DEC_FIELDS_FUEL_LEVEL_AFTER & encFields ) )
        {
            if( ALERT_FLAG_MASK == ( EVENT_TYPE_MASK & eventId ) )
            {
                // alerts use FMS 0.4% per bit encoding
                fuelLevelAfter = bd.readInt( 1 ) * 0.4f;
            }
            else
            {
                // events use 2 byte encoding with 2 decimal resolution.  i.e. 0.0 .. 100.0
                fuelLevelAfter = bd.checkedReadFloat(FUEL_LEVEL_MIN, FUEL_LEVEL_RES, 2, -1 );
            }
        }
        if( 0 != ( ENC_DEC_FIELDS_FUEL_LEVEL_CONFIRM & encFields ) )
        {
        	fuelLevelConfirm = bd.readInt( 1 ) * 0.4f;
        }

        if( 0 != ( ENC_DEC_FIELDS_TOTAL_FUEL_BEFORE & encFields ) )
        {
            totalFuelConsumedBefore = bd.readLong( 4 );
        }
        if( 0 != ( ENC_DEC_FIELDS_TOTAL_FUEL_AFTER & encFields ) )
        {
            totalFuelConsumedAfter = bd.readLong( 4 );
        }
        if( 0 != ( ENC_DEC_FIELDS_ONE_BYTE_VAL & encFields ) )
        {
            oneByteParam = bd.readInt(1);
        }
        if( 0 != ( ENC_DEC_FIELDS_DISTANCE & encFields ) )
        {
        	distance = bd.checkedReadFloat( 0, 0.1f, 2, -1 );
        }
        if( 0 != ( ENC_DEC_FIELDS_DURATION & encFields ) )
        {
            duration = bd.readInt( 2 );
       }
       if( 0 != ( ENC_DEC_FIELDS_SHORT_STRING_1 & encFields ) )
       {
    	   evtStringData = new String[3];
    	   evtStringData[0] = bd.readShortString();
       }
       if( 0 != ( ENC_DEC_FIELDS_SHORT_STRING_2_3 & encFields  ) )
       {
    	   if( null == evtStringData )
    	   {
    		   evtStringData = new String[3];
    		   evtStringData[0] = "";
    	   }
    	   evtStringData[1] = bd.readShortString();
    	   evtStringData[2] = bd.readShortString();
       }
       if( ENC_DEC_FIELDS_SECONDARY_TIMESTAMP == ( ENC_DEC_FIELDS_SECONDARY_TIMESTAMP & encFields ) )
       {
    	   secondaryTimeInMs = bd.readTimeInSecAsTimeInMs();
       }
    }

    /** Append the packed format for the given Event to the given byte encoder object */
    public void encodePackedData( String desc, ByteEncoder be, boolean isEncodeShiftId ) // throws Exception
    {
        if( ALERT_FLAG_MASK == ( EVENT_TYPE_MASK & eventId ) )
        {
            be.writeInt( 1, ALERT_VERSION_ID );
            be.setCfmsProtocolVersion( ALERT_VERSION_ID );
               
            CfmsConfigManifest cfg = new CfmsConfigManifest( true );
            cfg.encodePackedData( be );
            
            if( isEncodeShiftId )
            {
            	be.writeShortString( this.getShiftId() );
            }
        }
        
        be.writeInt( desc + ".eventId", 0, STATE_EVT_MAX, 1, eventId );
        
//        if( HLTH_EVENT_FLAG_MASK != ( eventId & EVENT_TYPE_MASK ))
//        {
//        	be.writeInt( desc + ".odometer", 0, AqConsts.ODOMETER_MAX_KM, 4, odometer );
//        }
//        
        be.writeLong( desc + ".time", 0, 0x7fffffff, 4, timeInMs / 1000 );
        
        if( null == location ) location = new AqLocation();
        location.encodePackedData( desc + ".location", be );

        // now the alert/event conditional fields
        short encFields = getEncodeDecodeFields( eventId );

        if( 0 != ( ENC_DEC_FIELDS_DRIVERID & encFields ) )
        {
            driverId.encodePackedData( desc, be );
        }
        
        if( 0 != ( ENC_DEC_FIELDS_REFID & encFields ) )
        {
        	if( refId < 0 ) refId = 0;
        	be.writeInt( 4, refId );
        }
        
        if( 0 != ( ENC_DEC_FIELDS_STAGE & encFields ) )
        {
        	if( ( stage < 1 ) || ( stage > 4) )
        	{
        		stage = 1;
        	}
        	
        	be.writeInt( 1, stage );
        }
        
        if( 0 != ( ENC_DEC_FIELDS_FUEL_LEVEL_BEFORE & encFields & encFields ) )
        {
        	encodeFuelLevel( be, fuelLevelBefore );      	
        }
        if( 0 != ( ENC_DEC_FIELDS_FUEL_LEVEL_AFTER & encFields ) )
        {
        	encodeFuelLevel( be, fuelLevelAfter );
        }
        if( 0 != ( ENC_DEC_FIELDS_FUEL_LEVEL_CONFIRM & encFields ) )
        {
        	encodeFuelLevel( be, this.fuelLevelConfirm );
        }
        
        if( 0 != ( ENC_DEC_FIELDS_TOTAL_FUEL_BEFORE & encFields ) )
        {
            be.writeLong( 4, totalFuelConsumedBefore );
        }
        if( 0 != ( ENC_DEC_FIELDS_TOTAL_FUEL_AFTER & encFields ) )
        {
            be.writeLong( 4, totalFuelConsumedAfter );
        }
        if( 0 != ( ENC_DEC_FIELDS_ONE_BYTE_VAL & encFields ) )
        {
            be.writeInt( 1, oneByteParam );
        }
        if( 0 != ( ENC_DEC_FIELDS_DISTANCE & encFields ) )
        {
            be.writeFloat( desc + ".speedingDistance", 0, 200000000, 0.1f, 2, distance );
        }
        if( 0 != ( ENC_DEC_FIELDS_DURATION & encFields ) )
        {
            be.writeInt( desc + ".speedingDurationSec", 2, duration );
       }
       if( 0 != ( ENC_DEC_FIELDS_SHORT_STRING_1 & encFields ) )
       {
    	   if( ( null != evtStringData ) && ( evtStringData.length > 0 ) )
    	   {
    		   be.writeShortString( evtStringData[0] );
    	   }
    	   else
    	   {
    		   be.writeShortString("");
    	   }
       }
       if( 0 != ( ENC_DEC_FIELDS_SHORT_STRING_2_3 & encFields  ) )
       {
    	   if( ( null != evtStringData ) && ( evtStringData.length > 1 ) )
    	   {
    		   be.writeShortString( evtStringData[1] );
    	   }
    	   else
    	   {
    		   be.writeShortString("");
    	   }
    	   
    	   if( ( null != evtStringData ) && ( evtStringData.length > 2 ) )
    	   {
    		   be.writeShortString( evtStringData[2] );
    	   }
    	   else
    	   {
    		   be.writeShortString("");
    	   }
       }
       if( ENC_DEC_FIELDS_SECONDARY_TIMESTAMP == ( ENC_DEC_FIELDS_SECONDARY_TIMESTAMP & encFields ) )
       {
    	   be.writeTimeInMsAsSecs( secondaryTimeInMs );
       }
    }
 
    private void encodeFuelLevel( ByteEncoder be, float fuelLevel )
    {
    	if( ALERT_FLAG_MASK == ( EVENT_TYPE_MASK & eventId ) )
    	{
    		int lb = (int) ( ( fuelLevel + 0.2f ) / 0.4f );
    		be.writeInt( "", 0, 250, 1, lb );
    	}
    	else
    	{
    		// events use 2 byte encoding with 2 decimal resolution.  i.e. 0.0 .. 100.0
            be.writeFloat( "", FUEL_LEVEL_MIN, FUEL_LEVEL_MAX, FUEL_LEVEL_RES, 2, fuelLevel );
    	}
    }
    
    private static Integer lock = new Integer( 0 );
    // TODO write unit test
//    public static AqEventAlert fromFile( String fileName )
//    {
//    	AqEventAlert retval = null;
//    	
//    	synchronized( lock )
//    	{
//    		InputStream is = AqFileUtils.openFileInputStream( fileName );
//
//    		if( null != is )
//    		{
//    			try
//    			{
//    				byte b[] = new byte[is.available()];
//    				is.read( b );
//
//                                //^^ALA=evtFileFrom:
//    				AqLog.getInstance().info( "^^ALA " + fileName + ", " + AqUtils.getHexData( b, 0, b.length ));
//    				ByteDecoder bd = new ByteDecoder( b );
//    				AqEventAlert e = new AqEventAlert();
//    				e.decodePackedData(bd, false);
//    				
//    				if( AqEventAlert.DRIVER_LOGON_EVENT_ID == e.getEventId() )
//    				{	
//    					// sneak some extra info on the driver logon event to be used in the 
//    					// health report.  This won't get encoded/decoded during the 
//    					// vPerf upload, but will be managed when going to/from the file
//    					// borrowing the "oneByteParam" to hold GPS/GPRS status at the time
//    					// the logon occurs.
//    					e.setOneByteParam( bd.readInt( 1 ) );
//    				}
//    			
//    				
//    				retval = e;
//    			}
//    			catch( Exception e )
//    			{
//    				//^^ALE=AqEventAlert.fromFile()
//    				AqLog.getInstance().error("^^ALE", e );
//    			}
//    			AqFileUtils.closeStream( is );
//    		}
//    	}
//    	return retval;
//    }
//    
//    // TODO write unit test
//    public void toFile( String baseFileName )
//    {
//    	String name = baseFileName;
//    	String newName = name + ".new";
//
//    	synchronized( lock )
//    	{
//            OutputStream os = AqFileUtils.openFileOutputStream( newName );
//
//            if( null == os )
//            {
//                //^^ALG=os is null attempting to write event to file
//                AqLog.getInstance().warn("^^ALG");
//            }
//            else
//            {
//                    
//                ByteEncoder be = new ByteEncoder();
//                try
//                {
//                    this.encodePackedData("", be);
//                }
//                catch( Exception ee )
//                {
//                    //^^ALH=AqEventAlert.toFile() encoding exception
//                    AqLog.getInstance().error("^^ALH");
//                    be = null;
//                }
//
//                if( null != be )
//                {
//    			
//                    if( AqEventAlert.DRIVER_LOGON_EVENT_ID == this.getEventId() )
//                    {
//                        // sneak some extra info on the driver logon event to be used in the 
//                        // health report.  This won't get encoded/decoded during the 
//                        // vPerf upload, but will be managed when going to/from the file
//                        // borrowing the "oneByteParam" to hold GPS/GPRS status at the time
//                        // the logon occurs.
//                        be.writeInt( 1, this.oneByteParam );
//                    }
//    			
//                    try 
//                    {
//                        byte b[] = be.getContent(); 
//
//                        //^^ALB=evtFileTo:
//                        AqLog.getInstance().info("^^ALB " + baseFileName + ", " + AqUtils.getHexData(b, 0, b.length ));
//                        os.write( b );
//                        AqFileUtils.closeStream( os );
//                        os = null;
//                        AqFileUtils.renameFile( newName,  name );
//                    } catch ( Exception e) 
//                    {
//                        //^^ALF=AqEventAlert.toFile() exception
//                        AqLog.getInstance().error("^^ALF", e );
//                    }
//                }
//                if( null != os ) AqFileUtils.closeStream( os );
//            }
//        }
//    }
//    
//    public void toFile( String dir, String baseName )
//    {
//    	toFile( dir + "/" + baseName );
//    }
 
}