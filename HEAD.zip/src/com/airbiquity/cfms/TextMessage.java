package com.airbiquity.cfms;

import java.io.IOException;

import com.airbiquity.aqlog.AqLog;
import com.airbiquity.exception.AqErrorException;
import com.airbiquity.util.AqUtils;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;

public class TextMessage {
	private long messageId = 0;
	private long parentMessageId = 0;
	private int messageFromType = 0;
	private byte[] messageFromRaw = {};
	private int messageToType = 0;
	private byte[] messageToRaw = {};
	private boolean isResponseRequired = false;
	private int priority = 0;
	private int messageContentId = 0;
	private String language = "eng";
	private int messageCodingScheme = 2;
	private String subject = new String();
	private String messageBody = new String();
	
	public long getMessageId() {
		return messageId;
	}
	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}
	public long getParentMessageId() {
		return parentMessageId;
	}
	public void setParentMessageId(long parentMessageId) {
		this.parentMessageId = parentMessageId;
	}
	public int getMessageFromType() {
		return messageFromType;
	}
	public void setMessageFromType(int messageFromType) {
		this.messageFromType = messageFromType;
	}
	public byte[] getMessageFromRaw() {
		return messageFromRaw;
	}
	
	public void setMessageFromRaw(byte[] messageFrom) {
		byte[] from = messageFrom;
		if( null == from ) from = new byte[0];
		this.messageFromRaw = from;
	}

	public int getMessageToType() {
		return messageToType;
	}
	public void setMessageToType(int messageToType) {
		this.messageToType = messageToType;
	}
	public byte[] getMessageToRaw() {
		return messageToRaw;
	}
	
	public void setMessageToRaw(byte[] messageTo) {

		byte[] to = messageTo;
		if( null == to ) to = new byte[0];
		this.messageToRaw = to;
	}

	public boolean isResponseRequired() {
		return isResponseRequired;
	}
	public void setResponseRequired(boolean isResponseRequired) {
		this.isResponseRequired = isResponseRequired;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public int getMessageContentId() {
		return messageContentId;
	}
	public void setMessageContentId(int messageContentId) {
		this.messageContentId = messageContentId;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public int getMessageCodingScheme() {
		return messageCodingScheme;
	}
	public void setMessageCodingScheme(int messageCodingScheme) {
		this.messageCodingScheme = messageCodingScheme;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMessageBody() {
		return messageBody;
	}
	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}
	
	/** Translates this object into a CMessage which will be used to transmit the message to Choreo.
	 * 
	 * @return
	 * @throws AqErrorException 
	 * @throws IOException 
	 */
	public void encodePackedData( ByteEncoder be ) throws IOException, AqErrorException
	{
		if( 0 == this.getMessageId() )
		{
			this.setMessageId( AqUtils.getGuid() );
		}

		be.writeLong( 8, this.getMessageId() );
		be.writeLong( 8, this.getParentMessageId() );

		be.writeInt(1, this.getMessageFromType() );
		be.writeBytes( this.getMessageFromRaw() );
		
		be.writeInt( 1, this.getMessageToType() );
		be.writeBytes( this.getMessageToRaw() );
		
		int bitFlags = this.getPriority() & 0x07;
		if( this.isResponseRequired() )
		{
			bitFlags |= 0x08;
		}
		be.writeInt( 1, bitFlags );
		
		int contentId = this.getMessageContentId();
		if( ( contentId < 0 ) || ( contentId > 5 ) )
		{
			contentId = 0;
		}
		
		be.writeInt( 1, contentId );

		// insure that language is a 3 letter string ... should get sanity checked against the ISO 639-2 as well ... later. 
		String lang = AqUtils.rightString("   " + this.getLanguage(), 3 );
		be.writeString( lang );
		
		int cs = this.getMessageCodingScheme();
		if( ( cs < 0 ) || ( cs > 5 ) )
		{
			cs = 2; // assume utf-8 as default for now
		}
		
		be.writeInt( 1 , cs );
		be.writeShortString( this.getSubject() );
		be.writeLongString( this.getMessageBody() );
	}
	
	
	public void decodePackedData( ByteDecoder bd )
	{
		try
		{
			this.setMessageId( bd.readLong(8) );
			this.setParentMessageId( bd.readLong(8) );
			int fromType = bd.readInt(1);
			this.setMessageFromType( fromType );
			if( ( 1 == fromType ) || ( 3 == fromType ) )
			{
				AqDriverId did = new AqDriverId();
				did.decodePackedData(bd);
				this.setMessageFromRaw( did.encodeRawBytes() );
			}
			else 
			{
				this.setMessageFromRaw( AqUtils.stringToShortStringRawBytes( bd.readShortString() ) );
			}

			int toType = bd.readInt(1);
			this.setMessageToType( toType );
			if( ( 1 == toType ) || ( 3 == toType ) )
			{
				AqDriverId did = new AqDriverId();
				did.decodePackedData(bd);
				this.setMessageToRaw( did.encodeRawBytes() );
			}
			else if( 2 == toType )
			{
				// a zero length string if it is to a vehicle as the OBU id is in the header.
				this.setMessageToRaw( AqUtils.stringToShortStringRawBytes( bd.readShortString() ) );
			}
			else
			{
				this.setMessageToRaw( AqUtils.stringToShortStringRawBytes( bd.readShortString() ) );
			}

			int bitFlags = bd.readInt(1);
			this.setPriority( bitFlags & 0x07 );
			this.setResponseRequired( ( 0x08 == ( bitFlags & 0x08 ) ) ? true : false);

			this.setMessageContentId( bd.readInt(1));

			// insure that language is a 3 letter string ... should get sanity checked against the ISO 639-2 as well ... later. 
			this.setLanguage(bd.readString( 3 ));

			this.setMessageCodingScheme( bd.readInt(1));

			this.setSubject( bd.readShortString() );
			this.setMessageBody( bd.readLongString() );
		}
		catch( Exception e )
		{
			AqLog.getInstance().error("Unable to decode TextMessage", e );
		}
	}
	
}
