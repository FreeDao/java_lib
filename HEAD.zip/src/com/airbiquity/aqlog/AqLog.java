/* ****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2009 by Airbiquity.  All rights reserved.
 *
 * ***************************************************************************
 */
package com.airbiquity.aqlog;

import android.util.Log;

public class AqLog implements IAqLog
{
    private static final IAqLog iLog = new AqLog();
    private static final String TAG = "AqLog";
    public static IAqLog getInstance()
    {
        return iLog;
    }

    public void error( Object o, Throwable t ) 
    {
    	if( o instanceof String )
    	{
    		Log.e( TAG, (String) o, t );
    	}
    }
    
    public void error( Object o  )
    {
    	if( o instanceof String )
    	{
    		Log.e( TAG, (String) o );
    	}
    }
    
    public void warn( Object o, Throwable t ) 
    { 
    	if( o instanceof String )
    	{
    		Log.w( TAG, (String) o, t );
    	}
    }
    
    public void warn( Object o  ) 
    { 
    	if( o instanceof String )
    	{
    		Log.w(TAG, (String)  o ); 
    	}
    }

    public void info( Object o, Throwable t ) 
    { 
    	if( o instanceof String )
    	{
    		Log.i( TAG, (String) o, t );
    	}
    }
    
    public void info( Object o  ) 
    { 
    	if( o instanceof String )
    	{
    		Log.i( TAG, (String) o );
    	}
    }

    public void debug( Object o, Throwable t ) 
    { 
    	if( o instanceof String )
    	{
    		Log.d( TAG, (String) o, t );
    	}
    }
    
    public void debug( Object o  ) 
    { 
    	if( o instanceof String )
    	{
    		Log.d( TAG, (String) o );
    	}
    }

    public void trace( Object o, Throwable t ) 
    { 
    	if( o instanceof String )
    	{
    		Log.v( TAG, (String) o, t );
    	}
    }
    
    public void trace( Object o  ) 
    { 
    	if( o instanceof String )
    	{
    		Log.v( TAG, (String) o );
    	}
    }

    public boolean isInfoEnabled() 
    { 
    	return true; 
    }
}
