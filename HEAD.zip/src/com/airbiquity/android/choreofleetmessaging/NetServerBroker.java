/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
*****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Timer;
import java.util.TimerTask;

import com.airbiquity.util.IniProperties;

import android.os.AsyncTask;
import android.util.Log;

/**
 * Provides a network-based broker for the Choreo Message services. Expects
 * the data to be streamed using a pattern-based packet signaler protocol.
 * 
 * @author Jack William Bell
 */
public class NetServerBroker extends PatternExtractor implements iCMessageBroker {

	//
	// Declarations.
	//
	
	protected static final String TAG = "NetServerBroker";
	protected static final int DEFAULT_SOCKET = 6502;
	protected static final int LISTEN_BACKLOG = 1; // Force to only one connection allowed.
	protected static final int CHUNK_SIZE = 512;
	
	/**
	 * Configuration key to use for configuring the local address (defaults to none).
	 */
	public static final String INI_KEY_LOCAL_ADDRESS = "nsb_local_address";
	/**
	 * Configuration key to use for configuring the port (defaults to 6502).
	 */
	public static final String INI_KEY_PORT = "nsb_port";
	
	//
	// Local Storage.
	//
	
	Socket mSocket = null;
	ServerSocket mServer = null;
	InetAddress mLocalAddress = null;
	int mPort = 0;
	Connector mConn = null;
    
	//
	// Local Classes.
	//
	
	public class Connector extends AsyncTask<ServerSocket, String, Socket> {

		@Override
		protected Socket doInBackground(ServerSocket... params) {
			ServerSocket svr = params[0];
			Socket skt = null;
			
			try {
				// Wait on blocking operation for a connection.
				skt = svr.accept();
				// TODO: Determine if we want to do this for certain. (JWB)
				skt.setKeepAlive(true);
			} catch (IOException e) {
				skt = null;
			}
			
			return skt;
		}
		
		/* Not used.
		@Override
	    protected void onProgressUpdate(String... progress) {
			
		}
		*/
		
		@Override
	    protected void onCancelled() {
			close_mSocket();
			Log.i(TAG, "Client cancelled.");			
		}
		
		@Override
	    protected void onPostExecute(Socket result) {
			mSocket = result;
			if( null != mSocket )
			{
				try {
					mSocket.setSoTimeout( 20000 );
				} catch (SocketException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			Log.i(TAG, "Client connected.");
		}
	}
    
	//
	// Static Functions.
	//
    
	//
	// Constructors.
	//
	
	//
	// Constructors.
	//
	
	public NetServerBroker() {
		super();
		Log.d(TAG,"Instantiating NetServiceBroker");
	}
	
	//
	// Private Instance Methods.
	//
	
	private void startConnect() {
		Log.i(TAG, "Starting connection.");
		
		close_mSocket();
		mConn = new Connector();
		mConn.execute(mServer);
	}
    
	private void close_mSocket()
	{
		if( null == mSocket )
		{
			try
			{
				mSocket.close();
			}
			catch( Exception e )
			{
				
			}
			mSocket = null;
		}
	}
	
	//
	// Public Instance Methods.
	//
	
	@Override
	public void initialize(String configurationString) {
		super.initialize(configurationString);
		
		// Get the passed configuration, if possible.
		IniProperties config = null;
		try {
			config = new IniProperties(configurationString);
		} catch (IOException e) {
			// TODO: Determine how we want to handle this. (JWB)
		}

		// TODO: Figure out if we need this at all for binding to the USB network
		// connection. (JWB).  
		mLocalAddress = null; // Default value...

		// TODO: The following 4 lines commentedout on 2012-09-18 to allow inbound connections.  Figure out why! (DQ)
//		try {
//			mLocalAddress = InetAddress.getByName(config.getProperty(INI_KEY_LOCAL_ADDRESS));
//		} catch (Exception e) {
//			// TODO: Determine how we want to handle this. (JWB)
//		}
		
		/*
		try {
			//mLocalAddress = InetAddress.getByName(AqUtils.getLocalIpAddress());
			mLocalAddress = InetAddress.getByName("127.0.0.1");
		} catch (UnknownHostException e) {
			mLocalAddress = null;
		}
		Log.i(TAG, "Address is: " + AqUtils.getLocalIpAddress());
		 */
		
		mPort = DEFAULT_SOCKET;
		try {
			mPort = Integer.parseInt(config.getProperty(INI_KEY_PORT));
		} catch (Exception e) {
			// TODO: Determine how we want to handle this. (JWB)
		}
	}

	@Override
	public boolean start() throws NoTransportException {
		boolean result = false;
		Log.i(TAG, "Starting.");

		try {
			mServer = new ServerSocket(mPort, LISTEN_BACKLOG, mLocalAddress);
			startConnect();
			result = true;
			Log.d("NetServerBroker", "bound to port: " + mPort );
		} catch (Exception ex) {
			Log.e("NetServerBroker", "NetServerBroker start failed, " + mLocalAddress + ":" + mPort, ex);
			mServer = null;
			close_mSocket();
			throw new NoTransportException(ex);
		}
		
		return result;
	}

	private boolean lastConnected = false;
	private boolean lastInputShutdown = false;
	private boolean lastOutputShutdown = false;
	private Socket lastSocket = null;
	
	@Override
	public boolean isConnected() {
		boolean isConnected =false;
		boolean isInputShutdown = false;
		boolean isOutputShutdown = false;
		if( null != mSocket )
		{
			isConnected = mSocket.isConnected();
			isInputShutdown = mSocket.isInputShutdown();
			isOutputShutdown = mSocket.isOutputShutdown();
		}

		if( ( mSocket != lastSocket ) ||
			( lastConnected != isConnected ) ||
			( lastInputShutdown != isInputShutdown ) ||
			( lastOutputShutdown != isOutputShutdown ) )
		{
			Log.d(TAG,"isConnected()  mSocket,isConected,isInputShutdown,isOutputShutdown:" + mSocket + "," + isConnected + "," + isOutputShutdown + "," + isInputShutdown );
		}
		
		lastSocket = mSocket;
		lastConnected = isConnected;
		lastInputShutdown = isInputShutdown;
		lastOutputShutdown = isOutputShutdown;
		return ((mSocket != null) && mSocket.isConnected() &&
				!mSocket.isInputShutdown() && !mSocket.isOutputShutdown());
	}

	@Override
	public CMessage process(CMessage dataToSend) throws NoTransportException, NoConnectionException {
		if (mServer == null || mServer.isClosed()) {
			mServer = null;
			close_mSocket();
			throw new NoTransportException();
		}
		
		if (!isConnected()) {
			Log.i(TAG, "Connection lost.");
			startConnect();
			throw new NoConnectionException();
		}
		
		CMessage result = null;

		try {
			InputStream in;
			OutputStream out;
			byte[] chunkRead = new byte[CHUNK_SIZE];
			byte[] chunk;
			int bytesRead;
			
			// If we have anything outgoing, send it on its way.
			if ( (dataToSend != null) && ( null != dataToSend.packet) )  {
				out = mSocket.getOutputStream();
				Log.d(TAG,"out:" + out );
				Log.d(TAG, "dataToSend: " + dataToSend );

				out.write(prepareMessagePacket(dataToSend.packet));
			}
			
			// If we have anything incoming, read all of 
			// it and add it to the internal message pattern 
			// checker.
			in = mSocket.getInputStream();
			while (in.available() > 0)  {
				bytesRead = in.read(chunkRead);
				if (bytesRead > 0) {
					if (bytesRead < CHUNK_SIZE) {
						chunk = new byte[bytesRead];
						System.arraycopy(chunkRead, 0, chunk, 0, bytesRead);
					}
					else {
						chunk = chunkRead;
					}
					this.addChunk(chunk);
				}
			}
			
			// If we found any messages, return the oldest one.
			// NOTE: It is possible that incoming messages might 
			// stack up faster than we send them out this 
			// way, but we should manage to empty the queue within
			// a few calls to process() more often than not. (JWB) 
			chunk = this.pullMessagePacket();
			if (chunk != null) {
				result = new CMessage(chunk);
			}
		} catch (Exception e) {
			// TODO Determine if this is the best way to handle this. (JWB)
			Log.e(TAG, "Connection lost.", e);
			startConnect();
			throw new NoConnectionException(e);
		}
		
		return result;
	}

	@Override
	public void stop() {
		Log.i(TAG, "Stopping.");
		if (isConnected()) {
			try {
				mSocket.close();
			} catch (Exception e) {
				// Ignore.
			}
		}
		
		if (mServer != null && !mServer.isClosed()) {
			try {
				mServer.close();
			} catch (Exception e) {
				// Ignore.
			}
		}
		
		mServer = null;
		mSocket = null;
	}

}
