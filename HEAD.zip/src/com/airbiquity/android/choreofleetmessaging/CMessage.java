/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
*****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

/* Test Code
	public static class MyMessage extends CMessage {
		public static int MY_MESSAGE_ID = 127;
		public static final boolean isRegistered = CMessage.registerFactoryClass(MY_MESSAGE_ID, MyMessage.class);
		public MyMessage(byte[] packet) {
			super(packet);
		}
		
		public Byte getTheOneByteOfData() {
			byte[] payload = this.getPayloadBytes();
			if (payload != null && payload.length > 0) {
				return payload[0];
			}	
			return null;
		}
	}
	
	public static void testCMessageSubclassing() {
		byte[] myPacket = CMessage.buildMessagePacket(new byte[]{1}, 127, false);
		byte[] invalidPacket = CMessage.buildMessagePacket(new byte[]{2}, 120, false);
		
		if (!MyMessage.isRegistered) System.out.println("MyMessage not registered for CMessage factory.");
	
		MyMessage testMessage = null;
		testMessage = (MyMessage) CMessage.messageFactory(myPacket);
		if (testMessage == null) System.out.println("Test 1 failed.");
		testMessage = (MyMessage) CMessage.messageFactory(myPacket, MyMessage.class);
		if (testMessage == null) System.out.println("Test 2 failed.");
		testMessage = (MyMessage) CMessage.messageFactory(invalidPacket);
		if (testMessage != null) System.out.println("Test 3 failed.");
		testMessage = (MyMessage) CMessage.messageFactory(invalidPacket, MyMessage.class);
		if (testMessage != null) System.out.println("Test 4 failed.");
		CMessage aMessage = (MyMessage) CMessage.messageFactory(myPacket);
		System.out.println("The messsage is a " + aMessage.getClass().getCanonicalName());
		testMessage = (MyMessage) aMessage;
		System.out.println("The messsage has one byte of data: " + testMessage.getTheOneByteOfData());		
	} 
 */

import java.io.IOException;
import java.io.InputStream;

import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;

import com.airbiquity.aqlog.AqLog;
import com.airbiquity.util.ByteDecoder;
import com.airbiquity.util.ByteEncoder;
import com.airbiquity.util.AqUtils;

/**
 * <p>Represents a single Choreo message. Acts as a base class for custom message 
 * classes. Provides methods to access the components of a message. Exposes the
 * actual message packet as a byte array containing the entire message.</p>
 * 
 * <p>CMessage instances are 'invariants': 
 * all constructors make copies of passed values and all message data 
 * is read-only, so it is safe to share instances of CMessage between threads.</p>
 * 
 * <p>Constructors are provided to create CMessage instances from various
 * data sources. Getters are provided to pull out specific values from the 
 * message. </p>
 * 
 * <p>Protected static helper functions are provided to manage CMessage data in 
 * Bundles. Protected static helper functions are provided to manipulate
 * the values of a byte array containing Choreo Message data.</p>
 * 
 * <h3>Sub-classing</h3>
 * 
 * <p>You should use CMessage as a base class, creating sub-classes for each
 * Choreo Message ID your application requires. CMessage provides a set of 
 * functions to register your custom sub-class with a factory and then 
 * create new instances from raw packets via a factory method. (More 
 * on this below.)</p>
 * 
 * <p>When sub-classing this class, at a minimum you should provide 
 * one or more custom constructors and custom getters for the message 
 * payload values your class supports. </p>
 * 
 * <p><b>NOTE:</b> Any message payload values may be defaulted, including 
 * defaulting to null, if appropriate.</p>
 * 
 * <p>Example of sub-classing CMessage. Note the use of the 
 * <code>CMessage.registerFactoryClass()</code> function to set the static value 
 * <code>isRegistered</code> in the class and to register the class with 
 * the CMessage factory list:</p>
 * <pre><blockquote>
public static class MyMessage extends CMessage {
	public static int MY_MESSAGE_ID = 127;
	public static final boolean isRegistered = CMessage.registerFactoryClass(MY_MESSAGE_ID, MyMessage.class);
	public MyMessage(byte[] packet) {
		super(packet);
		// TODO: Check message ID of packet and throw exception if it 
		// doesn't match MY_MESSAGE_ID.
	}
	public Byte getTheOneByteOfData() {
		byte[] payload = this.getPayloadBytes();
		if (payload != null && payload.length > 0) {
			return payload[0];
		}	
		return null;
	}
}
 * </blockquote></pre>
 * 
 * <p>Once a subclass has been created and registered (as above) you can easily create 
 * new instances of it via the <code>CMessage.messageFactory()</code> function. This function 
 * also allows you to create instances of any class which sub-classes CMessage, without
 * knowing in advance which class corresponds with the message ID of the packet you have. 
 * (So long as that class is registered with 
 * CMessage as described above). In cases where you don't know the class type at runtime 
 * you can still use it as a CMessage instance and then use reflection to determine the 
 * actual class type. For example:</p>
 * <pre><blockquote>
CMessage aMessage = CMessage.messageFactory(myPacket);
if (aMessage.getClass().getCanonicalName() == "com.mydomain.mypackage.MyMessage") {
	MyMessage myMsg = (MyMessage) aMessage;
	if (myMsg.getTheOneByteOfData() == 1) {
		doSomething();
	}
}
 * </blockquote></pre>
 * 
 * <p>Another way to use the <code>CMessage.messageFactory()</code> function is to pass 
 * in the class you expect the message packet to be. If the class registered for the 
 * message ID of the packet doesn't match, then you get back a null. For example:</p>
 * <pre><blockquote>
MyMessage myMsg = (MyMessage) CMessage.messageFactory(invalidPacket, MyMessage.class);
if (myMsg != null)  {
	if (myMsg.getTheOneByteOfData() == 1) {
		doSomething();
	}
}
 * </blockquote></pre>
 * 
 * @author Jack William Bell
 *
 */
public class CMessage {
	
	//
	// Declarations.
	//
    public static final int PRIORITY_TO_CHOREO_LOW    = 0x01; // used to fetch configuration updates and/or upload logs
    public static final int PRIORITY_TO_CHOREO_TXT_MSG_REQUEST = 0x02; // used for most messages being exchanged between choreo/ICS
    public static final int PRIORITY_TO_CHOREO_NORMAL = 0x04; // used for most messages being exchanged between choreo/ICS
    public static final int PRIORITY_TO_OBU           = 0x06; // used by OBU to send status messages to OBU.  Anyghing else? 
    public static final int PRIORITY_ACK              = 0x08; // used to insure that ACKS and response messages go first in order to satisfy retransmission logic as quickly as possible.  Acks shoudl be fire/forget (retries = 0)
    // other priorities TBD?
	
	protected static final String TAG = "CMessage";
	protected static final String MSG_PACKET_KEY = "msg_packet";
	protected static final String MSG_REFID_KEY = "msg_refid";
    
	//
	// Constants taken from FROM AqCfmsConfigVersion.java
	//
    protected static final int MSG_VER_IDX =  2;
    protected static final int MSG_MSB_DEVICE_ID_IDX = 3;
    protected static final int MSG_TIME_IDX = 6;
    protected static final int MSG_TRANSID_IDX = 10;
    protected static final int MSG_MSB_LEN_IDX = 18;
    protected static final int MSG_HEADER_SIZE = 22;

    protected static final int MSG_VERSION = 2;
    
    protected static final byte ASCII_I = 0x49;
    protected static final byte ASCII_SPACE = 0x20;
    protected static final byte ASCII_TILDE = 0x7E;
	
	//
	// Public storage.
	//
	
	/**
	 * The data packet of the CMessage. May be null.
	 */
	public final byte[] packet;
	private long reference_id;
	
	@SuppressWarnings("rawtypes")
	private static SparseArray<Class> FactoryClasses = new SparseArray<Class>();
	
	//
	// Static Functions.
	//
	
	/**
	 * Creates an instance of CMessage using the passed message packet and Class, where
	 * the Class is CMessage or a sub-class of CMessage.
	 * 
	 * @param packet
	 * @param cls
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected static CMessage makeMessageFromClass(byte[] packet, @SuppressWarnings("rawtypes") Class cls) {
		CMessage result = null;
		
		if (cls != null) {
			try {
				result = (CMessage) cls.getConstructor(new Class[]{byte[].class}).newInstance(packet);
			}
			catch (Exception ex) {
				
			}
		}
		
		return result;
	}
	
	/**
	 * Creates an instance of CMessage using the passed message packet, using the Class
	 * associated with the message ID of the packet. Returns null if no Class is 
	 * associated with that message ID.
	 * 
	 * @param packet
	 * @return
	 */
	public static CMessage messageFactory(byte[] packet) {
		return makeMessageFromClass(packet, 
				FactoryClasses.get(CMessage.extractMessageId(packet)));
	}
	
	/**
	 * Creates an instance of CMessage using the passed bundle, using the Class
	 * associated with the message ID of the packet in the bundle. Returns null if 
	 * no Class is associated with that message ID or the bundle does not contain
	 * a message packet.
	 * 
	 * @param bundle
	 * @return
	 */
	public static CMessage messageFactory(Bundle bundle) {
		return messageFactory(CMessage.extractMessagePacketFromBundle(bundle));
	}
	
	/**
	 * Creates an instance of the passed class (which must sub-class CMessage) using 
	 * the passed message packet. Returns null if a different Class is associated with 
	 * that message ID or if no Class is associated with that message ID.
	 * 
	 * @param packet
	 * @param forClass
	 * @return
	 */
	public static CMessage messageFactory(byte[] packet, @SuppressWarnings("rawtypes") Class forClass) {
		@SuppressWarnings("rawtypes")
		Class factoryClass = FactoryClasses.get(CMessage.extractMessageId(packet));
		if (forClass == factoryClass) {
			return makeMessageFromClass(packet, forClass);
		}
		
		return null;
	}
		
	/**
	 * Creates an instance of the passed class (which must sub-class CMessage) using 
	 * the message ID of the packet in the bundle. Returns null if a different Class 
	 * is associated with that message ID or if no Class is associated with that message 
	 * ID or the bundle does not contain a message packet.
	 * 
	 * @param bundle
	 * @param forClass
	 * @return
	 */
	public static CMessage messageFactory(Bundle bundle, @SuppressWarnings("rawtypes") Class forClass) {
		return messageFactory(CMessage.extractMessagePacketFromBundle(bundle), forClass);
	}
	
	/**
	 * <p>Adds a Class to the list of CMessage factories and associates it with the passed message ID,
	 * where the Class is CMessage or a sub-class of CMessage. Returns true if no other Class is registered
	 * for that message ID, otherwise false.</p>
	 * 
	 * <p>Sub-classes should call this method against a static member of the class to register themselves.
	 * For example:</p>
	 * <pre><blockquote>
	 * public static final boolean isRegistered = CMessage.registerFactoryClass(MY_MESSAGE_ID, MyMessage.class);
	 * </blockquote></pre>
	 * @param messageId
	 * @param factoryClass
	 * @return
	 */
	public static boolean registerFactoryClass(int messageId, @SuppressWarnings("rawtypes") Class factoryClass) {
		if (FactoryClasses.get(messageId) == null) {
			FactoryClasses.setValueAt(messageId, factoryClass);
			return true;
		}
		
		return false;
	}
	
	/**
	 * Removes the Class associated with the passed message ID (if any) from
	 * the list of CMessage factories.
	 * 
	 * @param messageId
	 */
	public static void unRegisterFactoryClass(int messageId) {
		FactoryClasses.remove(messageId);
	}
	
	/**
	 * Creates a Bundle containing the passed message packet. 
	 * 
	 * @param packet
	 * @return
	 */
	public static Bundle makeCMessageBundle(byte[] packet, long refid) {
		Bundle b = new Bundle();
		injectCMessageIntoBundle(b, packet, refid );
		return b;
	}
	
	/**
	 * Injects the passed message packet into the passed bundle using the following key(s).
	 * <ul>
	 * <li><b>msg_packet</b> The data payload of the Choreo message.</li>
	 * </ul>
	 * 
	 * @param bundle
	 * @param packet
	 * @param refid
	 */
	public static void injectCMessageIntoBundle(Bundle bundle, byte[] packet, long refid) {
		if (bundle != null && packet != null) {
			// TODO: Replace string constants with resources.
			// TODO: Determine if we need to clone the message payload.
			bundle.putByteArray(MSG_PACKET_KEY, packet);
			bundle.putLong(MSG_REFID_KEY, refid);
			
		}
	}
	
	/**
	 * Extracts a message packet from a bundle, if the bundle contains a
	 * byte array with the correct key value(s). Expects the following key(s):
	 * <ul>
	 * <li><b>msg_packet</b> The data payload of the Choreo message.</li>
	 * </ul>
	 * 
	 * @param bundle
	 * @return
	 */
	public static byte[] extractMessagePacketFromBundle(Bundle bundle) { 
		if (bundle != null) {
			// TODO: Replace string constants with resources. (JWB)
			// TODO: Determine if we need to clone the message payload. (JWB)
			return bundle.getByteArray(MSG_PACKET_KEY);			
		}
		
		return null;
	}

	public static long extractReferenceIdFromBundle(Bundle bundle) { 
		if (bundle != null) {
			return bundle.getLong(MSG_REFID_KEY);			
		}
		
		return 0;
	}
	
	/**
	 * Creates a CMessage instance from the passed bundle object.
	 * 
	 * @param bundle
	 * @return
	 */
	public static CMessage makeCMessageFromBundle(Bundle bundle) { 
		if (bundle != null) {
			CMessage cm = new CMessage(extractMessagePacketFromBundle(bundle));
			cm.reference_id = extractReferenceIdFromBundle(bundle);
			byte[] b = cm.packet;
			if( null == b ) b = new byte[0];
			//AqLog.getInstance().debug("fromBundle() refid: " + cm.reference_id + "data: " + AqUtils.getHexData( b, 0, b.length ));
			return cm;
		}
		return null;
	}
	
	/**
     * Extracts the message ID from the passed data packet or header.
     * 
	 * @param header
	 * @return
	 */
	public static int extractMessageId(byte header[]) {
		if (header[0] < 0){
			return (AqUtils.twoBytesToUnsignedInt(header[0], header[1]));
		}
		
		return header[0];
	}
	
    /**
     * Helper function that returns the number of bytes in the 
     * message header. Bytes following the header in the packet
     * are the payload.
     * 
     * @param packet
     * @return
     */
	protected static int messageHeaderSize( byte[] packet )
    {
        return headerStartOffset(packet) + MSG_HEADER_SIZE;
    }
    
	/**
	 * Helper function that returns the starting offset to use 
	 * for a message data packet, based on whether the Message ID
	 * value is one or two bytes. 
	 * 
	 * @param data
	 * @return '0' if a one byte Message ID, otherwise '1'.
	 */
	protected static int headerStartOffset(byte data[]) {
		// Currently we don't handle two byte message ID's correctly!
		//return (data[0] < 0)? 0:1;
		return 0;
	}

	/**
	 * Helper function to generate the bytes for a Message ID.
	 * 
     * <p><b>NOTE:</b> This function mostly exists to document how a message ID 
     * is formatted. The various 'make message' routines use a different 
     * method. Also note the differences between this function and 
     * AqUtils.unsignedIntToByteArray(), which does something similar. (JWB)</p> 
	 * 
	 * @param messageID
	 * @return A byte array containing one or two bytes.
	 * 
	 * @see com.airbiquity.util.AqUtils.unsignedIntToByteArray
	 * @see headerStartOffset
	 */
	protected static byte[] makeMessageIdBytes(int messageID) throws InvalidChoreoMessageId {	
		byte[] result, converted;
		
		if (messageID < 0 || messageID >= 32767) throw new InvalidChoreoMessageId(); // Not in range.
		
		converted = AqUtils.unsignedIntToByteArray(messageID);
		
		if (converted == null) throw new InvalidChoreoMessageId(); // Didn't convert for some reason.
		
		if (converted[0] != 0) {
			result = converted; // Two byte ID.
			result[0] |= (1 << 8); // Set the high bit to indicate it is a two byte ID.
			// NOTE: (Set a bit) myByte |= 1 << bit; (Clear a bit) myByte &= ~(1 << bit); 
			// (Toggle a big) myByte ^= 1 << bit;
		}
		else {
			result = new byte[1]; // One byte ID.
			result[0] = converted[1];
		}
			
		return result;        
	}
	
	/**
	 * Helper function to generate the bytes for the device ID.
	 * 
	 * @return A byte array containing five bytes.
	 */
	protected static byte[] makeDeviceIdBytes()
    {
        byte [] result = null;
        
        // TODO: Figure out how to do this properly for Android. ANDROID_ID is a possible value, but
        // it returns as a 64-bit value encoded in a string and is not reliable, especially in 
        // Android v2.2. android.os.Build.SERIAL is another possible, but it is an alpha=numeric string 
        // and is not available before Android v2.3. (JWB)
        // Old code:         
        //Properties props = AqProperties.getProperties();
        //int obuId = parseInteger("obu_id_s", props.getProperty( AqProperties.KEY_CFMS_OBU_ID, "0" ), 0 ); 
        
        int deviceId = 1;
        
        int i;
        result = new byte[5];
        result[0] = ASCII_I;
        result[1] = MSG_VERSION;

        int tmpDeviceId = deviceId;
        for( i=4;i>=2;i-- )
        {
            result[i] = (byte) ( tmpDeviceId & 0xff );
            tmpDeviceId = tmpDeviceId >> 8;
        }

        return result;
    }
    
    /** 
     * Build a Message header with the given attributes.
     *
     *  @param id The Message message ID to be associated with this message
     *  @param sz The number of bytes in rawData to put into the message
     *  @param compressed Compression indicator.  When set to true, indicates that the contents of rawData[] is compressed.
     *  @param transid The Message transaction id to be placed into the Message message header
     *
     *  @return A byte array containing the Message header.
     */
	protected static byte[] buildMessageHeader( int id, int sz, boolean compressed, long transId ) 
    {
        ByteEncoder byteEncoder = new ByteEncoder();
        long tstamp = 0;

        // Currently we don't handle two byte message ID's correctly!
        if (id > 127) throw new IllegalArgumentException("ID value must be less than 128, is " + id);
        
        byteEncoder.writeInt( 1, id );						// Message command

        // populate the 0x49, device ID (3 bytes), and default message version ( 5 bytes total )
        byteEncoder.writeBytes( makeDeviceIdBytes() );
		
        tstamp = AqUtils.getRtcTimeInMs();
        byteEncoder.writeLong( 4, tstamp / 1000 ); // Timestamp in seconds since 01/01/70
        
        byteEncoder.writeLong( 8, transId );				// Sequence number
		
        /*
        **  Fill in the payload length.  The MSB bit represents compression.
        **  
        */
        int tmpSz = sz;
        if( compressed )
        {
        	tmpSz = tmpSz | 0x80000000;
        }

        byteEncoder.writeInt( 4, tmpSz );
        return byteEncoder.getContent();
    }

    /** 
     * Build a Message header with the given attributes.  A unique transaction ID will be obtained for this
     *  message from AqGuidGenerator.
     *
     *  @param id The Message message ID to be associated with this message
     *  @param sz The number of bytes in rawData to put into the message
     *  @param compressed Compression indicator.  When set to true, indicates that the contents of rawData[] is compressed.
     *
     *  @return A byte array containing the Message header.
     */
    protected static byte[] buildMessageHeader( int id, int sz, boolean compressed ) 
    {
        long transId = AqUtils.getGuid();

        return buildMessageHeader( id, sz, compressed, transId );
    }

    /** 
     * Build a Message header with the given attributes.  A unique transaction ID will be obtained for this
     *  message from AqGuidGenerator.  The Message header size attribute will be determined by the querying the
     *  filesystem for the size of the file named filename.
     *
     *  @param filename The filename which contains the payload to be transmitted via the Message protocol.
     *  @param id The Message message ID to be associated with this message
     *  @param compressed Compression indicator.  When set to true, indicates that the contents of rawData[] is compressed.
     *
     *  @return A byte array containing the Message header.
     */
    protected static byte[] buildMessageHeader( InputStream fis, int id, boolean compressed ) 
    {
    	int totalBytes = 0;
    	try {
			totalBytes = fis.available();
		} catch (IOException e) {
			// Do nothing.
		}
    	return buildMessageHeader( id, totalBytes, compressed );
    }
    
    /** 
     * Build a Message packet with the given attributes and payload data.
     *
     *  @param rawData An array of bytes that make up the payload
     *  @param id The Message message ID to be associated with this message
     *  @param compressed Compression indicator.  When set to true, indicates that the contents of rawData[] is compressed.
     *  @param transaction The Message transaction id to be placed into the Message message header
     *
     *  @return A byte array containing the Message packet.
     */
    public static byte[] buildMessagePacket( byte[] rawData, int id, boolean compressed, long transaction ) 
    {
        ByteEncoder byteEncoder = new ByteEncoder();
		int rawDataSz = 0;
	
		if( null != rawData ) {
		    rawDataSz = rawData.length;
		}
	
		byte[] MessageHeader = buildMessageHeader( id, rawDataSz, compressed, transaction );
		//Log.d(TAG, "buildMessagePacket() hdr: " + AqUtils.getHexData( MessageHeader, 0, MessageHeader.length));
		
		// fill in the header
        byteEncoder.writeBytes( MessageHeader );

        // Write the payload
        if( null != rawData ) {
            byteEncoder.writeBytes( rawData );
        }
        
        /*
        **  Return the contents.
        */
        byte[] p = byteEncoder.getContent();
		//Log.d(TAG, "buildMessagePacket() packet: " + AqUtils.getHexData( p, 0, p.length));
		return p;
	}

    /** 
     * Build a Message packet with the given attributes and payload data.
     *
     *  @param rawData An array of bytes that make up the payload
     *  @param id The Message message ID to be associated with this message
     *  @param compressed Compression indicator.  When set to true, indicates that the contents of rawData[] is compressed.
     *
     *  @return A byte array containing the Message packet.
     */
    public static byte[] buildMessagePacket( byte[] rawData, int id, boolean compressed ) 
    {
        long transId = AqUtils.getGuid();
        
        return buildMessagePacket( rawData, id, compressed, transId );
    }
    
    /** 
     * Build a Message packet with the given attributes and payload data.
     *
     *  @param rawData An array of bytes that make up the payload
     *  @param id The Message message ID to be associated with this message
     *  @param sz The number of bytes in rawData to put into the message
     *  @param compressed Compression indicator.  When set to true, indicates that the contents of rawData[] is compressed.
     *
     *  @return A byte array containing the Message packet.
     */
    protected static byte[] buildMessagePacket( byte[] rawData, int id, int sz, boolean compressed ) 
    {
		byte[] b = rawData;
	
		if( sz < 0 ) sz = 0;
		
		// align payload to have sz bytes if necessary.
		// rawdata[] __SHOULD__ be sz bytes ... but must keep
		// legacy interface 
		if( sz == 0 ) {
		    b = null;
		}
		else if( b.length != sz  ) {
		    b = new byte[sz];
		    int i;
		    
		    for( i=0;i<sz;i++ ) {
				if( i < rawData.length ) {
				    b[i] = rawData[i];
				}
				else {
				    b[i] = 0;
				}
		    }
		}
		
		return buildMessagePacket( b, id, compressed );
    }
    
    /** 
     * Build a header only Message packet with the given attributes.  
     *
     *  @param id The Message message ID to be associated with this message
     *  @param compressed Compression indicator.  When set to true, indicates that the contents of rawData[] is compressed.
     *  @param transaction The Message transaction id to be placed into the Message message header
     *
     *  @return A byte array containing the Message packet.
     */
    protected static byte[] buildMessagePacket( int id, boolean compressed, long transaction ) 
    {
        return buildMessagePacket( null, id, compressed, transaction );
    }

    // TODO: Determine if we need this. (JWB)
    /* 
    protected static int extractMessageOemSize( byte[] msg )
    {
        return extractMessagePayloadLen( msg ) + MSG_HEADER_SIZE;
    }
    */
    
    /**
     * <p>Injects the passed message time into the passed data packet or header.</p>
     * 
     * <p><b>NOTE:</b> this method is used by the viaaq simulator and has limited error checking.</p>
     * <p><b>NOTE:</b> Seconds should not exceed 4 bytes ... it is define as long to accomodate
     *       unsigned values but will get encoded into 4 bytes.</p>
     *       
     * @param header
     * @param seconds
     */
    protected static void injectMessageTime( byte[] header, long seconds )
    {
    	// TODO: Use AqUtil instead of ByteEncoder. (JWB)
    	
        byte data[] = null;
        ByteEncoder be = new ByteEncoder();
        
        int pos = headerStartOffset(header);
        pos += MSG_TIME_IDX;
        
        if(  header.length > ( pos + 4 ) )
        {
            try
            {
                be.writeLong( 4, seconds );
                data = be.getContent();
                header[pos++] = data[0];
                header[pos++] = data[1];
                header[pos++] = data[2];
                header[pos++] = data[3];
            }
            catch( Exception e )
            {
            }
        }
    }
        
    /**
     * @param header
     */
    protected static void injectMessageTime( byte[] header )
    {
        long seconds = AqUtils.getRtcTimeInMs() / 1000;
        injectMessageTime( header, seconds );
    }

    /**
     * <p>Extracts the message time from the passed data packet or header.</p>
     * 
     * <p><b>NOTE:</b> this method is used by the viaaq simulator and has limited error checking.</p>
     * 
     * @param header
     * @return
     */
    protected static int extractMessageTime( byte[] header )
    {
    	// TODO: Use AqUtil instead of ByteDecoder. (JWB)
        byte data[] = null;
        int seconds = -1;
        
        int pos = headerStartOffset(header);
        pos += MSG_TIME_IDX;

        if(  header.length > ( pos + 4 ) )
        {
            data = new byte[4];
            data[0] = header[pos++];
            data[1] = header[pos++];
            data[2] = header[pos++];
            data[3] = header[pos++];
            
            try
            {
                ByteDecoder bd = new ByteDecoder( data );
                seconds = bd.readSignedInt( 4 );
            }
            catch( Exception e )
            {
            }
        }
        
        return seconds;
    }

    /**
     * <p>Injects the passed message device ID into the passed data packet or header.</p>
     * 
     * <p><b>NOTE:</b> this method is used by the viaaq simulator and has limited error checking.</p>
     * 
     * @param header
     * @param deviceId
     */
    protected static void injectMessageDeviceId( byte[] header, int deviceId )
    {
    	// TODO: Use AqUtil instead of ByteEncoder. (JWB)
        byte data[] = null;
        ByteEncoder be = new ByteEncoder();
        
        int pos = headerStartOffset(header);
        pos += MSG_MSB_DEVICE_ID_IDX;
        
        if(  header.length > ( pos + 3 ) )
        {
            try
            {
                be.writeInt( 3, deviceId );
                data = be.getContent();
                
                header[pos++] = data[0];
                header[pos++] = data[1];
                header[pos++] = data[2];
            }
            catch( Exception e )
            {
            }
        }
    }

    /**
     * <p>Extracts the message device ID from the passed data packet or header.</p>
     * 
     * <p><b>NOTE:</b> this method is used by the viaaq simulator and has limited error checking.</p>
     * 
     * @param header
     * @return
     */
    protected static int extractMessageDeviceId( byte[] header )
    {
    	// TODO: Use AqUtil instead of ByteDecoder. (JWB)
        int deviceId = 0;
        byte data[] = new byte[3];
        
        int pos = headerStartOffset(header);
        pos += MSG_MSB_DEVICE_ID_IDX;
        
        if(  header.length > ( pos + 3 ) )
        {
            data[0] = header[pos++];
            data[1] = header[pos++];
            data[2] = header[pos++];

            ByteDecoder bd = new ByteDecoder( data );
            try
            {
                deviceId = bd.readInt( 3 );
            }
            catch( Exception e )
            {
            }
        }

        return deviceId;
    }
    
    // TODO: Determine if the above or the below is the correct way to do this. (JWB)
    /*
    protected static int extractMessageDeviceId( byte [] header )
    {
        return ( ( ( header[MSG_MSB_DEVICE_ID_IDX] << 16 ) & 0x00ff0000 )
                 +  ( ( header[MSG_MSB_DEVICE_ID_IDX + 1] << 8 )  & 0x0000ff00 )
                 +  (   header[MSG_MSB_DEVICE_ID_IDX + 2]         & 0x000000ff ) );
    }
    */

    /**
     * <p>Injects the passed message transaction ID into the passed data packet or header.</p>
     * 
     * <p><b>NOTE:</b> this method is used by the viaaq simulator and has limited error checking.</p>
     * 
     * @param header
     * @param transId
     */
    protected static void injectMessageTransID( byte[] header, long transId )
    {
        int pos = headerStartOffset(header);
        pos += MSG_TRANSID_IDX;
        
    	byte data[] = AqUtils.unsignedLongToByteArray(transId);
    	System.arraycopy(header, 0, data, pos, 8);
    	/*
        byte data[] = null;
        ByteEncoder be = new ByteEncoder();
        
        if(  header.length > ( pos + 8 ) ) {
            try {
                be.writeLong( 8, transId );
                data = be.getContent();

                int i;
                for( i=0;i<data.length;i++) {
                    header[pos + i] = data[i];
                }
            }
            catch( Exception e ) {
            }
        } 
        */
    }
    
    /**
     * Extracts the message transaction ID from the passed data packet or header.
     * 
     * @param header
     * @return
     */
    protected static long extractMessageTransID( byte[] header )
    {        
        int pos = headerStartOffset(header);
        pos += MSG_TRANSID_IDX;
        
        /*
        byte data[] = new byte[8] ;
        data[0] = header[pos++];
        data[1] = header[pos++];
        data[2] = header[pos++];
        data[3] = header[pos++];
        data[4] = header[pos++];
        data[5] = header[pos++];
        data[6] = header[pos++];
        data[7] = header[pos++];
        
        ByteDecoder decode = new ByteDecoder( data );
        try {
            return decode.readLong( 8 );
        }
        catch( Exception e ) {
            return 0;
        }
        */
        return AqUtils.eightBytesToUnsignedLong(header[pos], header[pos + 1], header[pos + 2], 
        		header[pos + 3], header[pos + 4], header[pos + 5], header[pos + 6], header[pos + 7]);
    }

    /**
     * Injects the passed message version into the passed data packet or header.
     * 
     * @param header
     * @param version
     */
    protected static void injectMessageVersion( byte[] header, int version )
    {
        int pos = headerStartOffset(header);
        pos += MSG_VER_IDX;
        
        if( (null != header) && ( header.length > pos ) ) {
            header[pos] = (byte) version;
        }
    }

    /**
     * Extracts the message version from the passed data packet or header.
     * 
     * @param header
     * @return
     */
    protected static int extractMessageVersion( byte[] header )
    {
        int retval = -1;
        
        int pos = headerStartOffset(header);
        pos += MSG_VER_IDX;
        
        if( ( null != header  ) && ( header.length > pos ) ) retval = header[pos];
        
        return retval;
    }

    /**
     * Extracts the message payload length from the passed data packet or header.
     * 
     * @param header
     * @return
     */
    protected static int extractMessagePayloadLen( byte[] header )
    {
        /*
        **  Check the length of the payload by examining the Message header.
        **  If this is a large message there is a software download occurring.
        */
        
        int pos = headerStartOffset(header);
        pos += MSG_MSB_LEN_IDX;
        
        /*
        int sz =   ( ( header[pos++] << 24 ) & 0x7f000000 )
            +      ( ( header[pos++] << 16 ) & 0x00ff0000 )
            +      ( ( header[pos++] << 8 )  & 0x0000ff00 )
            +      (   header[pos++]         & 0x000000ff );
        return sz;
        */
        return (int) AqUtils.eightBytesToUnsignedLong((byte) 0, (byte) 0, (byte) 0, (byte) 0, 
        		header[pos], header[pos + 1], header[pos + 2], header[pos + 3]);
    }
    
    /**
     * Returns true if the message payload in the passed data packet or header
     * is compressed, otherwise false.
     * 
     * @param header
     * @return
     */
    protected static boolean isPayloadCompressed( byte[] header )
    {
        boolean retval = false;
        
        int pos = headerStartOffset(header);
        pos += MSG_MSB_LEN_IDX;
        
        // determine index of most significant byte of payload length
        // the most sig bit of most significant byte indicates
        // compression
        if( ( null != header ) && ( header.length > pos ) ) {
            retval = ( 0 != ( header[pos] & 0x80 ) );
        }
        
        return retval;
    }
    
    /**
     * Extracts the message payload from the passed data packet.
     * 
     * @param packet
     * @return
     */
    protected static byte[] extractPayload( byte[] packet )
    {
        int i;
        int len = 0;
        len = extractMessagePayloadLen( packet );
        byte [] retval = null;

        try
        {
        	int pos = headerStartOffset(packet);
        	pos += MSG_HEADER_SIZE;

        	byte[] rawData = new byte[len];
        	for( i = 0; i < len; i++ ) {
        		rawData[i] = packet[pos++];
        	}
        	retval = rawData;
        }
        catch( Exception e )
        {
        	AqLog.getInstance().error("malformed CFMS packet", e );
        }
        return retval;
    }
    
    //
	// Constructors.
	//

	/**
	 * Creates a CMessage with no payload.
	 * 
	 * @param messageID
	 * @param transactionId
	 */
	public CMessage(int messageID, long transactionId) {
		this.packet = buildMessagePacket(messageID, false, transactionId);
	}

	/**
	 * Creates a CMessage using the passed parameters.
	 * 
	 * @param messageID
	 * @param payload
	 */
	public CMessage(int messageID, byte[] payload) {
		this(messageID, payload, false);
	}

	/**
	 * Creates a CMessage using the passed parameters.
	 * 
	 * @param messageID
	 * @param payload
	 * @param compressed
	 */
	public CMessage(int messageID, byte[] payload, boolean compressed) {
		this.packet = buildMessagePacket(payload, messageID, compressed);
	}

	/**
	 * Creates a CMessage using the passed parameters.
	 * 
	 * @param messageID
	 * @param payload
	 * @param compressed
	 * @param transactionId
	 */
	public CMessage(int messageID, byte[] payload, boolean compressed, long transactionId) {
		this.packet = buildMessagePacket(payload, messageID, compressed, transactionId);
	}
	
	/**
	 * Creates a CMessage from a data packet.
	 * 
	 * @param messageData A byte array containing a Choreo message data packet or null.
	 */
	public CMessage(byte[] packet, long refid ) {
		if (packet != null) {
			this.packet = packet.clone();	
			this.reference_id = refid;
		}
		else {
			this.packet = null;
		}
	}

	public CMessage(byte[] packet) {
		this( packet, 0 );
	}
	
	/**
	 * Creates a CMessage by copying another cMessage.
	 * 
	 * @param message A CMessage instance or null.
	 */
	public CMessage(CMessage message) {
		if (message != null && message.packet != null) {
			this.packet = message.packet.clone();
		}
		else {
			packet = null;
		}
	}
	
	/**
	 * <p>Extracts the contents of a CMessage from a passed Bundle. Expects the 
	 * following keys in the Bundle:</p>
	 * <ul>
	 * <li><b>msg_packet</b> The data payload of the Choreo message.</li>
	 * </ul>
	 * 
	 * @param bundle A Bundle instance or null.
	 */
	public CMessage(Bundle bundle) {
		if (bundle != null && bundle.getByteArray(MSG_PACKET_KEY) != null) {
			// TODO: Replace string constants with resources.
			this.packet = bundle.getByteArray(MSG_PACKET_KEY).clone();
			this.reference_id = bundle.getLong(MSG_REFID_KEY);
		}
		else {
			packet = null;
		}
	}
	
	//
	// Private Instance Methods.
	//
    
	//
	// Public Instance Methods.
	//
    
	/**
	 * Returns a Bundle containing the message data packet with the following key(s):
	 * <ul>
	 * <li><b>msg_packet</b> The data payload of the Choreo message.</li>
	 * </ul>
	 * 
	 * @return A Bundle containing the message data packet.
	 */
	public Bundle toBundle() {
		byte[] b = this.packet;
		if( null == b ) b = new byte[0];
		//AqLog.getInstance().debug("toBundle() refid: " + this.reference_id + "data: " + AqUtils.getHexData( b, 0, b.length ));
		return makeCMessageBundle(this.packet,this.reference_id);
	}
	
	/**
	 * Injects the message data packet into the passed Bundle with the following key(s):
	 * <ul>
	 * <li><b>msg_packet</b> The data payload of the Choreo message.</li>
	 * </ul>
	 * 
	 * @param bundle A Bundle instance or null.
	 */
	public void injectIntoBundle(Bundle bundle) {
		injectCMessageIntoBundle(bundle, this.packet,this.reference_id);
	}
	
	/**
	 * Returns the message ID.
	 * 
	 * @return The message ID.
	 */
	public int getMessageId() {
		return extractMessageId(this.packet);
	}
	
	public long getReferenceId()
	{
		return this.reference_id;
	}
	
	/**
	 * Returns the message time.
	 * 
	 * @return The message time.
	 */
	public int getMessageTime() {
		return extractMessageTime(this.packet);
	}
	
	/**
	 * Returns the message version. 
	 * 
	 * @return The message version.
	 */
	public int getMessageVersion() {
		return extractMessageVersion(this.packet);
	}
		
	/** Returns the originating device ID.
	 * 
	 * @return The originating device ID.
	 */
	public int getDeviceId() {
		return extractMessageDeviceId(this.packet);
	}
	
	/**
	 * Returns the transaction ID.
	 * 
	 * @return The transaction ID.
	 */
	public long getTransId() {
		return extractMessageTransID(this.packet);
	}
	
	/**
	 * Returns true if the message payload is compressed, otherwise false.
	 * 
	 * @return True if the message payload is compressed, otherwise false.
	 */
	public boolean isPayloadCompressed() {
		return isPayloadCompressed(this.packet);
	}
	
	/**
	 * Returns the number of bytes in the message payload.
	 * 
	 * @return The number of bytes in the message payload.
	 */
	public int getPayloadLen() {
		return extractMessagePayloadLen(this.packet);
	}
	
	/**
	 * Returns the message payload as an array of bytes.
	 * 
	 * @return The message payload as an array of bytes.
	 */
	public byte[] getPayloadBytes() {
		return extractPayload(this.packet);
	}

	/**
	 * Returns a formatted String containing the message header values.
	 * 
	 * @return A formatted String containing the message header values.
	 */
	public String headerToString() {
		if( null == packet ) {
			return "CMessage: packet is null";
		}
		
		if( packet.length < MSG_HEADER_SIZE ) {
			return "CMessage: packet is malformed";
		}
		
		return "ID: " + getMessageId() + " Time: " + getMessageTime() + 
				" Ver: " + getMessageVersion() + " Dev ID: " + getDeviceId() +
				"Trans ID: " + getTransId() + " Compressed: " + isPayloadCompressed() +
				" Length: " + getPayloadLen();
	}
	
	/**
	 * Should be overridden by subclasses to provide some kind of formatted 
	 * version of the message payload.
	 * 
	 * @return A formatted version of the message payload.
	 */
	public String payloadToString() {
		if( null == packet ) {
			return "CMessage: payload is null";
		}

		return this.packet.toString();
	}
	
	@Override
	public String toString() {
		return headerToString() + " Payload: " + payloadToString();
	}
}