/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import com.airbiquity.android.sfsp.database.DBInstance;
import com.airbiquity.android.sfsp.database.ObjReliableMessage;
import com.airbiquity.aqlog.AqLog;
import com.airbiquity.util.AqUtils;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;

/**
 * <p>Provides an Android Service that runs a message broker in a separate 
 * thread.</p>
 * 
 * <p><b>NOTE:</b> This Service expects to run for the life of the application
 * using it. It is not designed to be started and stopped multiple times.</p>
 * 
 * <p><b>NOTE:</b> Do not start this Service directly. Because more than one
 * consumer might need to use this Service you should always rely on the 
 * message dispatcher helper class to manage this Service.</p>
 * 
 * @see CMessageDispatcher
 * @see iCMessageBroker
 * 
 * @author Jack William Bell
 */
public class CMessageBrokerService extends Service {

	//
	// Declarations.
	//
	
	private static final String TAG = "CMessageBrokerService";
	
	// TODO: Document each command. (JWB)
	public static final int CMD_ERROR = 0;
	public static final int CMD_HANDSHAKE = 1;
	public static final int CMD_REQUEST_STATE = 2;
	public static final int CMD_STOP = 3;
	public static final int CMD_STATE_REPORT = 8;
	public static final int CMD_STATE_CHANGE_NOTIFICATION = 9;
	public static final int CMD_CHOREO_MESSAGE = 10;
	public static final int CMD_REMOVE_CHOREO_MESSAGE = 11;
	
	// TODO: Document each status state value. (JWB)
	public static final int STATE_ERROR = 0;
	public static final int STATE_NOT_STARTED = 1;
	public static final int STATE_STARTED = 2;
	public static final int STATE_CONNECTING = 3;
	public static final int STATE_RECONNECTING = 4;
	public static final int STATE_READY = 5;
	public static final int STATE_STOPPED = 6;
	
	private static final long LO_PRIORITY_SERVICE_INTERVAL = 30000;
	private static final long NORMAL_PRIORITY_SERVICE_INTERVAL = 30000;
	private static final long HIGH_PRIORITY_SERVICE_INTERVAL = 2000;
	private static final long IDLE_TRANSMIT_INTERVAL = 60000;
	
	//
	// Local Storage.
	//
	
	private String mBrokerClass = "";
	private String mBrokerConfiguration = "";
	private int mStatusCode = STATE_NOT_STARTED;
	
	// This prevents excessive hits to the DB when there are no messages queued.
	// This variable is maintained by the reliable message query and add reliable message.
	// Any time the add reliable message is called, this will be set to false.  Any time
	// the query of the message queue results in 0 pending messages this will be set to true.
	private boolean isOutboundQueueEmpty = false;
	
	// Indicators for servicing of the  message priority levels.
	private static long lastLoPrioirtyServiceTime = 0;
	private static long lastNormalPrioirtyServiceTime = 0;
	private static long lastHighPrioirtyServiceTime = 0;
	private static long lastMessageSentTime = 0;	
	
	
	protected Messenger dispatcherSender = null;
	
    /**
     * Target we publish for the Dispatcher to send messages to DispatcherHandler.
     */
    protected final Messenger mDispatchReceiver = new Messenger(new DispatcherHandler(this));
	
    /**
     * Listener for the BrokerTask that can send messages to the Dispatcher.
     */
    protected final TaskListener mTaskListener = new TaskListener();
	
    /**
     * AsyncTask subclass that runs the actual message broker in a 
     * different thread.
     */
    protected final BrokerTask mBrokerTask = new BrokerTask();
    
	//
	// Local Classes.
	//
	
    /**
     * Handler for incoming messages from Message Dispatcher.
     */
    protected static class DispatcherHandler extends Handler {
    	WeakReference<CMessageBrokerService> mBrokerService;
    	
    	public DispatcherHandler(CMessageBrokerService brokerService) {
    		mBrokerService = new WeakReference<CMessageBrokerService>(brokerService);
    	}
    	
        @Override
        public void handleMessage(Message msg) {
        	CMessageBrokerService brokerService = mBrokerService.get();

        	// Process the message according to the current state.
            switch (msg.what) {
            case CMD_HANDSHAKE:
            {
            	// We reply only to the Dispatcher sending us messages. There
            	// should only be the one!
            	// TODO: Decide if we need to enable multiple dispatchers. For 
            	// example, from different applications. (JWB)
            	if (brokerService.dispatcherSender == null) {
            		brokerService.dispatcherSender = msg.replyTo;
            	}
        		// Send current state as a response to the handshake.
            	brokerService.sendMessageToDispatcher(makeAndroidMessage(CMD_STATE_CHANGE_NOTIFICATION, msg.arg1, brokerService.mStatusCode));
            }
            	break;
            case CMD_REQUEST_STATE:
            {		
        		// Send status code.
            	brokerService.sendMessageToDispatcher(makeAndroidMessage(CMD_STATE_REPORT, msg.arg1, brokerService.mStatusCode));
            }
                break;
            case CMD_STOP:
            	if (brokerService.mStatusCode == STATE_READY || brokerService.mStatusCode == STATE_CONNECTING) {
            		brokerService.mBrokerTask.cancel(true);
            	}
            	else {
            		// Send error message.
            		brokerService.sendMessageToDispatcher(makeErrorAndroidMessage("Attempt to stop when not started.", msg.arg1, 0));
            	}            		
                break;
            case CMD_CHOREO_MESSAGE:
            {
            	CMessage cm = new CMessage(msg.getData());
            	brokerService.mBrokerTask.sendMessage(cm, msg.arg1, msg.arg2 );
            }
            break;
            case CMD_REMOVE_CHOREO_MESSAGE:
            {
            	CMessage cm = new CMessage(msg.getData());
            	brokerService.mBrokerTask.deleteMessage( cm );
            }
            break;
            
            default:
            {
        		// Send error message.
            	brokerService.sendMessageToDispatcher(makeErrorAndroidMessage("Unknown Message.", msg.arg1, 0));
            }
            }
        }
    }

    /**
     * Allows us to call back into the broker service instance from the broker task instance 
     * without creating a circular reference and associated memory leak.
     */
    protected class TaskListener {
    	public void onStateChange(int newState) {
    		mStatusCode = newState;
    		sendMessageToDispatcher(makeAndroidMessage(CMD_STATE_CHANGE_NOTIFICATION, -1, mStatusCode));
    	}
    	
    	public void onMessage(CMessage cMsg) {
    		sendMessageToDispatcher(cMessageToAndroidMessage(cMsg));
    	}
    	
    	public void onException(Exception ex) {
    		mStatusCode = STATE_ERROR;
    		sendMessageToDispatcher(makeErrorAndroidMessage(ex, -1, 0));
    	}
    }
    
    /**
     * Lightweight class giving us a way to communicate different kinds of information 
     * from inside the broker task thread to the outside.
     */
    protected class TaskProgressInfo {
    	public final boolean isStateChange;
    	public final boolean isMessage;
    	public final boolean isError;
    	public final int newState;
    	public final CMessage message;
    	public final Exception exception;
    	
    	public TaskProgressInfo (int state) {
    		this.isStateChange = true;
    		this.isMessage = false;
    		this.isError = false;
    		this.newState = state;
    		this.message = null;
    		this.exception = null;
    	}
    	
    	public TaskProgressInfo (CMessage msg) {
    		this.isStateChange = false;
    		this.isMessage = true;
    		this.isError = false;
    		this.newState = -1;
    		this.message = msg;
    		this.exception = null;
    	}
    	
    	public TaskProgressInfo (Exception ex) {
    		this.isStateChange = false;
    		this.isMessage = false;
    		this.isError = true;
    		this.newState = -1;
    		this.message = null;
    		this.exception = ex;
    	}
    }
    
    
    private synchronized void addReliableMessage( CMessage cm, int priority, int maxRetries )
    {
		DBInstance db = DBInstance.getInstance(getApplicationContext());
		if( null != db )
		{
			
			ObjReliableMessage rmsg = new ObjReliableMessage();
			long transId = CMessage.extractMessageTransID( cm.packet );

			rmsg.setTransaction_id( transId );
			rmsg.setMessage_data( cm.packet );
			rmsg.setPriority(priority);
			rmsg.setRetries(maxRetries);

			//AqLog.getInstance().debug("addReliableMessage msgId,refId: " + cm.getMessageId() + "," + cm.getReferenceId() );
			rmsg.setMessageId( cm.getMessageId() );
			rmsg.setReferenceId(cm.getReferenceId() );
			
			LinkedList<ObjReliableMessage> ll = new LinkedList<ObjReliableMessage>();
			ll.add( rmsg );
			db.addReliableMessage(ll);
			this.isOutboundQueueEmpty = false;			
			//mOutgoingMessageQueue.add(msg);
		}
		else
		{
			AqLog.getInstance().error("Unable to get db instnace ... dropping data");
		}
    }
    
    private CMessage objReliableMessageToCMessage( ObjReliableMessage rmsg )
    {
    	CMessage cm = null;
    	if( null != rmsg )
    	{
    		byte[] b = rmsg.getMessage_bytes();
			if( null != b )
			{
				cm = new CMessage( b );
			}
    	}
    	return cm;
    }
    private synchronized ObjReliableMessage getOldestHighestPriorityReliableMessage()
    {
    	ObjReliableMessage retval = null;
    	if( ! isOutboundQueueEmpty )
    	{
    		DBInstance db = DBInstance.getInstance(getApplicationContext());
    		if( null != db ) 
    		{
    			List<ObjReliableMessage> l = db.selectReliableMessage();
    			if( ! l.isEmpty() )
    			{
    				try
    				{
    					retval = l.get( 0 );
    				}
    				catch( Exception e )
    				{
    					// Shouldn't be empty because isEmpty returned false!
    				}
    			}
    		}
    		if( null == retval ) this.isOutboundQueueEmpty = true;
    	}
    	return retval;
    }
    
    private synchronized void deleteReliableMessage( ObjReliableMessage rmsg )
    {
    	if( null != rmsg )
    	{
    		deleteReliableMessage( rmsg.getTransaction_id() );
    	}
    }

    public synchronized void deleteReliableMessage( long transId )
    {
    	int priority = -1;
		DBInstance db = DBInstance.getInstance(getApplicationContext());
		if( null != db )
		{
			ObjReliableMessage rmsg = db.getReliableMessage( transId );
			if( null != rmsg )
			{
				priority = rmsg.getPriority();
			}
			db.deleteReliableMessage( transId );
			if( priority >= CMessage.PRIORITY_TO_OBU )
			{
				lastHighPrioirtyServiceTime = 0;
			}
			else if( (priority <= CMessage.PRIORITY_TO_CHOREO_NORMAL ) && ( priority >= CMessage.PRIORITY_TO_CHOREO_TXT_MSG_REQUEST ) )
			{
				lastNormalPrioirtyServiceTime = 0;
			}
			else
			{
				lastLoPrioirtyServiceTime = 0;
			}
		}
    }

    private synchronized void decrementReliableMessageRetries( ObjReliableMessage rmsg )
    {
		DBInstance db = DBInstance.getInstance(getApplicationContext());
		if( (null != db) && (null != rmsg) )
		{
			int retriesRemaining = rmsg.getRetries();
			if( retriesRemaining <= 0 )
			{
				db.deleteReliableMessage( rmsg.getTransaction_id() );
			}
			else
			{
				retriesRemaining--;
				rmsg.setRetries(retriesRemaining);
				db.updateReliableMessage(rmsg);
			}
		}
    }
    
    
    /**
     * Extends AysncTask to give us a way to (safely) run the chosen broker in a separate 
     * thread.
     */
    protected class BrokerTask extends AsyncTask<String, TaskProgressInfo, String> {
    	private TaskListener mListener = null;
    	private LinkedList<CMessage> mOutgoingMessageQueue = new LinkedList<CMessage>();
    	
    	
    	protected void setTaskListener (TaskListener listener) {
    		mListener = listener;
    	}
    	
    	protected synchronized void sendMessage(CMessage msg, int priority, int maxRetries ) {
    		// Add to the end of the outgoing queue.
    		addReliableMessage( msg, priority,  maxRetries );								    		
    	}
    	
    	protected synchronized void deleteMessage( CMessage msg )
    	{
    		deleteReliableMessage( msg.getTransId() );    		
    	}
    	
		@Override
		protected String doInBackground(String... arg0) {
			String brokerClass = null;
			String brokerConfig = null;
			String resultMessage = "";
			boolean cancelled = this.isCancelled();
			boolean connected = false;
			iCMessageBroker broker = null;
			CMessage msgToSend = null;
			
			// Extract the arguments.
			if (arg0.length > 0) {
				brokerClass = arg0[0];
			}
			if (arg0.length > 1) {
				brokerConfig = arg0[1];
			}
			
			// Create a broker.			
			// TODO: Consider a broker factory using 'brokerClass' argument 
			// instead of creating it directly from a class name like this. (JWB)
	    	if (!cancelled && brokerClass != null) {
	        	try {
	        		broker = (iCMessageBroker) Class.forName(brokerClass).newInstance();
	        	}
	        	catch (Exception ex) {
	        		this.publishProgress(new TaskProgressInfo(ex));
	        		this.publishProgress(new TaskProgressInfo(STATE_ERROR));
	        		broker = null;
	        		cancelled = true;
	        	}
	    	}
	    	else {
	    		// TODO: Determine if this is how we want to handle this or if we should
	    		// make this an error condition. (JWB)
				broker = new MockBroker();
	    	}

	    	// Do we have anything?
	    	if (!cancelled) cancelled = this.isCancelled();
			if (!cancelled && broker != null) {
				this.publishProgress(new TaskProgressInfo(STATE_STARTED));
				// Initialize the broker.
	        	try {
	        		broker.initialize(brokerConfig);
	        	}
	        	catch (Exception ex) {
	        		this.publishProgress(new TaskProgressInfo(ex));
					this.publishProgress(new TaskProgressInfo(STATE_ERROR));
					cancelled = true;
	        	}
				// Can we start and run the broker?
	        	try {
					CMessage result = null;
					if (!cancelled) cancelled = this.isCancelled();
					if (!cancelled && broker.start()) {
						this.publishProgress(new TaskProgressInfo(STATE_CONNECTING));
						// Outer loop
						while (!cancelled) {
							connected = broker.isConnected();
							if (connected) {
								this.publishProgress(new TaskProgressInfo(STATE_READY));
							}
							// Broker processing loop.
							while (!cancelled && connected) {
								// Pop off the first item in the outgoing queue (if any) and 
								// process it.
								//msgToSend = mOutgoingMessageQueue.poll();
								msgToSend = null;
								ObjReliableMessage rmsg = getOldestHighestPriorityReliableMessage();
								long now = AqUtils.getRtcTimeInMs();
								if( null != rmsg )
								{
									// determine if message should be sent based upon priority
									// and last service time for the priority
									int pri = rmsg.getPriority();
									if( pri >= CMessage.PRIORITY_TO_OBU )
									{
										if( ( lastHighPrioirtyServiceTime +  HIGH_PRIORITY_SERVICE_INTERVAL ) < now )
										{
											lastHighPrioirtyServiceTime = now;
											msgToSend = objReliableMessageToCMessage( rmsg ); 
										}
									}
									else if( pri == CMessage.PRIORITY_TO_CHOREO_NORMAL )
									{
										if( ( lastNormalPrioirtyServiceTime +  NORMAL_PRIORITY_SERVICE_INTERVAL ) < now )
										{
											lastNormalPrioirtyServiceTime = now;
											msgToSend = objReliableMessageToCMessage( rmsg ); 

										}
									}
									else
									{
										if( ( lastLoPrioirtyServiceTime +  LO_PRIORITY_SERVICE_INTERVAL ) < now )
										{
											lastLoPrioirtyServiceTime = now;
											msgToSend = objReliableMessageToCMessage( rmsg ); 
										}
									}
									lastMessageSentTime = now;									
								}
								else if( ( lastMessageSentTime + IDLE_TRANSMIT_INTERVAL ) < now )
								{
									lastMessageSentTime = now;
									byte [] b = new byte[CMessage.MSG_HEADER_SIZE];
									Arrays.fill( b, (byte) 0 );
									b[1] = CMessage.ASCII_I;
									
									msgToSend = new CMessage(b); 									
								}
								
								try {
									if( null != msgToSend )
									{
										byte[] p = msgToSend.packet;
										if( null != p )
										{
											int len = p.length;
											
											// truncate hexdump to first 1K
											if( len > 1024 ) len = 1024;
											AqLog.getInstance().info( "CMessageBrokerService sending: " + AqUtils.getHexData( p, 0, len ));
										}
									}
									result = broker.process(msgToSend);
								}
								catch (NoTransportException ex) {
									this.publishProgress(new TaskProgressInfo(ex));
									this.publishProgress(new TaskProgressInfo(STATE_ERROR));
									cancelled = true;
									// TODO: Determine how we restart if we exit the loop here. In any 
									// case this exception shouldn't be thrown unless we have a permanent 
									// error. (JWB)
									break;
								}
								catch (NoConnectionException ex) {
									this.publishProgress(new TaskProgressInfo(STATE_RECONNECTING));
									connected = false;
								}
								catch (Exception ex) {
									this.publishProgress(new TaskProgressInfo(ex));
									// If we have an unsent message, push it back onto the queue.
									if (msgToSend != null) {
										//mOutgoingMessageQueue.addFirst(msgToSend);
									}
								}
								if (result != null) {
									byte[] p = result.packet;
									if( null != p )
									{
										int len = p.length;

										// truncate hexdump to first 1K
										if( len > 1024 ) len = 1024;
										AqLog.getInstance().info( "CMessageBrokerService rxPacket: " + AqUtils.getHexData( p, 0, len ));
									}
									
									// Send the processing result safely across thread boundaries.
									this.publishProgress(new TaskProgressInfo(new CMessage(result)));
								}
								
								if( null != msgToSend ) decrementReliableMessageRetries( rmsg );
								
								// Make sure this thread doesn't hog *all* the CPU.
								SystemClock.sleep(1);
								// Check the connected state again (if we think it is connected).
								if (connected && !broker.isConnected()) {
									this.publishProgress(new TaskProgressInfo(STATE_RECONNECTING));
									connected = false;
								}
								// See if we have been cancelled.
								if (!cancelled) cancelled = this.isCancelled();
								// Reset some variables.
								result = null;
								msgToSend = null;
							}
							// See if we have been cancelled.
							if (!cancelled) cancelled = this.isCancelled();
						}
						// All done!
						broker.stop();
					}
					else {
						this.publishProgress(new TaskProgressInfo(STATE_ERROR));
						resultMessage = "Could not start message broker";
					}
	        	}
	        	catch (Exception ex) {
	        		this.publishProgress(new TaskProgressInfo(ex));
					this.publishProgress(new TaskProgressInfo(STATE_ERROR));
					resultMessage = "Could not start message broker";
	        	}
			}
			else {
				this.publishProgress(new TaskProgressInfo(STATE_ERROR));
				resultMessage = "Could not create message broker for class " + brokerClass;
			}
			
			// Not strictly needed, but let's be explicit about when this goes onto the trash heap.
			broker = null;
			
			// Let's also give other threads a chance to catch up. I'd force garbage collection 
			// here too, if I could.
			SystemClock.sleep(100);
			
			// All thread processing is complete. Let AsyncTask handle the dirty details of spinning it down.
			return resultMessage; 
		}

		@Override
	    protected void onProgressUpdate(TaskProgressInfo... progress) {
			// NOTE: As currently implemented we don't really need 
			// to process this in a 'for' loop. However it is at least as 
			// performant as using an if statement and it allows us to
			// change how the data is sent later without recoding this. (JWB)
			for (int i = 0; i < progress.length; i++) {
				if (progress[i].isStateChange) {
					mListener.onStateChange(progress[i].newState);
				}
				else if (progress[i].isMessage) {
					mListener.onMessage(progress[i].message);
				}
				else if (progress[i].isError) {
					mListener.onException(progress[i].exception);
				}
			}
	    }

		@Override
	    protected void onCancelled() {
			// This is called if the task completes as expected, I.E. it is cancelled
			// when the message broker service is destroyed.
			mListener.onStateChange(STATE_STOPPED);
	    }

		@Override
	    protected void onPostExecute(String result) {
			// This is called if the task returns without being cancelled, which is not 
			// what is expected in this implementation and, thus, is an error.
			// TODO Create custom exception. (JWB)
			mListener.onException(new Exception("Message Broker processing failed. Message: " + result));
	    }
    }
    
	//
	// Static Functions.
	//
    
	/**
	 * @param msg
	 * @return
	 */
	protected static CMessage androidMessageToCMessage(Message msg) {
		CMessage cMsg = null;
		if (msg != null && msg.what == CMD_CHOREO_MESSAGE) {
			cMsg = new CMessage(msg.getData());
		}
		return cMsg;
	}

	/**
	 * @param cMsg
	 * @return
	 */
	protected static Message cMessageToAndroidMessage(CMessage cMsg) {
		Message msg = new Message();
		msg.what = CMD_CHOREO_MESSAGE;
		msg.arg1 = -1;
		msg.arg2 = cMsg.getMessageId();
		if (cMsg != null) {
			msg.setData(cMsg.toBundle());
		}
		return msg;
	}
    
	/**
	 * @param ex
	 * @param arg1
	 * @param arg2
	 * @return
	 */
	protected static Message makeErrorAndroidMessage(Exception ex, int arg1, int arg2) {
		return makeErrorAndroidMessage(ex.toString(), arg1, arg2);
	}
    
	/**
	 * @param errMessage
	 * @param arg1
	 * @param arg2
	 * @return
	 */
	protected static Message makeErrorAndroidMessage(String errMessage, int arg1, int arg2) {
		Message msg = makeAndroidMessage(CMD_ERROR, arg1, arg2);
		if (errMessage != null) {
			Bundle b = new Bundle();
			b.putString("error_message", errMessage);
			msg.setData(b);
		}
		return msg;
	}
    
	/**
	 * @param what
	 * @param arg1
	 * @param arg2
	 * @return
	 */
	protected static Message makeAndroidMessage(int what, int arg1, int arg2) {
		Message msg = Message.obtain();
		msg.what = what;
		msg.arg1 = arg1;
		msg.arg2 = arg2;
		return msg;
	}
    
	//
	// Constructors.
	//
    
    /**
	 * @param name
	 */
	public CMessageBrokerService() {
		super();
	}
	
	//
	// Private Instance Methods.
	//
	
	private void sendMessageToDispatcher(Message msg) {
		if (dispatcherSender != null) {
			// Send the Message.
			try {
				dispatcherSender.send(msg);
			} catch (RemoteException e) {
				// TODO: Decide how we want to handle this exception. (JWB)
			}
		}
	}
    
	//
	// Public Instance Methods.
	//
    
	@Override
    public void onCreate() {
		Log.d(TAG, "onCreate()");
		
		// TODO: Implement, if needed. (JWB)
    }	


    @Override
    public void onDestroy() {
		Log.d(TAG, "onDestroy()");
		
    	// Is the broker task still running?
    	if (mBrokerTask.getStatus() == AsyncTask.Status.RUNNING) {
        	// Try to cancel the task and give it plenty of opportunity to shut down.
        	mBrokerTask.cancel(true);
        	SystemClock.sleep(100);
        	SystemClock.sleep(100);        	
    	}
    	
    	// Force the status code, in case the task didn't shut down correctly.
    	mStatusCode = STATE_STOPPED;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
		Log.d(TAG, "onBind()");

    	// This if() provides a guard against binding twice. It also keeps us 
    	// from trying to start two message brokers at the same time.
    	// TODO: Determine if we want to allow for multiple bindings. This would
    	// mean figuring out how to only start the task once. (JWB)
    	if (mBrokerTask.getStatus() == AsyncTask.Status.PENDING &&
    			mStatusCode == STATE_NOT_STARTED) {
        	// Get the broker class and configuration.
    		// TODO: Replace string constants with resources.
        	mBrokerClass = intent.getStringExtra("broker_class");
        	mBrokerConfiguration = intent.getStringExtra("broker_configuration");
        	
        	// Start the broker task.
    		mBrokerTask.setTaskListener(mTaskListener);
    		mBrokerTask.execute(mBrokerClass, mBrokerConfiguration);
        	
        	// Return the Messenger the Dispatcher will use to send messages 
        	// to the Broker Service.
            return mDispatchReceiver.getBinder();
    	}
    	
    	// Something is wrong.
    	return null;
    }

}
