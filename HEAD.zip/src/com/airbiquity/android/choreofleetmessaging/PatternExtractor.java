/*                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
*****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.LinkedList;

import com.airbiquity.util.AqUtils;
import com.airbiquity.util.ByteBuff;
import com.airbiquity.util.CRC32;
import com.airbiquity.util.IniProperties;

/*
 * Test Code:
 		PatternExtractor pe = new PatternExtractor();
		pe.initialize("");
		
		byte[] syncPattern = {'s','Y','n','C'};
		byte[] pktHdr1 = {0,0,0,0,0,0,0,0,0,0};
		byte[] pktData1 = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		byte[] pktHdr2 = {0,0,0,0,0,0,0,0,0,0};
		byte[] pktData2 = {0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9};
		byte[] pktData3 = {100, 101, 102, 103, 104, 105, 106, 107, 108, 109};
		byte[] pkt1, pkt2, pkt3;
		byte[] len; 
		byte[] crc; 
		byte[] giantPkt; 
				
		len = AqUtils.unsignedIntToByteArray(pktData1.length);
		System.arraycopy(len, 0, pktHdr1, 0, 2);
		
		len = AqUtils.unsignedIntToByteArray(pktData2.length);
		System.arraycopy(len, 0, pktHdr2, 0, 2);
		
		CRC32 c = new CRC32();
		
		c.reset();
		c.update(pktData1);
		//System.out.println("pkt1 CRC: " + c.getValue());
		crc = AqUtils.unsignedLongToByteArray(c.getValue());
		//printByteArray(crc);
		System.arraycopy(crc, 0, pktHdr1, 2, 8);
		
		c.reset();
		c.update(pktData2);
		//System.out.println("pkt2 CRC: " + c.getValue());
		crc = AqUtils.unsignedLongToByteArray(c.getValue());
		//printByteArray(crc);
		System.arraycopy(crc, 0, pktHdr2, 2, 8);
		
		//System.out.println();
		//printByteArray(pktHdr1);
		//printByteArray(pktHdr2);
		//System.out.println();
		
		//System.out.println();
		pkt1 = AqUtils.concatByteArrays(pktHdr1, pktData1);
		//printByteArray(pkt1);
		pkt2 = AqUtils.concatByteArrays(pktHdr2, pktData2);
		//printByteArray(pkt2);
		//System.out.println();
		pkt3 = pe.prepareMessagePacket(pktData3);
		//printByteArray(pkt3);
		//System.out.println();
		
		giantPkt = AqUtils.concatByteArrays(syncPattern, pkt2);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		giantPkt = AqUtils.concatByteArrays(giantPkt, pkt1);
		giantPkt = AqUtils.concatByteArrays(giantPkt, syncPattern);
		
		System.out.println();
		int pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt2);
		//pr = pe.addChunk(pkt1); // Was being picked up twice!
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktHdr2);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktData2);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(syncPattern);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktHdr1);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pktData2);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(null);
		//pr = pe.addChunk(syncPattern);
		pr = pe.addChunk(giantPkt);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt3);
		//System.out.println("addChunk Result: " + pr);
		pr = pe.addChunk(pkt3);
		//System.out.println("addChunk Result: " + pr);
		
		System.out.println();
		System.out.println("Message count: " + pe.validMessagePacketCount()); // 7.
		System.out.println("Error count: " + pe.errorMessagePacketCount()); // 3.
		System.out.println();
		
		int pc = pe.validMessagePacketCount();
		for (int i = 1;i <= pc;i++) {
			pkt1 = pe.pullMessagePacket();
			System.out.print("Message Packet " + i + ": ");
			printByteArray(pkt1);
		}
 */

/**
 * <p>Implements an iCMessageExtracter that looks for a pattern of bytes 
 * and then uses a size and CRC value to check and extract the message.</p>
 * 
 * <p>This class may be used two ways:</p>
 * <ul>
 * <li>As a helper class for a message broker</li>
 * <li>By inheriting from this class when implementing a message broker</li>
 * </ul>
 * 
 * <p>The latter method (inheritance) is probably the most effective, as that
 * means you can use the one initialization string and just pass it to the 
 * super instance before addChunking it for broker-related configuration values.</p>
 * 
 * <p>The latter method (inheritance) is probably the most effective, as that
 * means you can use the one initialization string and just pass it to the 
 * super instance before addChunking it for broker-related configuration values.</p>
 * 
 * @author Jack William Bell
 * 
 * @see iCMessageExtracter
 */
public class PatternExtractor implements iCMessageExtracter {
	protected static final int DEFAULT_BUFFER_START_SIZE = 1024;
	protected static final byte[] DEFAULT_SEARCH_PATTERN = new byte[]{'s','Y','n','C'};
	protected static final int DEFAULT_MIN_OCCURS = 2;
	
	/**
	 * Configuration key to use for configuring the buffer start size.
	 */
	public static final String INI_KEY_BUFFER_START_SIZE = "pe_buffer_start_size";
	/**
	 * Configuration key to use for configuring the search pattern.
	 */
	public static final String INI_KEY_SEARCH_PATTERN = "pe_search_pattern";
	/**
	 * Configuration key to use for configuring the minimum pattern occurrence.
	 */
	public static final String INI_KEY_MIN_OCCURS = "pe_minimum_pattern_occurrence";
	
	private ByteBuff mBuff = null;
	private LinkedList<byte[]>	mValidPacketQueue = new LinkedList<byte[]>();
	private CRC32 mCrc = new CRC32();

	private int mMinPatternOccurs = 0;
	private int mSearchStartIdx = 0;
	private int mInvalidPacketCount = 0;
	private int mLastPacketFoundSize = 0;
	
	/**
	 * Default constructor.
	 */
	public PatternExtractor() {
		
	}
	
	/**
	 * @param idx
	 * @return
	 */
	protected byte[] extractPacketAtIndex(int idx) {
		byte[] pkt = null;
		int size = 0;
		long crc = 0;
		
		this.mLastPacketFoundSize = 0;
				
		// We will expect a header consisting of the following:
		// 2 byte packet size | 2 byte packet CRC value. This is followed 
		// by the actual packet bytes, which are of the size indicated and
		// which have a matching CRC.
		try {
			size = AqUtils.twoBytesToUnsignedInt(this.mBuff.get(idx), this.mBuff.get(idx + 1));
			crc = AqUtils.eightBytesToUnsignedLong(this.mBuff.get(idx + 2), this.mBuff.get(idx + 3),
					this.mBuff.get(idx + 4), this.mBuff.get(idx + 5), 
					this.mBuff.get(idx + 6), this.mBuff.get(idx + 7),
					this.mBuff.get(idx + 8), this.mBuff.get(idx + 9));
			if (size > 0) {
				// Get the packet.
				pkt = this.mBuff.extractRange(idx + 10, size);
				// Check the CRC.
				mCrc.reset();
				this.mCrc.update(pkt);
				if (this.mCrc.getValue() == crc) {
					this.mLastPacketFoundSize = size + 10; // Including header.
				}
				else {
					pkt = null;
				}
			}
		}
		catch (Exception ex) {
			// Ignore it.
		}
		
		return pkt;
	}
	
	/**
	 * <p>Looks for the next packet and extracts it. Returns true if there
	 * is another packet to examine, otherwise false.</p>
	 * 
	 * <p><b>NOTE:</b> This is where the magic happens. It is a fairly complex 
	 * search algorithm. Take care when changing it. Test heavily. (JWB)
	 * 
	 * <p><b>NOTE:</b> This method is highly coupled with extractPacketAtIndex(). (JWB)
	 * 
	 * @return
	 */
	protected boolean findNextPacket() {
		boolean result = false;
		
		// Make sure we are in a valid global state.
		if (this.mSearchStartIdx < 0) return false;
		
		// We are going to search for the pattern occurring at least the 
		// mMinPatternOccurs times in a row to signal the start of a message 
		// packet. HOWEVER, the pattern can occur a greater number of times in
		// a row! Or it might not be there at all. Or it might occur, followed 
		// by a break of non-pattern bytes, followed by the pattern again.
		//
		// So, we look for the pattern and we count the 
		// number times it occurs without a break. We stop looking when we 
		// fail to find the pattern (even if we already found it N times) or
		// when we encounter a break of non-pattern bytes and then the 
		// pattern again (1 time).
		int[] sr = this.mBuff.search(this.mSearchStartIdx);
		int foundCount = 0, nextIdx = 0;
		while (sr != null) {
			// Cache the next index from the search result.
			nextIdx = sr[2];
			
			// Increment the found count and look again.
			foundCount++;
			sr = this.mBuff.search(nextIdx);
			
			// Did we find the pattern again?
			if (sr != null) {
				// Was it not at the next index?
				if (sr[0] != nextIdx) {
					// Drop out and inspect what we might have.
					break;
				}
			}
		}
		
		// So, did we find anything?
		if (foundCount >= this.mMinPatternOccurs) {
			// If we got here then we found enough occurrences of the 
			// pattern to indicate we might have a packet. So let's
			// take a look.
			byte[] pkt = this.extractPacketAtIndex(nextIdx);
			if (pkt == null) {
				// Is there another instance of the pattern following
				// this potential packet?
				if (sr != null) {
					// We found an invalid packet, instead of just a 
					// partially formed one.
					this.mInvalidPacketCount++;
					
					// Move the search index ahead.
					this.mSearchStartIdx = sr[0];
					result = true;
				}
			}
			else {
				// Push the message packet onto the end of the queue.
				this.mValidPacketQueue.add(pkt);

				// Is there another instance of the pattern following
				// this packet?
				if (sr != null) {
					// Move the search index ahead.
					this.mSearchStartIdx = sr[0];
				}
				else {
					// Move the search index ahead.
					this.mSearchStartIdx += nextIdx + this.mLastPacketFoundSize;
				}
				result = true;
			}	
		}
		else if (sr != null) {
			// If we got here, we had a break of non pattern bytes between 
			// instances of the pattern, only the pattern didn't occur 
			// enough times to signal a message packet. This is probably 
			// a bad packet!
			this.mInvalidPacketCount++;
			
			// Move the search index ahead.
			this.mSearchStartIdx = sr[0];
			result = true;
		}
		
		return result;
	}

	@Override
	public void initialize(String configurationString) {
		// Get the passed configuration, if possible.
		IniProperties config = null;
		try {
			config = new IniProperties(configurationString);
		} catch (IOException e) {
			// TODO: Determine how we want to handle this. (JWB)
		}
		
		// Pull buffer start size out of config and use that, if any.
		int bufferStartSize = DEFAULT_BUFFER_START_SIZE;
		try {
			bufferStartSize = Integer.parseInt(config.getProperty(INI_KEY_BUFFER_START_SIZE));
		} catch (Exception e) {
			// TODO: Determine how we want to handle this. (JWB)
		}
		mBuff = new ByteBuff(bufferStartSize);
		
		// Pull search pattern out of the config and use that, if any.
		byte[] searchPattern = DEFAULT_SEARCH_PATTERN;
		String sp = config.getProperty(INI_KEY_SEARCH_PATTERN);
		if (sp != null) {
			try {
				searchPattern = sp.getBytes(Charset.forName("US-ASCII"));
			}
			catch (Exception ex) {
				// TODO: Determine how we want to handle this. (JWB)
			}
		}
		mBuff.setSearchPattern(searchPattern);
		
		// TODO: Pull minimum pattern occurrence out of the config and use that, if any. (JWB)
		mMinPatternOccurs = DEFAULT_MIN_OCCURS;
		try {
			mMinPatternOccurs = Integer.parseInt(config.getProperty(INI_KEY_MIN_OCCURS));
		} catch (Exception e) {
			// TODO: Determine how we want to handle this. (JWB)
		}
		
		// Do a clear to set the initial state.
		clear();
	}

	@Override
	public void clear() {
		mSearchStartIdx = 0;
		mInvalidPacketCount = 0;
		mValidPacketQueue.clear();
		mBuff.clear();
	}

	@Override
	public int addChunk(byte[] chunk) {
		// Append the chunk to the buffer.
		if (chunk != null) this.mBuff.appendChunk(chunk);
		
		// NOTE: This routine is highly coupled to findNextPacket(). (JWB)
		while (findNextPacket()) {}
		
		// Compress the buffer to remove already addChunked bytes.
		int size = this.mBuff.size();
		if (this.mSearchStartIdx < 0 || this.mSearchStartIdx >= size) {
			// There was an error in the search or else we just happened
			// to end up at the end of the buffer. Either way we simply clear the buffer.
			this.mBuff.clear();
			this.mSearchStartIdx = 0;
		}
		else if (this.mSearchStartIdx > 0 && this.mSearchStartIdx < size) {
			// We need to remove  the bytes before the search index.
			// NOTE: The -1 is a 'belt and suspenders' cheat. (JWB)
			this.mBuff.snipRange(0, this.mSearchStartIdx - 1); 
			this.mSearchStartIdx = 0;
		}
		
		// Return the current valid message count.
		return mValidPacketQueue.size();
	}

	@Override
	public int errorMessagePacketCount() {
		return mInvalidPacketCount;
	}

	@Override
	public int validMessagePacketCount() {
		return mValidPacketQueue.size();
	}

	@Override
	public byte[] pullMessagePacket() {
		if (mValidPacketQueue.size() > 0) {
			return mValidPacketQueue.pollFirst();
		}
		
		return null;
	}

	public byte[] prepareMessagePacket(byte[] messagePacket) {
		if (messagePacket == null) return null;
		
		int len = messagePacket.length;
		byte[] ba = new byte[len + 10];
		byte[] ptrn = this.mBuff.getSearchPattern();
		byte[] tmp;
		
		// Set the size.
		tmp = AqUtils.unsignedIntToByteArray(len);
		System.arraycopy(tmp, 0, ba, 0, 2);
		
		// Set the CRC.
		this.mCrc.reset();
		this.mCrc.update(messagePacket);
		tmp = AqUtils.unsignedLongToByteArray(this.mCrc.getValue());
		System.arraycopy(tmp, 0, ba, 2, 8);
		
		// Copy in the message packet.
		System.arraycopy(messagePacket, 0, ba, 10, len);
		
		// Add the sync pattern.
		// NOTE: This makes sure we have at least one more instance
		// of the sync pattern than the minimum. (JWB)
		// TODO: Non-optimal way to do this. Recode to make 'ba' big 
		// enough to hold everything and then just copy the bytes into 
		// 'ba' instead of concatenating. (JWB)
		ba = AqUtils.concatByteArrays(ptrn, ba);
		for (int i = 0;i < this.mMinPatternOccurs;i++) {
			ba = AqUtils.concatByteArrays(ptrn, ba);
		}
		
		// Done.
		return ba;
	}
}
