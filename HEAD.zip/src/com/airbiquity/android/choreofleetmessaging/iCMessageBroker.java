/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

/**
 * <p>Provides a message broker that communicates with an external device to send
 * and receive Choreo messages. Implementations of this interface must be 
 * completely self-contained, in the sense that they do not use code injection 
 * and are capable of being created with a generic constructor. </p>
 * 
 * <p>This interface follows a 'process control' pattern:</p>
 * <ol>
 * <li>Implementation is instantiated</li>
 * <li>Instance is configured</li>
 * <li>Instance is 'started' and sets itself up accordingly</li>
 * <li>Instance process implementation is called repeatedly until processing is complete</li>
 * <li>Instance is 'stopped' and cleans up as needed</li>
 * <li>Instance is removed from memory</li>
 * </ol>
 * 
 * <p><b>NOTE:</b> Implementations of this interface <em>do not</em> have to be re-usable. In other
 * words, once the stop() method is called you cannot call initialize() or start() again
 * and continue processing.</p>
 * 
 * @author Jack William Bell
 */
public interface iCMessageBroker {

	/**
	 * <p>Called before message broker processing to configure the message broker.</p>
	 * 
	 * <p><b>NOTE:</b> This method should only be called once.</p>
	 * 
	 * @param configurationString String containing configuration values for the 
	 * message broker. The configuration format is implementation dependent.
	 */
	public void initialize(String configurationString);
	
	/**
	 * <p>Called when the message broker service is starting processing, but before
	 * the 'loop' processing.</p>
	 * 
	 * <p><b>NOTE:</b> Avoid long-running operations inside of this method. If long running operations 
	 * are required, start separate threads for them from this method or from the runLoop() method
	 * and make certain those threads are cancelled/stopped by the stop() method.</p>
	 * 
	 * <p><b>NOTE:</b> This method should only be called once.</p>
	 * 
	 * @return True if the message broker could be started, otherwise returns false.
	 * @throws NoTransportException Could not make transport available.
	 */
	public boolean start() throws NoTransportException;
	
	/**
	 * Returns true if the broker is connected and can send/receive messages, otherwise
	 * false. 
	 * 
	 * <p><b>NOTE:</b> This method should perform the connection/reconnection processing
	 * (if not connected), otherwise it should do as quick and simple a connection check
	 * as possible in order to reduce calling loop costs. For example, you could
	 * actually check if the connection is lost in the process() method instead and 
	 * use a module-level variable that is returned by this method.</p>
	 * 
	 * @return True if the broker is connected and can send/receive messages, otherwise
	 * false. 
	 */
	public boolean isConnected();
	
	/**
	 * <p>Provides the code inside the 'loop' for the message broker implementation. This
	 * method is called over and over from the message broker service processing loop
	 * and, on each iteration, should attempt to send a message (if one is supplied) and
	 * return a message (if one is available). </p>
	 * 
	 * <p>Although the process() method can implement one or more loops internally in order 
	 * to do processing, it <em>must</em> exit as soon as data is available to return and 
	 * <em>should</em> exit as quickly as possible in order to allow the message broker 
	 * service to send the next message or stop processing.</p>
	 * 
	 * <p><b>NOTE:</b> Avoid long-running operations inside of this method. If long running operations 
	 * are required, start separate threads for them from this method or from the start() method
	 * and make certain those threads are cancelled/stopped by the stop() method.
	 * 
	 * @param dataToSend A CMessage object containing data to send or null. 
	 * @return A CMessage object containing data received or null.
	 * @throws NoTransportException Transport not available, fatal error.
	 * @throws NoConnectionException Connection lost, will try to reconnect. 
	 */
	public CMessage process(CMessage dataToSend) throws NoTransportException, NoConnectionException;
	
	/**
	 * <p>Called after the message broker service completes the 'loop' processing.</p>
	 * 
	 * <p><b>NOTE:</b> If long-running operations are delegated to separate threads, they <em>must</em> 
	 * be cancelled/stopped when this method is called.</p>
	 * 
	 * <p><b>NOTE:</b> This method should only be called once.</p>
	 */
	public void stop();
}
