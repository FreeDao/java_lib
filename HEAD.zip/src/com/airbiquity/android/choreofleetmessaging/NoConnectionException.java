package com.airbiquity.android.choreofleetmessaging;

public class NoConnectionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6748921154164892184L;

	public NoConnectionException() {
		super();
	}
	
	public NoConnectionException(String msg) {
		super(msg);
	}

	public NoConnectionException(Exception ex) {
		super(ex);
	}
}
