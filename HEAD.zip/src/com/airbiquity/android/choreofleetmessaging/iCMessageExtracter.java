/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
*****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

/**
 * <p>Implemented to provide a class that processes chunks of bytes
 * in a format or encoding that must be processed before the 
 * message packet(s) in a byte stream can be used.</p>
 *  
 * <p>If the data contains Choreo message packets, those packets 
 * are retained until extracted. Each chunk may contain all or part of
 * one or more messages. So you may need to add many chunks before you 
 * get one message and/or you can get many messages in one chunk. This
 * is especially suited to managing data sent via a streaming transport.</p>
 * 
 * <p><b>NOTE:</b> How the messages are formatted and encoded into
 * the byte chunks is implementation dependent.</p>
 * 
 * <p>To use a message extractor for processing, simply call it's 
 * initialize() method and then call the process() method for 
 * every chunk of data that arrives. process() returns the number 
 * of valid messages in the queue, as does validMessagePacketCount().
 * So, at any time that count is greater than zero, you can extract 
 * messages using the pullMessagePacket() method. </p>
 * 
 * <p>If you need to send a message, prepare for sending first by 
 * passing it to the prepareMessagePacket() method and sending the
 * returned value. This make certain that the message is in the 
 * correct format for the protocol or encoding the extractor
 * implementation is using.</p>
 * 
 * @author Jack William Bell
 */
public interface iCMessageExtracter {
	
	/**
	 * <p>Called before extract processing to configure the extractor.</p>
	 * 
	 * <p><b>NOTE:</b> This method should only be called once.</p>
	 * 
	 * @param configurationString String containing configuration values for the 
	 * extractor. The configuration format is implementation dependent.
	 */
	public void initialize(String configurationString);
	
	
	/**
	 * Clears the internal buffer(s), if any. This includes removing
	 * any message packets found.
	 */
	public void clear();
	
	/**
	 * <p>Processes the passed byte array as one chunk of many. Returns the 
	 * number of valid message packets currently available. (The same value
	 * as returned by validMessagePacketCount().)</p>
	 * 
	 * <p><b>NOTE:</b> Each chunk may contain all or part of one or 
	 * more messages. Each message found must be retained until it
	 * is extracted of the clear() method is called.</p>
	 * 
	 * @see validMessagePacketCount()
	 * @see pullMessagePacket()
	 * 
	 * @param chunk
	 * @return 
	 */
	public int addChunk(byte[] chunk);
	
	/**
	 * Returns the number of invalid Choreo message packets found so far.
	 * Invalid messages include any corrupted or otherwise unusable 
	 * packets.
	 * 
	 * @see clear()
	 * 
	 * @return 
	 */
	public int errorMessagePacketCount();
	
	/**
	 * Returns the number of valid Choreo message packets found so far.
	 * 
	 * @return 
	 */
	public int validMessagePacketCount();
	
	/**
	 * Returns and removes the oldest found Choreo message packet.
	 * 
	 * @return A Choreo message packet or null.
	 */
	public byte[] pullMessagePacket();
	
	/**
	 * Prepares the passed message packet for sending and returns
	 * the result as a byte array. Preparing the packet includes 
	 * processing it so that the message extractor implementation 
	 * would recognize it as a message packet and process it
	 * properly.
	 * 
	 * @param messagePacket
	 * @return
	 */
	public byte[] prepareMessagePacket(byte[] messagePacket);
}
