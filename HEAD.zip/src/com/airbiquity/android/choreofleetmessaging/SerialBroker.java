/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
*****************************************************************************/

package com.airbiquity.android.choreofleetmessaging;

/**
 * Provides a serial-based broker for the Choreo Message services. 
 * 
 * @author Jack William Bell
 *
 */
public class SerialBroker implements iCMessageBroker {

	@Override
	public void initialize(String configurationString) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean start() throws NoTransportException {
		// TODO Auto-generated method stub
		return false;
	}

	
	@Override
	public boolean isConnected() {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public CMessage process(CMessage dataToSend) throws NoTransportException, NoConnectionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

}
