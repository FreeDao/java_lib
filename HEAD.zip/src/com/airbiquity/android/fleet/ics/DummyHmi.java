package com.airbiquity.android.fleet.ics;

import com.airbiquity.aqlog.AqLog;

public class DummyHmi implements DirectorToHmiEventListener {

	public DummyHmi()
	{
	}
	
	@Override
	public void handleTextMessage(String jsonTextMessage) {
		AqLog.getInstance().debug("HMI got text message: " + jsonTextMessage );
	}

	@Override
	public void handleObuAlert(String jsonAlert) {
		AqLog.getInstance().debug("HMI got alert: " + jsonAlert );
	}

	@Override
	public void handleObuEvent(String jsonEvent) {
		AqLog.getInstance().debug("HMI got event: " + jsonEvent );
	}

	@Override
	public void handleObuStatus(String jsonObuStatus) {
		AqLog.getInstance().debug("HMI got OBU Status: " + jsonObuStatus );
	}

	@Override
	public void reset() {
		AqLog.getInstance().debug("HMI got reset()" );
	}

}
