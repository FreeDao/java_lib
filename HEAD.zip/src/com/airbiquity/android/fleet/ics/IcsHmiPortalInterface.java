package com.airbiquity.android.fleet.ics;

import com.airbiquity.android.fleet.icsobjs.DriverConfiguration;

/** This interface is the portal for the CFMS In-Cab Screen (ICS) web application running on Android to send
 *  receive data to/from the OBU and/or core/Choreo and also fetch data from local sources as needed.  This 
 *  interface has been simplified such that it only deals with object exchange and simple methods without 
 *  requiring the web application to have any knowledge of how the requests are filled or how the objects are generated. 
 *  
 * 
 * @author DQuimby
 *
 */
public interface IcsHmiPortalInterface  {
	
	/** The HMI application(s) will call this method in order to receive incoming
	 *  Objects and notifications from the IcsDirector.
	 * 
	 * @param listener The listener that will be registered.
	 */
	public void addDirectorToHmiEventListener( DirectorToHmiEventListener listener );
	
	/** The HMI application will use this method to send a text message to Choeo.  
	 * 
	 * @param jsonTextMessage
	 * 
	 * @return <code>true</code> if the json oject was decoded successfully and the text message
	 *         has been queued to be sent to Choreo.
	 */
	public boolean sendTextMessageToChoreo( String jsonTextMessage );
	
	/** Inform the director that the specified message has been viewed by the driver.
	 * 
	 * @param messageId The id of the message that was viewed.
	 * @return <code>true</code> if the specified message id is associated with a received text message.  If the 
	 *         message id doesn't match a received message in the datbase <code>false</code> will be returned instead.
	 */
	public boolean setMessageIsReadStatus( long messageId );

	/** Request the director to validate the given PIN code.  If the PIN is valid, the 
	 *  Director will notify the OBU that a valid PIN was entered on the touchscreen.  
	 *  This may not result in a valid logon if the OBU has already validated a logon source
	 *  With a higher order of precedence (i.e. DTCO card).  The HMI should not consider 
	 *  that a logon exists until it receives the ObuLogonEvent object.
	 * 
	 * @param pin The PIN code to be validated.
	 * @return <code>true</code> if the PIN is valid.  <code>false</code> otherwise.
	 */
	public boolean validatePin( String pin );
	
	/** The End User License Agreement (EULA) has been accepted by the specified driver.  The Director 
	 *  will update the database with this information so that the EULA will not need to be shown to 
	 *  this driver in the future.
	 * 
	 * @param driverIdType The type associated with the currently logged on driver.
	 * @param driverId The identifier string associated with the currently logged on driver.
	 * @return <code>true</code> if the EULA was previously accepted by the specified driver.  <code>false</code> otherwise.
	 */
	public boolean eulaIsAcceptedBy( byte driverIdType, String driverId );
	
	/** Get the configuration object for the specified driver. The configuration information will be fetched via
	 *  the data broker if there is existing configuration information for the specified driver.
	 * 
	 * @param driverIdType The type associated with the currently logged on driver.
	 * @param driverId The identifier string associated with the currently logged on driver.
	 * @return The object that contains the specified drivers configuration info.  If there is no existing confiuration
	 *         for the requested driver then null will be returned.
	 */
	public DriverConfiguration getDriverConfiguration( byte driverIdType, String driverId );

	/** Store a driver's configuration information.  This will be written to persistant storage by the data broker.
	 * 
	 * @param driverIdType The type associated with the currently logged on driver.
	 * @param driverId The identifier string associated with the currently logged on driver.
	 * @param configuration The configuration data to store and associate with the specified driver.
	 * @return
	 */
	public boolean setDriverConfiguration( byte driverIdType, String driverId, DriverConfiguration configuration );
	
	/** Return the content of a pre-defined text message in the specified language.  
	 * 
	 * @param language The language as ISO 639-2 requested for the pre-defined message.  
	 * @param preDefindeMsgId The pre-defined or "Standard message" identifier (Currently
	 * 		  there are 5 pre-defined messages defined ). 
	 * @return A string which contains the content of the pre-defined messaged in the specified language.
	 */
	public String getPredefinedTextMessage( String language, int preDefindeMsgId );
	
	
	public static final int DRIVING_TIP_CATEGORY_SCORE = 1;
	public static final int DRIVING_TIP_CATEGORY_IDLING = 2;  /// catagory representing vehicle idle time.
	public static final int DRIVING_TIP_CATEGORY_OVER_REV = 3;
	public static final int DRIVING_TIP_CATEGORY_HARSH_THROTTLE = 4;
	public static final int DRIVING_TIP_CATEGORY_BRAKING = 5;
	public static final int DRIVING_TIP_CATEGORY_CRUISE_CONTROL = 6;
	public static final int DRIVING_TIP_CATEGORY_COASTING = 7;
	public static final int DRIVING_TIP_LEVEL_NEEDS_IMPROVEMENT = 1;
	public static final int DRIVING_TIP_LEVEL_MEETS_TARGET = 2;
	public static final int DRIVING_TIP_LEVEL_GOOD_JOB = 3;
	

	/** Get a driving tip for the specified category, language, and level.  
	 *
	 * @param category The category of driving tip desired.  Should be one of {@code DRIVING_TIP_CATEGORY_SCORE  
	 *                 DRIVING_TIP_CATEGORY_IDLING, DRIVING_TIP_CATEGORY_OVER_REV, DRIVING_TIP_CATEGORY_HARSH_THROTTLE, 
	 *                 DRIVING_TIP_CATEGORY_CRUISE_CONTROL DRIVING_TIP_CATEGORY_COASTING}
	 * @param language The desired language for the requested tip.
	 * @param level An indication of how the results of the given shift compare against the targets.  This will 
	 *              help select a more appropriate tip to suit the specific condition. 
	 * @return A driving tip for the selected category in the selected language.  The tip will be relevant to the category and the driver's current score against targets.
	 *         
	 */
	public String getDrivingTip( int category, String language, int level );
	
	/** Fetch all messages for this vehicle and also those addressed to the driver that is currently logged on to the ICS.
	 *  The messages will be returned as an array of JSON Text Message objects that are sorted by date in descending order.
	 * 
	 * @return A string containing an array of JSON TextMessage objects.  If no messages are found addressed to the vehicle or current driver null will be returned.
	 */
	public String getTextMessagesForVehicleAndCurrentDriver();
}
