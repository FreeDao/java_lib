package com.airbiquity.android.fleet.icsobjs;

import org.json.JSONObject;

import com.airbiquity.cfms.AqDriverId;

/** An object which holds the current OBU status.  This will be consumed by the HMI to determine if 
 *  user input/display should be locked out. 
 *  
 * 
 * TBD: Should the OBU send status as a "fire and forget" message?  There is updated status every second, so
 * uploading it may not make sense to keep trying to upload an older status object if a newer one is available.
 * 
 * @author DQuimby
 *
 */
public class ObuStatus extends IcsHmiExchangeObject {
	long timestamp = 0;
	float vehicleSpeed = 0.0f;
	int driverIdType = AqDriverId.ID_TYPE_UNKNOWN;
	String driverId = "";
	String shiftId = "";
	boolean isGprsUp = false;
	double latitude = 0;
	double longitude = 0;
	
	public String getShiftId() {
		return shiftId;
	}

	public void setShiftId(String shiftId) {
		this.shiftId = shiftId;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public int getDriverIdType() {
		return driverIdType;
	}

	public void setDriverIdType(int driverIdType) {
		this.driverIdType = driverIdType;
	}

	/** Indicator of the OBU's current GPRS connectivity.  The CMessage dispatcher should avoid
	 *  transferring messages that are destined to Choreo when there is no GPRS connectivity.  
	 * 
	 * @return <code>true</code> indicates that the OBU's GPRS connection is currently available.
	 */
	public boolean isGprsUp() {
		return isGprsUp;
	}

	/** Set the indicator for the OBU's GPRS connectivity status.
	 * 
	 * @param isGprsUp <code>true</code> if the OBU currently has GPRS connectivity.  <code>false</code> if the OBU doesn't currently have GPRS.
	 */
	public void setGprsUp(boolean isGprsUp) {
		this.isGprsUp = isGprsUp;
	}

	/** Get the time the OBU recorded the OBU's status
	 * 
	 * @return The number of milli-seconds since 01/01/1970 that the status was recorded by the OBU.
	 */
	public long getTimestamp() {
		return timestamp;
	}
	
	/** Set the time the OBU recorded the OBU's status
	 * 
	 * @param timestamp The number of milli-seconds since 01/01/1970 that the status was recorded by the OBU.
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	
	/** Get the vehicle speed in kilometers per hour at the time the status was recorded.
	 * 
	 * @return The vehicle speed in kph.
	 */
	public float getVehicleSpeed() {
		return vehicleSpeed;
	}
	
	/** Set the vehicle speed in kilometers per hour at the time the status was recorded.
	 * 
	 * @param vehicleSpeed The vehicle speed in kph.
	 */
	public void setVehicleSpeed(float vehicleSpeed) {
		this.vehicleSpeed = vehicleSpeed;
	}
	
	/** Get the object which represents the driver that is currently logged on to the vehicle.
	 * 
	 * @return the 
	 */
	public String getDriverId() {
		return driverId;
	}

	/** 
	 * 
	 * @param currentDriver
	 */
	public void setDriverId( String driverId )
	{
		this.driverId = driverId;
	}

	public String toString()
	{
		String retval = null;
		try
		{
			JSONObject msgJson = new JSONObject();
			msgJson.put( IcsConstants.KEY_TIMESTAMP, this.getTimestamp()); 
			msgJson.put( IcsConstants.KEY_SHIFT_ID, this.getShiftId() ); 
			msgJson.put( IcsConstants.KEY_DRIVER_ID_TYPE, this.getDriverIdType() ); 
			msgJson.put( IcsConstants.KEY_DRIVER_ID, this.getDriverId() ); 
			msgJson.put( IcsConstants.KEY_LATITUDE, this.getLatitude());; 
			msgJson.put( IcsConstants.KEY_LONGITUDE, this.getLongitude()); 
			msgJson.put( IcsConstants.KEY_VEHICLE_SPEED, this.getVehicleSpeed() ); 
			retval = msgJson.toString();
		}
		catch( Exception e )
		{
			
		}
		return retval;
	}
}
