package com.airbiquity.android.fleet.icsobjs;

import com.airbiquity.cfms.AqDriverId;


/** This is a base class for logon and logoff events. It is used to manage the common fields for the logon/logoff events. 
 *  Only the sub-classes LogonEvent and LogoffEvent are passed from the IcsDirector to the HMI.   
 * 
 * @author DQuimby
 *
 */
public abstract class ObuShiftEvent extends IcsHmiExchangeObject {
	private long timestamp = 0;
	private AqDriverId driverId;

	/** Get the timestamp when this event occured.  The timestamp will be represented in milli-seconds since 1/1/1970.
	 * 
	 * @return the timestamp.
	 */
	public long getTimestamp() {
		return timestamp;
	}
	
	/** Set the timestamp when this event occured.  The timestamp is represented in milli-seconds since 1/1/1970.
	 * 
	 * @param timestamp the value that this event's timestamp will be set to.
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	
}
