package com.airbiquity.android.fleet.icsobjs;

import org.json.JSONObject;

import com.airbiquity.aqlog.AqLog;
import com.airbiquity.cfms.AqDriverId;
import com.airbiquity.util.JsonHelper;

public class DriverId extends IcsHmiExchangeObject {
	private int driverIdType = AqDriverId.ID_TYPE_UNKNOWN;
	private String driverId = "";
	
	public int getDriverIdType() {
		return driverIdType;
	}
	
	public void setDriverIdType(int driverIdType) {
		this.driverIdType = driverIdType;
	}
	
	public String getDriverId() {
		return driverId;
	}
	
	public void setDriverId(String driverId) {
		this.driverId = driverId;
	}
	
	
	public String toString()
	{
		String retval = null;
		try
		{
			JSONObject msgJson = new JSONObject();
			msgJson.put( IcsConstants.KEY_DRIVER_ID_TYPE, this.getDriverIdType() );
			msgJson.put( IcsConstants.KEY_DRIVER_ID, this.getDriverId() );
			retval = msgJson.toString();
		}
		catch( Exception e )
		{
			
		}
		return retval;
	}

	/** Populate the contents of this text messae object with the data specified in the given JSON string.
	 * 
	 * @param jsonString The json string that is to be used to populate this object.
	 * @return <code>true</code> if the object was successfully populated.
	 */
    public boolean fromJsonString( String jsonString )
    {
    	boolean retval = false;
    	try
    	{
    		JSONObject  json =  new JSONObject( jsonString );

    		// Default values assume the message is travelling from the ICS to Core.
    		this.setDriverIdType( JsonHelper.getInt(json, IcsConstants.KEY_DRIVER_ID_TYPE, IcsConstants.DRIVER_ID_TYPE_UNKNOWN ) );
    		this.setDriverId( JsonHelper.getString(json, IcsConstants.KEY_DRIVER_ID, "" ) );
			retval = true;
    	}
    	catch( Exception e )
    	{
    		AqLog.getInstance().debug("Error populating Text message from JSON object", e );
    	}
    	return retval;
    }
}

