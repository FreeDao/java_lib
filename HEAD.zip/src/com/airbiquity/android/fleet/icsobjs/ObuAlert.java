package com.airbiquity.android.fleet.icsobjs;

import org.json.JSONObject;

import com.airbiquity.cfms.AqEventAlert;

/** This class is used to exchange Alert data between the IcsDirector and the HMI.  It will
 *  The IcsDirector will translate from an incoming AqEventAlert object to an instance of this for
 *  incoming alerts.  Additionally the IcsDirector will be able to pull alerts from the database
 *  for the current shift and populate this object as well.
 * 
 * @author DQuimby
 *
 */
public class ObuAlert  {

	public static final String ALERT_TYPE_DRIVER_HRS = "DRIVER_HRS";
	public static final String ALERT_TYPE_PTO = "PTO";
	public static final String ALERT_TYPE_IDLING = "IDLING";
	public static final String ALERT_TYPE_SPEEDING = "SPEEDING";
	
	// Used as local db id key
	long id = 0;
	
	int alertTypeId = 0;
	String alertType = "UNKNOWN";
	double latitude = 0;
	double longitude = 0;
	long timestamp = 0;
	int odometer = 0;
	int driverIdType = 0;
	String driverId = "";
	String shiftId = "";
	int duration = 0;
	float distance = 0; // float?
	int maxSpeed = 0;
	
	/** Get the numeric corresponding to the alert type.
	 * 
	 * @return The alert type constant
	 */
	public int getAlertTypeId() {
		return alertTypeId;
	}
	
	
	/** Set the numeric constant cooresponding to the alert type
	 * 
	 * @param alertTypeId The constant
	 */
	
	public void setAlertTypeId(int alertTypeId) {
		this.alertTypeId = alertTypeId;
		
		switch( alertTypeId )
		{
		case AqEventAlert.ALERT_SPEEDING:
			alertType = ObuAlert.ALERT_TYPE_SPEEDING;
			break;
		case AqEventAlert.ALERT_IDLING:
			alertType = ObuAlert.ALERT_TYPE_IDLING;
			break;
		case AqEventAlert.ALERT_PTO:
			alertType = ObuAlert.ALERT_TYPE_PTO;
			break;
		case AqEventAlert.ALERT_DRIVER_HOURS_WARNING:
			alertType = ObuAlert.ALERT_TYPE_DRIVER_HRS;
			break;

		default: 
			break;
		}
	}
	
	/** Get the descriptive alert type
	 * 
	 * @return The alert type.  Will be one of "SPEEDING","IDLING", "PTO", or "DRIVER_HOURS_WARNING".
	 */
	public String getAlertType() {
		return alertType;
	}

	/** This is here for deserialization.  Don't use this directly otherwise.  set using the 
	 *  Alert Type Id constant which will populate the readable type.
	 * 
	 * @param alertType
	 */
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	
	/** Get the latitude of the vehicle that was recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @return The latitude at the beginning of the alert period in degrees.
	 */
	public double getLatitude() {
		return latitude;
	}

	/** Set the latitude of the vehicle that was recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @param latitude The latitude at the beginning of the alert period in degrees.
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	
	/** Get the longitude of the vehicle that was recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @return The longitude at the beginning of the alert period in degrees.
	 */
	public double getLongitude() {
		return longitude;
	}
	
	
	/** Set the longitude of the vehicle that was recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @param longitude The longitude at the beginning of the alert period in degrees.
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	/** Get the timestamp recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @return The number of milliseconds since Jan 1 1970 when the start of the alert occurred.
	 */
	public long getTimestamp() {
		return timestamp;
	}
	
	/** Set the timestamp recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @param timestamp The number of milliseconds since Jan 1 1970 when the start of the alert occurred.
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	
	
	/** Get the odometer recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @return The odometer reading of the vehicle in kilometers when the start of the alert occurred.
	 */
	public int getOdometer() {
		return odometer;
	}
	
	/** Set the odometer recorded at the beginning of the infraction recorded by this alert.
	 * 
	 * @param odometer The odometer reading of the vehicle in kilometers when the start of the alert occurred.
	 */
	public void setOdometer(int odometer) {
		this.odometer = odometer;
	}

	
	
	public int getDriverIdType() {
		return driverIdType;
	}


	public void setDriverIdType(int driverIdType) {
		this.driverIdType = driverIdType;
	}


	public String getDriverId() {
		return driverId;
	}


	public void setDriverId(String driverId) {
		this.driverId = driverId;
	}


	public String getShiftId() {
		return shiftId;
	}


	public void setShiftId(String shiftId) {
		this.shiftId = shiftId;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	public float getDistance() {
		return distance;
	}


	public void setDistance(float f) {
		this.distance = f;
	}


	public int getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String toString()
	{
		String retval = null;
		try
		{
			JSONObject msgJson = new JSONObject();
			msgJson.put( IcsConstants.KEY_ID, this.id );
			msgJson.put( IcsConstants.KEY_ALERT_TYPE, this.getAlertType() );
			msgJson.put( IcsConstants.KEY_SHIFT_ID, this.getShiftId() ); 
			msgJson.put( IcsConstants.KEY_TIMESTAMP, this.getTimestamp()); 
			msgJson.put( IcsConstants.KEY_ALERT_ODOMETER, this.getOdometer() ); 
			msgJson.put( IcsConstants.KEY_LATITUDE, this.getLatitude());; 
			msgJson.put( IcsConstants.KEY_LONGITUDE, this.getLongitude()); 
			msgJson.put( IcsConstants.KEY_DRIVER_ID_TYPE, this.getDriverIdType()); 
			msgJson.put( IcsConstants.KEY_DRIVER_ID, this.getDriverId() ); 

			if( AqEventAlert.ALERT_DRIVER_HOURS_WARNING  == this.alertTypeId )
			{
				msgJson.put( IcsConstants.KEY_ALERT_DURATION, JSONObject.NULL );
			}
			else
			{
				msgJson.put( IcsConstants.KEY_ALERT_DURATION, this.getDuration());
			}

			
			if( ( AqEventAlert.ALERT_DRIVER_HOURS_WARNING  == this.alertTypeId ) ||
				( AqEventAlert.ALERT_IDLING  == this.alertTypeId ) )
			{
				msgJson.put( IcsConstants.KEY_ALERT_DISTANCE_TRAVELLED, JSONObject.NULL);
			}
			else
			{
				msgJson.put( IcsConstants.KEY_ALERT_DISTANCE_TRAVELLED, this.getDistance() ); 
			}
			
			if( AqEventAlert.ALERT_SPEEDING != this.alertTypeId )
			{
				msgJson.put( IcsConstants.KEY_ALERT_MAX_SPEED, JSONObject.NULL );
			}
			else
			{
				msgJson.put( IcsConstants.KEY_ALERT_MAX_SPEED, this.getMaxSpeed() ); 
			}
			
			retval = msgJson.toString();
		}
		catch( Exception e )
		{
			
		}
		return retval;
	}
}
