package com.airbiquity.android.fleet.icsobjs;
import com.airbiquity.cfms.AqDriverId;
public class IcsConstants {
	// Keys for json
	public static final String KEY_ID = "id";
	public static final String KEY_TIMESTAMP = "timestamp";
	public static final String KEY_DRIVER_ID_TYPE = "driver_id_type";
	public static final String KEY_DRIVER_ID = "driver_id";
	public static final String KEY_SHIFT_ID = "shift_id";
	public static final String KEY_LATITUDE = "latitude";
	public static final String KEY_LONGITUDE = "longitude";
	public static final String KEY_VEHICLE_SPEED = "vehicle_speed";
	public static final String KEY_PRIORITY = "priority";
	
	// Keys used to/from JSON
	public static final String KEY_MSG_ID = "message_id";
	public static final String KEY_MSG_PARENT_ID = "parent_id";
	public static final String KEY_MSG_FROM_TYPE = "from_type" ;
	public static final String KEY_MSG_FROM = "from" ;
	public static final String KEY_MSG_TO_TYPE = "to_type";
	public static final String KEY_MSG_TO = "to";
	public static final String KEY_MSG_SUBJECT = "subject";
	public static final String KEY_MSG_DETAIL = "detail";
	public static final String KEY_MSG_TIMESTAMP = "timestamp";
	public static final String KEY_MSG_READ = "read";
	//public static final String KEY_MSG_PRIORITY = "priority";
	public static final String KEY_MSG_RESPONSE_REQUIRED = "response_required";
	public static final String KEY_MSG_LANGUAGE = "language";
	public static final String KEY_MSG_CONTENTID = "content_id";
	public static final String KEY_MSG_ENCODING = "encoding";
	
	// JSON constants for status messages
	//public static final String KEY_STATUS_TIMESTAMP = "timestamp";
	//public static final String KEY_STATUS_DRIVER_ID_TYPE = KEY_DRIVER_ID_TYPE;
	//public static final String KEY_STATUS_DRIVER_ID = KEY_DRIVER_ID;
	//public static final String KEY_STATUS_SHIFT_ID = "shift_id";
	
	// Keys for reply with options
	//public static final String KEY_REPLY_ID = "id";
	public static final String KEY_REPLY_LANGUAGE = "language";
	public static final String KEY_REPLY_NAME = "name";
	public static final String KEY_REPLY_ORDER = "order";
	
	// Keys for driver report
	public static final String KEY_REPORT_DATA = "data";
	public static final String KEY_REPORT_IS_LAST = "is_last_shift_period";
	public static final String KEY_REPORT_SEQUENCE_NUM = "sequence_num";
	public static final String KEY_REPORT_MSG_VERSION = "vperf_message_version";
	public static final String KEY_REPORT_TRANS_ID = "cfms_trans_id";
	public static final String KEY_REPORT_LOGON_TIME = "logon_time";
	public static final String KEY_REPORT_LOGOFF_TIME = "logoff_time";
	public static final String KEY_REPORT_DISTANCE = "total_distance_travelled";
	public static final String KEY_REPORT_DURATION = "total_duration";
	public static final String KEY_REPORT_IDLING = "idling_time";
	public static final String KEY_REPORT_OVER_REV = "over_rev_distance";
	public static final String KEY_REPORT_HARSH_THROTTLE = "harsh_throttle_distance";
	public static final String KEY_REPORT_BRAKING_DISTANCE = "braking_distance";
	public static final String KEY_REPORT_CRUISE = "cruise_control_time";
	public static final String KEY_REPORT_COASTING = "coasting_time";
	public static final String KEY_REPORT_TIP_NUMBER = "tip_number";
	public static final String KEY_REPORT_TIP_CATEGORY = "tip_category";
	public static final String KEY_REPORT_TIP_LEVEL = "tip_level";
	public static final String KEY_REPORT_TIP_LANGUAGE = "tip_language";
	public static final String KEY_REPORT_TIP_TEXT = "tip_text";
	
	// Keys used for driver config
	public static final String KEY_CFG_USERID = "user_id";
	public static final String KEY_CFG_DRIVERTYPE = "driver_type";
	public static final String KEY_CFG_EULA = "is_eula_accepted";
	public static final String KEY_CFG_AUDIO = "audio_sounds";
	public static final String KEY_CFG_LANGUAGE = "language_preference";
	public static final String KEY_CFG_MSG = "display_high_priority_message";
	public static final String KEY_CFG_ALERT = "display_high_priority_alert";
	
	// Keys for reliable messages need to re-send to server
	public static final String KEY_RMSG_TRANSACTIONID = "transaction_id";
	//public static final String KEY_RMSG_PRIORITY = "priority";
	public static final String KEY_RMSG_RETRIES = "retries";
	public static final String KEY_RMSG_MESSAGE_DATA = "message_data";
	
	// Keys for alert
	public static final String KEY_ALERT_TYPE = "alert_type";
	public static final String KEY_ALERT_ODOMETER = "odometer";
	public static final String KEY_ALERT_DURATION = "duration";
	public static final String KEY_ALERT_DISTANCE_TRAVELLED = "distance_travelled";
	public static final String KEY_ALERT_MAX_SPEED = "max_speed";
	

	// User id constants  .... Driver Id types, Core User, and Vehicle.
	public static final int ID_TYPE_VEHICLE = 0x0B; // A.K.A to vehicle
	public static final int ID_TYPE_CORE = 0x0C; 
	public static final int	DRIVER_ID_TYPE_UNKNOWN = AqDriverId.ID_TYPE_UNKNOWN;    // (0x20)
	public static final int DRIVER_ID_TYPE_DTCO = AqDriverId.ID_TYPE_TACHO;         // (0x00)
	public static final int DRIVER_ID_TYPE_IBUTTON = AqDriverId.ID_TYPE_IBUTTON;    // (0x60)
	public static final int DRIVER_ID_TYPE_KEYPAD = AqDriverId.ID_TYPE_UBU_KEYPAD;  // (0x40)

}
