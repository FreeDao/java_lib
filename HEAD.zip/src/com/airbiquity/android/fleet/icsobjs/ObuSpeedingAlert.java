package com.airbiquity.android.fleet.icsobjs;

/** This class is used to send a speeding alert from the IcsDirector to the HMI.  
 * 
 * @author DQuimby
 *
 */
public class ObuSpeedingAlert extends ObuPtoAlert {
	int maxSpeed = -1;

	/** Get the maximum speed reached during the speeding alert infraction.
	 * 
	 * @return speed The maximum speed during the alert period in kph
	 */
	public int getMaxSpeed() {
		return maxSpeed;
	}
	
	/** Set the maximum speed reached during the speeding alert infraction.
	 * 
	 * 
	 * @param maxSpeed The maximum speed during the alert period in kph.
	 */
	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}
}
