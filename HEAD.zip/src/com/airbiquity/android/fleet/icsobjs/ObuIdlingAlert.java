package com.airbiquity.android.fleet.icsobjs;

/** This class is used to pass an idling alert object from the IcsDirector to the HMI.
 * 
 * @author DQuimby
 *
 */
public class ObuIdlingAlert extends ObuAlert {
	int duration = -1;

	/** The duration of the infraction which triggered the alert.
	 *  This field applies to idling, PTO, and speeding alerts.
	 * 
	 * @return The duration of the infraction in seconds.
	 */
	public int getDuration() {
		return duration;
	}
	
	/** Set the duration of the infraction for the triggered alert.
	 * 
	 * @param duration The duration of the infraction in seconds.
	 */
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
}
