package com.airbiquity.android.fleet.icsobjs;

/** This object is used to pass an idling alert from the IcsDirector to the HMI.
 * 
 * @author DQuimby
 *
 */
public class ObuPtoAlert extends ObuIdlingAlert {
	float distance = -1;

	/** Get the distanced traveled between the start and end of the infraction.
	 * Speeding and PTO Alerts
	 * 
	 * @return The distance traveled in kilometers.
	 */
	public float getDistance() {
		return distance;
	}
	
	/** Set the distance traveled between the start and end of the infraction.  This field applies to 
	 * Speeding and PTO Alerts
	 * 
	 * @param distance The distance traveled in kilometers.
	 */
	public void setDistance(float distance) {
		this.distance = distance;
	}
	
}
