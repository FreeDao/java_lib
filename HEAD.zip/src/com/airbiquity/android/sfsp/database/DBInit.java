/**  
* @Title: DBDemo.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-9-25
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class DBInit {
	private DBInstance dbInstance;

	public DBInit(Context _context) {
		dbInstance = DBInstance.getInstance(_context);
		
		// TODO, for test
		//dbInstance.clear();
		
//		initMessage();
//		initConfig();
//		initReplywithOptions();
//		initReliableMessage();
		
		//dbInstance.close();
		
		testAddSnapshotSummary();
		testGetSnapshotSummariesWithShiftId();
		testDeleteOldSnapshotSummaries();
		
		testAddShiftAbstract();
		testGetRecentShiftAbstract();
		testDeleteShiftAbstract();
		
		testAddTips();
		testSelectTips();
		testDeleteTips();
	}
	
	public void clearDB() {
//		dbInstance.clear();
	}
	
	private void initMessage() {
		ArrayList<ObjMessage> msgs = new ArrayList<ObjMessage>();
		
		ObjMessage msg;
		
		for (int i=1; i<= 10; i++) {
			msg = new ObjMessage();
			
			msg.setParent_message_id(i);
			msg.setParent_message_id(0);
			msg.setIs_read(DBConstants.OPTION_ON);
			msg.setIs_require_response(0);
			
			msg.setPriority(1);
	    	msg.setContent_id(1);
			msg.setLanguage("eng");
			msg.setEncoding(2);
			
			msg.setMessage_from("nikm");
	    	msg.setMessage_from_type(IcsConstants.ID_TYPE_CORE);
			msg.setMessage_to_type(IcsConstants.ID_TYPE_VEHICLE);
			msg.setMessage_to(DBConstants.UNKNOWN_DRIVERID);
			
			msg.setTime(1349458840);
			msg.setSubject("Just for test " + i);
			msg.setBody("Test message " + i);
			
			msgs.add(msg);
		}
		
		dbInstance.addMessage(msgs);
	}
	
	private void initReplywithOptions() {		
		List<ObjReplywith> opts = new ArrayList<ObjReplywith>();
		
		ObjReplywith opt;
		
		opt = new ObjReplywith();
		opt.setLanguage("eng");
		opt.setName("Yes");
		opt.setOrder(1);
		opts.add(opt);
		
		opt = new ObjReplywith();
		opt.setLanguage("eng");
		opt.setName("No");
		opt.setOrder(2);
		opts.add(opt);
		
		opt = new ObjReplywith();
		opt.setLanguage("eng");
		opt.setName("In Progress");
		opt.setOrder(3);
		opts.add(opt);
		
		opt = new ObjReplywith();
		opt.setLanguage("eng");
		opt.setName("Accepted");
		opt.setOrder(4);
		opts.add(opt);
		
		opt = new ObjReplywith();
		opt.setLanguage("eng");
		opt.setName("Declined");
		opt.setOrder(5);
		opts.add(opt);
		
		opt = new ObjReplywith();
		opt.setLanguage("eng");
		opt.setName("Custom...");
		opt.setOrder(6);
		opts.add(opt);
		
		
		dbInstance.addReplywithOptions(opts);
	}
	
	private void initConfig() {
		ObjConfig cfg = new ObjConfig();
		
		cfg.setDriver_id(DBConstants.UNKNOWN_DRIVERID);
		cfg.setDriver_type(IcsConstants.DRIVER_ID_TYPE_DTCO);
		cfg.setIs_eula_accepted(DBConstants.OPTION_ON);
		cfg.setLanguage("eng");
		cfg.setAudio(DBConstants.OPTION_ON);
    	
		cfg.setShow_high_msg(DBConstants.OPTION_ON);
		cfg.setShow_high_alert(DBConstants.OPTION_ON);
		
		dbInstance.addConfig(cfg);
	}
	
	private void initReliableMessage() {
		List<ObjReliableMessage> msgs = new ArrayList<ObjReliableMessage>();
		
		ObjReliableMessage msg;
		
		for (int i=1; i<=10; i++) {
			msg = new ObjReliableMessage();
        	msg.setTransaction_id(i);
        	msg.setPriority(1);
        	msg.setRetries(0);
        	msg.setMessage_data("---");
	    	
	    	msgs.add(msg);
		}
		
		dbInstance.addReliableMessage(msgs);
	}
	
	// TODO, test function for database instance of driver report start
	public String testAddSnapshotSummary() {
		List<ObjSnapshotSummary> list = new ArrayList<ObjSnapshotSummary>();
		
		ObjSnapshotSummary obj;
		
		obj = new ObjSnapshotSummary("{\"timestamp\":123456, \"data\":\"test data\", \"is_last_shift_period\":false, \"sequence_num\":1, \"shift_id\":\"123\", \"vperf_message_version\":1, \"cfms_trans_id\":1}");
		
		list.add(obj);
		
		
		long id = dbInstance.addSnapshotSummary(list);
		Log.d("DB test", "testAddSnapshotSummary: " + id);
		
		return "";
	}
	
	public String testGetSnapshotSummariesWithShiftId() {
		List<ObjSnapshotSummary> list = dbInstance.getSnapshotSummariesWithShiftId("123");
		
		if (!list.isEmpty()) {
			JSONArray resultList = new JSONArray();
			try {
				for (ObjSnapshotSummary obj : list) {
					resultList.put(obj.toJsonObj());
				}
				
				JSONObject resultJson = new JSONObject();
				resultJson.put("list", resultList);
				
				Log.d("DB test", "testGetSnapshotSummariesWithShiftId: " + resultJson.toString());
			} catch (JSONException e) {
				Log.e("DB test", "Json error: ", e);
			}
		}
		
		return "";
	}
	
	public String testDeleteOldSnapshotSummaries() {
		int row = dbInstance.deleteOldSnapshotSummaries(1234567);
		Log.d("DB test", "testDeleteOldSnapshotSummaries: " + row);
		return "";
	}
	
	public String testAddShiftAbstract() {
		List<ObjShiftAbstract> list = new ArrayList<ObjShiftAbstract>();
		
		ObjShiftAbstract obj;
		
		obj = new ObjShiftAbstract("{\"shift_id\":\"123456\", \"logon_time\":123456, \"logoff_time\":123456, \"driver_id_type\":1, \"driver_id\":\"123456\", \"total_distance_travelled\":100.00, \"total_duration\":200.00, \"idling_time\":123456, \"over_rev_distance\":123456, \"harsh_throttle_distance\":300.00, \"braking_distance\":400.00, \"cruise_control_time\":123456, \"coasting_time\":123456}");
		
		list.add(obj);
		
		
		long id = dbInstance.addShiftAbstract(list);
		Log.d("DB test", "testAddShiftAbstract: " + id);
		
		return "";
	}
	
	public String testGetRecentShiftAbstract() {
		List<ObjShiftAbstract> list = dbInstance.getRecentShiftAbstract(10, "123456", 5);
		
		if (!list.isEmpty()) {
			JSONArray resultList = new JSONArray();
			try {
				for (ObjShiftAbstract obj : list) {
					resultList.put(obj.toJsonObj());
				}
				
				JSONObject resultJson = new JSONObject();
				resultJson.put("list", resultList);
				
				Log.d("DB test", "testGetRecentShiftAbstract: " + resultJson.toString());
			} catch (JSONException e) {
				Log.e("DB test", "Json error: ", e);
			}
		}
		
		return "";
	}
	
	public String testDeleteShiftAbstract() {
		int row = dbInstance.deleteShiftAbstract(1234567);
		Log.d("DB test", "testDeleteShiftAbstract: " + row);
		return "";
	}
	
	public String testAddTips() {
		List<ObjTips> list = new ArrayList<ObjTips>();
		
		ObjTips obj;
		
		obj = new ObjTips("{\"tip_number\":123, \"tip_category\":1, \"tip_level\":2, \"tip_language\":3, \"tip_text\":\"test tips text\"}");
		
		list.add(obj);
		
		
		long id = dbInstance.addTips(list);
		Log.d("DB test", "testAddTips: " + id);
		
		return "";
	}
	
	public String testSelectTips() {
		List<ObjTips> list = dbInstance.selectTips(1, 2, 3);
		
		if (!list.isEmpty()) {
			JSONArray resultList = new JSONArray();
			try {
				for (ObjTips obj : list) {
					resultList.put(obj.toJsonObj());
				}
				
				JSONObject resultJson = new JSONObject();
				resultJson.put("list", resultList);
				
				Log.d("DB test", "testSelectTips: " + resultJson.toString());
			} catch (JSONException e) {
				Log.e("DB test", "Json error: ", e);
			}
		}
		
		return "";
	}
	
	public String testDeleteTips() {
		int row = dbInstance.deleteTips(123);
		Log.d("DB test", "testDeleteTips: " + row);
		return "";
	}
	// Test function end ----------------------------------------------
}
