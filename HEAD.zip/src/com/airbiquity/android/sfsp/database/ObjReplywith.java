/**  
* @Title: ObjReplywith.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-10-1
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class ObjReplywith {
	private int id;
	
	private String language;
	private String name;
	private int order;
	
	public ObjReplywith() {
		
	}
	
	/**
	 * Initialize with json string
	 * @param String json
	 */
	public ObjReplywith(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			init(obj);
		} catch (JSONException e) {
			Log.e("ObjConfig", "Json error: ", e);
		}
	}
	
	/**
	 * Initialize with json object
	 * @param obj
	 */
	public ObjReplywith(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.id = obj.optInt(IcsConstants.KEY_ID);
		this.language = obj.optString(IcsConstants.KEY_REPLY_LANGUAGE);
		this.name = obj.optString(IcsConstants.KEY_REPLY_NAME);
		this.order = obj.optInt(IcsConstants.KEY_REPLY_ORDER);
	}

	public boolean isValid() {
		boolean isValid = true;
		
		if (this.language == null || this.name == null) {
			isValid = false;
		}
		
		return isValid;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the order
	 */
	public int getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(int order) {
		this.order = order;
	}
	
	/**
	 * Convert object to json object
	 * 
	 * @return String
	 */
	public JSONObject toJsonObj() {
		JSONObject json = new JSONObject();
		try {
			json.put(IcsConstants.KEY_ID, this.id);
			json.put(IcsConstants.KEY_REPLY_LANGUAGE, this.language);
			json.put(IcsConstants.KEY_REPLY_NAME, this.name);
			json.put(IcsConstants.KEY_REPLY_ORDER, this.order);
		} catch (JSONException e) {
			Log.e("ObjMessage", "Json error: ", e);
		}

		return json;
	}
	
	/**
	 * Convert object to json string
	 * 
	 * @return String
	 */
	public String toJsonString() {
		return toJsonObj().toString();
	}
}
