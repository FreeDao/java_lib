/**  
* @Title: ReliableMessage.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-9-24
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import org.json.JSONObject;

import android.util.Base64;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class ObjReliableMessage {	
	private long transaction_id = 0;
	private long reference_id = 0;
	private int message_id=0;
	private int priority;
	private int retries;
	private String message_data;
	
	public ObjReliableMessage() {
		
	}
	
	public ObjReliableMessage(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.transaction_id = obj.optLong(IcsConstants.KEY_RMSG_TRANSACTIONID);
		this.priority = obj.optInt(IcsConstants.KEY_PRIORITY);
		this.retries = obj.optInt(IcsConstants.KEY_RMSG_RETRIES);
		this.message_data = obj.optString(IcsConstants.KEY_RMSG_MESSAGE_DATA);
	}

	/**
	 * 
	 * Check value of the message
	 * 
	 * @return boolean
	 */
	public boolean isValid(){
		boolean isValid = true;
		
		if (this.message_data == null) {
			isValid = false;
		}
		
		return isValid;
	}

	/**
	 * @return the transaction_id
	 */
	public long getTransaction_id() {
		return transaction_id;
	}

	/**
	 * @param transaction_id the transaction_id to set
	 */
	public void setTransaction_id(long transaction_id) {
		this.transaction_id = transaction_id;
	}

	/**
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}

	/**
	 * @param priority the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	/**
	 * @return the retries
	 */
	public int getRetries() {
		return retries;
	}

	/**
	 * @param retries the retries to set
	 */
	public void setRetries(int retries) {
		this.retries = retries;
	}

	/**
	 * @return the message_data
	 */
	public String getMessage_data() {
		return message_data;
	}

	// returns the message data as a byte array assuming the message data
	// was encoded in base 64.
	public byte[] getMessage_bytes()
	{
		byte[] b = null;
		String s = getMessage_data();
		if( ( null != s ) && ( s.length() > 0 ) )
		{
			b = Base64.decode(s, Base64.DEFAULT);
		}
		return b;
	}
	
	/**
	 * @param message_data the message_data to set
	 */
	public void setMessage_data(String message_data) {
		this.message_data = message_data;
	}
	
	public void setMessage_data( byte[] data )
	{
		String b64_payload = Base64.encodeToString( data, Base64.DEFAULT );	// 
		setMessage_data( b64_payload );
	}
	
	public void setReferenceId( long id )
	{
		this.reference_id = id;
	}
	
	public long getReferenceId()
	{
		return this.reference_id;
	}
	
	public void setMessageId( int id )
	{
		this.message_id = id;
	}
	
	public int getMessageId()
	{
		return this.message_id;
	}
}
