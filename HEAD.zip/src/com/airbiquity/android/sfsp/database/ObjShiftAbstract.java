/**  
* @Title: ObjShiftAbstract.java
* @Package com.airbiquity.android.sfsp.database
* @Description: 
* @author nikm (kunming.ni@gmail.com)
* @date 2012-12-3
* @version V1.0  
*/
package com.airbiquity.android.sfsp.database;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.airbiquity.android.fleet.icsobjs.IcsConstants;

public class ObjShiftAbstract {
	private int id = 0; // ID for local database
	
	private String shift_id = "";
	private long logon_time = 0;
	private long logoff_time = 0;
	private int driver_id_type = 0;
	
	private String driver_id = "";
	private float total_distance_travelled = 0;
	private int total_duration = 0;
	private int idling_time = 0;
	
	private float over_rev_distance = 0;
	private float harsh_throttle_distance = 0;
	private float braking_distance = 0;
	private int cruise_control_time = 0;
	
	private int coasting_time = 0;

	public ObjShiftAbstract() {
		
	}
	
	/**
	 * Initialize with json string
	 * 
	 * @param String
	 *            json
	 */
	public ObjShiftAbstract(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			init(obj);
		} catch (JSONException e) {
			Log.e("ObjShiftAbstract", "Json error: ", e);
		}
	}
	
	/**
	 * Initialize with json object
	 * @param obj
	 */
	public ObjShiftAbstract(JSONObject obj) {
		init(obj);
	}
	
	private void init(JSONObject obj) {
		this.shift_id = obj.optString(IcsConstants.KEY_SHIFT_ID);
		this.logon_time = obj.optLong(IcsConstants.KEY_REPORT_LOGON_TIME);
		this.logoff_time = obj.optLong(IcsConstants.KEY_REPORT_LOGOFF_TIME);
		this.driver_id_type = obj.optInt(IcsConstants.KEY_DRIVER_ID_TYPE);
		
		this.driver_id = obj.optString(IcsConstants.KEY_DRIVER_ID);
		String tmp_travelled = obj.optString(IcsConstants.KEY_REPORT_DISTANCE);
		this.total_distance_travelled = (tmp_travelled != null && !("null").equals(tmp_travelled)) ? Float.parseFloat(tmp_travelled) : 0;
		this.total_duration = obj.optInt(IcsConstants.KEY_REPORT_DURATION);
		this.idling_time = obj.optInt(IcsConstants.KEY_REPORT_IDLING);
		
		String tmp_over_rev = obj.optString(IcsConstants.KEY_REPORT_OVER_REV);
		this.over_rev_distance = (tmp_over_rev != null && !("null").equals(tmp_over_rev)) ? Float.parseFloat(tmp_over_rev) : 0;
		String tmp_harsh_throttle = obj.optString(IcsConstants.KEY_REPORT_HARSH_THROTTLE);
		this.harsh_throttle_distance = (tmp_harsh_throttle != null && !("null").equals(tmp_harsh_throttle)) ? Float.parseFloat(tmp_harsh_throttle) : 0;
		String tmp_braking = obj.optString(IcsConstants.KEY_REPORT_BRAKING_DISTANCE);
		this.braking_distance = (tmp_braking != null && !("null").equals(tmp_braking)) ? Float.parseFloat(tmp_braking) : 0;
		this.cruise_control_time = obj.optInt(IcsConstants.KEY_REPORT_CRUISE);
		
		this.coasting_time = obj.optInt(IcsConstants.KEY_REPORT_COASTING);
	}
	
	public boolean isValid(){
		boolean isValid = true;
		
		if (this.shift_id == null) {
			isValid = false;
		}
		
		return isValid;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the shift_id
	 */
	public String getShift_id() {
		return shift_id;
	}

	/**
	 * @param shift_id the shift_id to set
	 */
	public void setShift_id(String shift_id) {
		this.shift_id = shift_id;
	}

	/**
	 * @return the logon_time
	 */
	public long getLogon_time() {
		return logon_time;
	}

	/**
	 * @param logon_time the logon_time to set
	 */
	public void setLogon_time(long logon_time) {
		this.logon_time = logon_time;
	}

	/**
	 * @return the logoff_time
	 */
	public long getLogoff_time() {
		return logoff_time;
	}

	/**
	 * @param logoff_time the logoff_time to set
	 */
	public void setLogoff_time(long logoff_time) {
		this.logoff_time = logoff_time;
	}

	/**
	 * @return the driver_id_type
	 */
	public int getDriver_id_type() {
		return driver_id_type;
	}

	/**
	 * @param driver_id_type the driver_id_type to set
	 */
	public void setDriver_id_type(int driver_id_type) {
		this.driver_id_type = driver_id_type;
	}

	/**
	 * @return the driver_id
	 */
	public String getDriver_id() {
		return driver_id;
	}

	/**
	 * @param driver_id the driver_id to set
	 */
	public void setDriver_id(String driver_id) {
		this.driver_id = driver_id;
	}

	/**
	 * @return the total_distance_travelled
	 */
	public float getTotal_distance_travelled() {
		return total_distance_travelled;
	}

	/**
	 * @param total_distance_travelled the total_distance_travelled to set
	 */
	public void setTotal_distance_travelled(float total_distance_travelled) {
		this.total_distance_travelled = total_distance_travelled;
	}

	/**
	 * @return the total_duration
	 */
	public float getTotal_duration() {
		return total_duration;
	}

	/**
	 * @param total_duration the total_duration to set
	 */
	public void setTotal_duration(int total_duration) {
		this.total_duration = total_duration;
	}

	/**
	 * @return the idling_time
	 */
	public long getIdling_time() {
		return idling_time;
	}

	/**
	 * @param idling_time the idling_time to set
	 */
	public void setIdling_time(int idling_time) {
		this.idling_time = idling_time;
	}

	/**
	 * @return the over_rev_distance
	 */
	public float getOver_rev_distance() {
		return over_rev_distance;
	}

	/**
	 * @param over_rev_distance the over_rev_distance to set
	 */
	public void setOver_rev_distance(float over_rev_distance) {
		this.over_rev_distance = over_rev_distance;
	}

	/**
	 * @return the harsh_throttle_distance
	 */
	public float getHarsh_throttle_distance() {
		return harsh_throttle_distance;
	}

	/**
	 * @param harsh_throttle_distance the harsh_throttle_distance to set
	 */
	public void setHarsh_throttle_distance(float harsh_throttle_distance) {
		this.harsh_throttle_distance = harsh_throttle_distance;
	}

	/**
	 * @return the braking_distance
	 */
	public float getBraking_distance() {
		return braking_distance;
	}

	/**
	 * @param braking_distance the braking_distance to set
	 */
	public void setBraking_distance(float braking_distance) {
		this.braking_distance = braking_distance;
	}

	/**
	 * @return the cruise_control_time
	 */
	public long getCruise_control_time() {
		return cruise_control_time;
	}

	/**
	 * @param cruise_control_time the cruise_control_time to set
	 */
	public void setCruise_control_time(int cruise_control_time) {
		this.cruise_control_time = cruise_control_time;
	}

	/**
	 * @return the coasting_time
	 */
	public long getCoasting_time() {
		return coasting_time;
	}

	/**
	 * @param coasting_time the coasting_time to set
	 */
	public void setCoasting_time(int  coasting_time) {
		this.coasting_time = coasting_time;
	}
	
	/**
	 * Convert object to json object
	 * 
	 * @return String
	 */
	public JSONObject toJsonObj() {
		JSONObject json = new JSONObject();
		try {			
			json.put(IcsConstants.KEY_ID, this.id);
			
			json.put(IcsConstants.KEY_SHIFT_ID, this.shift_id);
			json.put(IcsConstants.KEY_REPORT_LOGON_TIME, this.logon_time);
			json.put(IcsConstants.KEY_REPORT_LOGOFF_TIME, this.logoff_time);
			json.put(IcsConstants.KEY_DRIVER_ID_TYPE, this.driver_id_type);
			
			json.put(IcsConstants.KEY_DRIVER_ID, this.driver_id);
			json.put(IcsConstants.KEY_REPORT_DISTANCE, this.total_distance_travelled);
			json.put(IcsConstants.KEY_REPORT_DURATION, this.total_duration);
			json.put(IcsConstants.KEY_REPORT_OVER_REV, this.over_rev_distance);
			
			json.put(IcsConstants.KEY_REPORT_HARSH_THROTTLE, this.harsh_throttle_distance);
			json.put(IcsConstants.KEY_REPORT_BRAKING_DISTANCE, this.braking_distance);
			json.put(IcsConstants.KEY_REPORT_CRUISE, this.cruise_control_time);
			json.put(IcsConstants.KEY_REPORT_COASTING, this.coasting_time);
		} catch (JSONException e) {
			Log.e("ObjShiftAbstract", "Json error: ", e);
		}

		return json;
	}
	
	/**
	 * Convert object to json string
	 * 
	 * @return String
	 */
	public String toJsonString() {
		return toJsonObj().toString();
	}
}
