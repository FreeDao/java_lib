/**  
 * @Title: StartupReceiver.java
 * @Package receiver
 * @Description: 
 * @author nikm (kunming.ni@gmail.com)
 * @date Sep 18, 2012
 * @version V1.0  
 */
package com.airbiquity.android.sfsp.receiver;

import com.airbiquity.android.choreofleetmessaging.AlreadyStartedException;
import com.airbiquity.android.choreofleetmessaging.CMessageDispatcher;
import com.airbiquity.android.sfsp.AppHostMain;
import com.airbiquity.android.sfsp.service.DaemonService;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.hardware.usb.UsbManager;
import android.util.Log;

public class StartupReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		Log.d("StartupReceiver", "Receive broadcast, action: " + action);
		
		if (action.equals(Intent.ACTION_BOOT_COMPLETED)) {
			startApplication(context);
		} else if(action.equals(UsbManager.ACTION_USB_DEVICE_ATTACHED)) {
			Intent d = new Intent();
	        d.setAction(DaemonService.ACTION_DAEMON);
	        intent.putExtra("cmd", DaemonService.CMD_USB_CONNECT);
	        context.sendBroadcast(d);
		} else if(action.equals(Intent.ACTION_USER_PRESENT)) {
			startApplication(context);
		} else if(action.equals("com.airbiquity.android.startSfsp")) {
			startApplication(context);
		}
	}
	
	private void startApplication(Context context) {
		Intent bootActivityIntent = new Intent(context, AppHostMain.class);
		bootActivityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(bootActivityIntent);
		
		try {
			CMessageDispatcher.startup(context.getApplicationContext(), "com.airbiquity.android.choreofleetmessaging.NetServerBroker", null);
		} catch (AlreadyStartedException e) {
			Log.e("StartupReceiver", "CMessageDispatcher startup exception: ", e);
		}
		
		if (AppHostMain.isLock()) {
			context.startService(new Intent(context, DaemonService.class));
		}
	}
}
