package com.airbiquity.util;

import org.json.JSONObject;

import com.airbiquity.aqlog.AqLog;

public class JsonHelper {

	public static long getLong( JSONObject json, String name, long dflt )
	{
		long retval = dflt;
		if( ( null != json ) && ( null != name ) )
		{
			try
			{
				retval = json.getLong(name);
			}
			catch( Exception e )
			{
				AqLog.getInstance().warn( "Unable to get long JSON element: " + name );
			}
		}
		return retval;
	}
	
	public static int getInt( JSONObject json, String name, int dflt )
	{
		int retval = dflt;
		if( ( null != json ) && ( null != name ) )
		{
			try
			{
				retval = json.getInt(name);
			}
			catch( Exception e )
			{
				AqLog.getInstance().warn( "Unable to get int JSON element: " + name );
			}
		}
		return retval;
	}
	
	public static boolean getBoolean( JSONObject json, String name, boolean dflt )
	{
		boolean retval = dflt;
		if( ( null != json ) && ( null != name ) )
		{
			try
			{
				retval = json.getBoolean(name);
			}
			catch( Exception e )
			{
				AqLog.getInstance().warn( "Unable to get boolean JSON element: " + name );
			}
		}
		return retval;
	}
	
	public static String getString( JSONObject json, String name, String dflt )
	{
		String retval = dflt;
		if( ( null != json ) && ( null != name ) )
		{
			try
			{
				retval = json.getString(name);
			}
			catch( Exception e )
			{
				AqLog.getInstance().warn( "Unable to get String JSON element: " + name );
			}
		}
		return retval;
	}

}