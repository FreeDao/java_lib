/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2008-2012 by Airbiquity.  All rights reserved.
 *
 *  History:
 *  08-20-2012 Jack William Bell - Heavily modified for use in Android projects.
 *
*****************************************************************************/

package com.airbiquity.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Properties;

import com.airbiquity.aqlog.AqLog;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;

/**
 * Selected utility methods taken from the OBU project.
 * 
 * @author Jack William Bell
 */
public class AqUtils {
	
	private static final String TAG = "AqUtils";
	
    protected static byte ASCII_ZERO = (byte) 0x30;
    protected static byte ASCII_NINE = (byte) 0x39;
    protected static byte ASCII_A = (byte) 0x41;
    
    protected static byte ASCII_O = (byte) 0x4F;
    protected static byte ASCII_Q = (byte) 0x51;
    protected static byte ASCII_Z = (byte) 0x5A;
    protected static byte ASCII_ASTERISK = (byte) 0x2A;

    protected static final byte ASCII_I = 0x49;
    protected static final byte ASCII_SPACE = 0x20;
    protected static final byte ASCII_TILDE = 0x7E;

    private static final int[] vin_cksum_weight =
    {
        8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2
    };

    private static final int[] vin_cksum_value =
    {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
         0,  1,  2,  3,  4,  5,  6,  7,  8,  9, -1, -1, -1, -1, -1, -1,
        -1,  1,  2,  3,  4,  5,  6,  7,  8, -1,  1,  2,  3,  4,  5, -1,
         7, -1,  9,  2,  3,  4,  5,  6,  7,  8,  9, -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
    };

    /* Not used? 
    private static final int[] vin_cksum_chars = 
    {
        0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x58
    };
    */

    //
    // Stream routines.
    //
    
    /**
     * @param s
     * @param b
     * @param startIdx
     * @param numBytes
     * @param timeout
     * @return
     * @throws IOException
     */
    public static int inputStreamTimedRead( InputStream s, byte[] b, int startIdx, int numBytes, int timeout ) throws IOException
    {
        int retval = -1;

        int i = 0;
        for( i=0;i<timeout;i++ )
        {
            if( s.available() > 0 )
            {
                retval = s.read( b, startIdx, numBytes );
                break;
            }
            SystemClock.sleep( 1000 );
        }
        return retval;
    }
        
    //
    // Network routines.
    //
    
    public static String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (SocketException ex) {
            Log.e(TAG, ex.toString());
        }
        return null;
    }

    //
    // Byte conversion routines.
    //
    /*
     * Test Code		
     	long l1 = Long.MAX_VALUE;
		long l2 = 3682441086L;
		long l3 = 255;
		
		System.out.println("l1 Before: " + l1);
		System.out.print("l1 Bytes: ");
		byte[] lb = AqUtils.unsignedLongToByteArray(l1);
		printByteArray(lb);
		System.out.println();
		l1 = AqUtils.byteArrayToUnsignedLong(lb);
		System.out.println("l1 After:" + l1);
		
		System.out.println("l2 Before: " + l2);
		System.out.print("l2 Bytes: ");
		lb = AqUtils.unsignedLongToByteArray(l2);
		printByteArray(lb);
		System.out.println();
		l2 = AqUtils.byteArrayToUnsignedLong(lb);
		System.out.println("l2 After:" + l2);
		
		System.out.println("l3 Before: " + l3);
		System.out.print("l3 Bytes: ");
		lb = AqUtils.unsignedLongToByteArray(l3);
		printByteArray(lb);
		System.out.println();
		l3 = AqUtils.byteArrayToUnsignedLong(lb);
		System.out.println("l3 After:" + l3);
		System.out.println();
     */
    
    /**
     * @param val
     * @return
     */
    public static int byteToUnsignedValue(byte val) {
		// NOTE: Because Java bytes are signed, this means values greater than 127 
		// are negative. Resulting in a lot of futzing around to get the real values. (JWB) 
		// NOTE: Code purists--no need for shifts and bitwise ops! Let the compiler do the work. (JWB)
    	int iVal = val;
    	
    	if (iVal < 0) return (iVal * -1) + 127;
		return iVal;
    }
    
    /**
     * @param val
     * @return
     * @throws java.lang.ArithmeticException
     */
    public static byte unsignedValueToByte(int val) throws java.lang.ArithmeticException {
		// NOTE: See notes RE signed bytes above. (JWB)
		if (val > 255 || val < 0) {
			throw new java.lang.ArithmeticException();
		}
		if (val > 127) {
			return (byte) ((val - 128) * -1);
		}
		
		return (byte) val;
    }
    
    /**
     * @param data
     * @param offset
     * @return
     */
    public static int getUnsignedByteFromArray(byte data[], int offset) {
		return byteToUnsignedValue(data[offset]);
	}
	
    /**
     * @param data
     * @param offset
     * @param val
     * @throws java.lang.ArithmeticException
     */
    public static void setUnsignedByteInArray(byte data[], int offset, int val) 
			throws java.lang.ArithmeticException {
		data[offset] = unsignedValueToByte(val);
	}
    
    /**
     * @param one
     * @param two
     * @return
     */
    public static int twoBytesToUnsignedInt(byte one, byte two) {
    	return (int) eightBytesToUnsignedLong((byte) 0, (byte) 0, (byte) 0, (byte) 0, 
    			(byte) 0, (byte) 0, one, two);
    }
    
    /**
     * Convert a one or two byte array of bytes to an unsigned two-byte integer.
     * 
     * <p><b>NOTE:</b> This function mostly exists as an example of how to use 
     * twoBytesToUnsignedInt(). It is unlikely the use case it embodies
     * will occur often.</p>
     * 
     * @param ba
     * @return
     */
    public static int byteArrayToUnsignedInt(byte[] byteArray) {
    	if (byteArray.length > Integer.SIZE) throw new 
    		IllegalArgumentException("Array length must match one of the following types:\n Byte==" + Byte.SIZE
                + ", Short==" + Short.SIZE + ", Integer==" + Integer.SIZE);
    	
    	return (int) byteArrayToUnsignedLong(byteArray);
    }
    
    /**
     * Convert an unsigned two-byte integer to a two byte array.
     * 
     * @param val
     * @return
     */
    public static byte[] unsignedIntToByteArray(int value) {
    	if (value < 0) throw new IllegalArgumentException("Value argument must be zero or positive (unsigned Long).");
    	
        byte[] ret = new byte[2];  
        ret[1] = (byte) ((value >> (0*8)) & 0xFF);     
        ret[0] = (byte) ((value >> (1*8)) & 0xFF);     
        return ret;    
	}
    
    /**
     * @param zero
     * @param one
     * @param two
     * @param three
     * @param four
     * @param five
     * @param six
     * @param seven
     * @return
     */
    public static long eightBytesToUnsignedLong(byte zero, byte one, byte two, byte three, 
    		byte four, byte five, byte six, byte seven) {
    	return byteArrayToUnsignedLong(new byte[]{zero, one, two, three, four, five, six, seven});
    }
    
    /**
     * @param byteArray
     * @return
     */
    public static long byteArrayToUnsignedLong(byte[] byteArray) {
        int length;
        long value = 0;
        if (byteArray.length == Byte.SIZE / Byte.SIZE) {
          length = Byte.SIZE / Byte.SIZE;
        } else if (byteArray.length == Short.SIZE / Byte.SIZE) {
          length = Short.SIZE / Byte.SIZE;
        } else if (byteArray.length == Integer.SIZE / Byte.SIZE) {
          length = Integer.SIZE / Byte.SIZE;
        } else if (byteArray.length == Long.SIZE / Byte.SIZE) {
          length = Long.SIZE / Byte.SIZE;
        } else
          throw new IllegalArgumentException("Array length must match one of the following types:\n Byte==" + Byte.SIZE
              + ", Short==" + Short.SIZE + ", Integer==" + Integer.SIZE + ", Long==" + Long.SIZE);
        
        for (int i = 0; i < length; i++) {
          value |= ((0xffL & byteArray[i]) << (8 * (length - i - 1)));
        }
        return value;
    }
    
    /**
     * @param value
     * @return
     */
    public static byte[] unsignedLongToByteArray(long value) {
    	if (value < 0) throw new IllegalArgumentException("Value argument must be zero or positive (unsigned Long).");
    	
        byte[] ret = new byte[8];  
        ret[7] = (byte) ((value >> (0*8)) & 0xFF);     
        ret[6] = (byte) ((value >> (1*8)) & 0xFF);     
        ret[5] = (byte) ((value >> (2*8)) & 0xFF);     
        ret[4] = (byte) ((value >> (3*8)) & 0xFF);     
        ret[3] = (byte) ((value >> (4*8)) & 0xFF);     
        ret[2] = (byte) ((value >> (5*8)) & 0xFF);     
        ret[1] = (byte) ((value >> (6*8)) & 0xFF);     
        ret[0] = (byte) ((value >> (7*8)) & 0xFF);     
        return ret;    
	}
    
    //
    // Some array helper functions
    //
    
    /**
     * Works with two arrays of byte.
     * 
     * @param a
     * @param b
     * @return
     */
    public static byte[] concatByteArrays(byte[] a, byte[] b) {
        final int alen = a.length;
        final int blen = b.length;
		final byte[] result = new byte[alen + blen];
        System.arraycopy(a, 0, result, 0, alen);
        System.arraycopy(b, 0, result, alen, blen);
        return result;
   }
    
    /**
     * Works with two arrays of the same class type.
     * 
     * @param a
     * @param b
     * @return
     */
    public static <T> T[] concatArrays(T[] a, T[] b) {
        final int alen = a.length;
        final int blen = b.length;
        @SuppressWarnings("unchecked")
		final T[] result = (T[]) java.lang.reflect.Array.
                newInstance(a.getClass().getComponentType(), alen + blen);
        System.arraycopy(a, 0, result, 0, alen);
        System.arraycopy(b, 0, result, alen, blen);
        return result;
   }
    //
    // VIN Checksum
    //
    // TODO: Consider moving these functions to a separate class. (JWB)
    
    // CHAPTER V--NATIONAL HIGHWAY TRAFFIC SAFETY ADMINISTRATION, DEPARTMENT OF TRANSPORTATION
    // PART 565--VEHICLE IDENTIFICATION NUMBER REQUIREMENTS Section 565.6
    public static int calcVinChecksum( byte[] b )
    {
        int retval = -1;
        int sum = 0;
        if( 17 == b.length )
        {
            int i;
            for( i=0;i<17;i++ )
            {
                if( ( b[i] < 0 ) || ( b[i] > 127 ) ) break;
                if( vin_cksum_value[b[i]] < 0 ) break;
                
                sum = sum + ( vin_cksum_weight[i] * vin_cksum_value[b[i]] );
            }
            retval = sum % 11;
        }
        // System.out.println( "sum: " + retval );
        return retval;
    }

    public static boolean isDecimalDigit( byte ch )
    {
        return ( ( ch >= ASCII_ZERO ) && ( ch <= ASCII_NINE ) );
    }

    public static boolean isUpperCaseAlpha( byte ch )
    {
        return ( ( ch >= ASCII_A ) && ( ch <= ASCII_Z ) );
    }

//     private static boolean isPrintable( int i )
//     {
//         return ( ( i>0x1F ) && (i<0x7f) ); 
//     }
    
    // Previously in CheckVin.java
    
    // Validate Vin based on ISO 3779:2009(E) -- less stringent
    // with optional support for check sum validation as specified
    // in:
    // CHAPTER V--NATIONAL HIGHWAY TRAFFIC SAFETY ADMINISTRATION, DEPARTMENT OF TRANSPORTATION
    // PART 565--VEHICLE IDENTIFICATION NUMBER REQUIREMENTS Section 565.6
    
	/** The VIN alphabet consists of the numbers 0 .. 9 and the upper case roman
     *  characters in the range A..Z with the exception of the letters 'I', 'O', and 'Q'
     *
     *  NOTE:  This funciton assumes ASCII encoding
     */
    public static boolean isVinCharValid( byte ch )
    {
        boolean retval = false;
        
        if(  isDecimalDigit( ch ) ||
            (  isUpperCaseAlpha( ch ) &&
              ( ( ch != ASCII_I ) && ( ch != ASCII_O ) && ( ch != ASCII_Q ) ) ) )
        {
            retval = true;
        }
        return retval;
    }

    public static boolean validateVin( String vin, boolean useChecksum )
    {
        byte b[] = null;
        boolean retval = true;

        // sanity check parameter
        if( null == vin ) return false;
        
        try
        {
            b = vin.getBytes();
        }
        catch( Exception e )
        {
            // Punt --- assume default encoding scheme is ascii
            b = vin.getBytes();
        }

        // Loosen up logic for vin validatation so that FMS reported vins for volvo are 
        // transmitted and also any DTCO vins with fat fingered chars (i.e. an upper case 'O' instead of
        // a zero ... as seen with our DTCO test set.  Per experience, some incorrect information is better 
        // than no informatin for IVIN matching.
        if( ( b.length > 25 ) || ( b.length <= 0 )  || vin.equals("ALFAXRAY" ) ) 
        {
        	retval = false;
        }
        else
        {
        	int i;
            for( i=0;i<b.length;i++ )
            {
            	
            	if( ( b[i] < ASCII_SPACE ) || ( b[i] > ASCII_TILDE ) )
            	{
            		retval = false;
            		break;
            	}
            }
        }
//        
//        if( 17 != b.length )
//        {
//            retval = false;
//        }
//        else
//        {
//            int i;
//
//            // From ISO 3779 -- VIN shall consist of 3 sections
//            // -- first section: World Manufacturer Identifier (WMI) which shall be 3 chars
//            // -- second section: The vehicle descriptor section (VDS) which shall be 6 chars
//            // -- third section: The vehicle Indicator Section (VIS) which shall be 8 chars
//            // -- Sum of all chars == 17
//            for( i=0;i<17;i++ )
//            {
//                if( ( i > 14 ) && ! isDecimalDigit( b[i] ) )
//                {
//                    // ISO 3779 states last 4 digits must be numeric ( '0' .. '9' )
//                    retval = false;
//                    break;
//                }
//                else if( !isVinCharValid( b[i] ) )
//                {
//                    // All chars must be in range '0' .. '9' or 'A' .. 'Z'
//                    // except 'I', 'O', and 'Q'
//                    retval = false;
//                    break;
//                }
//            }
//
//            if( retval && useChecksum )
//            {
//                int cksum = calcChecksum( b );
//                //System.out.println( "cksum: " + cksum + ", vin_cksum_chars[cksum]: " + vin_cksum_chars[cksum] + ", b[8]: " + b[8] );
//                if( cksum < 0 )
//                {
//                    retval = false;
//                }
//                else if( vin_cksum_chars[cksum] != b[8] )
//                {
//                    retval = false;
//                }
//            }
//        }
        return retval;
    }

    public static boolean validateVin( String vin )
    {
        return validateVin( vin, false );
    }

    // Some FMS gateways appear to tack an asterisk ('*') on to the end of the VIN broadcast
    // This routine detects this specific character and will return a truncated VIN if it exists
    public static String trimFmsVin( String vin )
    {
        String retval = vin.trim();
        if( ( 18 == vin.length() ) && '*' == vin.charAt( 17 ) )
        {
            retval = vin.substring( 0, 17 );
        }
        return retval;
    }

    // From HexDump.java
	private static final int		ROW_BYTES = 16;
	private static final int		ROW_QTR1 = 3;
	private static final int		ROW_HALF = 7;
	private static final int		ROW_QTR2 = 11;

    private static final char[] hex_chars =
    {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
    };
    
	public static String getHexData( byte[] buf, int offset, int numBytes )
	{
		int			rows, i, j;
		byte[]		save_buf= new byte[ ROW_BYTES+2 ];
		char[]		hex_buf = new char[ 4 ];
		char[]		idx_buf = new char[ 8 ];
		String outStr = new String();
                
		outStr = "MSG - " + numBytes + " bytes.\n";
                
		rows = numBytes >> 4;
                if( 0 != ( numBytes & 0x0f ) ) rows++;
		for ( i = 0 ; i < rows ; i++ )
		{

                    // figure out how many bytyes on this row
                    int rowBytes = numBytes - ( i * ROW_BYTES );
                    
			int hexVal = (i * ROW_BYTES);
			idx_buf[0] = hex_chars[ ((hexVal >> 12) & 15) ];
			idx_buf[1] = hex_chars[ ((hexVal >> 8) & 15) ];
			idx_buf[2] = hex_chars[ ((hexVal >> 4) & 15) ];
			idx_buf[3] = hex_chars[ (hexVal & 15) ];

			String idxStr = new String( idx_buf, 0, 4 );
			outStr = outStr + idxStr + ": ";
		
			for ( j = 0 ; j < ROW_BYTES ; j++ )
			{
                            if( j < rowBytes )
                            {
				save_buf[j] = buf[ offset + (i * ROW_BYTES) + j ];

				hex_buf[0] = hex_chars[ (save_buf[j] >> 4) & 0x0F ];
				hex_buf[1] = hex_chars[ save_buf[j] & 0x0F ];

                                outStr = outStr + hex_buf[0] + hex_buf[1] + " ";

				if ( j == ROW_QTR1 || j == ROW_HALF || j == ROW_QTR2 )
                                    outStr = outStr + " ";

				if ( save_buf[j] < 0x20 || save_buf[j] > 0x7E )
					save_buf[j] = (byte) '.';
                            }
                            else
                            {
                                // Fill tail end of last row so that printable chars align
                                // with previous rows.
				save_buf[j] = (byte) ' ';
				outStr = outStr + "   ";
				if ( j == ROW_QTR1 || j == ROW_HALF || j == ROW_QTR2 )
					outStr = outStr + " ";
                            }
			}

			String saveStr = new String( save_buf, 0, j );
                        outStr = outStr + " | " + saveStr + " |\n" ;
		}
		
                return outStr;
		//return "rawHexDump:" + numBytes + "," + HexUtils.convert2HexString( buf ); 
	}
	
    // The following were formally from the class com.airbiquity.cfms.AqPackUnpackUtils
    
    /** Convert the given packed value 'i' to a floating point valud
     *  taking into consideration the target base and range.
     *
     *  @param base The base value of the range for the constructed float
     *  @param scalar the resolution per bit of the for the constructed float
     *  @param i Packed integer value to convert to float
     *
     *  @return The constructed floating point value
     */
    public static float packedToFloat( float base, float scalar, int i )
    {
        float f;
        f = ( ( (float) i ) * scalar ) + base;
        return f;
    }

    public static double packedToDouble( double base, double scalar, int i )
    {
        double d;
        d = ( ( (double) i ) * scalar ) + base;
        return d;
    }
    
    /**
     *
     *  @param base
     *  @param scalar
     *  @param f
     */
    public static int floatToPacked( float base, float scalar, float f )
    {
        /* allow for rounding after int conversion rather than truncate */
        f = f + ( scalar / (float) 2.0 );

        f = ( f - base ) / scalar;
        return (int) f;
    }

    public static int doubleToPacked( double base, double scalar, double d )
    {
        /* allow for rounding after int conversion rather than truncate */
        d = d + ( scalar / (double) 2.0 );

        d = ( d - base ) / scalar;
        return (int) d;
    }
    
    // From com.airbiquity.util.AqGuidGenerator
    protected static final long guidBlockSize = 5000;
    private static long guid = 0; 
    private static long guidLimit = 0;
    private static long guidPowerup = 0;
    private static boolean isSeeded = false;
    private static final Integer guidLock = Integer.valueOf( 0 );
    
    private static void seed()
    {
        getGuidBlock();
    }

    protected static void reSeed()
    {
	// may be called externally when a time event
	// occurs. ... or not.
	getGuidBlock();
    }

    private static void getGuidBlock()
    {
        synchronized( guidLock )
        {
            long tmp;
            long guidBase = 0;
            //long limit = 0; // Not used.

            // TODO: Figure out where we would load this from. (JWB) 
            //Properties guidProps = AqProperties.loadVersionedProperties( AqConsts.GUID_PROPERTIES );
            Properties guidProps = null;

            // no guid file, or back up guid file exists
            if( null == guidProps )
            {
                guidProps = new Properties();
            }

            // TODO: Fix. (JWB)
            /*
            if( null != guidProps )
            {
                guidBase = AqUtils.parseLong( "guid", guidProps.getProperty( AqConsts.NEXT_GUID_BASE_KEY, "0" ), 0l );
            }
            */

	
            //tmp = (new Date()).getTime();
            tmp = getRtcTimeInMs();
            
            //^^DZ1=getGuidBlock().  tmp,guidBase:
            Log.i(TAG, "^^DZ1 " + tmp + "," + guidBase );
            if( ( tmp > AqConsts.JAN_1_2005 ) && (tmp > guidBase ) )
            {
                // Time has been synced to GPS (or other device).  Use current time as seed
                // for guid block ... This mitigates the problem of repeated transaction ids
                // if the guid properties file gets blown away.
                guidBase = tmp;
            }

            //^^DZ3=getGuidBlock().  guidBase:
            Log.i(TAG, "^^DZ3 " + guidBase );
            guid = guidBase;
            guidLimit = guidBase + guidBlockSize;

            // write out the next guid starting block to file
            // TODO: Change this to use Android app storage.
            guidProps.setProperty( AqConsts.NEXT_GUID_BASE_KEY, Long.toString( guidLimit ) );
            //AqProperties.storeVersionedProperties( guidProps, AqConsts.GUID_PROPERTIES, null );
        }
    }

    private static long something()
    {
        long retval = 0;
        synchronized( guidLock )
        {
            if( ( false == isSeeded ) || ( ( guid < AqConsts.JAN_1_2005 ) && ( getRtcTimeInMs() > AqConsts.JAN_1_2005 ) ) ) 
            {
                seed();
                isSeeded = true;
                guidPowerup = guid;
            }

            // get next unique id
            guid++;

            // assign return value
            retval = guid;
            
            // 1st msb is Choreo originated, 2nd msb is ICS originated
            retval |= 0x4000000000000000L;
            
            if( guid >= guidLimit )
            {
                // get next block of guids.
                getGuidBlock();
            }
        }
        return retval;
    }
        
    public static long getGuid()
    {
        return something();
    }
    
    public static long getGuid_powerup()
    {
        return guidPowerup;
    }

    // Originally from StringTrim.java
    public static String rightString( String s, int chars )
    {
        String t = s;
        if( null == t ) t = "";

        String retval = new String( t );
        int len = retval.length();
        if( len > chars )
        {
            try
            {
                retval = retval.substring( len - chars, len );
            }
            catch( Exception e )
            {
                // shouldn't ever happen ... but return original string in case
            }
        }
        return retval;
    }

    /** If given string is greater than the the argument numChars, then truncate the stirng
     *  so the length is numChars long.
     *
     *  @param numChars The number of characters to truncate the string to.
     *  @return A string which has <= characters specified by numChars
     */
    public static String leftString( String s, int numChars )
    {
        String t = s;
        if( null == t ) t = "";
        String retval = new String( t );

        int len = retval.length();
        if( len > numChars )
        {
            try
            {
                retval = retval.substring( 0, numChars );
            }
            catch( Exception e )
            {
                // shouldn't ever happen ... but return original string in case
            }
        }
        return retval;
    }

    public static String removeStringSuffix( String s, String suffix )
    {
        String retval = s;
        if( ( null != s ) && ( null != suffix ) )
        {
            int sLen = s.length();
            int suffixLen = suffix.length();

            if( suffixLen <= sLen )
            {
                try
                {
                    String t = s.substring( sLen - suffixLen, sLen );
                    if( suffixLen == sLen )
                    {
                        retval = "";
                    }
                    else if( suffix.equals( t ) )
                    {
                        retval = s.substring( 0, sLen - suffixLen - 1 );
                    }
                }
                catch( Exception e )
                {
                    //^^FE1=removeSuffix()
                    Log.e(TAG, "^^FE1", e );
                }
            }
        }
        Log.d(TAG, "AqUtils.removeStringSuffix().  s,suffix,retval: " + s + "," + suffix + "," + retval );
        return retval;
    }


                                 
    /** Assuming a string construction of "<startstr><remainder>" this method will return
     *  the remainder.  If the given key doesn't match, then an empty string will be
     *  returned.
     *
     *  @param fullString The entire string which which contains <startstr><remainder>
     *  @param startStr The key portion of the string.  This routine will trime off the key and the following '=' char.
     *
     *  @return If startstr is found at the beginning of the given string the remainder
     *          of the string that immediately follows startstr will be returned.  If startst isn't found
     *          at the beginning of the string an empty string will be returned instead.
     */
    public static String getStringRemainder( String fullString, String startstr  )
    {
        String retval = "";

        if( ( null != fullString ) &&
            ( null != startstr ) )
        {
            int idx = fullString.indexOf( startstr );

            if( 0 == idx )
            {
                try
                {
                    retval = fullString.substring( startstr.length() );
                }
                catch( Exception e )
                {
                    retval = "";
                }
            }
        }
        return retval;
    }

 
    public static String stripCharFromString( String fullString, char stripChar )
    {
    	String retval = null;
    	if( null != fullString )
    	{
    		int len = fullString.length();
    		// first convert string into a char array
    		char[] chars = new char[len];
    		
    		
    		try
    		{
    			fullString.getChars( 0, len, chars, 0 );
    		}
    		catch( Exception e )
    		{
    			
    		}
    		
    		int i;
    		int j = 0;
    		for( i=0;i<chars.length;i++ ) 
    		{
    			if( stripChar != chars[i] )
    			{
    				chars[j] = chars[i];
    				j++;
    			}
    		}
    		retval = new String( chars, 0, j );
    	}
    	return retval;
    }
    
    /** Converts a null terminated byte array into a string with 
     *  the proceeding N chars before the null terminator.  If
     *  the byte array passed doesn't contain a null terminator, then the 
     *  return value is constructed with the full contents of the byte array
     * 
     * @param b The byte array which presumably contains a null terminator
     * @param offset The byte offset within the byte array to start at
     * @param isTrim If true, then trim leading/trailing spaces from the returned string.
     * @return The string composed of the data preceeding the null terminator
     */
    public static String nullTerminatedByteArrayToString( byte[] b, boolean isTrim )
    {
    	return nullTerminatedByteArrayToString( b, 0, isTrim );
    }
    
    /** Converts a null terminated byte array into a string with 
     *  the proceeding N chars before the null terminator.  If
     *  the byte array passed doesn't contain a null terminator, then the 
     *  return value is constructed with the full contents of the byte array
     * 
     * @param b The byte array which presumably contains a null terminator
     * @param isTrim If true, then trim leading/trailing spaces from the returned string.
     * @return The string composed of the data preceeding the null terminator
     */
    public static String nullTerminatedByteArrayToString( byte[] b, int offset, boolean isTrim )
    {
    	String retval = null;
    	int firstNull = -1;
    	int i;
    	
    	if( null != b )
    	{
    		for( i=offset;i<b.length;i++ )
    		{
    			if( 0 == b[i] )
    			{
    				firstNull = i;
    				break;
    			}
    		}

    		if( firstNull < 0 )
    		{
    			retval = new String( b );
    		}
    		else
    		{
    			try
    			{
    				retval = new String( b, 0, firstNull );
    			}
    			catch( Exception e )
    			{
    				retval = null;
    			}
    		}
    	}

    	if( isTrim && (null != retval) )
    	{
    		retval = retval.trim();
    	}
    	
    	return retval;
    }

    //
    // Following functions came from AqSys for OBU units...
    //
    
    /** Get the number of milliseconds elapsed since 01/01/1970 00:00:00 UTC
     */
    public static long getRtcTimeInMs()
    {
        return System.currentTimeMillis();
    }

    public static void setRtcTimeInMs( long ms )
    {
    }   
    
    // FIXME -- need to get continous time from somewhere.  otherwise time
    // sync will adversly affect elapsed relative run time calculations
    public static long continuousTimeMillis()
    {
        return getRtcTimeInMs();
    }
    
    // stolen from com.airbiquity.util.StringTrim ... Didn't want to make the AqSys 
    // dependent on a class in StringTrim .... some re-factoring is in order!
    public static String right( String s, int chars )
    {
        String t = s;
        if( null == t ) t = "";

        String retval = new String( t );
        int len = retval.length();
        if( len > chars )
        {
            try
            {
                retval = retval.substring( len - chars, len );
            }
            catch( Exception e )
            {
                // shouldn't ever happen ... but return original string in case
            }
        }
        return retval;
    }
    
    public static long parseLong( String desc, String val, long dflt )
    {
        long retval = dflt;
        if( null == desc ) desc = "";

        if( null != val )
        {
            try
            {
                retval = Long.parseLong( val.trim() );
            }
            catch( Exception e )
            {
                retval = dflt;
                if( null == desc ) desc = "";
                //^^FA1=Unable to parse 
                AqLog.getInstance().error("^^FA1" + desc, e );
            }
        }
        else
        {
            //^^FA2=null == val while parsing long 
            AqLog.getInstance().error( "^^FA2" + desc );
        }
        return retval;
    }

    public static int parseInteger( String desc, String val, int dflt, int radix )
    {
        int retval = dflt;
        if( null == desc ) desc = "";

        if( null != val )
        {
            try
            {
                retval = Integer.parseInt( val.trim(), radix );
            }
            catch( Exception e )
            {
                retval = dflt;
                //^^FA3=Unable to parse 
                AqLog.getInstance().error("^^FA3" + desc + ": " + e.toString(), e );
            }
        }
        else if( null != desc )
        {
            //^^FA4=null == val while parsing int 
            AqLog.getInstance().error( "^^FA4" + desc );
        }
        return retval;
    }

    public static boolean parseBoolean( String desc, String val, boolean dflt )
    {
        boolean retval = dflt;
        if( null == desc ) desc = "";

        if( null != val )
        {
            if( val.trim().equals("true") )
            {
                retval = true;
            }
            else if( val.trim().equals("false") )
            {
                retval = false;
            }
            else
            {
                retval = dflt;
                //^^FA9=Unable to parse Boolean.  desc,val:
                AqLog.getInstance().error("^^FA3" + desc + "," + val );
            }
        }
        else
        {
            //^^FAa=null == val while parsing Boolean 
            AqLog.getInstance().error( "^^FAa" + desc );
        }
        return retval;
    }
    
    public static int parseInteger( String desc, String val, int dflt )
    {
        return parseInteger( desc, val, dflt, 10 );
    }
    
    public static double parseDouble( String desc, String val, double dflt )
    {
        double retval = dflt;
        if( null == desc ) desc = "";

        if( null != val )
        {
            try
            {
                retval = Double.parseDouble( val.trim() );
            }
            catch( Exception e )
            {
                retval = dflt;
                //^^FA5=Unable to parse 
                AqLog.getInstance().error("^^FA5" + desc + ": " + e.toString(), e );
            }
        }
        else
        {
            //^^FA6=null == val while parsing double 
            AqLog.getInstance().error( "^^FA6" + desc );
        }
        return retval;
    }

    public static float parseFloat( String desc, String val, float dflt )
    {
        float retval = dflt;
        if( null == desc ) desc = "";
        if( null != val )
        {
            try
            {
                retval = Float.parseFloat( val.trim() );
            }
            catch( Exception e )
            {
                retval = dflt;
                if( null == desc ) desc = "";
                //^^FA7=Unable to parse 
                AqLog.getInstance().error("^^FA7" + desc + ": " + e.toString(), e );
            }
        }
        else
        {
            //^^FA8=null == val while parsing float 
            AqLog.getInstance().error( "^^FA8" + desc );
        }
        return retval;
    }

    public static String shortStringFromRawBytes( byte[] b )
    {
    	String s = null;
    	if( null != b )
    	{
    		try
    		{
    			ByteDecoder bd = new ByteDecoder( b );
    			s = bd.readShortString();
    		}
    		catch( Exception e )
    		{
    			AqLog.getInstance().error("Unable to decode short string from raw: " + AqUtils.getHexData( b, 0, b.length ));
    			s=null;
    		}
    	}
    	return s;
    }
    
    public static byte[] stringToShortStringRawBytes( String s )
	{
		ByteEncoder be = new ByteEncoder();
		if( null == s ) s = "";
		if( s.length() > 255 ) s = AqUtils.leftString(s, 255 );
		be.writeShortString( s );
		return be.getContent();
	}

    public static final String UNLOCK_FILE_NAME = "/unlock-me";
    public static void createUnlockFile(Context context)
    {
    	String path = "";
    	try {
    		path = context.getFilesDir().getPath().toString() + UNLOCK_FILE_NAME;

    		File f = new File( path );
			f.createNewFile();
			AqLog.getInstance().debug("createUnlockFile(): " + path );    	
		} catch (Exception e) {
			AqLog.getInstance().error("Unable to create unlock file", e );
		}
    }
    
    public static void deleteUnlockFile(Context context)
    {
    	String path = "";
    	try {
    		path = context.getFilesDir().getPath().toString() + UNLOCK_FILE_NAME;
    		File f = new File( path );
			f.delete();
    		AqLog.getInstance().debug("deleteUnlockFile(): " + path );
		} catch (Exception e) {
			AqLog.getInstance().error("Unable to delete unlock file", e );
		}
    }
    
    public static boolean isUnlockFilePresent(Context context)
    {
    	boolean retval = false;
    	String path = "";
    	try {
    		path = context.getFilesDir().getPath().toString() + UNLOCK_FILE_NAME;

    		File f = new File( path );
			retval = f.exists();
		} catch (Exception e) {
			AqLog.getInstance().error("Unable to test unlock file", e );
		}
    	AqLog.getInstance().debug("isUnlockFile( " + path + " ): " + retval );
    	return retval;
    }
}

