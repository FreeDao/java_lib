/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2007-2012 by Airbiquity.  All rights reserved.
 *
 *  History:
 *  08-20-2012 Jack William Bell - Modified for use in Android projects.
 *
*****************************************************************************/
package com.airbiquity.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import android.util.Log;


/**
 * Provides utility methods for encoding binary messages.
 * 
 * @author Mike O'Meara
 *
 */
public class ByteEncoder {
	
	public static final String TAG = "ByteEncoder";

    public static final int[] intMinValues = new int[]                        {    0,      0,        0,        0 };
    public static final int[] intMaxValues = new int[]                        { 0xfc, 0xfffc, 0xfffffc, Integer.MAX_VALUE - 3 };
    public static final int[] intByteEncoderExceptionValues = new int[]       { 0xfd, 0xfffd, 0xfffffd, Integer.MAX_VALUE - 2 };
    public static final int[] intConstraintExceptionValues = new int[]        { 0xfe, 0xfffe, 0xfffffe, Integer.MAX_VALUE - 1 };
    public static final int[] intOverflowExceptionValues = new int[]          { 0xff, 0xffff, 0xffffff, Integer.MAX_VALUE };

    public static final int[] signedIntMinValues = new int[]                  { -127, -32767, -1677215, Integer.MIN_VALUE + 1 };
    public static final int[] signedIntMaxValues = new int[]                  {  124,  32764,  1677212, Integer.MAX_VALUE - 3 };
    public static final int[] signedIntByteEncoderExceptionValues = new int[] {  125,  32765,  1677213, Integer.MAX_VALUE - 2 };
    public static final int[] signedIntConstraintExceptionValues = new int[]  {  126,  32766,  1677214, Integer.MAX_VALUE - 1 };
    public static final int[] signedIntOverflowExceptionValues = new int[]    {  127,  32767,  1677215, Integer.MAX_VALUE };

    public static final long[] longMinValues = new long[] { 0, 0, 0, 0 };
    public static final long[] longMaxValues = new long[] { 0xfcL, 0xfffcL, 0xfffffcL, 0xfffffffcL, 0xfffffffffcL, 0xfffffffffffcL, 0xfffffffffffffcL, Long.MAX_VALUE - 3 };
    public static final long[] longByteEncoderExceptionValues = new long[] { 0xfdL, 0xfffdL, 0xfffffdL, 0xfffffffdL, 0xfffffffffdL, 0xfffffffffffdL, 0xfffffffffffffdL, Long.MAX_VALUE - 2 };
    public static final long[] longConstraintExceptionValues = new long[] { 0xfeL, 0xfffeL, 0xfffffeL, 0xfffffffeL, 0xfffffffffeL, 0xfffffffffffeL, 0xfffffffffffffeL, Long.MAX_VALUE - 1 };
    public static final long[] longOverflowExceptionValues = new long[] { 0xffL, 0xffffL, 0xffffffL, 0xffffffffL, 0xffffffffffL, 0xffffffffffffL, 0xffffffffffffffL, Long.MAX_VALUE  };
    
    // This is used externally when the cfms data is being packed to determine
    // if the item under consideration to be packed should be included ---
    // sort of a cheat for now.  puts off having to build a factory
    // for this structure.
    private int cfmsVersion = 0;
	
    private final ByteArrayOutputStream bos = new ByteArrayOutputStream();
    private OutputStream os = bos;
    
    // NOTE: Not used. See constructors. (JWB)
    //private int key = 0;
    
    
    /**
     * Creates a <tt>Message Encoder</tt>
     */
    public ByteEncoder() {
    	// NOTE: Not used. (JWB)
        //this.key = 0;
    }

    // Override the byte array output stream and all output goes directly
    // to stream provided.  NOTE:  the methods getContent(), reset(), getSizeAsString(),
    // getSizeAsInt() return information that pertains to the default instance of a
    // ByteArrayOutputStream.  Those values don't pertain to the generic output stream
    // that is being used in preference to the default.
    public ByteEncoder( OutputStream os )
    {
    	this();
    	if( null != os )
    	{
    		this.os = os;
    	}
    }
    
	// NOTE: Not used. (JWB)
    /*
    public ByteEncoder( int key )
    {
        this.key = key;
    }
    */

    // TODO: Fix if we need this. (JWB)
    /*
    public int compareTo( Sortable sortable )
    {
        int retval = Sortable.NOT_COMPARABLE;
        Object o = sortable;
        if( o instanceof ByteEncoder )
        {
            ByteEncoder be = (ByteEncoder) o;
            if( this.key < be.key )
            {
                retval = Sortable.LESS_THAN;
            }
            else if( this.key > be.key )
            {
                retval = Sortable.GREATER_THAN;
            }
            else
            {
                retval = Sortable.EQUAL_TO;
            }
        }
        return retval;
    }
    */
    
    /**
     * Writes binary data to the message output. Call {@link #getContent()} to
     * get content.
     * 
     * @param data binary data to add to the message
     */
    public void writeBytes(byte[] data) throws RuntimeException {
        try {
            os.write(data);
        }
        catch (IOException e) {
            //throw new RuntimeException(e);
            throw new RuntimeException(e.toString());
            
        }
    }

    public void writeByte( byte b ) throws RuntimeException
    {
        try {
			os.write( b );
		} catch (IOException e) {
            throw new RuntimeException(e.toString());
		}
    }
    
    /**
     * Writes a string as ASCII encoded bytes to the message output. 
     * Call {@link #getContent()} to get content.
     * 
     * @param string to add to the message
     */
    public void writeString(String string) throws RuntimeException {
        try {
            os.write(string.getBytes());
        }
        catch (UnsupportedEncodingException e) {
            // throw new RuntimeException(e);
            throw new RuntimeException(e.toString());
            
        }
        catch (IOException e) {
            // throw new RuntimeException(e);
            throw new RuntimeException(e.toString());
        }
    }

    /**
     * Writes a length of string byte and then string as ASCII encoded bytes to the message output. 
     * Call {@link #getContent()} to get content.
     * 
     * @param string to add to the message
     */
    public void writeShortString(String value) throws IllegalArgumentException {
    	if( null == value )
    	{
    		value = "";
    	}
    	
        int length = value.length();
        if (length > 255) {
            //^^CPm=string exceeds maximum string length of 255:
            throw new IllegalArgumentException("^^CPm" + value);
        }
        writeInt(1, length);
        writeString(value);
    }

    /**
     * Writes a length of string byte and then string as ASCII encoded bytes to the message output. 
     * Call {@link #getContent()} to get content.
     * 
     * @param string to add to the message
     */
    public void writeLongString(String value) throws IllegalArgumentException {
        int length = value.length();
        if (length > 65535) {
            //^^CPn=string exceeds maximum string length of 65535:
            throw new IllegalArgumentException("^^CPn" + value);
        }
        writeInt(2, length);
        writeString(value);
    }

//     private void trap()
//     {
//         int a = 5;
//         int b = 0;
//         int c = 0;

//         try
//         {
//             c = a / b;
//         }
//         catch( Exception e )
//         {
//             Log.d(TAG, "trap()");
//             e.printStackTrace( System.out );
//         }
//     }
    
    private void internalWriteInt( int size, int value ) throws RuntimeException
    {
        // Log.d(TAG, "internalWriteInt() size: " + size + ", value: " + value );
        // trap();
        for (int i = 1; i <= size; i++) {
            try {
				os.write((byte) ((value >> (8 * (size - i)) & 0xff)));
			} catch (IOException e) {
			
            throw new RuntimeException(e.toString());
			}
        }
    }

    /**
     * Writes an integer to the message output. Call {@link #getContent()} to get
     * content.
     * 
     * @param size number of bytes to encode the integer value into
     * @param value integer value to encode
     */
    public void stuffedWriteInt(int size, int value) 
    {
    	if (size > 4 )
    	{
    		size = 4;
    	}
    	else if( size < 1)
    	{
    		size = 1;
    	}

    	if( ( value < 0 ) || ( value >= intOverflowExceptionValues[size - 1] ) )
    	{
    		// flag value too large to fit allocated storage
    		internalWriteInt( size, intOverflowExceptionValues[size - 1] );
    		// stuff into 32 bits
    		size = 4;
    	}

    	internalWriteInt( size, value );
    	//        limitedWriteInt( size, value);      
    }

    /**
     * Writes a signed (2's complement) integer to the message output. Call {@link #getContent()} to get
     * content.
     * 
     * @param size number of bytes to encode the integer value into
     * @param value integer value to encode
     */
    private void internalWriteSignedInt(int size, int value,boolean isStuff) {
        int tmp = 0;

        //Log.d(TAG, signedIntMinValues[size - 1] + " < "  + value + " < " + signedIntMaxValues[size - 1] + " ?" );
        
        if (value >= 0) {

            //Log.d(TAG, "value >= signedIntMaxValues[size - 1]: " + ( value >= signedIntMaxValues[size - 1] ) );
            
            if( isStuff && ( value >= signedIntMaxValues[size - 1] ) )
            {
                // flag value too large to fit allocated storage
                internalWriteInt( size, signedIntOverflowExceptionValues[size - 1] );
                
                // stuff into 32 bits
                size = 4;
            }

            internalWriteInt(size, value);

            
            //Log.d(TAG, "size: " + size + ", value " + value + ", tmp: " + tmp + ", value & 0xff: "  + (value & 0xff) );
        }
        else {

            if( isStuff && ( value <= signedIntMinValues[size - 1] ) )
            {
                internalWriteInt( size, signedIntOverflowExceptionValues[size - 1] );
                size = 4;
            }
            
            tmp = -value;
            if (size == 1) {
                tmp = (~tmp + 1) & 0xff;
                //Log.d(TAG, "size: " + size + ", value " + value + ", tmp: " + tmp + ", value & 0xff: " + (value & 0xff) );
            }
            else if (size == 2) {
                tmp = (~tmp + 1) & 0xffff;
                //Log.d(TAG, "size: " + size + ", value " + value + ", tmp: " + tmp + ", value & 0xffff: " + (value & 0xffff) );
            }
            else if (size == 3) {
                tmp = (~tmp + 1) & 0xffffff;
                //Log.d(TAG, "size: " + size + ", value " + value + ", tmp: " + tmp + ", value & 0xffffff: " + (value & 0xffffff) );
            }
            else if (size == 4) {
                tmp = (~tmp + 1) & 0xffffffff;
                //Log.d(TAG, "size: " + size + ", value " + value + ", tmp: " + tmp + ", value & 0xffffffff: " + (value & 0xffffffff) );
            }
            internalWriteInt(size, tmp);
        }

    }
    
    public void limitedWriteInt(int size, int value )
    {
        size = checkIntSize( size );
        value = checkUnsignedValue( size, value );
        internalWriteInt( size, value );
    }

    public void limitedWriteSignedInt( int size, int value )
    {
        size = checkIntSize( size );
        value = checkSignedValue( size, value );
        internalWriteSignedInt( size, value, false );
    }

    public void writeInt( int size, int value )
    {
        limitedWriteInt( size, value );
    }

    public void stuffedWriteSignedInt( int size, int value )
    {
        size = checkIntSize( size );
        internalWriteSignedInt( size, value, true );
        //limitedWriteSignedInt( size, value );
    }

    public void writeSignedInt( int size, int value )
    {
        limitedWriteSignedInt( size, value );
    }
    
    protected static int checkIntSize( int size )
    {
        if( size < 1 ) size = 1;
        else if( size > 4 ) size = 4;
        return size;
    }

    protected static int checkLongSize( int size )
    {
        if( size < 1 ) size = 1;
        else if( size > 8 ) size = 8;
        return size;
    }

    protected static int checkUnsignedValue( int size, int value )
    {
    	if( value < 0 )
        {
            value = 0;
        }
        else if( value > intMaxValues[size - 1] )
        {
            //Log.d(TAG, "limiting " + value + " to " + intMaxValues[size - 1] );
            value = intMaxValues[size - 1];
        }
        return value;
    }

    protected static long checkValue( int size, long value )
    {
        if( (size < 8 ) && ( value < 0 ) )
        {
            //Log.d(TAG, "limiting " + value + " to " + 0 );
            value = 0;
        }
        // else if( value > longMaxValues[size - 1] )
        else if( value > ( longMaxValues[size - 1] - 5 ) )
        {
            //Log.d(TAG, "limiting " + value + " to " + longMaxValues[size - 1] );
            value = longMaxValues[size - 1] - 5;
        }
        return value;
    }
    
    protected static int checkSignedValue( int size, int value )
    {
        // if( value < signedIntMinValues[size - 1] )
        if( value < ( signedIntMinValues[size - 1] ) )
        {
            //Log.d(TAG, "limiting " + value + " to " + signedIntMinValues[size - 1] );
            // value = signedIntMinValues[size - 1];
            value = signedIntMinValues[size - 1];
        }
        else if( value > ( signedIntMaxValues[size - 1] ) )
        {
            //Log.d(TAG, "limiting " + value + " to " + signedIntMaxValues[size - 1] );
            value = signedIntMaxValues[size - 1];
        }
        return value;
    }
    
    private void internalWriteLong(int size, long value) throws RuntimeException {
        for (int i = 1; i <= size; i++) {
            try {
				os.write((byte) ((value >> (8 * (size - i)) & 0xff)));
			} catch (IOException e) {
				throw new RuntimeException(e.toString());
			}
        }
    }

    public void stuffedWriteLong(int size, long value) {
//         size = checkLongSize( size );
//         if( value >= intMaxValues[size - 1] )
//         {
//             // flag value too large to fit allocated storage
//             internalWriteLong( size, longMaxValues[size - 1] );

//             // stuff into 32 bits
//             size = 8;
//             internalWriteLong( size, value );
//         }
        limitedWriteLong( size, value );
    }
    
    public void limitedWriteLong(int size, long value )
    {
        size = checkLongSize( size );
        value = checkValue( size, value );
        internalWriteLong( size, value );
    }

    public void writeLong( int size, long value )
    {
        limitedWriteLong( size, value );
    }

    
    public int getCfmsProtocolVersion()
    {
        return cfmsVersion;
    }

    public void setCfmsProtocolVersion( int version )
    {
        cfmsVersion = version;
    }

    // This is the only method which currently supports values which will overflow the specified storage.  I.e. if 1 byte is specified as the
    // storage size and the value 400 is passed as 'value', the value stored in the 1 byte will be the token representing "overflow".  However
    // a string will be written with the ASCII representation of he 'value' and the decoder will understand that if "overflow" than
    // decode a short string and intrepret as an int.
    public void writeInt( String desc, int minConstraint, int maxConstraint, int size, int value )
    {
        // Log.d(TAG, "writeInt: " + desc + ", min: " + minConstraint + ", max: " + maxConstraint + ", sz: " + size + ",val: " + value );
        if( ( value < minConstraint ) || ( value > maxConstraint ) )
        {
            //Log.d(TAG, "writeInt(): here 1" );
            //^^CP1=AqObuConstraintException packing
            Log.w(TAG, "^^CP1" + desc );
            internalWriteInt( size, intConstraintExceptionValues[size - 1] );
            //exceptionList.addException( desc, "AqObuConstraintException", minConstraint, maxConstraint, value );
        }
        else if( (value < 0 ) || ( value > intMaxValues[size - 1] ) )
        {
            //Log.d(TAG, "writeInt(): here 2" );
            //^^CP2=AqObuOverflowException packing
            Log.w(TAG, "^^CP2" + desc );
            
            
            // TODO: back to intOverflowExceptionValues[size - 1] in encoder version 8 stuffing in 4 bytes rather than string
            internalWriteInt( size, intByteEncoderExceptionValues[size - 1] );
//            // store the value as a string
//            try
//            {
//            	writeShortString( Integer.toString( value ) );
//            }
//            catch( Exception e )
//            {
//            	// failed to write in string representation.  Indicate 0 byte length string
//            	writeInt( 1, 0 );
//            	//exceptionList.addException( desc, "AqObuOverflowException", 0, intMaxValues[size - 1], value );
//            }
        }
        else
        {
            try
            {
                //Log.d(TAG, "writeInt(): here 3" );
                writeInt( size, value );
                //Log.d(TAG, "writeInt(): here 4" );
            }
            catch( IllegalArgumentException e )
            {
                //Log.d(TAG, "writeInt(): here 5" );
                //^^CP3=AqObuOverflowException packing 
                Log.w(TAG, "^^CP3" + desc + ": " + e.toString(), e );
                internalWriteInt( size, intByteEncoderExceptionValues[size - 1] );
                //exceptionList.addException( desc, "AqObuOverflowException", 0, intMaxValues[size - 1], value );
            }
            catch( Exception e )
            {
                //Log.d(TAG, "writeInt(): here 6" );
                //^^CP4=AqObuEncoderException packing 
                Log.w(TAG, "^^CP4" + desc + ": " + e.toString(), e );
                internalWriteInt( size, intByteEncoderExceptionValues[size - 1] );
                //exceptionList.addException( desc, "AqObuEncoderException", 0, intMaxValues[size - 1], value );
            }
        }
    }

    public void writeInt( String desc, int size, int value )
    {
        if( value < 0 )
        {
            value = 0;
        }
        else if( value > intMaxValues[size - 1] )
        {
            value = intMaxValues[size - 1];
        }

        writeInt( desc, 0, intMaxValues[size - 1], size, value );
    }
    
    public void writeSignedInt( String desc, int minConstraint, int maxConstraint, int size, int value )
    {
        //^^CP5=writeInt: 
        // Log.d(TAG, "^^CP5" + desc + ", min: " + minConstraint + ", max: " + maxConstraint + ", sz: " + size + ",val: " + value );
        if( ( value < minConstraint ) || ( value > maxConstraint ) )
        {
            //^^CP6=AqObuConstraintException packing
            Log.w(TAG, "^^CP6" + desc );
            internalWriteSignedInt( size, signedIntConstraintExceptionValues[size - 1], false );
            //exceptionList.addException( desc, "AqObuConstraintException", minConstraint, maxConstraint, value );
        }
        else if( ( value < signedIntMinValues[size - 1] ) || ( value > signedIntMaxValues[size - 1] ) )
        {
            //^^CP7=AqObuOverflowException packing
            Log.w(TAG, "^^CP7" + desc );
            internalWriteSignedInt( size, signedIntByteEncoderExceptionValues[size - 1], false );
            //exceptionList.addException( desc, "AqObuOverflowException", signedIntMinValues[size - 1], signedIntMaxValues[size - 1], value );
        }
        else
        {
            try
            {
                writeSignedInt( size, value );
            }
            catch( IllegalArgumentException e )
            {
                //^^CP8=AqObuOverflowException packing 
                Log.w(TAG, "^^CP8" + desc + ": " + e.toString(), e );
                internalWriteSignedInt( size, signedIntByteEncoderExceptionValues[size - 1], false );
                //exceptionList.addException( desc, "AqObuOverflowException", signedIntMinValues[size - 1], signedIntMaxValues[size - 1], value );
            }
            catch( Exception e )
            {
                //^^CP9=AqObuEncoderException packing 
                Log.w(TAG, "^^CP9" + desc + ": " + e.toString(), e );
                internalWriteSignedInt( size, signedIntByteEncoderExceptionValues[size - 1], false );
                //exceptionList.addException( desc, "AqObuEncoderException", signedIntMinValues[size - 1], signedIntMaxValues[size - 1], value );
            }
        }
    }

    public void writeLong( String desc, long minConstraint, long maxConstraint, int size, long value )
    {
        // Log.d(TAG, "writeLong(): here 1" );
        if( ( value < minConstraint ) || ( value > maxConstraint ) )
        {
            //^^CPa=writeLong desc,minConstraint,maxConstraint,sz,val:
            Log.d(TAG, "^^CPa" + desc + "," + minConstraint + "," + maxConstraint + "," + size + "," + value );

            writeLong( size, longConstraintExceptionValues[size - 1] );
        }
        else if( value > longMaxValues[size - 1] )
        {
            // Log.d(TAG, "writeLong(): here 3" );
            //^^CPc=AqObuOverflowException packing 
            Log.w(TAG, "^^CPc" + desc );
            writeLong( size, longOverflowExceptionValues[size - 1] );

            if( getCfmsProtocolVersion() < 6 )
            {
                // Log.d(TAG, "writeLong(): here 4" );
                //exceptionList.addException( desc, "AqObuOverflowException", 0, longMaxValues[size - 1], value );
            }
            else
            {
                // Log.d(TAG, "writeLong(): here 5" );
                // store the value as a string
                try
                {
                    writeShortString( Long.toString( value ) );
                }
                catch( Exception e )
                {
                    // failed to write in string representation.  Indicate 0 byte length string
                    writeInt( 1, 0 );
                    //exceptionList.addException( desc, "AqObuOverflowException", 0, longMaxValues[size - 1], value );
                }
            }
        }
        else
        {
            try
            {
                writeLong( size, value );
            }
            catch( IllegalArgumentException e )
            {
                //^^CPd=AqObuOverflowException packing 
                Log.w(TAG, "^^CPd" + desc + ": " + e.toString(), e );
                writeLong( size, longOverflowExceptionValues[size - 1] );
                //exceptionList.addException( desc, "AqObuOverflowException", 0, longMaxValues[size - 1], value );
            }
            catch( Exception e )
            {
                //^^CPe=AqObuEncoderException packing 
                Log.w(TAG, "^^CPe" + desc + ": " + e.toString(), e );
                writeLong( size, longOverflowExceptionValues[size - 1] );
                //exceptionList.addException( desc, "AqObuEncoderException ", 0, longMaxValues[size - 1], value );
            }
        }
    }

    // NOTE: size is the number of underlying bytes used to encode the float.
    public void writeFloat( String desc, float minConstraint, float maxConstraint, float scalar,  int size, float value )
    {
        //^^CPf=writeFloat: 
        // Log.d(TAG, "^^CPf" + desc + ",min: " + minConstraint + ", max: " + maxConstraint + ", sz: " + size + ",val: " + value );
        int intEncoding = AqUtils.floatToPacked( minConstraint, scalar, value );

        if( ( value < minConstraint ) || ( value > maxConstraint ) )
        {
            //^^CPg=AqObuConstraintException packing
            Log.w(TAG, "^^CPg" + desc );
            internalWriteInt( size, intConstraintExceptionValues[size - 1] );
            //exceptionList.addException( desc, "AqObuConstraintException", minConstraint, maxConstraint, value );
        }
        else if( intEncoding > intMaxValues[size - 1] )
        {
            //^^CPh=AqObuOverflowException packing
            Log.w(TAG, "^^CPh" + desc );
            internalWriteInt( size, intByteEncoderExceptionValues[size - 1] );
            //exceptionList.addException( desc, "AqObuOverflowException", 0, intMaxValues[size - 1], intEncoding );
        }
        else
        {
            try
            {
                writeInt( size, intEncoding );
            }
            catch( Exception e )
            {
                //^^CPk=AqObuEncoderException packing 
                Log.w(TAG, "^^CPk" + desc + ": " + e.toString(), e );
                writeInt( size, intByteEncoderExceptionValues[size - 1] );
                //exceptionList.addException( desc, "AqObuEncoderException", 0, intMaxValues[size - 1], intEncoding );
            }
        }
    }
    
    /**
     * Gets the message content without the header.
     * 
     * @return message content.  NOTE: when the
     *         default ByteArrayOutputStream is overridden
     *         using the overloaded constructor
     *         <code>ByteEncoder( OutputStream os )</code>
     *         this method will still return the content
     *         of the default output stream (which will be empty).
     */
    public byte[] getContent() {
        return bos.toByteArray();
    }
 
   public String toString()
    {
        return os.toString();
    }

   /**
	 * Resets the underlying default output stream. 
	 * NOTE: when the default ByteArrayOutputStream is overridden
     *         using the overloaded constructor
     *         <code>ByteEncoder( OutputStream os )</code>
     *         this method will not have any useful effect.
    */
    public void reset()
    {
        bos.reset();
    }
    
    /** Return the number of bytes contained in the encoder's
     *  default buffer as string.
     * 
	 * NOTE: when the default ByteArrayOutputStream is overridden
     *         using the overloaded constructor
     *         <code>ByteEncoder( OutputStream os )</code>
     *         this method will always output the value "0"
     * 
     * @return The number of bytes contained in the default buffer converted
     *         to the base 10 string representation.
     */
    public String getSizeAsString()
    {
        Integer i = Integer.valueOf( bos.size() );
        return i.toString();
    }
    
    /** Return the number of bytes contained in the encoder's
     *  default buffer.
     * 
	 * NOTE: when the default ByteArrayOutputStream is overridden
     *         using the overloaded constructor
     *         <code>ByteEncoder( OutputStream os )</code>
     *         this method will always output the value "0"
     * 
     * @return The number of bytes contained in the default buffer.
     */
    public int getSizeAsInt()
    {
        return bos.size();
    }
    
    public void writeTimeInMsAsSecs( long ms )
    {
    	// round to nearest second
    	ms = ms + 500;
    	ms /= 1000;
    	
    	writeLong( 4, ms );
    }
    
    /** Convert from milliseconds to seconds with some limit checking.
     * 
     * @param ms Milliseconds to convert
     * @return time in seconds.
     */
    public static int milliSecondsToSeconds( long ms )
    {
    	long result = ms / 1000;
    	if( result > Integer.MAX_VALUE ) result = Integer.MAX_VALUE;
    	if( result < 0 ) result = 0;
    	
    	return (int) result;
    }
}
