package com.airbiquity.util;

/*
 * Test Code:
  		ByteBuffer bb = new ByteBuffer(64);
		for (byte b = 0;b < 100;b++) {
			bb.add(b);
		}
		bb.appendChunk(new byte[]{100, 101, 102, 103, 104});
		for (int i = 0;i < bb.size();i++) {
			System.out.print(i + ":" + bb.get(i) + ", ");
			if (i > 1 && i % 20 < 1) System.out.println();
		}
		System.out.println();
		byte[] ch = bb.extractRange(100, 5);
		printByteArray(ch);
		System.out.println();
		bb.snipRange(32, 16);
		for (int i = 0;i < bb.size();i++) {
			System.out.print(i + ":" + bb.get(i) + ", ");
			if (i > 1 && i % 20 < 1) System.out.println();
		}
		System.out.println();
		bb.snipRange(0, 16);
		for (int i = 0;i < bb.size();i++) {
			System.out.print(i + ":" + bb.get(i) + ", ");
			if (i > 1 && i % 20 < 1) System.out.println();
		}
		System.out.println();
		bb.snipRange(bb.size() - 5, 5);
		for (int i = 0;i < bb.size();i++) {
			System.out.print(i + ":" + bb.get(i) + ", ");
			if (i > 1 && i % 20 < 1) System.out.println();
		}
		System.out.println();
		bb.setSearchPattern(new byte[]{30, 31, 48, 49});
		int[] sr = bb.search();
		if (sr == null) System.out.println("Not found.");
		else System.out.print("Pos: " + sr[0] + " Len: " + sr[1] + " Next: " + sr[2]);
		System.out.println();
		System.out.println();
		sr = bb.search(15);
		if (sr == null) System.out.println("Not found.");
		else System.out.print("Pos: " + sr[0] + " Len: " + sr[1] + " Next: " + sr[2]);
 */

/**
 * Manages a buffer of bytes. Although there are some similarities to ArrayList, 
 * this class provides better performance when adding or extracting chunks (sub-arrays)
 * and dispenses with a lot of functionality not required for straight-ahead buffering
 * of bytes.
 * 
 * @author Jack William Bell
 */
public class ByteBuff {
	private static final int DEFAULT_START_BUFFER_SIZE = 2048;
	private static final int MIN_START_BUFFER_SIZE = 64;
	
	private int mBufferContentSize = 0;
	private int mBufferResizeFactor = 0;
	private byte[] mBuffer = null;
	
    private int[] mSearchFailurePattern = null;
    private byte[] mSearchPattern = null;

    private void expandIfNeeded(int spaceRequired) {
    	// Do we need to do anything at all?
    	int length = mBuffer.length;
        if (length - mBufferContentSize >= spaceRequired) return;

        // How much are we going to resize to?
        int newLength = mBufferResizeFactor; 
        if (newLength < spaceRequired) newLength += spaceRequired;
        newLength += length;
        
        // Resize it.
        byte[] newArray = new byte[newLength];
        System.arraycopy(mBuffer, 0, newArray, 0, length);
        mBuffer = newArray;
     }
    
    /**
     * <p>Search the data byte array for the first occurrence of the byte 
     * array pattern. Uses Knuth-Morris-Pratt Pattern Matching Algorithm.</p>
     * 
     * <p>Modified from Public Domain code found here:
     * 	http://helpdesk.objects.com.au/java/search-a-byte-array-for-a-byte-sequence</p>
     * 
     * @param data
     * @return
     */
    private int indexOf(int startIndex) {        
        if (mSearchPattern != null && startIndex < mBufferContentSize) {
            int j = 0;
            for (int i = startIndex; i < mBufferContentSize; i++) {
                while (j > 0 && mSearchPattern[j] != mBuffer[i]) {
                    j = mSearchFailurePattern[j - 1];
                }
                if (mSearchPattern[j] == mBuffer[i]) {
                    j++;
                }
                if (j == mSearchPattern.length) {
                    return i - mSearchPattern.length + 1;
                }
            }
        }

        return -1;
    }

    /**
     * Computes the failure function using a boot-strapping process,
     * where the pattern is matched against itself.
     * 
     * @param pattern
     * @return
     */
    private int[] computeFailure(byte[] pattern) {
        int[] failure = new int[pattern.length];

        int j = 0;
        for (int i = 1; i < pattern.length; i++) {
            while (j>0 && pattern[j] != pattern[i]) {
                j = failure[j - 1];
            }
            if (pattern[j] == pattern[i]) {
                j++;
            }
            failure[i] = j;
        }

        return failure;
    }
    
    /**
     * 
     */
    public ByteBuff() {
    	reset();
    }

    /**
     * @param startingBufferSize
     */
    public ByteBuff(int startingBufferSize) {
    	reset(startingBufferSize);
    }

    /**
     * @return
     */
    public int size() {
    	return mBufferContentSize;
    }
    
    /**
     * @param val
     */
    public void add(byte val) {
    	expandIfNeeded(1);
    	this.mBuffer[this.mBufferContentSize++] = val;
    }
    
    /**
     * @param index
     * @param val
     */
    public void set(int index, byte val) throws IndexOutOfBoundsException {
    	if (index < this.mBufferContentSize) {
        	this.mBuffer[index] = val;
    	}
    	else {
    		throw new IndexOutOfBoundsException();
    	}
    }
    
    /**
     * @param index
     * @return
     */
    public byte get(int index) throws IndexOutOfBoundsException {
    	if (index < this.mBufferContentSize) {
        	return this.mBuffer[index];
    	}

    	throw new IndexOutOfBoundsException();
    }
    
    /**
     * @param val
     */
    public void appendChunk(byte[] chunk) {
    	if (chunk == null) return;
    	
    	expandIfNeeded(chunk.length);
    	
    	System.arraycopy(chunk, 0, mBuffer, this.mBufferContentSize, chunk.length);
    	this.mBufferContentSize += chunk.length;
    }
    
    /**
     * @return
     */
    public byte[] toByteArray() {
    	return extractRange(0, this.mBufferContentSize, null);
    }
    
    /**
     * @param toArray
     * @return
     */
    public byte[] toByteArray(byte[] toArray) {
    	return extractRange(0, this.mBufferContentSize, toArray);
    }
    
    /**
     * @param index
     * @param length
     * @return
     */
    public byte[] extractRange(int index, int length) {
    	return extractRange(index, length, null);
    }
    
    /**
     * @param index
     * @param length
     * @param toArray
     * @return
     */
    public byte[] extractRange(int index, int length, byte[] toArray) {
    	if (toArray == null) toArray = new byte[length];
    	System.arraycopy(mBuffer, index, toArray, 0, length);
    	return toArray;
    }

    /**
     * Resets the buffer to the starting condition using the default buffer size.
     */
    public void reset() {
    	reset(DEFAULT_START_BUFFER_SIZE);
    }
    
    /**
     * Resets the buffer to the starting condition using the passed buffer size.
     * 
     * @param startingBufferSize
     */
    public void reset(int startingBufferSize)  {    	
    	if (startingBufferSize < MIN_START_BUFFER_SIZE) startingBufferSize = MIN_START_BUFFER_SIZE;
    	
    	this.mBufferContentSize = 0;
    	this.mBufferResizeFactor = startingBufferSize / 2; // We will not grow exponentally!
    	this.mBuffer = new byte[startingBufferSize];
    	this.mSearchPattern = null;
    	this.mSearchFailurePattern = null;
    }

    /**
     * Removes all contents from the buffer, without resetting. Does not reset the 
     * buffer settings or the search pattern.
     */
    public void clear()  {
    	truncate(0);
    }

    /**
     * Removes the contents of the buffer starting at and following the passed index.
     * 
     * @param atIndex
     */
    public void truncate(int atIndex) throws java.lang.ArrayIndexOutOfBoundsException {
    	if (atIndex < 0 || atIndex > this.mBufferContentSize) throw new java.lang.ArrayIndexOutOfBoundsException();
    	this.mBufferContentSize = atIndex;
    }
    
    /**
     * Remove the specified range from the buffer.
     * 
     * @param startIndex
     * @param size
     */
    public void snipRange(int startIndex, int length) {
    	if (length < 1) return;
        System.arraycopy(mBuffer, startIndex + length, mBuffer, startIndex, this.mBufferContentSize - (startIndex + length));
    	this.mBufferContentSize -= length;
    }
    
    public byte[] getSearchPattern() {
    	return this.mSearchPattern;
    }
    
    /**
     * @param pattern
     */
    public void setSearchPattern(byte[] pattern) {
    	if (pattern != null) {
        	this.mSearchPattern = pattern;
        	this.mSearchFailurePattern = computeFailure(pattern); // nikm
    	}
    	else {
        	this.mSearchPattern = null;
        	this.mSearchFailurePattern = null;
    	}
	}
    
	/**
	 * <p>Searches the entire buffer for a pattern provided via setSearchPattern(). If
	 * a result is found it returns a three element array of integers where the 
	 * first element is the index where the pattern was found, the second element 
	 * is the length of the pattern and the third element is the index of the first
	 * byte following the pattern or -1 if there are no bytes in the buffer following
	 * the pattern. If the pattern is not found it returns null.</p>
	 * 
	 * <p>Equivalent to calling 'search(0)'.</p>
	 * 
	 * @return A three-element integer array or null.
	 */
	public int[] search() {
		return search(0);
	}

	/**
	 * Searches the buffer, starting at the passed index, for a pattern provided via 
	 * setSearchPattern(). If a result is found it returns a three element array of 
	 * integers where the first element is the index where the pattern was found, the 
	 * second element is the length of the pattern and the third element is the index 
	 * of the first byte following the pattern or -1 if there are no bytes in the buffer 
	 * following the pattern. If the pattern is not found it returns null.
	 * 
	 * @param startIndex
	 * @return A three-element integer array or null.
	 */
	public int[] search(int startIndex) {
		int[] result = null;
		
		int pos = indexOf(startIndex);
		if (pos > -1) {
			result = new int[3];
			result[0] = pos;
			result[1] = mSearchPattern.length;
			if (pos >= this.mBufferContentSize - 1) {
				result[2] = -1;
			}
			else {
				result[2] = pos + result[1];
			}
		}
		
		return result;
	}

}
