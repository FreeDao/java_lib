var language_preference = null;// define the default language_preference
var t = null;// define the default language object
var settingExits = false;
var testFlag = true;
var funcAvailable = false;
var inMotion = false;
var navigationSelected = false;
var messagePopup = null;
var alertPopup = null;
var messageInmotionPopup = null;
var alertInmotionPopup = null;
// get today's time stamp
var todayTimeStamp = new Date(new Date().getFullYear(), new Date().getMonth(),
		new Date().getDate()).getTime() / 1000;

$(document).ready(function() {
	util = new Util();
	setInterval(function() {
		util.setTime();
	}, 1000);
});

var Util = function() {

};

Util.prototype = {
	_btnPressedTimer : null,// The timer of btnPressed
	_processTimer : null,// The timer of process bar
	_imageIndex : 0,
	_notifyTimer : null,
	_message_notifyTimer : null,
	_alert_notifyTimer : null,
	setTime : function() {
		var now = new Date();
		var year = now.getFullYear();
		var month = now.getMonth() + 1;
		var day = now.getDate();
		var hours = now.getHours();
		var minutes = now.getMinutes();
		var seconds = now.getSeconds();
		if (minutes.toString().length == 1) {
			minutes = '0' + minutes;
		}
		time = hours + ':' + minutes;
		$(".time").html(time);
	},
	/**
	 * Format time stamp,
	 * 
	 * @param tim:
	 *            time stamp
	 * @param dat:
	 *            the date format
	 */
	timeToDate : function(tim, dat) {
		return new Date(parseInt(tim) * 1000).format(dat);
	},
	/**
	 * The click effect and the action after the event,
	 * 
	 * @param className:
	 *            the class name of selected element
	 * @param nextAction:
	 *            the action which will be run after the effect
	 */
	sendsToTime: function(s){
		var h = parseInt(s/3600);
		var m = parseInt((s%3600)/60);
		var HH = null;
		var MM = null;
		if(h>0 && h < 10){
			HH = "0" + h;
		}else if(h == 0){
			HH = "00";
		}else if(h >= 10){
			HH = h + "";
		}
		if(m > 0 && m < 10){
			MM = "0" + m;
		}else if(m == 0){
			MM = "00";
		}else if(m >= 10){
			MM = m + "";
		}		
		return HH+":"+MM;
	},
	btnPressed : function(className, nextAction) {
		$("." + className).removeClass(className + "_active");
		$("." + className).addClass(className + "_pressed");
		if (this._btnPressedTimer) {
			clearTimeout(this._btnPressedTimer);
		}
		this._btnPressedTimer = setTimeout(function() {
			$("." + className).removeClass(className + "_pressed");
			$("." + className).addClass(className + "_active");
			if (nextAction != null) {
				nextAction();
			}
		}, 100);
	},

	checkBtnPressed : function(el, nextAction) {
		if (!$("." + el).last().hasClass(el + "_hide")) {
			$("." + el).removeClass(el + "_hide");
			$("." + el).last().addClass(el + "_pressed");
			setTimeout(function() {
				$("." + el).last().removeClass(el + "_pressed")
				$("." + el).last().addClass(el + "_hide");
				if (nextAction != null) {
					nextAction();
				}
			}, 100);
        }
        else 
            if ($("." + el).last().hasClass(el + "_hide")) {
			$("." + el).last().addClass(el + "_hide" + "_pressed");
			setTimeout(function() {
				$("." + el).last().removeClass(el + "_hide" + "_pressed")
				$("." + el).last().removeClass(el + "_hide");
				if (nextAction != null) {
					nextAction();
				}
			}, 100);
		}

	},

	/**
	 * Add the active effect,
	 * 
	 * @param className:
	 *            the class name of selected element
	 */
	btnActive : function(className) {
		$("." + className).addClass(className + "_active");
	},
	/**
	 * Clean the active effect of selected elements,
	 * 
	 * @param classNameArry:
	 *            the class name of selected elements
	 */
	clearOtherBtnActive : function(classNameArry) {
		for ( var i in classNameArry) {
            $("." + classNameArry[i]).removeClass(classNameArry[i] + "_pressed");
			$("." + classNameArry[i]).removeClass(classNameArry[i] + "_active");
		}
	},
	/**
	 * Add the process bar on the element whose id is appointed,
	 * 
	 * @param id:
	 *            the id of appointed elements
	 */
	process : function(id) {
		var _this = this;
		var path = "common/images/spinner-";
        var iconArray = new Array("1.png", "2.png", "3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png");
		$("#" + id).attr({
			"src" : path + iconArray[_this._imageIndex]
		});
		_this._imageIndex++;
		if (_this._imageIndex == 11) {
			_this._imageIndex = 0;
		}
		if (this._processTimer) {
			clearTimeout(this._processTimer);
		}
		this._processTimer = setTimeout(function() {
			_this.process(id);
		}, 100);
	},
	hideSetting : function() {
		$("#temp_setting").remove();
		$(".setting").hide();
		this.bindSetting();
	},
	/**
	 * bind the setting event
	 */
	bindSetting : function() {
		settingExits = true;
		$("#settings").addClass("setting_icon");
		$("#settings").bind('click', function() {
			util.btnPressed('setting_icon', function() {
				$("#temp_setting").remove();
				$(".setting").append($("<div>").attr("id", "temp_setting"));
				new Settings('#temp_setting', {});
			});
		});
	},
	/**
	 * when setting changed, then applied and send the new configuration to the
	 * backend
	 * 
	 * @param conf:
	 *            configuration
	 */
	applySetting : function(conf) {
		ConfigurationData.setConf(conf);
		this.getSetting();
	},
	/**
	 * read the configuration file and then configure
	 */
	getSetting : function() {
		var lang;
		switch (configuration.language_preference) {
		case "eng":
			lang = "English";
			break;
		case "nld":
			lang = "Dutch";
			break;
		case "fra":
			lang = "French";
			break;
		case "spa":
			lang = "Spanish";
			break;
		case "deu":
			lang = "German";
			break;
		case "ita":
			lang = "Italian";
			break;
		case "hun":
			lang = "Hungarian";
			break;
		case "pol":
			lang = "Polish";
			break;
		case "nor":
			lang = "Norwegian";
			break;
		case "dan":
			lang = "Danish";
			break;
		case "cze":
			lang = "Czech";
			break;
		case "rom":
			lang = "Romainian";
			break;
		default:
			lang = "English";
			break;
		}

		$.ajax({
			type : "GET",
			url : "locales/" + lang + ".json",
			dataType : "json",
			async : false,
			success : function(data) {
				t = data;
			},
			error : function(data) {

			}
		});
	},
	/**
	 * The popup screen
	 * 
	 * @param notify_type:
	 *            popup
	 *            type:"NOTIFY_TYPE_TEXT_MESSAGE"/"NOTIFY_TYPE_ALERT"/"NOTIFY_TYPE_RESET"
	 * @param notify_obj:
	 *            popup content
	 */
	notify : function(notify_type, notify_obj) {
    	notify_obj = decodeURIComponent(notify_obj); // For special character issue
        util.showLog("-----------funcAvailable:" + funcAvailable);
		util.showLog("-----------notify_type:" + notify_type);
		util.showLog("-----------notify_obj:" + notify_obj);
        if (funcAvailable) {
			if (notify_type == "NOTIFY_TYPE_TEXT_MESSAGE") {
				 MessageData.storeMessage(JSON.parse(notify_obj));
				MESSAGE_NOTIFY.high_count = 0;
				MESSAGE_NOTIFY.normal_count = 0;
				$.each(messageList, function(index, item) {
					if (item.read == 0) {
						if (item.priority > 5) {
							MESSAGE_NOTIFY.high_count += 1;
                        }
                        else {
							MESSAGE_NOTIFY.normal_count += 1;
						}
					}
				});
				if (MESSAGE_NOTIFY.high_count > 0) {
					if (settingExits) {
						$("#settings").unbind();
					}
					$("#message_notify").show();
					$("#message_notify").removeClass("left_side_btn_notify_bg")
							.addClass("left_side_btn_notify_bg_active");
					$("#message_notify").html(MESSAGE_NOTIFY.high_count);
					if (!inMotion) {
						$("#temp_notify").remove();
						$(".notify").append(
								$("<div>").attr("id", "temp_notify"));
						messagePopup = null;
						messagePopup = new Notify('#temp_notify', {
							notify_type : "message_priority_high",
							notify_count : MESSAGE_NOTIFY.high_count,
							data : messageList
						});
						message_popupExist = true;
						if (this._message_notifyTimer) {
							clearTimeout(this._message_notifyTimer);
						}
						this._message_notifyTimer = setTimeout(function() {
							$("#temp_notify").remove();
							$(".notify").hide();
							Android.cancelSoundNotification();
							message_popupExist = false;
						}, 300000);
					} else if (inMotion) {
						if (configuration.display_high_priority_message == 1) {

							highPriorityMessageInmotion = true;
							$("#temp_drive_mode").remove();
							$(".drive_mode").append(
									$("<div>").attr("id", "temp_drive_mode"));
							new DrivModule('#temp_drive_mode', {});
							$("#temp_in_motion_notify").remove();
							$(".in_motion_notify").append(
									$("<div>").attr("id",
											"temp_in_motion_notify"));
							messageInmotionPopup = null;
							messageInmotionPopup = new InMotionNotify('#temp_in_motion_notify', {
								notify_type : "message_priority_high_inmotion",
								notify_count : MESSAGE_NOTIFY.high_count,
								data : messageList
							});
							if (this._message_notifyTimer) {
								clearTimeout(this._message_notifyTimer);
							}
							this._message_notifyTimer = setTimeout(function() {
//								$("#temp_notify").remove();
//								$(".notify").hide();
								$("#temp_in_motion_notify").remove();
								$(".in_motion_notify").hide();
								$("#temp_drive_mode").remove();
								$(".drive_mode").hide();
								highPriorityMessageInmotion = false;
								Android.cancelSoundNotification();
							}, 300000);
						}
					}

				} else if (MESSAGE_NOTIFY.normal_count > 0) {
					if (settingExits) {
						$("#settings").unbind();
					}
					util.showLog("-----HMI----inmotion:" + inMotion);
					$("#message_notify").show();
					$("#message_notify").removeClass(
							"left_side_btn_notify_bg_active").addClass(
							"left_side_btn_notify_bg");
					$("#message_notify").html(MESSAGE_NOTIFY.normal_count);
					$("#temp_notify").remove();
					$(".notify").append($("<div>").attr("id", "temp_notify"));
					messagePopup = null;
					messagePopup = new Notify('#temp_notify', {
						notify_type : "message_priority_normal",
						notify_count : MESSAGE_NOTIFY.normal_count,
						data : messageList
					});
					message_popupExist = true;
					if (this._message_notifyTimer) {
						clearTimeout(this._message_notifyTimer);
					}
					this._message_notifyTimer = setTimeout(function() {
						$("#temp_notify").remove();
						$(".notify").hide();
						Android.cancelSoundNotification();
						message_popupExist = false;
					}, 300000);
				} else if (MESSAGE_NOTIFY.high_count == 0
						&& MESSAGE_NOTIFY.normal_count == 0) {
					$("#message_notify").hide();
					$("#temp_notify").remove();
					$(".notify").hide();
					message_popupExist = false;
					highPriorityMessageInmotion = false;
					if (testFlag) {
						Android.cancelSoundNotification();
					}
				}
			} else if (notify_type == "NOTIFY_TYPE_ALERT") {
				AlertData.storeAlert(JSON.parse(notify_obj));
				ALERT_NOTIFY.alertCount = 0;
				var alertUnreadIndex;
				$.each(alertList, function(index, item) {
					if (item.read == 0) {
						ALERT_NOTIFY.alertCount += 1;
						alertUnreadIndex = index;
					}
				});
				if (ALERT_NOTIFY.alertCount > 0) {
					if (settingExits) {
						$("#settings").unbind();
					}
					$("#alerts_notify").show();
					$("#alerts_notify").removeClass("left_side_btn_notify_bg")
							.addClass("left_side_btn_notify_bg_active");
					$("#alerts_notify").html(ALERT_NOTIFY.alertCount);
					if (!inMotion) {
						if (settingExits) {
							$("#settings").unbind();
						}
						$("#alert_temp_notify").remove();
						$(".alert_notify").append(
								$("<div>").attr("id", "alert_temp_notify"));
						alertPopup = null;
						alertPopup = new AlertNotify('#alert_temp_notify', {
							notify_type : "alert_notify",
							notify_count : ALERT_NOTIFY.alertCount,
							data : alertList,
							item : alertList[alertUnreadIndex]
						});
						alert_popupExist = true;
						if (this._alert_notifyTimer) {
							clearTimeout(this._alert_notifyTimer);
						}
						this._alert_notifyTimer = setTimeout(function() {
							$("#alert_temp_notify").remove();
							$(".alert_notify").hide();
							Android.cancelSoundNotification();
							alert_popupExist = false;
						}, 300000);

					} else if (inMotion) {

						if (configuration.display_high_priority_alert == 1) {
							$("#temp_drive_mode").remove();
							$(".drive_mode").append(
									$("<div>").attr("id", "temp_drive_mode"));
							new DrivModule('#temp_drive_mode', {});
							$("#alert_temp_in_motion_notify").remove();
							$(".alert_in_motion_notify").append(
									$("<div>").attr("id",
											"alert_temp_in_motion_notify"));
							alertInmotionPopup = null;
							alertInmotionPopup = new AlertInMotionNotify(
									'#alert_temp_in_motion_notify', {
								notify_type : "alerts_inmotion",
								notify_count : ALERT_NOTIFY.alertCount,
								data : alertList,
								item : alertList[alertUnreadIndex]
							});
							alertInmotionExist = true;
							if (this._alert_notifyTimer) {
								clearTimeout(this._alert_notifyTimer);
							}
							this._alert_notifyTimer = setTimeout(function() {
								$("#alert_temp_in_motion_notify").remove();
								$(".alert_in_motion_notify").hide();
								if(!highPriorityMessageInmotion){
									$("#temp_drive_mode").remove();
									$(".drive_mode").hide();
								}
								alertInmotionExist = false;
								Android.cancelSoundNotification();
							}, 300000);
						}
					}
				} else {
					$("#alerts_notify").hide();
					$("#alert_temp_notify").remove();
					$(".alert_notify").hide();
				}

			}
		}
		if (notify_type == "NOTIFY_TYPE_OBU_STATUS") {
			var obuStatus = JSON.parse(notify_obj);
			util
					.showLog("-----HMI----inmotion1:"
							+ obuStatus.is_vehicle_moving);
			if (obuStatus.is_vehicle_moving == false) {
				inMotion = false;
				$("#temp_in_motion").remove();
				$(".in_motion").hide();
				$("#temp_drive_mode").remove();
				$(".drive_mode").hide();
				highPriorityMessageInmotion = false;
				alertInmotionExist = false;
				if (settingExits) {
					this.bindSetting();
				}
			} else if (obuStatus.is_vehicle_moving == true) {
				inMotion = true;
				$("#temp_in_motion").remove();
				$(".in_motion").append($("<div>").attr("id", "temp_in_motion"));
				new InMotion('#temp_in_motion', {});
			}
		} else if (notify_type == "NOTIFY_TYPE_RESET") {
			var conf = JSON.parse(notify_obj);
			util.showLog("-----HMI----reset conf:" + notify_obj);
			configuration.display_high_priority_message = conf.display_high_priority_message;
			configuration.user_id = conf.user_id;
			configuration.language_preference = conf.language_preference;
			configuration.driver_type = conf.driver_type;
			configuration.audio_sounds = conf.audio_sounds;
			configuration.display_high_priority_alert = conf.display_high_priority_alert;
			configuration.is_eula_accepted = conf.is_eula_accepted;
			util.applySetting(configuration);
			$("#message_send_content").remove();
			$("#message_send_msg_content").remove();
			$("#temp_notify").remove();
			$(".notify").hide();
			$("#alert_temp_notify").remove();
			$(".alert_notify").hide();
			$("#temp_custom_popup").remove();
			$("#temp_setting").remove();
			$(".custom_popup").hide();
			$(".setting").hide();
			if (testFlag) {
				Android.cancelSoundNotification();
			}

			$("#temp_body_content").remove();
			$(".body_content").append(
					$("<div>").attr("id", "temp_body_content"));
			if (configuration.is_eula_accepted == 1) {
				homeInstance = new Home('#temp_body_content', {
					boolGetMsg : true,
					boolGetAlt : true,
					viewType : "messages"
				});
			} else {
				funcAvailable = false;
				new HomeLogin('#temp_body_content', {})
				$("#temp_right_side_content").remove();
				$(".right_side_content").append(
						$("<div>").attr("id", "temp_right_side_content"));
				new Eula('#temp_right_side_content', {});
			}
		}
	},
	showToast : function(msg) {
		if (testFlag) {
			Android.showToast(msg);
		} else {
			console.log(msg);
		}
	},
	showLog : function(log) {
		if (testFlag) {
			Android.log(log);
		} else {
			console.log(log);
		}
	},
	/**
	 * TTS
	 */
	textToSpeach : function(text, lang) {
		if (testFlag) {
			Android.setTtsText(text, lang);
		}
	},
	/**
	 * Get the value of parameter in url
	 * 
	 * @param name:
	 *            The key of parameter in url
	 */
	getUrlVar : function(name) {
		var vars = [], hash;
		var hashes = window.location.href.slice(
				window.location.href.indexOf('?') + 1).split('&');
		for ( var i = 0; i < hashes.length; i++) {
			var tmp = hashes[i];
			var tmpIndex = tmp.indexOf("=");
			hash = [];
			hash[0] = tmp.substring(0, tmpIndex).replace(/^\s*|\s*$/g, "");
			hash[1] = tmp.substring(tmpIndex + 1, tmp.length).replace(
					/^\s*|\s*$/g, "");
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
		return vars[name];
	},

	setNavigationFlag : function(navigationSelectedFlag) {
		if (inMotion) {
			if ((messageInmotionPopup == null) && (alertInmotionPopup == null)) {
				navigationSelected = navigationSelectedFlag;
			}
		} else if (!inMotion) {
			if ((messagePopup == null) && (alertPopup == null)) {
				navigationSelected = navigationSelectedFlag;
			}
		}
	}
}
/**
 * Add the format method in Date
 */
Date.prototype.format = function(format) {
	var o = {
		"M+" : this.getMonth() + 1, // month
		"d+" : this.getDate(), // day
		"h+" : this.getHours(), // hour
		"m+" : this.getMinutes(), // minute
		"s+" : this.getSeconds(), // second
		"q+" : Math.floor((this.getMonth() + 3) / 3), // quarter
		"S" : this.getMilliseconds()
	// millisecond
	}

	if (/(y+)/.test(format)) {
		format = format.replace(RegExp.$1, (this.getFullYear() + "")
				.substr(4 - RegExp.$1.length));
	}

	for ( var k in o) {
		if (new RegExp("(" + k + ")").test(format)) {
			format = format.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k])
					: (("00" + o[k]).substr(("" + o[k]).length)));
		}
	}
	return format;
}
