var UPDATE_NOTIFY_TYPE = {
    MESSAGE: 0,
    ALERT: 1
}
var _notifyTimer = null;
var alertNotifyTimer = null;
var Home = can.Control({
    init: function(){
		funcAvailable = true;
        util.hideSetting();
        $("#temp_custom_popup").remove();
        $(".custom_popup").hide();
        this.element.html(can.view('common/views/home.ejs', {}));
        var boolGetMsg = this.options.boolGetMsg;
        var boolGetAlt = this.options.boolGetAlt;
        if (boolGetMsg) {
            messageList = MessageData.getMessage();
        }
        if (boolGetAlt) {
            alertList = AlertData.getAlert();
        }
        this.updateNotify();
        if (this.options.viewType != "alerts") {
            this['#startMessage click'](boolGetMsg);
        }
    },
    '#startMessage click': function(boolGetMsg){
        this.clearOtherActive();
        util.btnPressed("message_btn", function(){
            if (boolGetMsg != false) {
                $("#temp_right_side_content").remove();
                $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
                new Message('#temp_right_side_content', {
                    boolGetMsg: true
                });
            }
        });
    },
    '#startAlert click': function(){
        this.clearOtherActive();
        util.btnPressed("alert_btn", function(){
            $("#temp_right_side_content").remove();
            $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
            new Alert("#temp_right_side_content", {
                boolGetAlt: true
            });
        });
    },
    
    '#startReport click': function(){
        this.clearOtherActive();
        util.btnPressed("report_btn", function(){
            $("#temp_right_side_content").remove();
            $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
            new Report("#temp_right_side_content", {});
        });
    },
    '#startNavigation click': function(){
        this.clearOtherActive();
        util.btnPressed("navigation_btn", null);
        // TODO, nikm, for test
        Android.openNavigation(JSON.stringify({
            "geo": "47.604819,-122.33801"
        }));
    },
    clearOtherActive: function(){
        var btnArray = new Array("message_btn", "alert_btn", "report_btn", "navigation_btn");
        util.clearOtherBtnActive(btnArray);
    },
    "updateNotify": function(update_notify_type){
        MESSAGE_NOTIFY.high_count = 0;
        MESSAGE_NOTIFY.normal_count = 0;
        $.each(messageList, function(index, item){
            if (item.read == 0) {
                if (item.priority > 5) {
                    MESSAGE_NOTIFY.high_count += 1;
                }
                else {
                    MESSAGE_NOTIFY.normal_count += 1;
                }
            }
        });
        if (MESSAGE_NOTIFY.high_count > 0) {
            $("#message_notify").show();
            $("#message_notify").removeClass("left_side_btn_notify_bg").addClass("left_side_btn_notify_bg_active");
            $("#message_notify").html(MESSAGE_NOTIFY.high_count);
        }
        else 
            if (MESSAGE_NOTIFY.normal_count > 0) {
                $("#message_notify").show();
                $("#message_notify").removeClass("left_side_btn_notify_bg_active").addClass("left_side_btn_notify_bg");
                $("#message_notify").html(MESSAGE_NOTIFY.normal_count);
            }
            else 
                if (MESSAGE_NOTIFY.high_count == 0 &&
                MESSAGE_NOTIFY.normal_count == 0) {
                    $("#message_notify").hide();
                    $("#temp_notify").remove();
                    $(".notify").hide();
                    if (testFlag) {
                        Android.cancelSoundNotification();
                    }
                }
        ALERT_NOTIFY.alertCount = 0;
        $.each(alertList, function(index, item){
            if (item.read == 0) {
                ALERT_NOTIFY.alertCount += 1;
            }
        });
        if (ALERT_NOTIFY.alertCount > 0) {
            $("#alerts_notify").show();
            $("#alerts_notify").addClass("left_side_btn_notify_bg_active");
            $("#alerts_notify").html(ALERT_NOTIFY.alertCount);
        }
        else {
            $("#alerts_notify").hide();
            $("#alert_temp_notify").remove();
            $(".notify").hide();
            if (testFlag) {
                //Android.cancelSoundNotification();
            }
        }
    }
});

var InMotion = can.Control({
    init: function(){
        $(".in_motion").show();
        this.element.html(can.view('common/views/in_motion.ejs', {}));
        if (settingExits) {
            $("#settings").removeClass("setting_icon");
            $("#settings").unbind();
        }
    }
});

var DrivModule = can.Control({
    init: function(){
        $(".drive_mode").show();
        this.element.html(can.view('common/views/drive_mode.ejs', {}));
    }
});
