/*
 * HomeLoading is a loading page when the app start.
 */
var homeInstance;

var HomeLoading = can.Control({
    init: function(){
        console.log(this.element);
        this.element.html(can.view("login/views/homeLoading.ejs", {}));
    }
});

var HomeLogin = can.Control({
    init: function(){
        $("#settings").removeClass("setting_icon");
        $("#settings").unbind();
        settingExits = false;
        this.element.html(can.view('login/views/homeLogin.ejs', {}));
        this.beginLogin();
    },
    beginLogin: function(){
        $("#temp_right_side_content").remove();
        $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
        new Login('#temp_right_side_content', {});
    }
});
/*
 * This is a login page.
 */
var Login = can.Control({
    init: function(){
        this.element.html(can.view('login/views/loginList.ejs', {}));
    },
    '.login_pin_btn click': function(){
        util.btnPressed("login_pin_btn", function(){
            $("#temp_right_side_content").remove();
            $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
            new Pin('#temp_right_side_content', {});
        });
        
    },
    '.login_cancel_btn click': function(){
    	//Android.autoUpdate();
        util.btnPressed("login_cancel_btn", null);
    }
});
/*
 * Need to input the pin code for verifying. getPinCode function : get the input
 * pin code.
 */
var Pin = can.Control({
    init: function(){
        this.element.html(can.view('login/views/pinList.ejs', {}));
		$(".text_password").focus(function(){
			$(this).val('');
			$(this).attr("val", $(this).val());
			$(this).parent().removeClass("pot_cover");
		});
    },
    '.password_group input keyup': function(el, ev){
        this.keyListenner(el);
    },
    keyListenner: function(el){
        var _this = this;
        function keyUp(e){
            var currKey = 0, e = e || event;
            currKey = e.keyCode || e.which || e.charCode;
			util.showLog("-----------------key code----:" + currKey);
            if (currKey == 8) {
                el.parent().prev().children().focus();
            }
            else {
                var patrn = /[0-9]/;
                if (patrn.exec(el.val())) {
                    el.attr("val", el.val());
                    el.val('');
                    el.parent().addClass("pot_cover");
                    el.parent().next().children().focus();
                    if (el.attr("id") == "password6") {
                        el.blur();
                    }
                }
            }
        }
        document.onkeyup = keyUp;
    },
    getPinCode: function(){
        var t1 = $("#password1").attr("val");
        var t2 = $("#password2").attr("val");
        var t3 = $("#password3").attr("val");
        var t4 = $("#password4").attr("val");
        var t5 = $("#password5").attr("val");
        var t6 = $("#password6").attr("val");
        var pinCode = t1 + t2 + t3 + t4 + t5 + t6;
        return pinCode;
    },
    '.btn_cancel click': function(){
        util.btnPressed("btn_cancel", function(){
            $("#temp_right_side_content").remove();
            $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
            new Login('#temp_right_side_content', {});
        });
    },
    '.btn_submit click': function(){
        var pinCode = this.getPinCode();
        util.btnPressed("btn_submit", function(){
            $(".notify").show();
            $("#temp_notify").remove();
            $(".notify").append($("<div>").attr("id", "temp_notify"));
            new verifyPin('#temp_notify', {
                pincode: pinCode
            });
        });
    }
});
/*
 * Verify the pin code When return status is true,jump to eula page.Else comfirm
 * pin code.
 */
var verifyPin = can.Control({
    init: function(){
        this.element.html(can.view('login/views/verify_pin.ejs', {}));
        util.process("showVerifyIcon");
        this.verify(this.options.pincode);
    },
    verify: function(pinCode){
        var loginStatus = LoginData.verifyPin(pinCode);
        util.showLog("-----HMI----loginStatus:" + loginStatus.status);
        if (loginStatus.status) {
            // success get configure
            $("#temp_notify").remove();
            $(".notify").hide();
            $("#temp_right_side_content").remove();
            $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
            new Eula('#temp_right_side_content', {});
        }
        else {
            // fail
            $("#temp_notify").remove();
            $(".notify").append($("<div>").attr("id", "temp_notify"));
            new Notify('#temp_notify', {
                notify_type: "Error_PIN_CODE"
            });
        }
    }
});

var Eula = can.Control({
    init: function(){
        this.element.html(can.view('login/views/eulaList.ejs', {}));
    },
    '.button_language click': function(){
        util.btnPressed("button_language", function(){
            $("#temp_custom_popup").remove();
            $(".custom_popup").append($("<div>").attr("id", "temp_custom_popup"));
            new SetLanguage('#temp_custom_popup', {
                applyLanguage: true
            });
            $(".custom_popup").show();
        });
    },
    '.eula_cancel_btn click': function(){
        util.btnPressed("eula_cancel_btn", function(){
            $("#temp_right_side_content").remove();
            $(".right_side_content").append($("<div>").attr("id", "temp_right_side_content"));
            ;
            new Pin('#temp_right_side_content', {});
        });
    },
    '.eula_accept_btn click': function(){
        util.btnPressed("eula_accept_btn", function(){
            $("#temp_body_content").remove();
            $(".body_content").append($("<div>").attr("id", "temp_body_content"));
            
            // TODO, nikm, user must access EULA
            var acceptStatus = LoginData.acceptEula();
            if (acceptStatus.status) {
                if (configuration != null) 
                    configuration.is_eula_accepted = 1;
                homeInstance = new Home('#temp_body_content', {
                    boolGetMsg: true,
                    boolGetAlt: true,
					viewType: "messages"
                });
                util.bindSetting();
                //for test  NOTIFY_TYPE_TEXT_MESSAGE
//                messageList = MessageData.getMessage();
//            	setInterval(function(){util.notify("NOTIFY_TYPE_TEXT_MESSAGE",messageList);}, 37000);
//                alertList = AlertData.getAlert();
//            	setInterval(function(){util.notify("NOTIFY_TYPE_ALERT",alertList);},3000);
            }
        });
    }
});

$(document).ready(function(){
    util = new Util();
    setInterval(function(){
        util.setTime();
    }, 1000);
    if (util.getUrlVar("test")) {
        testFlag = false;
    }
    configuration = ConfigurationData.getConf();
    util.getSetting();
    $("#temp_body_content").remove();
    $(".body_content").append($("<div>").attr("id", "temp_body_content"));
    new HomeLoading('#temp_body_content', {});
    util.process("loading_icon");
    setTimeout(function(){
        $("#temp_body_content").remove();
        $(".body_content").append($("<div>").attr("id", "temp_body_content"));
        new HomeLogin('#temp_body_content', {})
    }, 3000);
});
