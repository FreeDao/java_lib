var messageList;
var MESSAGE_NOTIFY = {
    high_count: 0,
    normal_count: 0
};
var MESSAGES = [{
    "timestamp": 259272077,
    "to_type": 1,
    "to": "123456",
    "id": 20,
    "detail": "Test message 10",
    "priority": 6,
    "subject": "Just for test10",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272076,
    "to_type": 1,
    "to": "123456",
    "id": 19,
    "detail": "Test message 9",
    "priority": 6,
    "subject": "Just for test9",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272076,
    "to_type": 1,
    "to": "123456",
    "id": 18,
    "detail": "Test message 8",
    "priority": 1,
    "subject": "Just for test8",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272075,
    "to_type": 1,
    "to": "123456",
    "id": 17,
    "detail": "Test message 7",
    "priority": 1,
    "subject": "Just for test7",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272075,
    "to_type": 1,
    "to": "123456",
    "id": 16,
    "detail": "Test message 6",
    "priority": 1,
    "subject": "Just for test6",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272073,
    "to_type": 1,
    "to": "123456",
    "id": 15,
    "detail": "Test message 5",
    "priority": 1,
    "subject": "Just for test5",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272072,
    "to_type": 1,
    "to": "123456",
    "id": 14,
    "detail": "Test message 4",
    "priority": 1,
    "subject": "Just for test4",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272070,
    "to_type": 1,
    "to": "123456",
    "id": 13,
    "detail": "Test message 3",
    "priority": 1,
    "subject": "Just for test3",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272070,
    "to_type": 1,
    "to": "123456",
    "id": 12,
    "detail": "Test message 2",
    "priority": 1,
    "subject": "Just for test2",
    "read": 0,
    "from": "nikm"
}, {
    "timestamp": 259272070,
    "to_type": 1,
    "to": "123456",
    "id": 11,
    "detail": "Test message 1",
    "priority": 1,
    "subject": "Just for test1",
    "read": 0,
    "from": "nikm"
}];

var RESPONSE_STATUS = {
    "status": true
};

var MessageData = can.Model({
    test: function(){
    },
    getMessage: function(){
        var userId = ConfigurationData.getConf().user_id;
        var msgReq = {
            "user_id": userId
        };
        var msg;
        if (testFlag) {
            msg = Android.getMessages(JSON.stringify(msgReq));
            if (msg != "") {
                msg = JSON.parse(Android.getMessages(JSON.stringify(msgReq)));
                msg = msg.messages;
            }
            else {
                msg = JSON.parse("[]");
            }
        }
        else {
            msg = MESSAGES;
        }
        util.showLog("-----HMI----msg:" + JSON.stringify(msg));
        var messages = new can.Observe.List(msg);
        return messages;
    },
    updateMessage: function(item){
        var user_id = ConfigurationData.getConf().user_id;
        var setReadReq = {
            "user_id": user_id,
            "message_id": item.id
        };
        var setMsgReadStatus;
        if (testFlag) {
            setMsgReadStatus = JSON.parse(Android.setMessageStatus(JSON.stringify(setReadReq)));
            util.showLog("-----HMI----setMsgReadStatus:" +
            setMsgReadStatus.status);
        }
        else {
            setMsgReadStatus = RESPONSE_STATUS;
        }
        if (setMsgReadStatus.status) {
            item.read = 1;
            for(var i in MESSAGES){
            	if(MESSAGES[i].id == item.id){
            		MESSAGES[i].read = 1;
            	}
            }
        }
        else {
            util.showToast("Set message status unsuccessfully!!!");
        }
    },
    deleteMessage: function(item, index){
        var user_id = ConfigurationData.getConf().user_id;
        var delMsgReq = {
            "user_id": user_id,
            "message_id": item.id
        };
        var delStatus;
        if (testFlag) {
            delStatus = JSON.parse(Android.deleteMessage(JSON.stringify(delMsgReq)));
        }
        else {
            delStatus = RESPONSE_STATUS;
        }
        util.showLog("-----HMI----delStatus:" + delStatus.status);
        if (delStatus.status) {
            messageList.splice(index, 1);
        }
        else {
            util.showToast("Delete message unsuccessfully!!!");
        }
    },
    storeMessage: function(obj){
        messageList.unshift(obj);
        util.showLog("-----HMI---storeMessage-messageList:" +
        JSON.stringify(messageList));
    },
    sendMsg: function(message){
        var sendStatus;
        if (testFlag) {
            sendStatus = JSON.parse(Android.sendMessage(message));
        }
        else {
            sendStatus = RESPONSE_STATUS;
        }
        if (sendStatus.status) {
            // success
            util.showToast("Send message successfully");
        }
        else {
            // fail
            util.showToast("Send message unsuccessfully!!!");
        }
    }
}, {});
