var Report = can.Control({
    init: function(){
        this.element.html(can.view('apps/report/views/reportMain.ejs', {}));
        reportList = ReportData.getReport();
        $("#temp_report_container_content").remove();
        $(".report_container_content").append($("<div>").attr("id", "temp_report_container_content"));
        new ReportList('#temp_report_container_content', {
            data: reportList
        });
    }
});

var ReportList = can.Control({
    init: function(){
        this.element.html(can.view('apps/report/views/reportList.ejs', {
            data: this.options.data
        }));
    },
    '.report_item_category click': function(el, ev){
        var reportItem = this.options.data[el.parent().attr("index")];
        $("#temp_custom_popup").remove();
        $(".custom_popup").append($("<div>").attr("id", "temp_custom_popup"));
        new ReportDialog('#temp_custom_popup', {
            dialogType: "detail",
            reportItem: reportItem
        });
        $(".custom_popup").show();
    },
    _btnPressedTimer: null,
    '.report_item_view click': function(el, ev){
        var reportItem = this.options.data[el.parent().attr("index")];
        $(".report_item_view").removeClass("report_item_view_active");
        el.addClass("report_item_view_pressed");
        if (this._btnPressedTimer) {
            clearTimeout(this._btnPressedTimer);
        }
        this._btnPressedTimer = setTimeout(function(){
            el.removeClass("report_item_view_pressed");
            el.addClass("report_item_view_active");
            $("#temp_custom_popup").remove();
            $(".custom_popup").append($("<div>").attr("id", "temp_custom_popup"));
            new ReportDialog('#temp_custom_popup', {
                dialogType: "tip",
                reportItem: reportItem
            });
            $(".custom_popup").show();
            
            // $("#temp_body_content").remove();
            // $(".body_content").append($("<div>").attr("id",
            // "temp_body_content"));
            // new ShifReport('#temp_body_content', {});
        }, 100);
    }
});

var ReportDialog = can.Control({
    init: function(){
        this.element.html(can.view('apps/report/views/reportDialog.ejs', {
            dialogType: this.options.dialogType,
            item: this.options.reportItem
        }));
        if (this.options.dialogType == "detail") {
            $("#fleet").addClass("popup_content_header_span_active");
            this.loadBarChart("fleet", this.options.reportItem);
        }
        if (settingExits) {
            $("#settings").unbind();
        }
    },
    '.popup_close click': function(){
        util.btnPressed("popup_close", function(){
            $("#temp_custom_popup").remove();
            $(".custom_popup").hide();
        });
        if (settingExits) {
            util.bindSetting();
        }
    },
    _btnPressedTimer: null,
    '.popup_content_header span click': function(el, ev){
        var _this = this;
        var column = el.attr("value");
        var item = _this.options.reportItem;
        $(".popup_content_header_span").removeClass("popup_content_header_span_active");
        el.addClass("popup_content_header_span_pressed");
        if (_this._btnPressedTimer) {
            clearTimeout(_this._btnPressedTimer);
        }
        _this._btnPressedTimer = setTimeout(function(){
            el.removeClass("popup_content_header_span_pressed");
            el.addClass("popup_content_header_span_active");
            _this.loadBarChart(column, item)
        }, 100);
    },
    loadBarChart: function(column, item){
        console.log(column);
        var chartData = null;
        var average = null;
        var unit_name = item.unit_name;
        var y_max = item.max;
        item.detail.each(function(item, index){
            if (item.column.toLowerCase() == column.toLowerCase()) {
                chartData = item.last_5_scores;
                average = item.average;
            }
        });
        
        $("#temp_popup_chart_container").remove();
        $(".popup_chart_container").append($("<div>").attr("id", "temp_popup_chart_container"));
        new BarChart('#temp_popup_chart_container', {
            unit_name: unit_name,
            y_max: y_max,
            chartData: chartData,
            column: column,
            average: average
        });
    }
});

var BarChart = can.Control({
    init: function(){
        this.element.html(can.view('apps/report/views/barChart.ejs', {
            unit_name: this.options.unit_name,
            y_max: this.options.y_max,
            chartData: this.options.chartData,
            column: this.options.column,
            average: this.options.average
        }));
        this.setBarHeight(this.options.y_max, this.options.chartData, this.options.average);
    },
    setBarHeight: function(y_max, chartData, average){
        // var average = (chartData[0].score + chartData[1].score +
        // chartData[2].score + chartData[3].score +
        // chartData[4].score)/5;
        var maxHeight = parseInt($(".bar_charts").css("height").split("px")[0]);
        chartData.each(function(item, index){
            $(".bar_chart" + index).css({
                "height": item.score / y_max *
                maxHeight +
                "px",
                "background-color": item.score >= average ? "#008249" : "#d32d12"
            });
        });
        var averageHeight = average / y_max * maxHeight + "px";
        $(".bar_average").css({
            "height": averageHeight
        });
        var averageTextContentHeight = $(".average_text_content").css("height");
        if (parseInt(averageHeight.split("px")[0]) < parseInt(averageTextContentHeight.split("px")[0])) {
			$(".average_text_content").css({"top": "-" + averageTextContentHeight});
		}else{
			$(".average_text_content").css({"top": "0px"});
        }
    }
});

var ShifReport = can.Control({
    init: function(){
        this.element.html(can.view('apps/report/views/shiftReport.ejs', {}));
        $("#temp_shift_report_list_container").remove();
        $(".shift_report_list_container").append($("<div>").attr("id", "temp_shift_report_list_container"));
        new ReportList('#temp_shift_report_list_container', {
            data: reportList
        });
    },
    '.shift_power_down click': function(){
        util.btnPressed("shift_power_down", function(){
            // TODO
        });
    }
});
