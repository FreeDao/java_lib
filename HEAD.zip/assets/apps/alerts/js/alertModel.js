/**
 *
 */
var alertList;
var ALERT_NOTIFY = {
    alertCount: 0
};
var ALERTS = [{
    "timestamp": 1353386299000,
    "id": 10,
    "max_speed": 100,
    "distance_travelled": 2.5,
    "duration": 200,
    "shift_id": "AAABBBCCC",
    "driver_id": "NL 12345678901234",
    "longitude": -122,
    "odometer": 123456,
    "latitude": 47,
    "alert_type": "SPEEDING",
    "driver_id_type": 0,
	"read": 0
}, {
    "timestamp": 1353386299000,
    "id": 11,
    "max_speed": 100,
    "distance_travelled": 2.5,
    "duration": 200,
    "shift_id": "AAABBBCCC",
    "driver_id": "NL 12345678901234",
    "longitude": -122,
    "odometer": 123456,
    "latitude": 47,
    "alert_type": "IDLING",
    "driver_id_type": 0,
	"read": 0
}, {
    "timestamp": 1353386299000,
    "id": 12,
    "max_speed": 100,
    "distance_travelled": 2.5,
    "duration": 200,
    "shift_id": "AAABBBCCC",
    "driver_id": "NL 12345678901234",
    "longitude": -122,
    "odometer": 123456,
    "latitude": 47,
    "alert_type": "PTO",
    "driver_id_type": 0,
	"read": 0
}, {
    "timestamp": 1353386299000,
    "id": 13,
    "max_speed": 100,
    "distance_travelled": 2.5,
    "duration": 200,
    "shift_id": "AAABBBCCC",
    "driver_id": "NL 12345678901234",
    "longitude": -122,
    "odometer": 123456,
    "latitude": 47,
    "alert_type": "SPEEDING",
    "driver_id_type": 0,
	"read": 1
}, {
    "timestamp": 1353386299000,
    "id": 14,
    "max_speed": 100,
    "distance_travelled": 2.5,
    "duration": 200,
    "shift_id": "AAABBBCCC",
    "driver_id": "NL 12345678901234",
    "longitude": -122,
    "odometer": 123456,
    "latitude": 47,
    "alert_type": "DRIVER_HRS",
    "driver_id_type": 0,
	"read": 0
}];
var AlertData = can.Model({
    getAlert: function(){
        var userId = ConfigurationData.getConf().user_id;
        var altReq = {
            "user_id": userId
        };
        var alt;
        if (testFlag) {
            //**********but I find there is no method about alert part in java code***********
            alt = Android.getAlerts(JSON.stringify(altReq));
			util.showLog("-----"+ alt);
            if (alt != "") {
                alt = JSON.parse(Android.getAlerts(JSON.stringify(altReq)));
				alt = alt.alerts;
            }
            else {
                alt = JSON.parse("[]");//what is this???
            }
        }
        else {
            alt = ALERTS;
        }
        
        var alerts = new can.Observe.List(alt);
        return alerts;
    },
    updateAlert: function(item){
        var user_id = ConfigurationData.getConf().user_id;
        var setReadReq = {
            "user_id": user_id,
            "alert_id": item.id
        };
        var setAltReadStatus;
        if (testFlag) {
            //there is no such method in java code .
            setAltReadStatus = JSON.parse(Android.setAlertStatus(JSON.stringify(setReadReq)));
        }
        else {
            setAltReadStatus = RESPONSE_STATUS;
        }
		util.showLog("------------set alert status: " + setAltReadStatus.status);
        if (setAltReadStatus.status) {
            item.read = 1;
            for(var i in ALERTS){
            	if(ALERTS[i].id == item.id){
            		ALERTS[i].read = 1;
            	}
            }
        }
        else {
            util.showToast("Set alert status unsuccessfully");
        }
    },
    storeAlert: function(obj){
        alertList.unshift(obj);
        util.showLog("-----HMI---storeAlert-alertList:" +
        JSON.stringify(alertList));
    }
    
}, {});
