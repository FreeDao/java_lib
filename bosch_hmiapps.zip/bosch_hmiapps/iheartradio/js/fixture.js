$(document).ready(function($) {

	can.fixture.on = false;

	/*
	var cmd = {
		"command" : "createCustomStation",
		"params" : {
			"artistId" : "50a33959f0f0831e77898471",
			"playStation" : "false"
		}
	};
	*/

	var MAINMENU = {
		"errors" : null,
		"menu" : [ {
			"position" : "0",
			"menuText" : "My Stations",
			"actionCommand" : {
				"command" : "getMyStationsList"
			},
			"name" : "my_stations"
		}, {
			"position" : "1",
			"menuText" : "Stations Near You",
			"actionCommand" : {
				"command" : "getStationsNearby"
			},
			"name" : "stations_nearby"
		}, {
			"position" : "2",
			"menuText" : "Live Stations",
			"actionCommand" : {
				"command" : "liveStationsMenu"
			},
			"name" : "live_stations"
		}, {
			"position" : "3",
			"menuText" : "Featured Custom Stations",
			"actionCommand" : {
				"command" : "featuredStationsGenresMenu"
			},
			"name" : "featured_custom_stations"
		}, {
			"position" : "4",
			"menuText" : "iHeartRadio Originals",
			"actionCommand" : {
				"command" : "getFeaturedStations"
			},
			"name" : "iheart_original_stations"
		}, {
			"position" : "5",
			"menuText" : "Recently Played",
			"actionCommand" : {
				"command" : "getRecentStations"
			},
			"name" : "recently_played_stations"
		} ]
	};

	var LIVEMENU = {
		"errors" : null,
		"menu" : [ {
			"position" : "0",
			"menuText" : "Music & Entertainment",
			"actionCommand" : {
				"command" : "liveStationsMusicGenresMenu"
			},
			"name" : "music_and_entertainment"
		}, {
			"position" : "1",
			"menuText" : "Talk Radio",
			"actionCommand" : {
				"command" : "liveStationsTalkGenresMenu"
			},
			"name" : "talk_radio"
		}, {
			"position" : "2",
			"menuText" : "Stations By Location",
			"actionCommand" : {
				"command" : "liveStationsStatesMenu"
			},
			"name" : "stations_by_location"
		} ]
	};

	var LiveStationsMusicGenresMenu = {
		"musicGenres" : [ {
			"position" : "0",
			"menuText" : "80s & 90s Hits",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "18"
				}
			},
			"name" : "18"
		}, {
			"position" : "1",
			"menuText" : "Alternative",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "1"
				}
			},
			"name" : "1"
		}, {
			"position" : "2",
			"menuText" : "Artist-Hosted Stations",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "94"
				}
			},
			"name" : "94"
		}, {
			"position" : "3",
			"menuText" : "Christian & Gospel",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "2"
				}
			},
			"name" : "2"
		}, {
			"position" : "4",
			"menuText" : "Classic Rock",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "3"
				}
			},
			"name" : "3"
		}, {
			"position" : "5",
			"menuText" : "Classical",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "4"
				}
			},
			"name" : "4"
		}, {
			"position" : "6",
			"menuText" : "College Radio",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "98"
				}
			},
			"name" : "98"
		}, {
			"position" : "7",
			"menuText" : "Comedy",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "19"
				}
			},
			"name" : "19"
		}, {
			"position" : "8",
			"menuText" : "Country",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "5"
				}
			},
			"name" : "5"
		}, {
			"position" : "9",
			"menuText" : "Dance",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "77"
				}
			},
			"name" : "77"
		}, {
			"position" : "10",
			"menuText" : "Hip Hop and R&B",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "6"
				}
			},
			"name" : "6"
		}, {
			"position" : "11",
			"menuText" : "Holiday",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "97"
				}
			},
			"name" : "97"
		}, {
			"position" : "12",
			"menuText" : "Jazz",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "7"
				}
			},
			"name" : "7"
		}, {
			"position" : "13",
			"menuText" : "Mix & Variety",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "8"
				}
			},
			"name" : "8"
		}, {
			"position" : "14",
			"menuText" : "Oldies",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "10"
				}
			},
			"name" : "10"
		}, {
			"position" : "15",
			"menuText" : "Reggae & Island",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "11"
				}
			},
			"name" : "11"
		}, {
			"position" : "16",
			"menuText" : "Rock",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "12"
				}
			},
			"name" : "12"
		}, {
			"position" : "17",
			"menuText" : "Soft Rock",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "13"
				}
			},
			"name" : "13"
		}, {
			"position" : "18",
			"menuText" : "Spanish",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "14"
				}
			},
			"name" : "14"
		}, {
			"position" : "19",
			"menuText" : "Top 40 & Pop",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "16"
				}
			},
			"name" : "16"
		}, {
			"position" : "20",
			"menuText" : "World",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "17"
				}
			},
			"name" : "17"
		} ],
		"errors" : null
	};

	var LiveStationsTalkGenresMenu = {
		"talkGenres" : [ {
			"position" : "0",
			"menuText" : "News & Talk",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "9"
				}
			},
			"name" : "9"
		}, {
			"position" : "1",
			"menuText" : "Public Radio",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "93"
				}
			},
			"name" : "93"
		}, {
			"position" : "2",
			"menuText" : "Sports",
			"actionCommand" : {
				"command" : "getLiveStationsByGenre",
				"params" : {
					"genreId" : "15"
				}
			},
			"name" : "15"
		} ],
		"errors" : null
	};

	// state id = 48
	var LiveStationsCitiesMenu = {
		"cities" : [ {
			"position" : "0",
			"menuText" : "Charleston",
			"actionCommand" : {
				"command" : "getLiveStationsByCity",
				"params" : {
					"cityId" : "202"
				}
			},
			"name" : "202"
		}, {
			"position" : "1",
			"menuText" : "Columbia",
			"actionCommand" : {
				"command" : "getLiveStationsByCity",
				"params" : {
					"cityId" : "203"
				}
			},
			"name" : "203"
		}, {
			"position" : "2",
			"menuText" : "Florence",
			"actionCommand" : {
				"command" : "getLiveStationsByCity",
				"params" : {
					"cityId" : "503"
				}
			},
			"name" : "503"
		}, {
			"position" : "3",
			"menuText" : "Greenville",
			"actionCommand" : {
				"command" : "getLiveStationsByCity",
				"params" : {
					"cityId" : "204"
				}
			},
			"name" : "204"
		}, {
			"position" : "4",
			"menuText" : "Myrtle Beach",
			"actionCommand" : {
				"command" : "getLiveStationsByCity",
				"params" : {
					"cityId" : "509"
				}
			},
			"name" : "509"
		}, {
			"position" : "5",
			"menuText" : "Spartanburg",
			"actionCommand" : {
				"command" : "getLiveStationsByCity",
				"params" : {
					"cityId" : "433"
				}
			},
			"name" : "433"
		} ],
		"errors" : null
	};

	var FeaturedGenresMenu = {
		"genres" : [ {
			"position" : "0",
			"menuText" : "Pop",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "92"
				}
			},
			"name" : "987"
		}, {
			"position" : "1",
			"menuText" : "Rock",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "26"
				}
			},
			"name" : "962"
		}, {
			"position" : "2",
			"menuText" : "Rap",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "23"
				}
			},
			"name" : "985"
		}, {
			"position" : "3",
			"menuText" : "R&B",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "30"
				}
			},
			"name" : "984"
		}, {
			"position" : "4",
			"menuText" : "Country",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "40"
				}
			},
			"name" : "970"
		}, {
			"position" : "5",
			"menuText" : "Latin",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "38"
				}
			},
			"name" : "980"
		}, {
			"position" : "6",
			"menuText" : "Blues",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "36"
				}
			},
			"name" : "964"
		}, {
			"position" : "7",
			"menuText" : "Electronic",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "65"
				}
			},
			"name" : "972"
		}, {
			"position" : "8",
			"menuText" : "Jazz",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "68"
				}
			},
			"name" : "979"
		}, {
			"position" : "9",
			"menuText" : "Holiday",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "61"
				}
			},
			"name" : "978"
		}, {
			"position" : "10",
			"menuText" : "World",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "59"
				}
			},
			"name" : "994"
		}, {
			"position" : "11",
			"menuText" : "Christian",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "56"
				}
			},
			"name" : "977"
		}, {
			"position" : "12",
			"menuText" : "Soundtrack",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "52"
				}
			},
			"name" : "989"
		}, {
			"position" : "13",
			"menuText" : "Easy Listening",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "49"
				}
			},
			"name" : "971"
		}, {
			"position" : "14",
			"menuText" : "Vocal",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "46"
				}
			},
			"name" : "992"
		}, {
			"position" : "15",
			"menuText" : "Reggae",
			"actionCommand" : {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : "44"
				}
			},
			"name" : "986"
		} ],
		"errors" : null
	};

	var DiscoveryMenu = {
		"errors" : null,
		"menu" : [ {
			"position" : "0",
			"menuText" : "Familiar",
			"actionCommand" : {
				"command" : "setVarietyLevel",
				"params" : {
					"level" : "1"
				}
			},
			"name" : "familiar"
		}, {
			"position" : "1",
			"menuText" : "Mixed",
			"actionCommand" : {
				"command" : "setVarietyLevel",
				"params" : {
					"level" : "2"
				}
			},
			"name" : "mixed"
		}, {
			"position" : "2",
			"menuText" : "Less Familiar",
			"actionCommand" : {
				"command" : "setVarietyLevel",
				"params" : {
					"level" : "3"
				}
			},
			"name" : "less_familiar"
		} ]
	};

	can.fixture('POST /mainmenu', function(original, respondWith) {
		return MAINMENU;
	});

	can.fixture('POST /live_stations', function(original, respondWith) {
		return LIVEMENU;
	});

	can.fixture('POST /talk_radio', function(original, respondWith) {
		return LiveStationsTalkGenresMenu;
	});

	can.fixture('POST /live_stations_by_genre', "iheartradio/js/lsbygenre.json");

	can.fixture('POST /music_and_entertainment', function(original, respondWith) {
		return LiveStationsMusicGenresMenu;
	});

	can.fixture('POST /stations_by_location', "iheartradio/js/states.json");

	can.fixture('POST /cities_menu', function(original, respondWith) {
		return LiveStationsCitiesMenu;
	});

	can.fixture('POST /live_stations_by_city', "iheartradio/js/lsbycity.json");

	can.fixture('POST /featured_custom_stations', function(original, respondWith) {
		return FeaturedGenresMenu;
	});

	can.fixture('POST /my_stations', "iheartradio/js/mystations.json");

	can.fixture('POST /iheart_original_stations', "iheartradio/js/featuredstations.json");

	can.fixture('POST /stations_nearby', "iheartradio/js/stationsnearby.json");

	can.fixture('POST /recently_played_stations', "iheartradio/js/recentstations.json");

	can.fixture('POST /featured_artists', "iheartradio/js/featuredartists.json");

	can.fixture('POST /songs', "iheartradio/js/songs.json");

	can.fixture('POST /discoverymenu', function(original, respondWith) {
		return DiscoveryMenu;
	});

	can.fixture('POST /playercommand', function(original, respondWith) {
		return {
			status : '200 ok'
		};
	});

	can.fixture('POST /pausecommand', function(original, respondWith) {
		return {
			status : '200 ok'
		};
	});

	can.fixture('POST /scancommand', function(original, respondWith) {
		return {
			status : '200 ok'
		};
	});

	can.fixture('POST /thumbsUpCustom', function(original, respondWith) {
		return {
			status : '200 ok'
		};
	});

	can.fixture('POST /thumbsDownCustom', function(original, respondWith) {
		return {
			status : '200 ok'
		};
	});

	can.fixture('POST /deleteStation', function(original, respondWith) {
		return {
			status : '200 ok'
		};
	});

	can.fixture('POST /createCustomStation', function(original, respondWith) {
		return {
			status : '200 ok'
		};
	});

	can.fixture('POST /skipSongcommand', function(original, respondWith) {
		var songId = (10001 + Math.round(Math.random() * 10)) + "";
		return {
			// dont know what's the return value type from the
			// HAP maybe is a songId
			songid : songId
		};
	});

	can.fixture('POST /setVarietyLevel', function(original, respondWith) {
		return {
			varietyLevel : "VarietyLevel"
		};
	});
});
