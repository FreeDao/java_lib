var IHR = {};
IHR.Models = {};

$(function() {
	
	IHR.Models.ROOT_URL = "http://10.20.71.132";

	IHR.Models.API = can.Model({
		/* @Static */
		defaults : {
			//HapCommandControlURL : "%CHOREO_SERVER_URL_BASE%:8080/hap/api/1.0/commandControl/com.clearchannel.iheartradio",
			HapCommandControlURL : "/commandControl/com.clearchannel.iheartradio",
			HapGetEventIDURL : "%CHOREO_SERVER_URL_BASE%:8090/hap/api/1.0/getEventId",
			HapGetEventURL : "%CHOREO_SERVER_URL_BASE%:8090/hap/api/1.0/getEvent"
		},

		sendHttpRequest : function(args) {
			$.ajax({
				url : args.url,
				data : JSON.stringify(args.data),
				type : args.type,
				timeout : 20000,
				dataType : args.dataType,
				success : args.success,
				error : args.error
			});
		},

		getMainMenu : function(opts) {
			console.warn('Getting main menu...');
			var command = {
				"command" : "mainMenu"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/mainmenu";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		actionCommandRequest : function(opts) {
			console.warn('Come into action command request!');
			var command = opts.actionCommand;
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/" + opts.name;
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		getImagesRequest : function(opts) {
			console.warn('Come into image command request!');
			var command = {
					"command" : "getImage",
					"params" : opts.params
				};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/image";
			}
			
			var xhr = new XMLHttpRequest();
			xhr.open('POST', url, true);
			xhr.responseType = 'arraybuffer';
			xhr.onload = function(e) {
				//console.log(this.response);
				var uInt8Array = new Uint8Array(this.response);
				var res = Utils.binaryToBase64(uInt8Array);
				if(this.status == 200) {
					(opts.success)('data:image/png;base64,' + res);
				}
			};
			xhr.onerror = function() {
				opts.error;
			};
			xhr.send(JSON.stringify(command));
			
		},

		/* Play Commands */
		playRequestCommand : function(opts) {
			console.warn("come into play command");
			var command = {
				"command" : "play"
			};
			if (opts.params) {
				command = $.extend({}, command, {
					"command" : "play",
					"params" : opts.params
				});
			}
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/playercommand";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Pause Commands */
		pauseRequestCommand : function(opts) {
			var command = {
				"command" : "pause"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/pausecommand";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Skip Commands */
		skipRequestCommand : function(opts) {
			var command = {
				"command" : "skipSong"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/skipSongcommand";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});

		},
		
		/* Scan Live Stations Commands */
		scanRequestCommand : function(opts) {
			var command = {
				"command" : "scanLiveStation"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/scancommand";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Save Live Stations Commands */
		saveStationRequestCommand : function(opts) {
			var command = {
				"command" : "saveLiveStation",
				"params" : opts.params
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/savecommand";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		/* Thumb Up Current Playing Song Commands */
		thumbsUpRequestCommand : function(opts) {
			var command = {
				"command" : "thumbsUpSong"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/thumbsUpCustom";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});

		},
		
		/* Thumb Down Current Playing Song Commands */
		thumbsDownRequestCommand : function(opts) {
			var command = {
				"command" : "thumbsDownSong"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/thumbsDownCustom";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Get Asynchronous Event ID */
		getAsyncEventID : function(opts) {
			var url = IHR.Models.API.defaults.HapGetEventIDURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			this.sendHttpRequest({
				url : url,
				data : null,
				dataType : 'json',
				type : 'GET',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Get Asynchronous Event Message */
		getAsyncEventMessage : function(opts) {
			var url = IHR.Models.API.defaults.HapGetEventURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			this.sendHttpRequest({
				url : url,
				data : opts.content,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		/* Delete Station Command */
		delateStationRequestCommand : function(opts) {
			var command = {
				"command" : "deleteStation",
				"params" : opts.params
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/deleteStation";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Get Cities By State Command */
		getCitiesByStateCommand : function(opts) {
			var command = {
				"command" : "getCitiesByState",
				"params" : opts.params
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/getCitiesByState";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		/* Get liveStations By City Command */
		getLiveStationsByCityCommand : function(opts) {
			var command = {
				"command" : "getLiveStationsByCity",
				"params" : opts.params
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/getLiveStationsByCity";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		/* Get LiveStations By Genre Command */
		getLiveStationsByGenreCommand : function(opts) {
			var command = {
				"command" : "getLiveStationsByGenre",
				"params" : opts.params
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/getLiveStationsByGenre";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Get My Stations */
		getMyStationsList : function(opts) {
			var command = {
				"command" : "getMyStationsList"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/my_stations";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		/* Create a Custom Station */
		createCustomStation : function(opts) {
			// params : opts.params
			var command = {
				"command" : "createCustomStation",
				"params" : opts.params
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/createCustomStation";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},

		/* Get Discovery Menu */
		getDiscoveryMenu : function(opts) {
			var command = {
				"command" : "discoveryMenu"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/discoverymenu";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/* Set Variety Level */
		setVarietyLeve : function(opts) {
			var command = {
				"command" : "setVarietyLevel",
				"params" : {
					"level" : opts.level
				}
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			if (can.fixture.on) {
				url = "/setvarietyleve";
			}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		
		/*
		 * get current state of the player return track object
		 * or stationId
		 */
		getPlayerState : function(opts) {
			var command = {
				"command" : "getPlayerState"
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			
			//if (can.fixture.on) {
				//url = "/my_stations";
			//}
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		},
		/*get current state of the player return track object or stationId*/
		getFeaturedArtistsByGenre : function(opts){
			var command = {
				"command" : "getFeaturedArtistsByGenre",
				"params" : {
					"artistCategoryId" : opts.params.artistCategoryId
				}
			};
			var url = IHR.Models.API.defaults.HapCommandControlURL;
			url = url.replace("%CHOREO_SERVER_URL_BASE%", IHR.Models.ROOT_URL);
			this.sendHttpRequest({
				url : url,
				data : command,
				dataType : 'json',
				type : 'POST',
				success : opts.success,
				error : opts.error
			});
		}
	}, {
		_handlers : [],
		_socket : null,
		registerFunction : function(commandId, fun) {
			this._handlers[commandId] = fun;
		},
		/* Socket connection with hup service */
		_connect : function() {
			console.warn("come into IHR _connect()");
			var that = this;
			if (!that._socket) {
				that._socket = io.connect("/CommandControl").send("com.clearchannel.iheartradio");
				that._socket.on('AsyncEvent', function(data) {
					console.warn("AsyncEvent - _socket.on Returned");
					// TODO
					console.log(String.fromCharCode.apply(this, data));
					console.log(data);
					console.warn("END AsyncEvent");
				});
			}
		},
	});

	IHR.Models.RESP = can.Model({
		/* @Static */
		_mainMenu : null,
		
		setMainMenu : function(data) {
			this._mainMenu = data;
		},
		
		getMainMenu : function() {
			return this._mainMenu;
		},
		
		_myStationList : null,
		
		setMyStationList : function(data) {
			this._myStationList = data;
		},
		
		getMyStationList : function() {
			return this._myStationList;
		},
		
		_stationsNearby : null,
		
		setStationsNearby : function(data) {
			this._stationsNearby = data;
		},
		
		getStationsNearby : function() {
			return this._stationsNearby;
		},
		
		_liveStationMenu : null,
		
		setLiveStationMenu : function(data) {
			this._liveStationMenu = data;
		},
		
		getLiveStationMenu : function() {
			return this._liveStationMenu;
		},
		
		_featuredStationsGenresMenu : null,
		
		setFeaturedStationsGenresMenu : function(data) {
			this._featuredStationsGenresMenu = data;
		},
		
		getFeaturedStationsGenresMenu : function() {
			return this._featuredStationsGenresMenu;
		},
		
		_featuredStations : null,
		
		setFeaturedStations : function(data) {
			this._featuredStations = data;
		},
		
		getFeaturedStations : function() {
			return this._featuredStations;
		},
		
		_recentStations : null,
		
		setRecentStations : function(data) {
			this._recentStations = data;
		},
		
		getRecentStations : function() {
			return this._recentStations;
		},
		
		_featuredArtists : null,
		
		setFeaturedArtists : function(data) {
			this._featuredArtists = data;
		},
		
		getFeaturedArtists : function() {
			return this._featuredArtists;
		},
		
		_liveStationsTalkGenresMenu : null,
		
		setLiveStationsTalkGenresMenu : function(data) {
			this._liveStationsTalkGenresMenu = data;
		},
		
		getLiveStationsTalkGenresMenu : function() {
			return this._liveStationsTalkGenresMenu;
		},
		
		_liveStationsByGenre : null,
		
		setLiveStationsByGenre : function(data) {
			this._liveStationsByGenre = data;
		},
		
		getLiveStationsByGenre : function() {
			return this._liveStationsByGenre;
		},
		
		_liveStationsMusicGenresMenu : null,
		
		setLiveStationsMusicGenresMenu : function(data) {
			this._liveStationsMusicGenresMenu = data;
		},
		
		getLiveStationsMusicGenresMenu : function() {
			return this._liveStationsMusicGenresMenu;
		},
		
		_states : null,
		
		setStates : function(data) {
			this._states = data;
		},
		
		getStates : function() {
			return this._states;
		},
		
		_cities : null,
		
		setCity : function(data) {
			this._cities = data;
		},
		
		getCity : function() {
			return this._cities;
		},
		
		_liveStationsByCity : null,
		
		setLiveStationsByCity : function(data) {
			this._liveStationsByCity = data;
		},
		
		getLiveStationsByCity : function() {
			return this._liveStationsByCity;
		},
		
		_discoveryMenu : null,
		
		setDiscoveryMenu : function(data) {
			this._discoveryMenu = data;
		},
		
		getDiscoveryMenu : function() {
			return this._discoveryMenu;
		}
	}, {});

});
