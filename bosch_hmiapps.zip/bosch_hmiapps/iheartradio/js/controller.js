/*****************************************************************************
 *
 *                      AIRBIQUITY PROPRIETARY INFORMATION
 *
 *          The information contained herein is proprietary to Airbiquity
 *           and shall not be reproduced or disclosed in whole or in part
 *                    or used for any design or manufacture
 *              without direct written authorization from Airbiquity.
 *
 *            Copyright (c) 2012 by Airbiquity.  All rights reserved.
 *
 *****************************************************************************/
/*
 * TODO List:
 * 1.IHR.LongPolling - just wrote a code structure, didnt debug with ihr
 * 2.I should consider how to handle the public params while getting asynchronous message from ihr
 * 3.format code style - Header/done!, MainHome/done!, LiveStations done!, LivePlayer done!
 * */

var root = this;

$(function() {
	var isPlaying = false;
	var nowPlayingStation = {};
	var nowSelectStation = {};
	var nowSelectDeleteStation = {};
	var currentControl = null;
	var nowPlayingSong = {
		songTitle : "no song is playing",
		artistName : "no artist"
	};
	var nowPlayingSongOb = new can.Observe({
		songTitle : "song title",
		artistName : "artist name"
	});
	var nowSelectCity = null;
	var nowPlayingSonglike = null;
	var setCreateButton = false;
	var setScanButton = null;
	/* Controller - Header */
	IHR.Header = can.Control({
		defaults : {}
	}, {
		_header : null,
		init : function() {
			var that = this;
			if (!that._header) {
				that._header = new can.Observe({
					title : "I Heart Radio",
					icon : "RESERVED for icon url or anything else"
				});
			}
			$("#header").html(can.view("iheartradio/views/header-views/common.ejs", {
				data : that._header
			}));
		},
		updateTitle : function(title) {
			this._header.attr("title", title);
		},
		"#header-title click" : function() {
			this.updateTitle("I Heart Radio");
			mainHome.showPage();
		},
	});

	/* Controller - Main Home */
	IHR.MainHome = can.Control({
		/** @Static * */
		defaults : {}
	}, {
		init : function() {
			this.showPage();
			ihr._connect();
		},

		showPage : function() {
			if (IHR.Models.RESP.getMainMenu() != null && IHR.Models.RESP.getMainMenu() != undefined) {
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/main_home.ejs', {
					"data" : IHR.Models.RESP.getMainMenu().menu
				}));
			} else {
				var success = function(data) {
					console.log("Get main menu request successed : " + JSON.stringify(data));
					IHR.Models.RESP.setMainMenu(data);
					$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/main_home.ejs', {
						"data" : IHR.Models.RESP.getMainMenu().menu
					}));
				};
				var error = function(jqXHR) {
					console.log("Get main menu request caught error : " + JSON.stringify(jqXHR));
				};
				IHR.Models.API.getMainMenu({
					success : success,
					error : error
				});
			}
		},

		/* My stations */
		"#my_stations click" : function(el) {
			// menu button's id
			var menuName = el.attr("id");
			// action command from ihr response
			var actionCommand = getActionCommand(IHR.Models.RESP.getMainMenu().menu, menuName);
			if (!actionCommand)
				return;
			var success = function(data) {
				// store my stations list
				IHR.Models.RESP.setMyStationList(data);
				header.updateTitle("My Stations");
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.MyStations("#pagecontent", {
					myStationsList : data
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : menuName,
				callback : success
			});
		},

		/* Stations Near You */
		"#stations_nearby click" : function(el) {
			// menu button's id
			var menuName = el.attr("id");
			// action command from ihr response
			var actionCommand = getActionCommand(IHR.Models.RESP.getMainMenu().menu, menuName);
			if (!actionCommand)
				return;
			var success = function(data) {
				IHR.Models.RESP.setStationsNearby(data);
				// store nearby stations list
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.Nearby("#pagecontent", {
					stationsNearby : data
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : menuName,
				callback : success
			});
		},

		/* Live Stations */
		"#live_stations click" : function(el) {
			// menu button's id
			var menuName = el.attr("id");
			// action command from ihr response
			var actionCommand = getActionCommand(IHR.Models.RESP.getMainMenu().menu, menuName);
			if (!actionCommand)
				return;
			var success = function(data) {
				IHR.Models.RESP.setLiveStationMenu(data);
				// store live station sub menu
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.LiveStations("#pagecontent", {
					liveStationMenu : data
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : menuName,
				callback : success
			});
		},

		/* Featured Stations */
		"#featured_custom_stations click" : function(el) {
			// menu button's id
			var menuName = el.attr("id");
			// action command from ihr response
			var actionCommand = getActionCommand(IHR.Models.RESP.getMainMenu().menu, menuName);			
			if (!actionCommand)
				return;
			var success = function(data) {
				IHR.Models.RESP.setFeaturedStationsGenresMenu(data);
				// store featured stations genres menu
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.FeaturedStations("#pagecontent", {
					genres : IHR.Models.RESP.getFeaturedStationsGenresMenu()
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : menuName,
				callback : success
			});
		},

		/* I Heart Originals */
		"#iheart_original_stations click" : function(el) {
			// menu button's id
			var menuName = el.attr("id");
			// action command from ihr response
			var actionCommand = getActionCommand(IHR.Models.RESP.getMainMenu().menu, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setFeaturedStations(data);
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.iHROriginals("#pagecontent", {
					station : IHR.Models.RESP.getFeaturedStations()
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : menuName,
				callback : success
			});
		},

		/* Recently Played */
		"#recently_played_stations click" : function(el) {
			// menu button's id
			var menuName = el.attr("id");
			// action command from ihr response
			var actionCommand = getActionCommand(IHR.Models.RESP.getMainMenu().menu, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setRecentStations(data.recentStations);
				console.log(JSON.stringify(data.recentStations));
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.RecentlyPlayed("#pagecontent", {
					station : IHR.Models.RESP.getRecentStations()
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : menuName,
				callback : success
			});
		}
	});

	/* Controller - My Stations */
	IHR.MyStations = can.Control({
		/** @Static */
		defaults : {
			myStationsMenu : ["By Last Played", "By Name", "Delete Stations"],
			myStationsList : {},
			byNameStationList : {},
			stationId : null,
			stationType : null,
		},
		deleteStation : null
	}, {

		init : function(element, options) {
			IHR.MyStations.defaults.myStationsList = options.myStationsList;
			IHR.MyStations.defaults.byNameStationList = sortByName(options.myStationsList.stations);
			console.log(JSON.stringify(IHR.MyStations.defaults.byNameStationList));
			header.updateTitle("My Stations");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/mystations-menu.ejs', {
				"data" : IHR.MyStations.defaults.myStationsMenu
			}));
		},

		/* Sort by last play time*/
		".by_last_played click" : function() {//TODO doesn't sort now
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/my-station-list.ejs', {
				"data" : IHR.MyStations.defaults.myStationsList.stations
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		/*sort by station name*/
		".by_name .list-text click" : function() {
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/my-station-list.ejs', {
				"data" : IHR.MyStations.defaults.byNameStationList
			}));

			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		".my-station-list aqli click" : function(el) {
			var stationId = el.find(".list-text").parent().attr("id");
			if (currentControl) {
				try {
					currentControl.destroy();
				} catch(e) {
					currentControl = null;
				}
			}

			nowSelectStation = getStationByID(IHR.MyStations.defaults.myStationsList.stations, stationId);

			var success = function(data) {
				if (nowSelectStation.type == "live") {
					currentControl = new IHR.LivePlayer("#pagecontent", {
						station : nowSelectStation
					});
				} else {
					currentControl = new IHR.CustomPlayer("#pagecontent", {
						station : nowSelectStation
					});
				}
				isPlaying = true;
				displayPlayorPause();
			};

			var error = function(jqXHR) {
				console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
			};
			IHR.Models.API.playRequestCommand({
				params : {
					"stationId" : stationId,
					"stationType" : nowSelectStation.type
				},
				success : success,
				error : error
			});

		},

		".delete_stations click" : function() {
			header.updateTitle("Delete Stations");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/delete-station-list.ejs', {
				"data" : IHR.MyStations.defaults.byNameStationList
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		/* delete stations list*/
		".delete-station-list aqli click" : function(el) {
			IHR.MyStations.defaults.stationId = el.find(".list-text").parent().attr("id");
			IHR.MyStations.deleteStation = el;
			nowSelectDeleteStation = getStationByID(IHR.MyStations.defaults.myStationsList.stations, IHR.MyStations.defaults.stationId);
			IHR.MyStations.defaults.stationType = nowSelectDeleteStation.type;
			var text = "Do you want to delete " + nowSelectDeleteStation.name + "?";
			new IHR.Overlay("#pagecontent", {
				text : text
			});

		},

		".button-container #yesButton click" : function() {
			var success = function(data) {
				console.log("Delete my station successful!");
				// remove the overlay
				$('#overlay-container').slideUp(500, function() {
					$(this).remove();
				});
				// hide the station
				IHR.MyStations.deleteStation.hide("slow");

			};

			var error = function(jqXHR) {
				console.log("delete station Command request caught error : " + JSON.stringify(jqXHR));
			};

			IHR.Models.API.delateStationRequestCommand({
				params : {
					stationId : IHR.MyStations.defaults.stationId,
					stationType : IHR.MyStations.defaults.stationType
				},
				success : success,
				error : error
			});
		},

		".button-container #noButton click" : function() {
			$('#overlay-container').slideUp(500, function() {
				$(this).remove();
			});
		}
	});

	/* Controller - Nearby Stations */
	IHR.Nearby = can.Control({
		/** @Static */
		defaults : {
			nearby : {}
		}
	}, {
		init : function(element, options) {
			IHR.Nearby.defaults.nearby = options.stationsNearby;
			header.updateTitle("Nearby");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/nearby-station-list.ejs', {
				"data" : IHR.Nearby.defaults.nearby.nearbyStations
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
			$(".list-text-break div").each(function(){
				$(this).mouseover(function(){
					if ($(this).width() > $(this).parent().width()) {
						$(this).parent().addClass('marquee');
					}
				}).mouseout(function(){
					$(this).parent().removeClass('marquee');
				});
			});
		},

		".nearby-station-list aqli click" : function(el) {
			var stationId = el.find(".list-text").parent().attr("id");
			if (currentControl)
				currentControl.destroy();

			nowSelectStation = getStationByID(IHR.Nearby.defaults.nearby.nearbyStations, stationId);

			var success = function() {
				currentControl = new IHR.LivePlayer("#pagecontent", {
					station : nowSelectStation
				});
				isPlaying = true;
				displayPlayorPause();
			};

			var error = function(jqXHR) {
				console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
			};
			IHR.Models.API.playRequestCommand({
				params : {
					"stationId" : stationId,
					"stationType" : nowSelectStation.type
				},
				success : success,
				error : error
			});
		}
	});

	/* Controller - Live Stations */
	IHR.LiveStations = can.Control({
		/** @Static */
		defaults : {
			liveStationMenu : ["Station By Location", "Talk Radio", "Music and Entertainment"]
		}
	}, {
		init : function(element, options) {
			header.updateTitle("Live Stations");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-stations-menu.ejs', {
				"data" : this.options.liveStationMenu.menu
			}));
		},

		/* Live Stations - Talk Radio */
		"#talk_radio click" : function(el) {
			var menuName = el.attr("id");
			var actionCommand = getActionCommand(this.options.liveStationMenu.menu, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setLiveStationsTalkGenresMenu(data);
				header.updateTitle("Talk Radio");
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/livestations-talk-menu.ejs', {
					"data" : IHR.Models.RESP.getLiveStationsTalkGenresMenu().talkGenres
				}));
			};

			if (IHR.Models.RESP.getLiveStationsTalkGenresMenu() == null || IHR.Models.RESP.getLiveStationsTalkGenresMenu() == undefined) {
				getSubMenu({
					actionCommand : actionCommand,
					menuName : menuName,
					callback : success
				});
			} else {
				header.updateTitle("Talk Radio");
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/livestations-talk-menu.ejs', {
					"data" : IHR.Models.RESP.getLiveStationsTalkGenresMenu().talkGenres
				}));
			}
		},

		/* Live Stations Talk - Stations List */
		".livestations-talk-menu .list-text click" : function(el) {
			var menuName = el.parent().attr("id");
			var actionCommand = getActionCommand(IHR.Models.RESP.getLiveStationsTalkGenresMenu().talkGenres, menuName);
		
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setLiveStationsByGenre(data);
				header.updateTitle(el.text());
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-list.ejs', {
					"view" : "live-stations-by-genre",
					"data" : IHR.Models.RESP.getLiveStationsByGenre().stations
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			
			var error = function(jqXHR) {
				console.log("Get Live Station By Genre caught error : " + JSON.stringify(jqXHR));
			};
			
			getSubMenu({
					actionCommand : actionCommand,
					menuName : 'live_stations_by_genre',
					callback : success
				});
		},

		/* Live Stations Genres */
		"#music_and_entertainment click" : function(el) {
			var menuName = el.attr("id");
			var actionCommand = getActionCommand(this.options.liveStationMenu.menu, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setLiveStationsMusicGenresMenu(data);
				header.updateTitle("Music and Entertainment");
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-list-genres', {
					"data" : IHR.Models.RESP.getLiveStationsMusicGenresMenu().musicGenres
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};

			if (IHR.Models.RESP.getLiveStationsMusicGenresMenu() == null || IHR.Models.RESP.getLiveStationsMusicGenresMenu() == undefined) {
				getSubMenu({
					actionCommand : actionCommand,
					menuName : menuName,
					callback : success
				});
			} else {
				header.updateTitle("Music and Entertainment");
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-list-genres', {
					"data" : IHR.Models.RESP.getLiveStationsMusicGenresMenu().musicGenres
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			}
		},

		".live-station-list-genres .list-text click" : function(el) {
			var menuName = el.parent().attr("id");
			var actionCommand = getActionCommand(IHR.Models.RESP.getLiveStationsMusicGenresMenu().musicGenres, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setLiveStationsByGenre(data);
				if (nowSelectCity != null) {
					nowSelectCity = null;
				}
				header.updateTitle(el.text());
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-list.ejs', {
					"view" : "live-stations-by-genre",
					"data" : IHR.Models.RESP.getLiveStationsByGenre().stations
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			
			getSubMenu({
				actionCommand : actionCommand,
				menuName : 'live_stations_by_genre',
				callback : success
			});

		},

		"#live-stations-by-genre .list-text click" : function(el) {
			var stationId = el.parent().attr("id");
			var station = getStationByID(IHR.Models.RESP.getLiveStationsByGenre().stations, stationId);
			this.initLivePlayer(stationId, station);
		},

		initLivePlayer : function(stationId, station) {
			nowSelectStation = station;

			var success = function(data) {
				console.log("Get playCommand request successfully!");
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}

				currentControl = new IHR.LivePlayer("#pagecontent", {
					station : station
				});

				// TODO Add the city name
				if (nowSelectCity != null) {
					header.updateTitle(station.name + " - " + nowSelectCity);
				}
				isPlaying = true;
				displayPlayorPause();
			};

			var error = function(jqXHR) {
				console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
			};

			IHR.Models.API.playRequestCommand({
				params : {
					"stationId" : stationId,
					"stationType" : nowSelectStation.type
				},
				success : success,
				error : error
			});
		},

		"#live-stations-by-city .list-text click" : function(el) {
			var stationId = el.parent().attr("id");
			var station = getStationByID(IHR.Models.RESP.getLiveStationsByCity().stations, stationId);
			this.initLivePlayer(stationId, station);
		},

		/* Live Stations - Stations by Location */
		"#stations_by_location click" : function(el) {
			var menuName = el.attr("id");
			var actionCommand = getActionCommand(this.options.liveStationMenu.menu, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setStates(data);
				header.updateTitle("Stations By Location");
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-list-states.ejs', {
					"data" : IHR.Models.RESP.getStates().states
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : menuName,
				callback : success
			});
		},

		/* Live Stations States */
		".live-station-list-states .list-text click" : function(el) {
			var menuName = el.parent().attr("id");
			var actionCommand = getActionCommand(IHR.Models.RESP.getStates().states, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setCity(data);
				header.updateTitle(el.text());
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-list-cities.ejs', {
					"data" : IHR.Models.RESP.getCity().cities
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : 'cities_menu',
				callback : success
			});
		},

		/* Live Stations Cities */
		".live-station-list-cities .list-text click" : function(el) {
			var menuName = el.parent().attr("id");
			nowSelectCity = el.text();
			var actionCommand = getActionCommand(IHR.Models.RESP.getCity().cities, menuName);
			if (!actionCommand)
				return;

			var success = function(data) {
				IHR.Models.RESP.setLiveStationsByCity(data);
				header.updateTitle(el.text());
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-list.ejs', {
					"view" : "live-stations-by-city",
					"data" : IHR.Models.RESP.getLiveStationsByCity().stations
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};

			getSubMenu({
				actionCommand : actionCommand,
				menuName : 'live_stations_by_city',
				callback : success
			});
		}
	});

	/* Controller - Featured Stations */
	IHR.FeaturedStations = can.Control({
		/** @Static */
		defaults : {
			featuredStations : {},
			featuredGenresMenu : {}
		}
	}, {
		init : function(element, options) {
			header.updateTitle("Genres");
			IHR.FeaturedStations.defaults.featuredStations = this.options.genres.genres;
			IHR.FeaturedStations.defaults.featuredStations.sort(this.sortByMenuText);
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/featured-stations-genres.ejs', {
				"data" : IHR.FeaturedStations.defaults.featuredStations
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
				scrollratio : 0.2
			});
		},
		//sort text by alphabet
		sortByMenuText : function(a, b) {
			var _a = a.menuText;
			var _b = b.menuText;
			if (_a > _b) {
				return 1;
			} else {
				return -1;
			}
		},

		".featured-stations-genres .list-text click" : function(el) {
			//menu button's id
			var menuName = el.parent().attr("id");
			console.log("Station Id: " + menuName);
			var actionCommand = getActionCommand(this.options.genres.genres, menuName);
			if (!actionCommand) {
				return;				
			}
			var success = function(data) {
				console.log("=== Get Featured Artists Result - Start ===");
				console.log(data);
				console.log("=== Get Featured Artists Result - End ===");
				IHR.Models.RESP.setFeaturedArtists(data);
				
				//store my stations list
				header.updateTitle("Featured Stations");
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/featured-stations-list.ejs', {
					"data" : IHR.Models.RESP.getFeaturedArtists().artists
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			var error = function(jqXHR) {
				console.log("Get Featured Artists By Genre caught error : " + JSON.stringify(jqXHR));
			};
			IHR.Models.API.getFeaturedArtistsByGenre({
					params : actionCommand.params,
					success:success,
					error : error
			});
		},

		".featured-stations-list .list-text click" : function(el) {
			var stationId = el.parent().attr("id");
			var station = getStationByID(IHR.Models.RESP.getFeaturedArtists().artists, stationId);
			nowSelectStation = station;

			if (currentControl) {
				try {
					currentControl.destroy();
				} catch(e) {
					currentControl = null;
				}
			}
			var success = function() {
			currentControl = new IHR.CustomPlayer("#pagecontent", {
				station : nowSelectStation
			});
			};
			var error = function(jqXHR) {
				console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
			};
			IHR.Models.API.playRequestCommand({
				params : {
					"stationId" : stationId,
					"stationType" : nowSelectStation.type
				},
				success:success,
				error : error
			});
			isPlaying = true;
			displayPlayorPause();
		}
	});

	/* Controller - iHeartRadio Originals */
	IHR.iHROriginals = can.Control({
		/** @Static */
		defaults : {
			iHROriginals : {}
		}
	}, {
		init : function(element, options) {
			header.updateTitle("iHR Originals");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/iHROriginals-stations-list.ejs', {
				"data" : this.options.station.featuredStations
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		".iHROriginals-stations-list .list-text click" : function(el) {
			var stationId = el.parent().attr('id');
			var station = getStationByID(this.options.station.featuredStations, stationId);

			nowSelectStation = station;
			if (currentControl) {
				try {
					currentControl.destroy();
				} catch(e) {
					currentControl = null;
				}
			}
			var success = function() {
				//play station on the device
			};
			var error = function(jqXHR) {
				console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
			};
			IHR.Models.API.playRequestCommand({
				params : {
					"stationId" : stationId,
					"stationType" : nowSelectStation.type
				},
				success:success,
				error : error
			});
			
			currentControl = new IHR.CustomPlayer("#pagecontent", {
				station : nowSelectStation
			});
			
			isPlaying = true;
			displayPlayorPause();
		}
	});

	/* Controller - Recently Played */
	IHR.RecentlyPlayed = can.Control({
		/** @Static */
		defaults : {
			recentlyPlayed : {},
			byStationstramp:[]
		}
	}, {
		init : function(element, options) {
			header.updateTitle("Recently Played");
			IHR.RecentlyPlayed .defaults.byStationstramp = sortByTimestamp(this.options.station);
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/recently-played.ejs', {
				"data" : IHR.RecentlyPlayed .defaults.byStationstramp
			}));
		},
		".recently-played-list .list-text click" : function(el) {
			var stationId = el.parent().attr('id');
			var station = getStationByID(this.options.station, stationId);
			nowSelectStation = station;
			if (currentControl) {
				try {
					currentControl.destroy();
				} catch(e) {
					currentControl = null;
				}
			}
			
		var success = function(){
			if (nowSelectStation.type == "live") {
				currentControl = new IHR.LivePlayer("#pagecontent", {
					station : nowSelectStation
				});
			} else {
				currentControl = new IHR.CustomPlayer("#pagecontent", {
					station : nowSelectStation
				});
			}
		}
		
		var error = function(jqXHR) {
			console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
		};
		IHR.Models.API.playRequestCommand({
			params : {
				"stationId" : stationId,
				"stationType" : nowSelectStation.type
			},
			success:success,
			error : error
		});
			isPlaying = true;
			displayPlayorPause();
		}
	});

	/* Controller - Overlay */
	IHR.Overlay = can.Control({}, {
		init : function(el, opt) {
			$('#pagecontent').append(can.view('iheartradio/views/pagecontent-views/overlay.ejs', {
				"text" : opt.text
			}));
			$('#overlay-container').slideDown(500, function() { });
		}
	});
	
	/* Controller - Popup */
	IHR.Popup = can.Control({}, {
		init : function(el, opt) {
			$('#pagecontent').append(can.view('iheartradio/views/pagecontent-views/popup.ejs', {
				"text" : opt.text
			}));
			$('#popup-container').slideDown(500, function() { });
		}
	});

	/* Controller - Live Player */
	IHR.LivePlayer = can.Control({}, {
		init : function(el, opt) {
			header.updateTitle(opt.station.name + ' - ' + opt.station.city);
			var imgBase64 = null;
			IHR.Models.API.getImagesRequest({
				params : nowSelectStation.imageCommand.params,
				success : function(data) {
					console.log('Get image successful!');
					imgBase64 = data;
				},
				error : function(jqXHR) {
					console.log('Get image failed!');
				},
			});

			var success = function(data) {				
				setScanButton = data.state.hasScanAvailable;
				if (data.state.metaData) {
					nowPlayingSong = data.state.metaData;
                    nowPlayingSongOb.attr({ songTitle: data.state.metaData.songTitle, artistName: data.state.metaData.artistName });
                  if(!data.state.metaData.isPlayingSong)
						setCreateButton = true;
				} else {
					nowPlayingSong = {
						songTitle : "",
						artistName : ""
					};
                    nowPlayingSongOb.attr({ songTitle: "", artistName: "" });
					setCreateButton = true; 
				}
			};

			var error = function(jqXHR) {
				Console.log("Failed to get song!");
			};

			IHR.Models.API.getPlayerState({
				success : success,
				error : error
			});	
			
			setTimeout(function() {
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/live-station-player.ejs', {
					data : nowPlayingSongOb,
					image : imgBase64
				}));
				$('#nowplaying-image').css({
					'background' : 'none'
				});				
				
				if(setScanButton == "false"){
					scanDisable();
				}
				
				if(setCreateButton){					
					createDisable();
				}
			
			}, 3000);

			nowPlayingStation = opt.station;
		},

		/* Now Playing */
		"#np-play-icon click" : function() {
			var success = function() {
				displayPlayorPause();
			};

			var error = function(jqXHR) {
				console.log("Get playCommand request caught error: " + JSON.stringify(jqXHR));
			};

			if (isPlaying) {
				isPlaying = !isPlaying;
				IHR.Models.API.pauseRequestCommand({
					success : success,
					error : error
				});
			} else {
				isPlaying = !isPlaying;
				IHR.Models.API.playRequestCommand({
					success : success,
					error : error
				});
			}
		},

		"#nowplaying-scan click" : function() {
			if($("#np-scan-icon").attr("style") == "color:gray"){
			var success = function(res) {
				console.log("scan success!");
			};

			var error = function(jqXHR) {
				console.log("Get scanCommand request caught error: " + JSON.stringify(jqXHR));
			};

			IHR.Models.API.scanRequestCommand({
				success : success,
				error : error
			});
		}else{
			console.log("the scan button is disabled");
		}
		},

		"#nowplaying-create click" : function(el) {
			if($("#np-create-icon").attr("style") == "color:gray"){
			console.warn("Now playing stationis : " + JSON.stringify(nowPlayingStation));
			_this = this;
			if (currentControl) {
				currentControl.destroy();
			}
			var success = function(data) {
				if (data.state.track) {
					nowPlayingStation.name = data.state.track.title;
					var success = function() {
						console.log("Create custom station successful!");
						if (currentControl) {
							try {
								currentControl.destroy();
							} catch (e) {
								currentControl = null;
							}
						}
						currentControl = new IHR.CustomPlayerStatus("#pagecontent", {
							station : nowPlayingStation,
							item : "create",
							prompt : "Building custom station..."
						});
						isPlaying = true;
						displayPlayorPause();
					};

					var error = function(jqXHR) {
						console.error("Create custom station caught error: " + JSON.stringify(jqXHR));
					};

					var params = {
						"artistId" : data.state.track.artistId,
						"playStation" : "true"
					};

					IHR.Models.API.createCustomStation({
						success : success,
						error : error,
						params : params
					});
				} else if (data.state.metaData) {
					if (data.state.metaData.isPlayingSong == true) {
						nowPlayingStation.name = data.state.metaData.songTitle;
						var success = function() {
							console.log("Create custom station successful!");
							if (currentControl) {
								try {
									currentControl.destroy();
								} catch (e) {
									currentControl = null;
								}
							}
							currentControl = new IHR.CustomPlayerStatus("#pagecontent", {
								station : nowPlayingStation,
								item : "create",
								prompt : "Building custom station..."
							});
							isPlaying = true;
							displayPlayorPause();
						};
						var error = function(jqXHR) {
							console.error("Create custom station caught error: " + JSON.stringify(jqXHR));
						};
						var params = {
							"songId" : data.state.metaData.songId,
							"playStation" : "true"
						};
						IHR.Models.API.createCustomStation({
							success : success,
							error : error,
							params : params
						});
					} else {
						_this.init("#pagecontent", {
							station : nowPlayingStation
						});
						createDisable();
					}
				} else {
					_this.init("#pagecontent", {
							station : nowPlayingStation
						});
						createDisable();
				}
			};

			var error = function(jqXHR) {

			};

			IHR.Models.API.getPlayerState({
				success : success,
				error : error
			});
		}else{
			console.log("the create button is disabled");
			}
		},

		"#nowplaying-menu click" : function() {
			header.updateTitle(nowPlayingStation.name + " Menu");
			var success = function(data) {
				console.log("Get my station list successful!");
				IHR.Models.RESP.setMyStationList(data);
				var exist = false;
				for (var i in data.stations) {
					if(data.stations[i].id == nowPlayingStation.id) {
						exist = true;
						break;
					}
				}
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/livestations-player-menu.ejs', {
					'exist' : exist
				}));
			};
			
			var error = function(jqXHR) {
				console.error("Get My Station List Caught Error: " + JSON.stringify(jqXHR));
			};
			
			if (IHR.Models.RESP.getMyStationList() == null
					|| IHR.Models.RESP.setMyStationList == undefined) {
				IHR.Models.API.getMyStationsList({
					success : success,
					error : error
				});
			} else {
				var exist = false;
				var myStations = IHR.Models.RESP.getMyStationList().stations;
				for (var i in myStations) {
					if(myStations[i].id == nowPlayingStation.id) {
						exist = true;
						break;
					}
				}
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/livestations-player-menu.ejs', {
					'exist' : exist
				}));
			}
		},

		/* Now playing menu */
		".save_station click" : function() {
			$("#list").addClass("hidden");
			$(".loding-status").removeClass("hidden");
			var success = function(data) {
				$(".loding-status").addClass("hidden");
				new IHR.Popup("#pagecontent", {
					text : 'Save this station successful!'
				});
				console.log("save station successful!");
			};

			var error = function(jqXHR) {
				$(".loding-status").addClass("hidden");
				new IHR.Popup("#pagecontent", {
					text : 'Save this station failed!'
				});
				console.log("save station Command request caught error : " + JSON.stringify(jqXHR));
			};

			IHR.Models.API.saveStationRequestCommand({
				params : {
					stationId : nowPlayingStation.id,
				},
				success : success,
				error : error
			});

		},
		
		"#ok-btn click" : function() {
			if (currentControl) {
				currentControl.destroy();
			}
			currentControl = new IHR.LivePlayer("#pagecontent", {
				station : nowPlayingStation
			});
		},

		".livestations-player-menu .my_stations click" : function() {
			var success = function(data) {
				console.log("Get my station list successful!");
				IHR.Models.RESP.setMyStationList(data);
				header.updateTitle("My Stations");
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.MyStations("#pagecontent", {
					myStationsList : data
				});
			};

			var error = function(jqXHR) {
				console.error("Get My Station List Caught Error: " + JSON.stringify(jqXHR));
			};

			if (IHR.Models.RESP.getMyStationList() == null || IHR.Models.RESP.setMyStationList == undefined) {
				IHR.Models.API.getMyStationsList({
					success : success,
					error : error
				});
			} else {
				header.updateTitle("My Stations");
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.MyStations("#pagecontent", {
					myStationsList : IHR.Models.RESP.getMyStationList()
				});
			}
		}
	});

	/* Controller - Custom Player */
	IHR.CustomPlayer = can.Control({}, {
		init : function(el, opt) {
			console.log("=== Init Custom Player ===");
			header.updateTitle(opt.station.name + " Radio");
			nowPlayingStation = opt.station;
			var setlike = false;
			var success = function(data) {
				console.log("=== Get Player State - Start ===");
				console.log(data);
				console.log("=== Get Player State - End ===");
				if (data.state.track) {
					console.log("nowPlayingSonglike : " + nowPlayingSonglike);
					console.log(nowPlayingSong.title);
					console.log(data.state.track.title);
					if ((nowPlayingSong.title == data.state.track.title) && nowPlayingSonglike) {
						setlike = true;
					}
					nowPlayingSong = data.state.track;
					nowPlayingSongOb.attr({
						songTitle : data.state.track.title,
						artistName : data.state.track.albumName
					});
					console.log("++++++data.state.track++++++:" + JSON.stringify(nowPlayingSong));
				} else if (data.state.metaData) {
					console.log("nowPlayingSonglike : " + nowPlayingSonglike);
					console.log(nowPlayingSong.songTitle);
					console.log(data.state.metaData.songTitle);
					if ((nowPlayingSong.songTitle == data.state.metaData.songTitle) && nowPlayingSonglike) {
						setlike = true;
					}
					nowPlayingSong = data.state.metaData;
					nowPlayingSongOb.attr({
						songTitle : data.state.metaData.songTitle,
						artistName : data.state.metaData.artistName
					});
					console.log("++++++data.state.metaData++++++:" + JSON.stringify(nowPlayingSong));
				} else {
					nowPlayingSong = {
						songTitle : "Custom Station",
						artistName : ""
					};
				}
			};

			var error = function(jqXHR) {
				console.log("Failed to get song!");
			};
			
			IHR.Models.API.getPlayerState({
				success : success,
				error : error
			});
			
			setTimeout(function() {
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/custom-station-player.ejs',{
					data : nowPlayingSongOb
				}));
						
				if (setlike) {
					setLikeState();
				}
			}, 3000);
			
			this.getImage();
		},
		
		getImage : function() {
			// TODO
			// var stationId = nowPlayingStation.id;
		},
		
		".custom-station-player #nowplaying-more click" : function() {
			header.updateTitle(nowPlayingStation.name + " Menu");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/custom-stations-menu.ejs', {
				"data" : [
						"Create new station from this song",
						"Discovery tuner",
						"My Stations" ]
			}));
		},
		
		/* Now Playing */
		"#nowplaying-play-or-pause click" : function() {
			var success = function() {
				displayPlayorPause();
			};

			var error = function(jqXHR) {
				console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
			};
			
			if (isPlaying) {
				isPlaying = !isPlaying;
				IHR.Models.API.pauseRequestCommand({
					success : success,
					error : error
				});
			} else {
				isPlaying = !isPlaying;
				IHR.Models.API.playRequestCommand({
					success : success,
					error : error
				});

			}
		},
		
		"#nowplaying-thumbs-down click" : function() {
			//alert("Dislike!");
			var _this = this;

			var success = function() {
				console.log("thumbsDown success!");
				$("#np-down-icon").removeClass("np-down-icon");
				$("#np-down-icon").addClass("np-down-icon-light");
                                nowPlayingSonglike = false; 
				/*
				 * onMetaDataChanged
				 * use nowPlayingStation here it could be the previous song
				 * but it should be the new song playing now
				 */
				var success = function() {
					_this.init("#pagecontent",{station: nowPlayingStation});
					isPlaying = true;
					displayPlayorPause();
				};
				var error = function(jqXHR) {
					console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
				};
				IHR.Models.API.playRequestCommand({
					success : success,
					error : error
				});
			};

			var error = function(jqXHR) {
				console.log("Get thumbsDownCommand request caught error : " + JSON.stringify(jqXHR));
			};

			IHR.Models.API.thumbsDownRequestCommand({
				success : success,
				error : error
			});

		},
		
		"#nowplaying-thumbs-up click" : function() {
			//alert("Like!");
			var success = function() {
				console.log("thumbsUp success!");
				//show hightLight
				$("#np-up-icon").removeClass("np-up-icon");
				$("#np-up-icon").addClass("np-up-icon-light");
				nowPlayingSonglike = true;
			};

			var error = function(jqXHR) {
				console.log("Get thumbsUpCommand request caught error: " + JSON.stringify(jqXHR));
			};
			
			IHR.Models.API.thumbsUpRequestCommand({
				success : success,
				error : error
			});
		},
		
		".create_new_station_from_this_song click" : function() {
			_this = this;
			if (currentControl) {
				currentControl.destroy();
			}
			var success = function(data1) {
				if (data1.state.track) {
					console.log(JSON.stringify(data1.state.track));
					nowPlayingStation.name = data1.state.track.title;
					var success = function(data2) {
						console.log("Create custom station successfully.");
						if (currentControl) {
							try {
								currentControl.destroy();
							} catch (e) {
								currentControl = null;
							}
						}
						currentControl = new IHR.CustomPlayerStatus("#pagecontent", {
							station : nowPlayingStation,
							item : "create",
							prompt : "Building custom station..."
						});
						isPlaying = true;
						displayPlayorPause();
					};
					
					var error = function(jqXHR) {
						console.error("Create custom station caught error: " + JSON.stringify(jqXHR));
					};
					
					var params = {
						"songId" : data1.state.track.id,
						"playStation" : "true"
					};
					
					IHR.Models.API.createCustomStation({
						success : success,
						error : error,
						params : params
					});
				} else if (data1.state.metaData) {
					console.log(JSON.stringify(data1.state.metaData));
					if (data1.state.metaData.isPlayingSong == true) {
						nowPlayingStation.name = data1.state.metaData.songTitle;
						var success = function(data2) {
							console.log("Create custom station successfully.");
							if (currentControl) {
								currentControl.destroy();
							}
							currentControl = new IHR.CustomPlayerStatus("#pagecontent", {
								station : nowPlayingStation,
								item : "create",
								prompt : "Building custom station..."
							});
							isPlaying = true;
							displayPlayorPause();
						};
						
						var error = function(jqXHR) {
							console.error("Create custom station caught error: " + JSON.stringify(jqXHR));
						};
						var params = {
							"songId" : data1.state.metaData.songId,
							"playStation" : "true"
						};
						
						IHR.Models.API.createCustomStation({
							success : success,
							error : error,
							params : params
						});
					} else {
						_this.init("#pagecontent", {
							station : nowPlayingStation
						});
						console.log("Can not create station!");
					}
				} else {
					_this.init("#pagecontent", {
						station : nowPlayingStation
					});
					console.log("Can not create station!");
				}
			};

			var error = function(jqXHR) {

			};
			
			IHR.Models.API.getPlayerState({
				success : success,
				error : error
			});
		},
		
		".my_stations click" : function() {
			var success = function(data) {
				console.log("Get my station list successfully.");
				IHR.Models.RESP.setMyStationList(data);
				header.updateTitle("My Stations");
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.MyStations("#pagecontent", {
					myStationsList : data
				});
			};
			
			var error = function(jqXHR) {
				console.error("Get My Station List Caught Error: " + JSON.stringify(jqXHR));
			};
			
			if (IHR.Models.RESP.getMyStationList() == null
					|| IHR.Models.RESP.setMyStationList == undefined) {
				IHR.Models.API.getMyStationsList({
					success : success,
					error : error
				});
			} else {
				header.updateTitle("My Stations");
				if (currentControl) {
					try {
						currentControl.destroy();
					} catch (e) {
						currentControl = null;
					}
				}
				currentControl = new IHR.MyStations("#pagecontent", {
					myStationsList : IHR.Models.RESP.getMyStationList()
				});
			}
		},
		
		".discovery_tuner click" : function() {
			var success = function(data) {
				IHR.Models.RESP.setDiscoveryMenu(data.menu);
				header.updateTitle("Discovery Tuner");
				$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/custom-stations-menu-discovery.ejs', {
					"data" : data.menu
				}));
				var varietyLevel = nowPlayingStation.varietyLevel;
				var levelItem = null;
				if (varietyLevel == "3") {
					levelItem = $("#less_familiar");
				} else if (varietyLevel == "2") {
					levelItem = $("#mixed");
				} else {
					levelItem = $("#familiar");
				}

				levelItem.attr("style", "color:#F8991C");
			};

			var error = function(jqXHR) {
				console.error("Get discovery menu caught error: " + JSON.stringify(jqXHR));
			};

			IHR.Models.API.getDiscoveryMenu({
				success : success,
				error : error
			});
		},
		
		".custom-stations-menu-discovery .list-text click" : function(el, ev) {
			var _this = this;
			var menuName = el.parent().attr('id');
			$('.light, .dark').css({ 'color' : 'white' });
			el.parent().css("color", "#F8991C");
			// action command from ihr response
			var actionCommand = getActionCommand(IHR.Models.RESP.getDiscoveryMenu(), menuName);
			if (!actionCommand) {
				return;
			}
			var success = function(data) {
				_this.init('', {
					station : nowPlayingStation
				});
				displayPlayorPause();
				console.log(data.varietyLevel);
			};
			
			getSubMenu({
				actionCommand : actionCommand.command,
				menuName : menuName,
				callback : success
			});
		}
	});

	/* Controller - Live Player Status */
	IHR.LivePlayerStatus = can.Control({
	}, {
		init : function(el, opt) {
			header.updateTitle("Status");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/create-station-status.ejs', {
				data : opt.prompt
			}));
			setTimeout(function() {
				currentControl = new IHR.LivePlayer("#pagecontent", {
					station : nowPlayingStation
				});
				isPlaying = false;
				displayPlayorPause();
				if (opt.item == "create") {
					var text = "Play " + nowPlayingStation.name + " now?";
					new IHR.Overlay("#pagecontent", {
						text : text
					});
				}
				if (opt.item == "save") {
					console.log("You can't save it again");
				}

			}, 3000);
		},

		"#yesButton click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});

			if (currentControl)
				currentControl.destroy();
			currentControl = new IHR.CustomPlayer("#pagecontent", {
				station : nowPlayingStation
			});
			isPlaying = true;
			displayPlayorPause();
		},

		"#noButton click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
		}
	});

	/* Controller - Custom Player Status*/
	IHR.CustomPlayerStatus = can.Control({}, {
		init : function(el, opt) {
			header.updateTitle("Status");
			$('#pagecontent').html(can.view('iheartradio/views/pagecontent-views/create-station-status.ejs', {
				data : opt.prompt
			}));
			setTimeout(function() {
				
				isPlaying = false;
				displayPlayorPause();
				if (opt.item == "create") {
					var text = "Play " + nowPlayingSong.songTitle + " now?";
					new IHR.Overlay("#pagecontent", {
						text : text
					});
				}
			}, 3000);
		},

		"#yesButton click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
			var success = function() {
				isPlaying = true;
				displayPlayorPause();
			};

			var error = function(jqXHR) {
				console.log("Get playCommand request caught error : " + JSON.stringify(jqXHR));
			};
			IHR.Models.API.playRequestCommand({
				success : success,
				error : error
			});
			currentControl = new IHR.CustomPlayer("#pagecontent", {
				station : nowPlayingStation
			});

		},

		"#noButton click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
			currentControl = new IHR.CustomPlayer("#pagecontent", {
				station : nowPlayingStation
			});
		}
	});

	/* Controller - Long Polling */
	IHR.LongPolling = can.Construct({
		getEventTimer : null,

		init : function(el, opt) {
			console.log("Come into long pulling init function.");
			getEventTimer = setInterval(this.getEventID, 2000);
		},

		/* Get Asynchronous Message */
		getEventID : function() {
			var _this = this;
			var error = function(jqXHR) {
				console.warn("Get event id request caught error : " + JSON.stringify(jqXHR));
			};

			var success = function(payload) {
				if (payload) {
					if (payload.applicationName == "com.clearchannel.iheartradio") {
						console.log("getEventID ---> " + payload.eventID);
						var content;
						if (payload.eventId.length > 1) {
							content = {
								"command" : "getEvents",
								"eventIds" : payload.eventId
							};
						} else {
							content = {
								"command" : "getEvent",
								"eventId" : payload.eventId
							};
						}

						IHR.Models.API.getAsyncEventMessage({
							content : content,
							success : _this.processAsyncData,
							error : function(jqXHR) {
								console.warn("Get event message request caught error : " + JSON.stringify(jqXHR));
							}
						});
					}
				}
			};

			IHR.Models.API.getAsyncEventID({
				success : success,
				error : error
			});
		},

		/* Process Asynchronous Message */
		processAsyncData : function(payload) {
			if (payload != null && payload.length > 0) {
				//callbackFunctionArray : ["onStateChanged","onMetaDataChanged","onLiveRadioChanged","onDMCASkipFail","onScanAvailableChanged","onPlayerError","onTrackChanged","onStationChanged"],
				var callbackFunc = eval(payload.eventID(payload.eventData));
				if (callbackFunc != null) {
					callbackFunc(payload);
				}
			}
		},

		onStateChanged : function(eventData) {
			var isPlay = eventData.playerPlaying;
			console.warn("onStateChanged -->" + JSON.stringify(eventData));
		},
		onMetaDataChanged : function(eventData) {
			console.warn("onMetaDataChanged -->" + JSON.stringify(eventData));
		},
		onLiveRadioChanged : function(eventData) {
			console.warn("onLiveRadioChanged -->" + JSON.stringify(eventData));
		},
		onDMCASkipFail : function(eventData) {
			console.warn("onDMCASkipFail -->" + JSON.stringify(eventData));
		},
		onScanAvailableChanged : function() {
			console.warn("onScanAvailableChanged -->" + JSON.stringify(eventData));
		},
		onPlayerError : function() {
			console.warn("onPlayerError -->" + JSON.stringify(eventData));
		},
		onTrackChanged : function() {
			console.warn("onStationChanged -->" + JSON.stringify(eventData));
		},
		onStationChanged : function() {
			console.warn("onStationChanged -->" + JSON.stringify(eventData));
			//change player screen
		},
		destroy : function() {
			getEventTimer = null;
		}
	});

	/* Change play or pause image */
	var displayPlayorPause = function() {
		if (isPlaying) {
			$("#np-play-icon").removeClass("np-play-icon");
			$("#np-play-icon").addClass("np-pause-icon");
		} else {
			$("#np-play-icon").removeClass("np-pause-icon");
			$("#np-play-icon").addClass("np-play-icon");
		}
	};
	/* keep the like status of the same song*/
	var setLikeState = function(){
		if(nowPlayingSonglike){
			$("#np-up-icon").removeClass("np-up-icon");
			$("#np-up-icon").addClass("np-up-icon-light");
		}
		else{
			$("#np-up-icon").removeClass("np-up-icon-light");
			$("#np-up-icon").addClass("np-up-icon");
		}
	};
	/* set the create button to disable when the station can not be created
	 */
	var createDisable =  function(){
		$("#np-create-icon").css("color","gray");
		setCreateButton = false;

	};
	
	/*set the scan button to disable when the station can not be scanned	 
	 */
	
	var scanDisable = function(){
		$("#np-scan-icon").css("color","gray");
	}
	
	
	/* Get Action Command from Specified Menu Name*/
	var getActionCommand = function(data, name) {
		var command = null;
		for (var x in data) {
			if (data[x].name == name)
				command = data[x].actionCommand;
		}
		return command;
	};
	/* Get Sub Menu List */
	var getSubMenu = function(args) {
		IHR.Models.API.actionCommandRequest({
			actionCommand : args.actionCommand,
			name : args.menuName,
			success : function(data) {
				args.callback(data);
			},
			error : function(jqXHR) {
				console.warn("Get sub menu request caught error : " + JSON.stringify(jqXHR));
			}
		});
	};
	/* Get Station By ID*/
	var getStationByID = function(stations, id) {
		var station = null;
		for (var x in stations) {
			if (stations[x].id == id)
				station = stations[x];
		}
		return station;
	};
	/* Get Station By Name*/
	var getStationByName = function(stations, name) {//TODO will combine with getStationByID
		var station = null;
		for (var x in stations) {
			if (stations[x].name == name)
				station = stations[x];
		}
		return station;
	};
	
	var getStationByTimestamp = function(stations,timestamp){
		var station = null;
		for(var x in stations){
			if(stations[x].timestamp == timestamp){
				station = stations[x];
			}
		}
		return station
	}

	/* Get Image Command */
	var getImageCommand = function(stations, id) {//TODO will combine with get actioncommand
		var command = null;
		for (var x in data) {
			if (data[x].name == name)
				command = data[x].imageCommand;
		}
		return command;
	};
	/*sort by name*/
	var sortByName = function(stationList) {
		var newStationList = [];
		var stationName = [];

		for (var i in stationList) {
			stationName[i] = stationList[i].name;
		}
		stationName.sort();
		for (var j in stationName) {
			newStationList.push(getStationByName(stationList, stationName[j]));
		}
		return newStationList;
	};
	
	var compareIntValue = function(num1,num2){
		var temp1 = parseInt(num1);
		var temp2 = parseInt(num2);
		if(temp1<temp2) {
		 return 1;
		} else if(temp1 == temp2){
		   return 0;
		} else {
		return -1;
		}
	}
	
	var sortByTimestamp = function(stationList){		
		var newStationList = [];
		var stationTimestamp = [];
		for(var i in stationList){
			stationTimestamp[i] = stationList[i].timestamp;
		}
		stationTimestamp.sort(compareIntValue);
		for(var j in stationTimestamp){
			newStationList.push(getStationByTimestamp(stationList,stationTimestamp[j]));
		}
		return newStationList; 
	}

	var ihr = new IHR.Models.API();
	var header = new IHR.Header("#header", {});
	var mainHome = new IHR.MainHome("#pagecontent", {});
	//var longpolling = new IHR.LongPolling();
});