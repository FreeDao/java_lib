var iheartradio = can.Construct({}, {
	
	/**
     * Initialize the home app
     */
	init : function() {
        $('aqapp').html( 'iheartradio/views/init.ejs', {} );
    }
});

APP.iheartradio = new iheartradio();

AQ.loadStylesheet("iheartradio/iheartradio.css");

AQ.loadScript("iheartradio/js/util.js", function() {
	AQ.loadScript("iheartradio/js/model.js", function() {
		AQ.loadScript(["iheartradio/js/fixture.js", "iheartradio/js/controller.js"]);
	});
});

