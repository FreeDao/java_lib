/**
 * @constructor
 * @param {Array} data
 */
function Data(data) {
	this.commandName = resources.command.fromCode.UNKNOWN;
	this.command = -1;
	this.data = {};
	this.rawData = data;

	//params for PNDR_RETURN_TRACK_TITLE
	this.trackToken = null;
	this.trackTitle = null;
	this.artistName = null;
	this.albumName = null;

	this.segmentIndex = null;
	this.totalSegments = null;
	this.imageData = null;
	this.timeElapsed = null;
	
	if (data && data.length) {
		
		var command = data[0];
		this.command = command;
		this.commandName = resources.command.fromCode[command];
		//based on the command and command name, let's parse the content.
		//TODO: [high] (nhat) - parse the command here, or delegate to another parser.
		switch (this.commandName) {
			case resources.constants.PNDR_SESSION_START:
				Logger.log("PROCESSING SESSION START");
					
				var firstTwoBytes = data.slice(1, 3);
				this.apiVersion = Conversion.intFromBytes(firstTwoBytes);
				var accessoryBytes = data.slice(3, 11);
				var accessory = "";
				for (var i = 0; i < accessoryBytes.length; i++) {
					accessory = accessory + String.fromCharCode(accessoryBytes[i]);
				}
				this.accessoryId = accessory;

				var albumArtSizeArray = data.slice(11, 13);
				this.albumArtSize = Conversion.intFromBytes(albumArtSizeArray);

				this.imageType = data[13];

				this.flags = data[14];
					

				if (this.apiVersion == 3) {
					var stationArtDimensionArray = data.slice(14);
					this.stationArtDimension = Conversion.intFromBytes(stationArtDimensionArray);
				}
				break;
			case resources.constants.PNDR_RETURN_TRACK_TITLE:
				var trackTokenBytes = data.slice(1, 5);
				var trackToken= "";
				for (var i = 0; i < trackTokenBytes.length; i++) {
					trackToken = trackToken + String.fromCharCode(trackTokenBytes[i]);
				}
				this.trackToken = trackToken;
				var trackNameBytes = data.slice(5);
				var trackName= "";
				for (var i = 0; i < trackNameBytes.length; i++) {
					trackName = trackName + String.fromCharCode(trackNameBytes[i]);
				}
				this.trackName = trackName;
				break;
			case resources.constants.PNDR_RETURN_TRACK_ARTIST:
				var trackTokenBytes = data.slice(1, 5);
				var trackToken= "";
				for (var i = 0; i < trackTokenBytes.length; i++) {
					trackToken = trackToken + String.fromCharCode(trackTokenBytes[i]);
				}
				this.trackToken = trackToken;
				var artistNameBytes = data.slice(5);
				var artistName= "";
				for (var i = 0; i < artistNameBytes.length; i++) {
					artistName = artistName + String.fromCharCode(artistNameBytes[i]);
				}
				this.artistName = artistName;
				break;
			case resources.constants.PNDR_RETURN_TRACK_ALBUM:
				var trackTokenBytes = data.slice(1, 5);
				var trackToken= "";
				for (var i = 0; i < trackTokenBytes.length; i++) {
					trackToken = trackToken + String.fromCharCode(trackTokenBytes[i]);
				}
				this.trackToken = trackToken;
				var albumNameBytes = data.slice(5);
				var albumName= "";
				for (var i = 0; i < albumNameBytes.length; i++) {
					albumName = albumName + String.fromCharCode(albumNameBytes[i]);
				}
				this.albumName = albumName;
				break;
			case resources.constants.PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT:
				var trackTokenBytes = data.slice(1, 5);
				var trackToken= "";
				for (var i = 0; i < trackTokenBytes.length; i++) {
					trackToken = trackToken + String.fromCharCode(trackTokenBytes[i]);
				}
				this.trackToken = trackToken;
				this.segmentIndex = data[5];
				this.totalSegments = data[6];
				var imageData = "";
				var imageDataBytes = data.slice(7);
				for (var i = 0; i < imageDataBytes.length; i++) {
					imageData = imageData + String.fromCharCode(imageDataBytes[i]);
				}
				this.imageData = imageData;
				break;
			case resources.constants.PNDR_UPDATE_TRACK_ELAPSED:
				var trackTokenBytes = data.slice(1, 5);
				var trackToken= "";
				for (var i = 0; i < trackTokenBytes.length; i++) {
					trackToken = trackToken + String.fromCharCode(trackTokenBytes[i]);
				}
				this.trackToken = trackToken;
				this.timeElapsed = Conversion.intFromBytes(data.slice(5));
				break;
		}
	}
}

Data.prototype.getCommandName = function() {
	return this.commandName;
};

Data.prototype.getCommand = function() {
	return this.command;
};

Data.prototype.getData = function() {
	return this.data;
};

Data.prototype.getVersion = function() {
	return this.apiVersion;
};

Data.prototype.getAccessoryId = function() {
	return this.accessoryId;
};

Data.prototype.getImageType = function() {
	return this.imageType;
};

Data.prototype.getFlags = function() {
	return this.flags;
};

Data.prototype.getAlbumArtSize = function() {
	return this.albumArtSize;
};

Data.prototype.getStationArtDimension = function() {
	return this.stationArtDimension;
};

Data.prototype.getRawData = function() {
	return this.rawData;
};

Data.prototype.getTrackToken = function() {
	return this.trackToken;
};

Data.prototype.getTrackName = function() {
	return this.trackName;
};

Data.prototype.getArtistName = function() {
	return this.artistName;
};

Data.prototype.getAlbumName = function() {
	return this.albumName;
};

Data.prototype.getSegmentIndex = function() {
	return this.segmentIndex;
};

Data.prototype.getTotalSegments = function() {
	return this.totalSegments;
};

Data.prototype.getImageData = function() {
	return this.imageData;
};

Data.prototype.getTimeElapsed = function() {
	return this.timeElapsed;
};



//reconstruct the byte array.
Data.prototype.toByte = function() {
	//only support SESSION_START at the moment, look @ the constructor for more info
	if (this.getCommandName() != resources.constants.PNDR_SESSION_START) {
		return this.getRawData();
	}


	var result = new Array();

	result.push(this.getCommand());
	if (this.getVersion()) {
		result = result.concat(Conversion.bytesFromInt(this.getVersion(), 2));
	}
	var accessoryId = this.getAccessoryId();

	//8 character
	for (var i = 0; i < accessoryId.length; i++) {
		result.push(accessoryId[i].charCodeAt(0)); //no double byte.
	}

	result = result.concat(Conversion.bytesFromInt(this.getAlbumArtSize(), 2));

	result.push(this.getImageType());

	result.push(this.getFlags());

	if (this.getStationArtDimension()) {
		result = result.concat(Conversion.bytesFromInt(this.getStationArtDimension(), 2));
	}

	return result;
};