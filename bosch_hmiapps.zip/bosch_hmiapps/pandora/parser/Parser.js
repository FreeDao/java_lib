function Parser() {
	this.handlers = new Array();
	this.handlers.push(new HandlerStart());
	this.handlers.push(new HandlerType());
	this.handlers.push(new HandlerSequence());
	this.handlers.push(new HandlerSize());
	this.handlers.push(new HandlerPayload());
	this.handlers.push(new HandlerCRC());
	this.handlers.push(new HandlerEnd());
}

/**
 * @param {Object} data the raw data
 */
Parser.prototype.parse = function(data) {
	var context = {};
	context.nextIndex = 0;
	var frame = new Frame();
	for (var i = 0; i < this.handlers.length; i++) {
		var handler = this.handlers[i];
		//short circuit the loop to avoid redundant processing if the frame is bad.
		if (context.hasError) {
			break;
		}
		handler.handle(data, context, frame);
	}
	return frame;
};

/**
 * Handler Start
 */
function HandlerStart() {

}

HandlerStart.prototype.handle = function(data, context, frame) {
	if (!data || context.hasError) {
		return;
	}

	var first = data[context.nextIndex];
	if (first == Frame.FLAG_FIRST) {
		context.nextIndex = 1;
		frame.setFirst(first);
	} else {
		context.hasError = true;
	}
};

/**
 * Handler type
 */
function HandlerType() {

}

HandlerType.prototype.handle = function(data, context, frame) {
	if (!data || context.hasError) {
		return;
	}

	var type = data[context.nextIndex];
	if (type == 0x00 || type == 0x01) {
		frame.setType(type);
		context.nextIndex = 2;
	} else {
		context.hasError = true;
	}
};

/**
 * Handler sequence
 */
function HandlerSequence() {

}

HandlerSequence.prototype.handle = function(data, context, frame) {
	if (!data || context.hasError) {
		return;
	}

	var sequence = data[context.nextIndex];
	if (sequence == 0x00 || sequence == 0x01) {
		frame.setSequence(sequence);
		context.nextIndex = 3;
	} else {
		context.hasError = true;
	}
};

/**
 * Handler size
 */
function HandlerSize() {

}

HandlerSize.prototype.handle = function(data, context, frame) {
	if (!data || context.hasError) {
		return;
	}


	//4 bytes
	var temp = new Array();
	for (var i = 0; i < 4; i++) {
		temp.push(data[context.nextIndex+i]);
	}

	var size = Conversion.intFromBytes(temp);

	frame.setSize(size);
	context.payloadSize = size;
	context.nextIndex = context.nextIndex + 4 /*4 bytes*/;
};


/**
 * Handler payload
 */
function HandlerPayload() {

}

HandlerPayload.prototype.handle = function(data, context, frame) {
	if (!data || context.hasError) {
		return;
	}
	var payloadSize = context.payloadSize;

	//not ack and empty payload is bad data.
	if (!payloadSize && !frame.isAck()) {
		context.hasError = true;
		return;
	}

	var payload = new Array();
	if (payloadSize) {
		payload = data.slice(context.nextIndex, context.nextIndex + payloadSize);
		context.nextIndex = context.nextIndex + payloadSize;
	}
    frame.setPayload(Payload.factory(payload));
};

/**
 * Handler crc
 */
function HandlerCRC() {

}

HandlerCRC.prototype.handle = function(data, context, frame) {
	if (context.hasError) {
		return;
	}
	var start = context.nextIndex;
	//2 bytes
	var tmp = new Array();
	tmp.push(data[start]);
	tmp.push(data[start+1]);

	var crc = Conversion.intFromBytes(tmp);

	frame.setCrc(crc);
	context.nextIndex += 2;
};

/**
 * Handler crc
 */
function HandlerEnd() {

}

HandlerEnd.prototype.handle = function(data, context, frame) {
	if (!data || context.hasError) {
		return;
	}

	var index = context.nextIndex;
	var last = data[index];
	if (last != Frame.FLAG_LAST) {
		context.hasError = true;
		return;
	}
	frame.setLast(last);
};


