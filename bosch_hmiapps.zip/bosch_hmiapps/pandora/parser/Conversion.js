var Conversion = (function() {
	return {
		intFromBytes: function(x) {
			var val = 0;
			for (var i = 0; i < x.length; ++i) {
				val += x[i];
				if (i < x.length - 1) {
					val = val << 8;
				}
			}
			return val;
		},
		bytesFromInt: function(x, arraySize) {
			var bytes = [];
			var i = arraySize;
			do {
				bytes[--i] = x & (255);
				x = x >> 8;
			} while (i);
			return bytes;
		},

		/**
		 * CRC-16-CCITT implementation
		 * http://introcs.cs.princeton.edu/java/51data/CRC16CCITT.java.html
		 * @param array
		 */
		crc: function(array) {
			var crc = 0xFFFF;
			var polynomial = 0x1021;

			for (var i = 0; i < array.length; i++) {
				var b = array[i];
				for (var j = 0; j < 8; j++) {
					var bit = ((b >> (7 - j) & 1) == 1);
					var c15 = ((crc >> 15 & 1) == 1);
					crc <<= 1;
					if (c15 ^ bit) {
						crc ^= polynomial;
					}
				}
			}
			crc &= 0xFFFF;

			return crc;
		}
	};
})();