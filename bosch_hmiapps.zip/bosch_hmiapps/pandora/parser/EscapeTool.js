/**
 * pandoralink escape and unescape logic.
 */
var EscapeTool = (function() {
	return {
		/**
		 *
		 * @param {Array} data
		 */
		escape: function(data) {

			var encounteredStart = false;

			var escaped = new Array();
			for (var i = 0; i < data.length; i++) {
				var b = data[i];
				//encounter escaped char, escape it
				if (b == Frame.FLAG_ESCAPE) {
					escaped.push(Frame.FLAG_ESCAPE);
					escaped.push(Frame.FLAG_ESCAPE_ESCAPE);
					continue;
				}

				//enounter the first again, escape it
				if (encounteredStart && b == Frame.FLAG_FIRST) {
					escaped.push(Frame.FLAG_ESCAPE);
					escaped.push(Frame.FLAG_FIRST_ESCAPE);
					continue;
				}

				//encounter last, but not last yet.
				if (b == Frame.FLAG_LAST && i + 1 < data.length) {
					escaped.push(Frame.FLAG_ESCAPE);
					escaped.push(Frame.FLAG_LAST_ESCAPE);
					continue;
				}

				escaped.push(b);

				if (b == Frame.FLAG_FIRST && !encounteredStart) {
					encounteredStart = true;
				}
			}
			return escaped;
		},
		/**
		 * @param {Array} data
		 */
		unescape: function(data) {
			var encounteredEscape = false;
			var unescaped = new Array();
			for (var i = 0; i < data.length; i++) {
				var b = data[i];
				if (b == Frame.FLAG_ESCAPE) {
					encounteredEscape = true;
					continue;
				}
				if (encounteredEscape) {
					if (b == Frame.FLAG_FIRST_ESCAPE) {
						unescaped.push(Frame.FLAG_FIRST);
					} else if (b == Frame.FLAG_ESCAPE_ESCAPE) {
						unescaped.push(Frame.FLAG_ESCAPE)
					} else if (b == Frame.FLAG_LAST_ESCAPE) {
						unescaped.push(Frame.FLAG_LAST);
					}
					encounteredEscape = false;
					continue;
				}
				unescaped.push(b);
			}

			return unescaped;
		}
	};
})();