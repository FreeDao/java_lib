/**
 * @constructor
 * @param {Object=} first
 * @param {Object=} type
 * @param {Object=} sequence
 * @param {Object=} size
 * @param {Payload=} payload
 * @param {Object=} crc
 * @param {Object=} last
 */
function Frame(first, type, sequence, size, payload, crc, last) {
    this.first = null;
    this.type = 0;
    this.sequence = 0;
    this.size = null;
    this.payload = null;
    this.crc = null;
    this.last = null;

    if (first) {
        this.first = first;
    }

    if (type) {
        this.type = type;
    }
    if (sequence) {
        this.sequence = sequence;
    }
    if (size) {
        this.size = size;
    }
    if (payload) {
        this.payload = payload;
    }
    if (crc) {
        this.crc = crc;
    }
    if (last) {
        this.last = last;
    }
}

/*
 * STATIC FRAMES
 */
/**
 * generate an ACK frame with the given sequence
 * @param {Frame} frame
 */
Frame.ACK = function (frame) {
    return new Frame(Frame.FLAG_FIRST, Frame.FLAG_TYPE_ACK, frame.getSequence(), 0, new Payload([]), -1, Frame.FLAG_LAST);
};

/**
 * helper to create a frame
 * @param {number} type
 * @param {number} size
 * @param {Payload} payload
 * @return {Frame}
 */
Frame.DATA = function (payload) {
    return new Frame(Frame.FLAG_FIRST, Frame.FLAG_TYPE_DATA, -1, payload.toByte().length, payload, -1, Frame.FLAG_LAST);
};

/*
 * Constants
 */
Frame.FLAG_FIRST = 0x7E;
Frame.FLAG_FIRST_ESCAPE = 0x5E;

Frame.FLAG_LAST = 0x7C;
Frame.FLAG_LAST_ESCAPE = 0x5C;

Frame.FLAG_ESCAPE = 0x7D;
Frame.FLAG_ESCAPE_ESCAPE = 0x5D;

Frame.FLAG_TYPE_ACK = 0x01;
Frame.FLAG_TYPE_DATA = 0x00;

Frame.prototype.isAck = function () {
    return this.getType() == Frame.FLAG_TYPE_ACK;
};

Frame.prototype.isValid = function () {
    return this.getLast() == Frame.FLAG_LAST;
};

Frame.prototype.toByte = function (useCrc) {
    var result = new Array();

    result.push(this.getFirst());
    result.push(this.getType());
    result.push(this.getSequence());

	var dataBytes = [];
	if (this.getPayload()) {
		dataBytes = this.getPayload().toByte();
		if (!dataBytes || dataBytes.length == 0) {
			dataBytes = [];
		}
    }

	var size = this.getSize();
    //4 bytes for the size,
	if (dataBytes.length != this.getSize()/*the payload size has been modified, we need to modify the size.*/) {
		size = dataBytes.length;
	}

	//append the size
	result = result.concat(Conversion.bytesFromInt(size, 4));
	//append the payload
	result = result.concat(dataBytes);


    if (useCrc) {
        //2 bytes for crc
        result = result.concat(Conversion.bytesFromInt(this.getCrc(), 2));
    } else {
        var temp = new Array();

        temp.push(this.getType());
        temp.push(this.getSequence());
        temp = temp.concat(Conversion.bytesFromInt(size, 4));
        temp = temp.concat(dataBytes);
        result = result.concat(Conversion.bytesFromInt(Conversion.crc(temp), 2));
    }
    result.push(this.getLast());
    return EscapeTool.escape(result);
};

Frame.prototype.setFirst = function (first) {
    this.first = first;
};

Frame.prototype.getFirst = function () {
    return this.first;
};

Frame.prototype.setLast = function (last) {
    this.last = last;
};

Frame.prototype.getLast = function () {
    return this.last;
};

Frame.prototype.setType = function (type) {
    this.type = type;
};

Frame.prototype.getType = function () {
    return this.type;
};

Frame.prototype.setSize = function (size) {
    this.size = size;
};

Frame.prototype.getSize = function () {
    return this.size;
};

Frame.prototype.setCrc = function (crc) {
    this.crc = crc;
};

Frame.prototype.getCrc = function () {
    return this.crc;
};

Frame.prototype.setSequence = function (sequence) {
    this.sequence = sequence;
};

Frame.prototype.getSequence = function () {
    return this.sequence;
};

Frame.prototype.setPayload = function (payload) {
    this.payload = payload;
};

Frame.prototype.getPayload = function () {
    return this.payload;
};