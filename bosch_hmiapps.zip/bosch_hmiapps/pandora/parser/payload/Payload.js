/**
 *
 * @type {*}
 */
var Payload = Class.extend({
    init:function (data) {
        this.command = resources.command.fromCode.UNKNOWN;
        this.raw = data;
		this.dirty = false;
        if (data && data.length > 0) {
            this.parse(data);
        }

		//reflectively override the setters to mark the dirty flag.
		var me = this;
		var methods = [];
		for (var m in me) {
			var o = me[m];
			if (typeof(o) == "function" && m.indexOf("set") == 0) {
				methods.push({name: m, method: o, source:me});
			}
		}

		for (var i = 0; i < methods.length; i++) {
			var result = methods[i];

			var aspect = function(result) {
				return function() {
					result.source.dirty = true;
					return result.method.apply(result.source, arguments);
				};
			}(result);

			me[result.name] = aspect;
		}
	},

	markAsDirty: function() {
		this.dirty = true;
	},

	parse:function (data) {
		var command = data[0];
        this.raw = data;
        this.command = command;
        this.commandName = resources.command.fromCode[command];
        return this;
    },
    getCommand:function () {
        return this.command;
    },
    setCommand:function (command) {
        this.command = command;
    },
    getCommandName:function () {
        return this.commandName;
    },

    //this is being used in Engine, so we have to put it here. Subclass will override this
    getTrackToken:function () {
        return null;
    },

	//go through all of the getters and build up a json data.
	toJSON: function() {
		var me = this;
		var methods = [];
		for (var m in me) {
			var o = me[m];
			if (typeof(o) == "function" && m.indexOf("get") == 0) {
				methods.push({name: m, method: o, source:me});
			}
		}

		var data = {};
		for (var i = 0; i < methods.length; i++) {
			var result = methods[i];
			data[result.name.slice(3)] = result.method.apply(result.source,null);
		}

		return data;
	},
	
    //return payload as a string
    //TODO implement other bases, only supports hex right now
    toString:function (base) {
        var payloadStr = "";
        var payloadBytes = this.toByte();
		for (var i = 0; i < payloadBytes.length; i += 1) {
    		if(base == 16) {
				payloadStr = payloadStr + payloadBytes[i].toString(16) + " ";
			}
		}
		return payloadStr;
	},
	
    //reconstruct the byte array.
    toByte:function () {
        if(this.dirty){
            return this.buildBytes();
        }
        if (this.raw && this.getCommand() != resources.command.fromCode.UNKNOWN) {
            this.raw[0] = this.getCommand();
            return this.raw;
        }
        return [];
    },

    buildBytes:function () {
        var result = new Array();
        result.push(this.getCommand());
        return result;
    }
});

Payload.factory = function (data) {
    var payload = new Payload(data);
    var command = payload.getCommand();
    switch (command) {
        case resources.command.toCode.PNDR_SESSION_START:
            return new SessionStartPayload(data);
        case resources.command.toCode.PNDR_RETURN_TRACK_TITLE:
            return new TrackTitlePayload(data);
        case resources.command.toCode.PNDR_RETURN_TRACK_ARTIST:
            return new TrackArtistPayload(data);
        case resources.command.toCode.PNDR_RETURN_TRACK_ALBUM:
            return new TrackAlbumPayload(data);
        case resources.command.toCode.PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT:
            return new TrackAlbumArtSegmentPayload(data);
        case resources.command.toCode.PNDR_RETURN_STATION_ART_SEGMENT:
            return new StationArtSegmentPayload(data);
        case resources.command.toCode.PNDR_RETURN_GENRE_STATION_ART_SEGMENT:
            return new GenreStationArtSegmentPayload(data);
        case resources.command.toCode.PNDR_RETURN_BRANDING_IMAGE_SEGMENT:
            return new BrandingArtSegmentPayload(data);
        case resources.command.toCode.PNDR_UPDATE_TRACK_ELAPSED:
            return new TrackElapsedPayload(data);
        case resources.command.toCode.PNDR_UPDATE_TRACK_ALBUM_ART:
            return new UpdateTrackAlbumArtPayload(data);
        case resources.command.toCode.PNDR_RETURN_TRACK_INFO:
            return new TrackInfoPayload(data);
        case resources.command.toCode.PNDR_RETURN_TRACK_INFO_EXTENDED:
            return new TrackInfoExtendedPayload(data);
        case resources.command.toCode.PNDR_EVENT_STATION_DELETE:
            return new StationDeletePayload(data);
        case resources.command.toCode.PNDR_EVENT_STATIONS_SORT:
            return new StationSortPayload(data);
        case resources.command.toCode.PNDR_RETURN_STATION_INFO:
            return new StationInfoPayload(data);
        case resources.command.toCode.PNDR_RETURN_STATION_COUNT:
            return new StationCountPayload(data);
        case resources.command.toCode.PNDR_RETURN_STATION_TOKENS:
            return new StationTokensPayload(data);
		case resources.command.toCode.PNDR_UPDATE_NOTICE:
		    return new UpdateNoticePayload(data);
		case resources.command.toCode.PNDR_UPDATE_STATUS:
		    return new UpdateStatusPayload(data);
		case resources.command.toCode.PNDR_RETURN_SEARCH_RESULT_INFO:
			return new SearchResultInfoPayload(data);
        case resources.command.toCode.PNDR_EVENT_STATION_SELECT:
            return new StationSelectPayload(data);
		case resources.command.toCode.PNDR_RETURN_GENRE_STATION_NAMES:
			return new GenreStationNamesPayload(data);
		case resources.command.toCode.PNDR_RETURN_GENRE_CATEGORY_NAMES:
			return new GenreCategoryNamesPayload(data);
		case resources.command.toCode.PNDR_EVENT_SELECT_GENRE_STATION:
			return new GenreStationSelectPayload(data);
		case resources.command.toCode.PNDR_UPDATE_STATION_ACTIVE:
			return new ReturnStationActivePayload(data);
		case resources.command.toCode.PNDR_RETURN_STATUS:
			return new ReturnStatusPayload(data);
		case resources.command.toCode.PNDR_RETURN_STATION_ACTIVE:
			return new ReturnStationActivePayload(data);
		case resources.command.toCode.PNDR_UPDATE_TRACK:
			return new UpdateTrackPayload(data);
		case resources.command.toCode.PNDR_UPDATE_STATION_DELETED:
			return new UpdateStationDeletedPayload(data);
		case resources.command.toCode.PNDR_UPDATE_SEARCH:
			return new UpdateSearchPayload(data);
		case resources.command.toCode.PNDR_UPDATE_STATION_ADDED:
			return new UpdateStationAddedPayload(data);
		case resources.command.toCode.PNDR_RETURN_TRACK_EXPLAIN_SEGMENT:
			return new ReturnTrackExplainSegmentPayload(data);
		case resources.command.toCode.PNDR_UPDATE_STATIONS_ORDER:
			return new UpdateStationsOrderPayload(data);
		case resources.command.toCode.PNDR_RETURN_STATIONS_ORDER:
			return new ReturnStationsOrderPayload(data);
		case resources.command.toCode.PNDR_UPDATE_TRACK_EXPLAIN:
			return new UpdateTrackExplainPayload(data);
		case resources.command.toCode.PNDR_UPDATE_TRACK_BOOKMARK_TRACK:
			return new UpdateTrackBookmarkPayload(data);
		case resources.command.toCode.PNDR_UPDATE_TRACK_BOOKMARK_ARTIST:
			return new UpdateTrackBookmarkPayload(data);
		case resources.command.toCode.PNDR_UPDATE_TRACK_RATING:
			return new UpdateTrackRatingPayload(data);
    }
    return payload;
};
