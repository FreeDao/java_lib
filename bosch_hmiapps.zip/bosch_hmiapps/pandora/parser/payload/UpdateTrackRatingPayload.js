var UpdateTrackRatingPayload = Payload.extend({
	init : function(data) {
		this._super(data);
	},
	parse : function(data) {
		this._super(data);

		this.trackToken = null;
		this.explain_length = null;
		return this;
	},
	getTrackToken : function() {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
		return this.trackToken;
	},
	getExplainLength : function(){
		if (!this.explain_length) {
			this.explain_length =  Conversion.intFromBytes(this.raw.slice(5, 9));
			console.log("getExplainLength -- >" + this.explain_length);
		}
		return this.explain_length;
	}
});
