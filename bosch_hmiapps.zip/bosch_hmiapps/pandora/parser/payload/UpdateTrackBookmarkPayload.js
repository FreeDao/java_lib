var UpdateTrackBookmarkPayload = Payload.extend({
	init : function(data) {
		this._super(data);
	},
	parse : function(data) {
		this._super(data);

		this.trackToken = null;
		this.is_bookmarked = false;
		return this;
	},
	getTrackToken : function() {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
		return this.trackToken;
	},
	getIsBookmarked : function() {
		this.is_bookmarked = this.raw[5];
		console.log("getIsBookmarked -- >" + this.is_bookmarked);
		return this.is_bookmarked;
	}
});
