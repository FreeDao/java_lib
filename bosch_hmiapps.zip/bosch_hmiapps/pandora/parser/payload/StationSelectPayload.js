var StationSelectPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);
		this.stationToken = null;

        return this;
    },
    getStationToken:function () {
		if (!this.stationToken) {
			var stationTokenBytes = this.raw.slice(1, 5);
			this.stationToken = Conversion.intFromBytes(stationTokenBytes);
		}
		return this.stationToken;
    },
	setStationToken:function(stationToken){
		this.stationToken = stationToken;
	},
	buildBytes:function () {
        var array = new Array();
        array.push(this.getCommand());
        array = array.concat(Conversion.bytesFromInt(this.getStationToken, 4));

        return array;
    }
});