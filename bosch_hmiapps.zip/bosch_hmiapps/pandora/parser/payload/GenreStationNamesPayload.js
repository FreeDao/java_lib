var GenreStationNamesPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);
		this.namesArray = new Array();

        return this;
    },
	getCategoryIndex:function() {
        return this.raw[1];
    },

    getStartIndex:function() {
        return this.raw[2];
    },

	getNamesArray:function() {
		if (this.namesArray.length == 0) {
			var namesBytes = this.raw.slice(3);

			var position = 0;
			while (position < namesBytes.length) {
				var name = "";
				for (var j = position; j < namesBytes.length; j++) {
					if (namesBytes[j] == 0) {
						break;
					}
					name += String.fromCharCode(namesBytes[j]);
				}
				this.namesArray.push(name);
				position += name.length + 1;
			}
		}
		return this.namesArray;
	}
});