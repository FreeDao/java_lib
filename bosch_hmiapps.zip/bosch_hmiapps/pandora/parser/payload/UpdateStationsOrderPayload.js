var UpdateStationOrderPayload = Payload.extend({
    init:function (data) {
        this._super(data);
        this.order = null;
    },
    parse:function (data) {
        this._super(data);
        return this;
    },
    getOrder:function () {
    	this.order = Conversion.intFromBytes(this.raw.slice(1));
    	console.log("UpdateStationOrderPayload.js:getOrder()-------->order:" + this.order);
        return this.order;
    }
});