var GetStationTokensPayload = Payload.extend({

    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_GET_STATION_TOKENS);
    },

    parse:function (data) {
        this._super(data);

		this.startIndex = data[1];
		this.count = data[2];

        return this;
    },

    buildBytes:function () {
        var result = new Array();
        result.push(this.getCommand());
		result = result.concat(Conversion.bytesFromInt(this.getStartIndex(), 1));
		result = result.concat(Conversion.bytesFromInt(this.getCount(), 1));

        return result;
    },

    getStartIndex:function () {
        return this.startIndex;
    },
    setStartIndex: function(startIndex){
        this.startIndex = startIndex;
    },

	getCount:function () {
        return this.count;
    },
    setCount: function(count){
        this.count = count;
    }
});