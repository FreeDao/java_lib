var EventTrackSkipPayload = Payload.extend({

    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_EVENT_TRACK_SKIP);
    }

});