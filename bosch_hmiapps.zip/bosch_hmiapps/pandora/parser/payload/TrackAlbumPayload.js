var TrackAlbumPayload = Payload.extend({
	init:function (data) {
		this._super(data);
	},
	parse:function (data) {
		this._super(data);
		this.trackToken = null;
		this.albumName = null;

		return this;
	},
	getTrackToken:function () {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
		return this.trackToken;
	},
	setTrackToken: function(token) {
		this.trackToken = token;
	},
	getAlbumName:function () {
		if (!this.albumName) {
			var albumNameBytes = this.raw.slice(5);
			var albumName = "";
			for (var j = 0; j < albumNameBytes.length; j++) {
				albumName = albumName + String.fromCharCode(albumNameBytes[j]);
			}
			this.albumName = albumName;
		}
		return this.albumName;
	},
	setAlbumName:function (name) {
		this.albumName = name;
	},
	buildBytes: function() {
		var result = new Array();
		result.push(this.getCommand());
		result = result.concat(Conversion.bytesFromInt(this.getTrackToken(), 4));
		for (var j = 0; j < this.getAlbumName().length; j++) {
			result = result.concat(this.getAlbumName().charCodeAt(j));
		}
		result = result.concat(0);
		return result;
	}
});