var GenreStationArtSegmentPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.artLength = null;
		this.imageData = null;
    },
	parse: function(data){
		this._super(data);

		return this;
	},	
    getStationToken:function () {
        return this.raw.slice(1,2) * 1000 + this.raw.slice(2,3);
    },
    getCategoryIndex:function () {
        return this.raw.slice(1,2);
    },
    getStationIndex:function () {
        return this.raw.slice(2,3);
    },
    getSegmentIndex:function () {
        return this.raw[7];
    },
    getTotalSegments:function () {
        return this.raw[8];
    },
    getArtLength:function () {
		if (!this.artLength){
			this.artLength = Conversion.intFromBytes(this.raw.slice(3, 7));
		}
        return this.artLength;
    },
	getImageData:function () {
		if (!this.imageData) {
			var imageData = "";
			var imageDataBytes = this.raw.slice(9);
			for (var j = 0; j < imageDataBytes.length; j++) {
				imageData = imageData + String.fromCharCode(imageDataBytes[j]);
			}
			this.imageData = imageData;
		}
		return this.imageData;
	}
});