var GenreStationSelectPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);

		this.categoryIndex = data[1];
		this.stationIndex = data[2];
        return this;
    },
	getCategoryIndex:function() {
        return this.categoryIndex;
    },

    getStationIndex:function() {
        return this.stationIndex;
    }
});