var UpdateNoticePayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);

        this.code =  data[1];
        return this;
    },
    getCode:function () {
        return this.code;
    },
	getNotice:function () {
		return resources.getStringForCode(resources.notice, this.code);
    }
});