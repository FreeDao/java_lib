var GenreCategoryNamesPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);
		this.namesArray = new Array();
        return this;
    },

    getStartIndex:function() {
        return this.raw[1];
    },

	getNamesArray:function() {
		if (this.namesArray.length == 0) {
			var namesBytes = this.raw.slice(2);
			var position = 0;
			while (position < namesBytes.length) {
				var name = "";
				for (var j = position; j < namesBytes.length; j++) {
					if (namesBytes[j] == 0) {
						break;
					}
					name += String.fromCharCode(namesBytes[j]);
				}
				this.namesArray.push(name);
				position += name.length + 1;
			}
		}
		return this.namesArray;
	}
});