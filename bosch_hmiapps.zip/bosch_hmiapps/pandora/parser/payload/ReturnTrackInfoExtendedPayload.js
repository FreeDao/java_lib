var ReturnTrackInfoExtendedPayload = ReturnTrackInfoPayload.extend({
	init:function (data) {
		this._super(data);
		this.setCommand(resources.command.toCode.PNDR_RETURN_TRACK_INFO_EXTENDED);
	},
	parse:function (data) {
		this._super(data);
		this.parsed = false;
		return this;
	},

	parsePayload: function(data) {
		var state = 0;
		var extendedBytes = data.slice(16, data.length);
		var temp = "";
		for (var j = 0; j < extendedBytes.length; j++) {
			if (extendedBytes[j] == 0) {
				if (state == 0) {
					this.trackName = temp;
				} else if (state == 1) {
					this.artistName = temp;
				} else {
					this.albumName = temp;
				}
				state++;
				temp = "";
			} else {
				temp = temp + String.fromCharCode(extendedBytes[j]);
			}
		}
		this.parsed = true;
	},

	getText: function() {
		if (!this.parsed) {
			this.parsePayload(this.raw);
		}
		return this.text;
	},

	setText: function(text) {
		this.text = text;
	},

	getTrackName: function() {
		if (!this.parsed) {
			this.parsePayload(this.raw);
		}
		return this.trackName;
	},

	setTrackName: function(name) {
		this.trackName = name;
	},

	getAlbumName: function() {
		if (!this.parsed) {
			this.parsePayload(this.raw);
		}
		return this.albumName;
	},

	setAlbumName: function(name) {
		this.albumName = name;
	},

	getArtistName: function() {
		if (!this.parsed) {
			this.parsePayload(this.raw);
		}
		return this.artistName;
	},

	setArtistName: function(name) {
		this.artistName = name;
	},

	buildBytes:function () {
		var result = this._super();

		//TODO check with UTF8
		for (var j = 0; j < this.getTrackName().length; j++) {
			result = result.concat(this.getTrackName().charCodeAt(j));
		}
		result = result.concat(0);
		for (var j = 0; j < this.getArtistName().length; j++) {
			result = result.concat(this.getArtistName().charCodeAt(j));
		}
		result = result.concat(0);
		for (var j = 0; j < this.getAlbumName().length; j++) {
			result = result.concat(this.getAlbumName().charCodeAt(j));
		}
		result = result.concat(0);
		return result;
	}

});