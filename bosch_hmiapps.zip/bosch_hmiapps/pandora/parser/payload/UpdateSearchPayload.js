var UpdateSearchPayload = Payload.extend({
	init : function(data) {
		this._super(data);
	},
	parse : function(data) {
		this._super(data);
		this.searchId = null;
		this.music_tokens = [];

		return this;
	},
	getSearchId : function() {
		if (!this.searchId) {
			var searchIdBytes = this.raw.slice(1, 5);
			this.searchId = Conversion.intFromBytes(searchIdBytes);
			/*
			 for (var j = 0; j < searchIdBytes.length; j++) {
			 this.searchId = this.searchId + String.fromCharCode(searchIdBytes[j]);
			 }*/
		}
		return this.searchId;
	},
	getMusicTokens : function() {
		//Lee
		var position = 5;
		while (position < this.raw.length) {
			var fourBytes = this.raw.slice(position, position + 4);
			var musicToken = Conversion.intFromBytes(fourBytes);
			this.music_tokens.push(musicToken);
			position = position + 5;
		}
		console.log("UpdateSearchPayload.js:getMusicTokens()--------->music_tokens[]:" + music_tokens);
		return this.music_tokens;
	}
}); 