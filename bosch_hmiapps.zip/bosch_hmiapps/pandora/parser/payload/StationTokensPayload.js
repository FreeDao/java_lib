var StationTokensPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);

        this.stationTokens = new Array();

        return this;
    },

    getStartIndex:function () {
        return this.raw[1];
    },
    setStartIndex:function (startIndex) {
        this.startIndex = startIndex;
    },
    getStationTokens:function () {
		if (this.stationTokens.length == 0) {
			for (var i = 2; i < this.raw.length; i += 4) {
				this.stationTokens.push(Conversion.intFromBytes(this.raw.slice(i, i + 4)));
			}
		}
		return this.stationTokens;
    },
    buildBytes:function () {
        var array = new Array();
        array.push(this.getCommand());
        array.push(this.getStartIndex());

        for (var i = 0; i < this.getStationTokens().length; i++) {
            array = array.concat(Conversion.bytesFromInt(this.getStationTokens()[i], 4));
        }

        return array;
    }
});