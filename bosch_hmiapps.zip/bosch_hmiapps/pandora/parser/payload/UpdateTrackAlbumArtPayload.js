var UpdateTrackAlbumArtPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);

		this.trackToken = null;
		this.albumArtLength = null;

        return this;
    },
    getTrackToken:function () {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
        return this.trackToken;
    },

	getAlbumArtLength:function () {
		if (!this.albumArtLength) {
			var albumArtLengthBytes = this.raw.slice(5, 9);
			this.albumArtLength = Conversion.intFromBytes(albumArtLengthBytes);
		}
        return this.albumArtLength;
    }
});