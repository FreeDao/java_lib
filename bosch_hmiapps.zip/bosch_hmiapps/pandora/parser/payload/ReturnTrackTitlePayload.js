var ReturnTrackTitlePayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_RETURN_TRACK_TITLE);
    },
    parse:function (data) {
        this._super(data);
		this.trackToken = null;
		this.trackName = null;

        return this;
    },
    getTrackToken:function () {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
        return this.trackToken;
    },
    getTrackName:function () {
		if (!this.trackName) {
			var trackNameBytes = this.raw.slice(5);
			var trackName = "";
			for (var j = 0; j < trackNameBytes.length; j++) {
				trackName = trackName + String.fromCharCode(trackNameBytes[j]);
			}
			this.trackName = trackName;
		}
        return this.trackName;
    },
	setTrackName: function(name){
		this.trackName = name;
	},
	setTrackToken: function(name){
		this.trackToken = name;
	},
	buildBytes: function() {
		var result = new Array();
        result.push(this.getCommand());
		result = result.concat(Conversion.bytesFromInt(this.getTrackToken(), 4));
		for (var j = 0; j < this.getTrackName().length; j++) {
			result = result.concat(this.getTrackName().charCodeAt(j));
		}
		result = result.concat(0);
		return result;
	}
});