var TrackInfoPayload = Payload.extend({
	init:function (data) {
		this._super(data);
	},
	parse:function (data) {
		this._super(data);
		this.version = 1;
		this.trackToken = null;
		this.albumArtLength = null;
		this.duration = null;
		this.elapsed = null;
		this.rating = null;
		this.clearAlbumArtLength = false;

		this.rating = data[13];

		this.permissionFlags = 31;
		this.identityFlags = 0;

		if (data.length > 15) {
			this.version = 3;
			this.permissionFlags = data[14];
			this.identityFlags = data[15];
		}

		return this;
	},

	getTrackToken:function () {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
		return this.trackToken;
	},

	getAlbumArtLength:function () {
		if (this.clearAlbumArtLength){
			return 0;
		}
		if (!this.albumArtLength) {
			//album art length
			var albumArtLengthBytes = this.raw.slice(5, 9);
			this.albumArtLength = Conversion.intFromBytes(albumArtLengthBytes);
		}
		return this.albumArtLength;
	},

	setClearAlbumArtLength: function(flag){
	    this.clearAlbumArtLength = flag;
	},

	setAlbumArtLength:function (length) {
		this.albumArtLength = length;
	},

	getDuration:function () {
		if (!this.duration) {
			var durationBytes = this.raw.slice(9, 11);
			this.duration = Conversion.intFromBytes(durationBytes);
		}
		return this.duration;
	},

	getElapsed:function () {
		if (!this.elapsed) {
			var elapsedBytes = this.raw.slice(11, 13);
			this.elapsed = Conversion.intFromBytes(elapsedBytes);
		}
		return this.elapsed;
	},

	getRating:function () {
		return this.rating;
	},

	getRatingString:function() {
		return resources.getStringForCode(resources.track.rating, this.rating);
	},

	getPermissionFlags:function () {
		return this.permissionFlags;
	},

	getPermissionStrings:function() {
		return resources.getStringsForBitmask(resources.track.permissionflag, this.permissionFlags);
	},

	getIdentityFlags:function () {
		return this.identityFlags;
	},

	getIdentityStrings:function() {
		return resources.getStringsForBitmask(resources.track.identityflag, this.identityFlags);
	},

	setRating:function(rating) {
		this.rating = rating;
	},

	setPermissionFlags:function(flags) {
		if (flags.length == 0) {
			return;
		}
		this.permissionFlags = flags[0];
		for (var j = 1; j < flags.length; j++) {
			this.permissionFlags = this.permissionFlags + flags[j];
		}
	},

	setIdentityFlags:function(flags) {
		if (flags.length == 0) {
			return;
		}
		this.identityFlags = flags[0];
		for (var j = 1; j < flags.length; j++) {
			this.identityFlags = this.identityFlags + flags[j];
		}
	},

	buildBytes:function () {
		var result = new Array();
		result.push(this.getCommand());
		result = result.concat(Conversion.bytesFromInt(this.getTrackToken(), 4));

		result = result.concat(Conversion.bytesFromInt(this.getAlbumArtLength(), 4));
		result = result.concat(Conversion.bytesFromInt(this.getDuration(), 2));
		result = result.concat(Conversion.bytesFromInt(this.getElapsed(), 2));
		result.push(this.getRating());
		result.push(this.getPermissionFlags());
		result.push(this.getIdentityFlags());
		return result;
	}

});