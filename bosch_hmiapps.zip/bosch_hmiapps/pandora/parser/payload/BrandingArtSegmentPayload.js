var BrandingArtSegmentPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);
		this.imageData = null;

        return this;
    },
    getSegmentIndex:function () {
        return this.raw[1];
    },
    getTotalSegments:function () {
        return this.raw[2];
    },
    getImageData:function () {
		if (!this.imageData) {
			var imageData = "";
			var imageDataBytes = this.raw.slice(3);
			for (var j = 0; j < imageDataBytes.length; j++) {
				imageData = imageData + String.fromCharCode(imageDataBytes[j]);
			}
			this.imageData = imageData;
		}
        return this.imageData;
    }
});