var StationDeletePayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);
		this.stationToken = null;

        return this;
    },
    getStationToken:function () {
		if (!this.stationToken) {
			var stationTokenBytes = this.raw.slice(1, 5);
			this.stationToken = Conversion.intFromBytes(stationTokenBytes);
		}
        return this.stationToken;
    }
	
});