var SetTrackElapsedPollingPayload = Payload.extend({

    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_SET_TRACK_ELAPSED_POLLING);
    }

});