var TrackArtistPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);
		this.trackToken = null;
		this.artistName = null;

        return this;
    },
    getTrackToken:function () {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
		return this.trackToken;
    },
	setTrackToken: function(name){
		this.trackToken = name;
	},
	getArtistName:function () {
		if (!this.artistName) {
			var artistNameBytes = this.raw.slice(5);
			var artistName = "";
			for (var j = 0; j < artistNameBytes.length; j++) {
				artistName = artistName + String.fromCharCode(artistNameBytes[j]);
			}
			this.artistName = artistName;
		}
		return this.artistName;
	},
    setArtistName:function (name) {
        this.artistName = name;
    },
	buildBytes: function() {
		var result = new Array();
        result.push(this.getCommand());
		result = result.concat(Conversion.bytesFromInt(this.getTrackToken(), 4));
		for (var j = 0; j < this.getArtistName().length; j++) {
			result = result.concat(this.getArtistName().charCodeAt(j));
		}
		result = result.concat(0);
		return result;
	}
});