var ReturnStationsOrderPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_RETURN_STATIONS_ORDER);
    },
    parse:function (data) {
        this._super(data);

        return this;
    },
    getType: function(){
        return this.raw[1];
    }
});