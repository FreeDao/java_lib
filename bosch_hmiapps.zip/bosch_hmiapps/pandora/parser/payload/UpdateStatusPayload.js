var UpdateStatusPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);

        this.code = data[1];
        return this;
    },
    getCode:function () {
        return this.code;
    },
    setCode:function (code) {
        this.code = code;
    },
    getStatus:function () {
		return resources.getStringForCode(resources.status, this.code);
    },
    
    buildBytes:function () {
        var result = new Array();
        result.push(this.getCommand());
        result.push(this.getCode());
        return result;
    }
});