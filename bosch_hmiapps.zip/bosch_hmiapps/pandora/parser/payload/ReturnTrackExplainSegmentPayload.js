var ReturnTrackExplainSegmentPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.trackToken = null;
		this.data = null;
    },
	parse: function(data){
		this._super(data);
		
		return this;
	},
	getTrackToken:function () {
		if (!this.trackToken){
			this.trackToken = Conversion.intFromBytes(this.raw.slice(1,5));
		}
        return this.trackToken;
    },
    getSegmentIndex:function () {
        return this.raw[5];
    },
    getTotalSegments:function () {
        return this.raw[6];
    },
	getData:function () {
		if (!this.data) {
			var data = "";
			var dataBytes = this.raw.slice(7);
			for (var j = 0; j < dataBytes.length; j++) {
				data = data + String.fromCharCode(dataBytes[j]);
			}
			this.data = data;
		}
		console.log("ReturnTrackExplainSegmentPayload.js:getData()-------->this.data:" + this.data);
		return this.data;
	}
});