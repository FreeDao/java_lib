var UpdateStationDeletedPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_UPDATE_STATION_DELETED);
    },
    parse:function (data) {
        this._super(data);
		this.stationToken = null;

        return this;
    },
    getStationToken:function () {
		if (!this.stationToken) {
			var stationTokenBytes = this.raw.slice(1, 5);
			this.stationToken = Conversion.intFromBytes(stationTokenBytes);
		}
        return this.stationToken;
    }
	
});