var ReturnSearchResultInfoPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_RETURN_SEARCH_RESULT_INFO);
    },
    parse:function (data) {
        this._super(data);
		this.searchResult = new Array();
		this.searchId = null;

        return this;
    },
	getSearchId:function () {
		if (!this.searchId) {
			var searchIdBytes = this.raw.slice(1, 5);
			this.searchId = "";
			for (var j = 0; j < searchIdBytes.length; j++) {
				this.searchId = this.searchId + String.fromCharCode(searchIdBytes[j]);
			}
		}
		
		return this.searchId;
	},

	getSearchResult:function () {
		if (this.searchResult.length == 0) {
			var position = 5;
			var resultArray = new Array();
			while (position < this.raw.length) {
				var fourBytes = this.raw.slice(position, position + 4);
				var musicToken = Conversion.intFromBytes(fourBytes);
				var type = this.raw[position + 4];
				var restOfBytes = this.raw.slice(position + 5);
				var description = "";
				var descLength = 0;
				for (var j = 0; j < restOfBytes.length; j++) {
					if (restOfBytes[j] == 0) {
						break;
					}
					description += String.fromCharCode(restOfBytes[j]);
					descLength++;
				}
				resultArray.push({musicToken: musicToken,type: type,description: description});
				position = position + descLength + 1 + 5;
			}
			this.searchResult = resultArray;
		}
        return this.searchResult;
    }
});