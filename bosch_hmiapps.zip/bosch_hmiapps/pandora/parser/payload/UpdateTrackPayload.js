var UpdateTrackPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_UPDATE_TRACK);
    },
    parse:function (data) {
        this._super(data);

        var trackTokenBytes = data.slice(1, 5);
		this.trackToken = Conversion.intFromBytes(trackTokenBytes);
        return this;
    },
    getTrackToken:function () {
        if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
        return this.trackToken;
    },
    setTrackToken:function (trackToken) {
        this.trackToken = trackToken;
    },
    
    buildBytes:function () {
        var result = new Array();
		result.push(this.getCommand());
        result = result.concat(Conversion.bytesFromInt(this.getTrackToken(), 4));
        return result;
    }
});