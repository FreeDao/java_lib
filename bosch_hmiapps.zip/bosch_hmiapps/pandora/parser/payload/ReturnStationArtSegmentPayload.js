var ReturnStationArtSegmentPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_RETURN_STATION_ART_SEGMENT);
		this.stationToken = null;
		this.artLength = null;
		this.imageData = null;
    },
	parse: function(data){
		this._super(data);

		return this;
	},
	getStationToken:function () {
		if (!this.stationToken){
			this.stationToken = Conversion.intFromBytes(this.raw.slice(1,5));
		}
        return this.stationToken;
    },
    getSegmentIndex:function () {
        return this.raw[9];
    },
    getTotalSegments:function () {
        return this.raw[10];
    },
    getArtLength:function () {
		if (this.artLength){
			 this.artLength = Conversion.intFromBytes(this.raw.slice(5, 9));
		}
        return this.artLength;
    },
    getImageData:function () {
		if (!this.imageData) {
			var imageData = "";
			var imageDataBytes = this.raw.slice(11);
			for (var j = 0; j < imageDataBytes.length; j++) {
				imageData = imageData + String.fromCharCode(imageDataBytes[j]);
			}
			this.imageData = imageData;
		}
		return this.imageData;
	}
});