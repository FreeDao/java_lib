var SessionStartPayload = Payload.extend({

    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_SESSION_START);
    },

    parse:function (data) {
        this._super(data);

        var firstTwoBytes = data.slice(1, 3);
        this.apiVersion = Conversion.intFromBytes(firstTwoBytes);
        var accessoryBytes = data.slice(3, 11);
        var accessory = "";
        for (var i = 0; i < accessoryBytes.length; i++) {
            accessory = accessory + String.fromCharCode(accessoryBytes[i]);
        }
        this.accessoryId = accessory;

        var albumArtSizeArray = data.slice(11, 13);
        this.albumArtSize = Conversion.intFromBytes(albumArtSizeArray);

        this.imageType = Number(data[13]);

        this.flags = data[14];

        if (this.apiVersion == 3) {
            var stationArtDimensionArray = data.slice(15);
            this.stationArtDimension = Conversion.intFromBytes(stationArtDimensionArray);
        }
        return this;
    },

    buildBytes:function () {
        var result = new Array();
        result.push(this.getCommand());
        if (this.getApiVersion()) {
            result = result.concat(Conversion.bytesFromInt(this.getApiVersion(), 2));
        }
        var accessoryId = this.getAccessoryId();
        //8 character
        for (var i = 0; i < accessoryId.length; i++) {
            result.push(accessoryId[i].charCodeAt(0)); //no double byte.
        }
        result = result.concat(Conversion.bytesFromInt(this.getAlbumArtSize(), 2));
        result.push(this.getImageType());
        result.push(this.getFlags());
        if (this.getStationArtDimension()) {
            result = result.concat(Conversion.bytesFromInt(this.getStationArtDimension(), 2));
        }
        return result;
    },

    getApiVersion:function () {
        return this.apiVersion;
    },
    setApiVersion: function(version){
        this.apiVersion = version;
    },
    getAccessoryId:function () {
        return this.accessoryId;
    },
    setAccessoryId:function (accessoryId) {
        this.accessoryId = accessoryId;
    },
    getAlbumArtSize:function () {
        return this.albumArtSize;
    },
    setAlbumArtSize:function (albumArtSize) {
        this.albumArtSize = albumArtSize;
    },
    getStationArtDimension:function () {
        return this.stationArtDimension;
    },
    setStationArtDimension:function (stationArtDimension) {
        this.stationArtDimension = stationArtDimension;
    },
    getFlags:function () {
        return this.flags;
    },
    setFlags:function (flags) {
        this.flags = flags;
    },
    getImageType:function () {
        return this.imageType;
    },
	setImageType: function(imageType){
		this.imageType = imageType;
	}
});