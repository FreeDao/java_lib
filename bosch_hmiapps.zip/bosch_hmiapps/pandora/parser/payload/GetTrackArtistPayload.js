var GetTrackArtistPayload = Payload.extend({

    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_GET_TRACK_ARTIST);
    }

});