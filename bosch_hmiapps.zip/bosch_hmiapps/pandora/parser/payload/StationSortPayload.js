var StationSortPayload = Payload.extend({
    init:function (data) {
        this._super(data);
    },
    parse:function (data) {
        this._super(data);

        return this;
    },
    getType: function(){
        return this.raw[1];
    }
});