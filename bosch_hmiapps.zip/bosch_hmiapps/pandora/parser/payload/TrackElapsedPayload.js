var TrackElapsedPayload = Payload.extend({
	init:function (data) {
		this._super(data);
	},
	parse:function (data) {
		this._super(data);
		this.trackToken = null;
		this.timeElapsed = null;

		return this;
	},
	getTrackToken:function () {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
		return this.trackToken;
	},
	getTimeElapsed:function () {
		if (!this.timeElapsed) {
			this.timeElapsed = Conversion.intFromBytes(this.raw.slice(5));
		}
		return this.timeElapsed;
	}
});