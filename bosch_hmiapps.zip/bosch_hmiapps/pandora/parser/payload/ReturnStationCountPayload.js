var ReturnStationCountPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_RETURN_STATION_COUNT);
    },
    parse:function (data) {
        this._super(data);
        this.count = data[1];
        return this;
    },
    getCount:function () {
        return this.count;
    },
    setCount:function (count) {
        this.count = count;
    },
	buildBytes:function () {
        var array = new Array();
        array.push(this.getCommand());
        array.push(this.getCount());
        return array;
    }
});