var UpdateTrackExplainPayload = Payload.extend({
	init : function(data) {
		this._super(data);
	},
	parse : function(data) {
		this._super(data);

		this.trackToken = null;
		this.explainLength = null;
		return this;
	},
	getTrackToken : function() {
		if (!this.trackToken) {
			var trackTokenBytes = this.raw.slice(1, 5);
			this.trackToken = Conversion.intFromBytes(trackTokenBytes);
		}
		return this.trackToken;
	},
	getExplainLength : function(){
		if (!this.explainLength) {
			this.explainLength = Conversion.intFromBytes(this.raw.slice(5, 9));
			console.log("getTrackRating -- >" + this.explainLength);
		}
		return this.explainLength;
	}
});
