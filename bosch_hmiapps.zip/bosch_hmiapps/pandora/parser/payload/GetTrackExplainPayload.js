var GetTrackExplainPayload = Payload.extend({

    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_GET_TRACK_EXPLAIN);
    },

    parse:function (data) {
        this._super(data);

        var maxPayloadLengthBytes = data.slice(1, 5);
        this.maxPayloadLength = Conversion.intFromBytes(maxPayloadLengthBytes);

        return this;
    },

    buildBytes:function () {
        var result = new Array();
        result.push(this.getCommand());
        result = result.concat(Conversion.bytesFromInt(this.getMaxPayloadLength(), 4));

        return result;
    },

    getMaxPayloadLength:function () {
        return this.maxPayloadLength;
    },
    setMaxPayloadLength: function(maxPayloadLength){
        this.maxPayloadLength = maxPayloadLength;
    }
});