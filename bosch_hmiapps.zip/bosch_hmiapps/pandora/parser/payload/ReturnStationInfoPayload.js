var ReturnStationInfoPayload = Payload.extend({
    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_RETURN_STATION_INFO);
		this.version = 3;
		this.parsed = false;
    },

    parse:function (data) {
        this._super(data);

        this.stations = new Array();

        return this;
    },

    getFirstStationInfo:function () {
		if(!this.parsed){
			this.parseStationInfoPayload(this.raw);
		}
		
        if (this.stations && this.stations.length > 0) {
            return this.stations[0];
        }
        return {};
    },

    getStationInfoList:function () {
		if (!this.parsed) {
			this.parseStationInfoPayload(this.raw);
		}
		return this.stations;
	},

	parseStationInfoPayload: function(data) {

		var handleStationToken = function (counter, data, station) {
			var bytes = data.slice(counter, counter + 4);
			station["stationToken"] = Conversion.intFromBytes(bytes);
			return counter + 4;
		};

		var handleFlags = function (counter, data, station) {
			station["flags"] = data[counter];
			return counter + 1;
		};

		var handleStationName = function (counter, data, station) {
			var name = "";
			for (var i = counter; i < data.length; i++) {
				if (data[i] == 0) {
					break;
				}
				name += String.fromCharCode(data[i]);
			}
			if (name.length == 248) {
				this.version = 1;
			}
			station["stationName"] = name;
			return counter + (name.length + 1); //include the null terminated character 0
		};

		var counter = 1; //skip the first byte.
		while (counter < data.length) {
			var station = {};
			counter = handleStationToken(counter, data, station);
			counter = handleFlags(counter, data, station);
			counter = handleStationName(counter, data, station);
			this.stations.push(station);
		}
		this.parsed = true;
	},

	buildBytes :function () {
		var result = new Array();
		result.push(this.getCommand());

		var stations = this.getStationInfoList();

		for (var j = 0; j < stations.length; j++) {
			result = result.concat(Conversion.bytesFromInt(stations[j]['stationToken'], 4));

			result = result.concat(Conversion.bytesFromInt(stations[j]['flags'],1));
			
			for (var n = 0; n < stations[j]['stationName'].length; n++) {
				result = result.concat(stations[j]['stationName'].charCodeAt(n));
			}
			result = result.concat(0);
//			if (this.version == 1){
//				for (var r = this.stations[j]['stationName'].length; r < 285; r++) {
//					result = result.concat(Conversion.bytesFromInt(0));
//				}
//			}

		}
        return result;
    }
});