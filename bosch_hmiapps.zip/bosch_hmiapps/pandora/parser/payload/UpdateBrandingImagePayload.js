var UpdateBrandingImagePayload = Payload.extend({

    init:function (data) {
        this._super(data);
		this.setCommand(resources.command.toCode.PNDR_UPDATE_BRANDING_IMAGE);
    },

    parse:function (data) {
        this._super(data);

        var imageLengthBytes = data.slice(1, 5);
        this.imageLength = Conversion.intFromBytes(imageLengthBytes);

        return this;
    },

    buildBytes:function () {
        var result = new Array();
        result.push(this.getCommand());
        result = result.concat(Conversion.bytesFromInt(this.getImageLength(), 4));

        return result;
    },

    getImageLength:function () {
        return this.imageLength;
    },
    setImageLength: function(imageLength){
        this.imageLength = imageLength;
    }
});