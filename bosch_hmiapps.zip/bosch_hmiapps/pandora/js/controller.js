var root = this;

$(function() {

	var curSelectStation = "";
	var nowPlayingStation = "";

	/* Controller - Header */
	Pandora.Header = can.Control({
		defaults : {}
	}, {
		_header : null,
		init : function() {
			var that = this;
			if (!that._header)
				that._header = new can.Observe({
					title : nowPlayingStation,
					icon : "RESERVED for icon url or anything else"
				});
			$('#header').html(can.view("pandora/views/header-views/now_playing.ejs", {
				data : that._header
			}));
		},
		updateTitle : function(title) {
			this._header.attr("title", title);
		},
		"#header-title click" : function() {
			this.updateTitle(nowPlayingStation);
			pagecontent.showPlayerPage();
		}
	});

	/* Controller - PageContent */
	Pandora.Pagecontent = can.Control({
		/** @Static */
		defaults : {
			submenu : [ 
				$.t('submenu_changeStation'), 
				$.t('submenu_trackInfo'), 
				$.t('submenu_newStationFromTrack'), 
				$.t('submenu_newStationFromArtist'), 
				$.t('submenu_bookmarkThisTrack'), 
				$.t('submenu_bookmarkThisArtist'), 
				$.t('submenu_deleteCurrentStation') ],
				
			stationsListMenu : [
				$.t('stationsListMenu_NewStation'),
				$.t('stationsListMenu_DeleteStation'),
				$.t('stationsListMenu_SortByDate') ],
				
			sortOptions : [
				$.t('sortOptions_sortStationsByDate'),
				$.t('sortOptions_sortStationsByAZ') ],
			
			userStationsBeginAt : 4,
		},
		
		deleteSeed : null,
		deleteStation : null,
		cfmBookMarkArt : $.t('cfmBookMarkArt'),
		cfmBookMarkTrk : $.t('cfmBookMarkTrk'),
		cfmDelStation : $.t('cfmDelStation'),
		cfmDeleting : $.t('cfmDeleting'),
		cfmNewStationArt : $.t('cfmNewStationArt'),
		cfmNewStationTrk : $.t('cfmNewStationTrk'),
		cfmNoStation : $.t('cfmNoStation'),
	}, {
		_curSongInfo : null,
		_stationList : null,
		init : function(element, options) {
			pandora._connect();
			this.registerHandler();
			pandora.sessionStart();
			this.initApp();
			$('#header').show();
			this.showPlayerPage();
		},
		initApp : function() {
			pandora.getStatus();
			pandora.getStationCount();
			pandora.getAllStationTokens();
			pandora.getStationActive();
		},
		showPlayerPage : function() {
			var that = this;
			if (!that._curSongInfo)
				that._curSongInfo = new can.Observe({
					title : Pandora.Models.RESP.getTrackInfoExt().title ? null : $.t('playerTitle'),
					artist : Pandora.Models.RESP.getTrackInfoExt().artist ? null : $.t('playerArtist'),
					album : Pandora.Models.RESP.getTrackInfoExt().album ? null : $.t('playerAlbum'),
					duration : Pandora.Models.RESP.getTrackInfoExt().duration ? null : "0:00",
					elapsed : Pandora.Models.RESP.getTrackInfoExt().elapsed ? null : "0:00",
					rating : Pandora.Models.RESP.getTrackInfoExt().rating ? null : -1,
					image : Pandora.Models.RESP.getTrackImage() ? null : "",
					desc : Pandora.Models.RESP.getTrackDescription(),
					isplay : Pandora.Models.RESP.getPlayStatus()
				});
			$('#header').show();
			$('#pagecontent').html(can.view('pandora/views/pagecontent-views/now_playing.ejs', {
				data : that._curSongInfo
			}));
			initPlayPauseButton();
		},

		showEditListPage : function() {
			console.log("station list : " + Pandora.Models.RESP.getStations());
			$('#pagecontent').html(can.view('pandora/views/pagecontent-views/station_list_edit.ejs', {
				"data" : this._stationList
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
			header.updateTitle($.t('headerDeleteStations'));
		},

		/* PLAY OR PAUSE */
		"#nowplaying-play-or-pause click" : function() {
			if (Pandora.Models.RESP.getPlayStatus()) {
				pandora.setTrackElapsedPolling();
				pandora.eventTrackPause();
			} else {
				pandora.eventTrackPlay();
			}
			Pandora.Models.RESP.setPlayStatus(!Pandora.Models.RESP.getPlayStatus());
			initPlayPauseButton();
		},

		/* Thumbs Down */
		"#nowplaying-thumbs-up click" : function() {
			pandora.eventTrackRatePositive();
		},

		/* Thumbs Down */
		"#nowplaying-thumbs-down click" : function() {
			pandora.eventTrackRateNegative();
		},

		/* CURRENT PLAYING STATION ITEM  */
		".station-list .radio .list-text click" : function(el) {
			var sToken = el.parent().attr("id");
			console.log("You want to change to play this station: " + sToken);
			if (sToken) {
				pandora.eventStationSelect(sToken);
			}
		},

		/* SORT OPTIONS */
		"#sort_by_date_or_a-z click" : function() {
			this.element.html(can.view('pandora/views/pagecontent-views/sort.ejs', {
				"data" : Pandora.Pagecontent.defaults.sortOptions
			}));
			header.updateTitle(header.updateTitle($.t('headerSortingOptions')));
		},

		".sort_stations_by_date click" : function() {
			pandora.eventStationsSort(0x00);
		},

		".sort_stations_by_a-z click" : function() {
			pandora.eventStationsSort(0x01);
		},

		/* NEW STATIONS */
		".new_station_from_track click" : function() {
			this.overlay("popup.ejs", {
				confirm : Pandora.Pagecontent.cfmNewStationTrk,
				btn_1_class : "visible",
				btn_2_class : "visible",
				btn_1 : "confirm-ns-track-yes",
				btn_2 : "confirm-ns-track-no",
			});
		},

		"#confirm-ns-track-yes click" : function() {
			var _this = this;
			$('#overlay-container').slideUp(500, function() {
			});
			pandora.eventStationCreateFromCurrentTrack();
			setTimeout(function() {
				_this.init();
				header.updateTitle(nowPlayingStation);
			}, 2000);
		},
		".new_station_from_artist click" : function() {
			this.overlay("popup.ejs", {
				confirm : Pandora.Pagecontent.cfmNewStationArt,
				btn_1_class : "visible",
				btn_2_class : "visible",
				btn_1 : "confirm-ns-artist-yes",
				btn_2 : "confirm-ns-artist-no",
			});
		},
		"#confirm-ns-artist-yes click" : function() {
			var _this = this;
			$('#overlay-container').slideUp(500, function() {
			});
			pandora.eventStationCreateFromCurrentArtist();
			setTimeout(function() {
				_this.init();
				header.updateTitle(nowPlayingStation);
			}, 2000);
		},

		"#bookmark_this_track click" : function() {
			this.overlay("popup.ejs", {
				confirm : Pandora.Pagecontent.cfmBookMarkTrk,
				btn_1_class : "visible",
				btn_2_class : "visible",
				btn_1 : "confirm-bk-track-yes",
				btn_2 : "confirm-bk-track-no",
			});
		},
		"#confirm-bk-track-yes click" : function() {
			var _this = this;
			$('#overlay-container').slideUp(500, function() {
			});
			pandora.eventTrackBookmarkTrack();
			setTimeout(function() {
				_this.init();
				header.updateTitle(nowPlayingStation);
			}, 2000);
		},
		"#bookmark_this_artist click" : function() {
			this.overlay("popup.ejs", {
				confirm : Pandora.Pagecontent.cfmBookMarkArt,
				btn_1_class : "visible",
				btn_2_class : "visible",
				btn_1 : "confirm-bk-artist-yes",
				btn_2 : "confirm-bk-artist-no",
			});
		},
		"#confirm-bk-artist-yes click" : function() {
			var _this = this;
			$('#overlay-container').slideUp(500, function() {
			});
			pandora.eventTrackBookmarkArtist();
			setTimeout(function() {
				_this.init();
				header.updateTitle(nowPlayingStation);
			}, 2000);
		},
		"#confirm-ns-artist-no, #confirm-ns-track-no, #confirm-bk-track-no, #confirm-bk-artist-no click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
		},

		/* NEW STATION - SEARCH */
		"#new_station click" : function() {
			$('#header').hide();
			root.template.buildListTemplate("pd_search_stations", null, "", "keyboard", "Search", "input-text", null, "status-input", "Preset", "preset", "123/ABC", "numExchange", "Delete", "delete");
		},

		"#pd_search_stations #ok click" : function(el) {
			var searchText = $("#status-input").val();
			if (searchText == "" || searchText == undefined)
				return;
			pandora.eventSearchExtended(4, searchText);
			//$('#header').show();
			//this.displaySearchResult();
		},

		"#search-input click" : function() {
			$("#search-input").val("");
		},

		".search-results .list-text click" : function(el) {
			var sToken = el.parent().attr("id");
			var searchId = el.parent().attr("searchid");
			console.log("you want to play the station with token:" + sToken);
			if (sToken) {
				pandora.eventSearchSelect(searchId, sToken);
			}
		},

		/* MORE OPTIONS */
		"#nowplaying-more click" : function() {
			$('#pagecontent').html(can.view('pandora/views/pagecontent-views/more.ejs', {
				"data" : Pandora.Pagecontent.defaults.submenu
			}));
			header.updateTitle(nowPlayingStation);
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		".change_station click" : function() {
			this.showListPage();
		},

		/* TRACK INFORMATION */
		".track_information click" : function() {
			header.updateTitle(nowPlayingStation);
			$('#pagecontent').html(can.view('pandora/views/pagecontent-views/track-info.ejs', {
				"data" : this._curSongInfo
			}));
			pagingControl.init();
		},

		/* STATION LIST EDIT SCREEN */
		"#delete_stations click" : function() {
			this.showEditListPage();
		},
		/* STATION SEED EDIT SCREEN */
		".station-list-edit .list-text click" : function(el) {
			Pandora.Pagecontent.deleteStation = el.parent();

			this.overlay("popup.ejs", {
				confirm : Pandora.Pagecontent.cfmDelStation,
				btbtn_1_class : "visible",
				btn_2_class : "visible",
				btn_1 : "delete-station-yes",
				btn_2 : "delete-station-no"
			});
		},

		/* DELETE NOW PLAYING STATION */
		"#delete_current_station click" : function() {
			this.overlay("popup.ejs", {
				confirm : Pandora.Pagecontent.cfmDelStation,
				btn_1_class : "visible",
				btn_2_class : "visible",
				btn_1 : "delete-station-yes",
				btn_2 : "delete-station-no"
			});
		},

		"#delete-station-yes click" : function(el) {
			var header = $("#header-text").text();
			var curToken = null;
			if ($("#list").hasClass("station-list-edit")) {
				curToken = Pandora.Pagecontent.deleteStation.attr("id");
				if (curToken) {
					pandora.eventStationDelete(curToken);
				}
				this.overlay("popup.ejs", {
					confirm : Pandora.Pagecontent.cfmDeleting,
					btn_1_class : "unvisible",
					btn_2_class : "unvisible",
					btn_1 : null,
					btn_2 : null
				});

				setTimeout(function() {
					$('#overlay-container').slideUp(500, function() {
					});
					Pandora.Pagecontent.deleteStation.hide("slow");
				}, 3000);
			} else {
				curToken = Pandora.Models.RESP.getActiveStation();
				if (curToken) {
					pandora.eventStationDelete(curToken);
				}
			}
			$('#overlay-container').remove();
		},

		"#delete-station-no click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
		},

		/* OVERLAY */
		overlay : function(overlay, data) {
			$('#overlay-container').remove();
			$('#pagecontent').append(can.view('pandora/views/pagecontent-views/overlay.ejs', {
				"overlay" : overlay,
				"data" : data
			}));
			$('#overlay-container').slideDown(500, function() {
			});
		},

		showListPage : function() {
			if (Pandora.Models.RESP.getStations().length == 0) {
				pandora.getAllStationTokens();
			}
			var that = this;
			if (!that._stationList)
				that._stationList = new can.Observe({
					info : Pandora.Models.RESP.getStations(),
					images : Pandora.Models.RESP.getStationArt()
				});

			header.updateTitle("Station List");
			$('#pagecontent').html(can.view('pandora/views/pagecontent-views/station_list.ejs', {
				"data" : {
					"menu" : Pandora.Pagecontent.defaults.stationsListMenu,
					"stations" : that._stationList
				}
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
			
			if (Pandora.Models.RESP.getActiveStation()) {
				var sToken = Pandora.Models.RESP.getActiveStation();
				var oel = $(".station-list");
				oel.find(".list-playing").removeClass("nowplaying");
				var el = $("#" + sToken);
				console.log("current playing station is : " + sToken);
				el.find(".list-playing").addClass("nowplaying");
			}
		},

		displaySearchResult : function() {
			$('#pagecontent').html(can.view('pandora/views/pagecontent-views/search-results.ejs', {
				"data" : Pandora.Models.RESP.getSearchResults()
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
			header.updateTitle($.t('headerSsearchResult'));
		},

		updateStatus : function(payload) {
			var status = pandora.processReturnStatus(payload);
			console.log("PNDR_RETURN_STATUS---> app status : " + status);
			//change view: playing or list page
			if (status == resources.status.PNDR_STATUS_PLAYING) {
				Pandora.Models.RESP.setPlayStatus(true);
				this._curSongInfo.attr("isplay", Pandora.Models.RESP.getPlayStatus());
				
				pandora.getTrackInfoExtended();
				pandora.getTrackAlbumArt();
				pandora.eventTrackExplain();

				this.showPlayerPage();
				pandora.getStationActive();
			} else if(status == resources.status.PNDR_STATUS_PAUSED){
				Pandora.Models.RESP.setPlayStatus(false);
				this._curSongInfo.attr("isplay", Pandora.Models.RESP.getPlayStatus());
				this.showPlayerPage();
				pandora.getStationActive();
			} else if (status == resources.status.PNDR_STATUS_NO_STATIONS) {
				this.showListPage(); //TODO will change to display no stations warning page
			} else if (status == resources.status.PNDR_STATUS_NO_STATION_ACTIVE) {
				this.showListPage();
			} else {
				pandora.getStatus();
			}
		},
		
		/* get all current track infos together */
		getTrackInfos : function() {
			pandora.getTrackInfo();
			pandora.getTrackTitle();
			pandora.getTrackArtist();
			pandora.getTrackAlbum();
		},

		/* Update Status (0x81   PNDR_UPDATE_STATUS) */
		PNDR_UPDATE_STATUS : function(payload) {
			this.updateStatus(payload);
		},
		
		/* Return Status (0x82   PNDR_RETURN_STATUS) */
		PNDR_RETURN_STATUS : function(payload) {
			this.updateStatus(payload);
		},
		
		/* Update Notice (0x83 – PNDR_UPDATE_NOTICE) */
		PNDR_UPDATE_NOTICE : function(payload){
			var code = pandora.processUpdateNotice(payload);
			if(code == resources.notice.PNDR_NOTICE_SKIP_LIMIT_REACHED){
				console.warn("Pandora doesn't limit to skip to next station :(");	
			}else if(code == resources.notice.PNDR_NOTICE_ERROR_BOOKMARK){
				console.warn("Bookmark track error :(");	
			}
		},
		
		/* Update Track (0x90   PNDR_UPDATE_TRACK) */
		PNDR_UPDATE_TRACK : function(payload) {
			var tToken = pandora.processUpdateTrack(payload);
			if (tToken != 0)
				Pandora.Models.RESP.setTrackToken(tToken);
			console.log("PNDR_UPDATE_TRACK---> track token is : " + tToken);
			pandora.getTrackInfoExtended();
			pandora.getTrackAlbumArt();
		},
		
		/* Return Track Info (0x91   PNDR_RETURN_TRACK_INFO) */
		PNDR_RETURN_TRACK_INFO : function(payload) {
			var trackInfo = pandora.processTrackInfo(payload);
			console.log("PNDR_RETURN_TRACK_INFO--->" + JSON.stringify(trackInfo));
			Pandora.Models.RESP.setTrackRate(trackInfo.rating);
		},
		
		/* Return Track Title (0x92   PNDR_RETURN_TRACK_TITLE) */
		PNDR_RETURN_TRACK_TITLE : function(payload) {
			var name = pandora.processTrackTitle(payload);
			if (name != "") {
				Pandora.Models.RESP.setTrackTitle(name);
				this._curSongInfo.attr("title", Pandora.Models.RESP.getTrackTitle());
				console.log("PNDR_RETURN_TRACK_TITLE--->" + Pandora.Models.RESP.getTrackTitle());
			}
		},
		
		/* Return Track Artist (0x93   PNDR_RETURN_TRACK_ARTIST) */
		PNDR_RETURN_TRACK_ARTIST : function(payload) {
			var artist = pandora.processTrackArtist(payload);
			if (artist != "") {
				Pandora.Models.RESP.setTrackArtist(artist);
				this._curSongInfo.attr("artist", Pandora.Models.RESP.getTrackArtist());
				console.log("PNDR_RETURN_TRACK_ARTIST--->" + Pandora.Models.RESP.getTrackArtist());
			}
		},
		
		/* Return Track Album (0x94   PNDR_RETURN_TRACK_ALBUM) */
		PNDR_RETURN_TRACK_ALBUM : function(payload) {
			var album = pandora.processTrackAlbum(payload);
			if (album != "") {
				Pandora.Models.RESP.setTrackAlbum(album);
				this._curSongInfo.attr("album", Pandora.Models.RESP.getTrackAlbum());
				console.log("PNDR_RETURN_TRACK_ALBUM--->" + Pandora.Models.RESP.getTrackAlbum());
			}
		},
		
		/* Return Track Album Art Segment (0x95   PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT) 149*/
		PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT : function(payload) {
			var encodedImages = pandora.processTrackAlbumArt(payload);
			if (encodedImages != null) {
				Pandora.Models.RESP.setTrackImage(encodedImages);
				console.log("PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT---> encodedImages:" + encodedImages);
				this._curSongInfo.attr("image", Pandora.Models.RESP.getTrackImage());
			}
		},
		
		/* Update Track Album Art (0x96 – PNDR_UPDATE_TRACK_ALBUM_ART) */
		PNDR_UPDATE_TRACK_ALBUM_ART : function(payload){
			var albumArt = pandora.processUpdateTrackAlbumArt(payload);
			if(albumArt.albumArtLength > 0)
				pandora.getTrackAlbumArt();
		},
		
		/* Return Track Explain Segment (0x9A – PNDR_RETURN_TRACK_EXPLAIN_SEGMENT) */
		PNDR_RETURN_TRACK_EXPLAIN_SEGMENT : function(payload) {
			var explain = pandora.processTrackExplainSegment(payload);
			if (explain != null) {
				Pandora.Models.RESP.setTrackDescription(explain);
				console.log("PNDR_RETURN_TRACK_EXPLAIN_SEGMENT---> explain:" + explain);
				this._curSongInfo.attr("desc", Pandora.Models.RESP.getTrackDescription());
			}
		},
		
		/* Return Station Active (0xB1 – PNDR_RETURN_STATION_ACTIVE) */
		PNDR_RETURN_STATION_ACTIVE : function(payload) {
			var token = pandora.processStationActive(payload);
			console.log("PNDR_RETURN_STATION_ACTIVE---> current station token : " + token);
			if (token != null) {
				Pandora.Models.RESP.setActiveStation(token);
				pandora.getStationInfo(token);
			} else {
				pandora.getStationActive();
			}
		},
		
		/* Return Station Count (0xB2   PNDR_RETURN_STATION_COUNT) */
		PNDR_RETURN_STATION_COUNT : function(payload) {
			var count = pandora.processStationCount(payload);
			if (count >= 0) {
				Pandora.Models.RESP.setStationsCount(count);
				console.log("PNDR_RETURN_STATION_COUNT---> count:" + Pandora.Models.RESP.getStationsCount());
			} else {
				pandora.getStationCount();
			}
		},
		
		/* Return Station Tokens (0xB3   PNDR_RETURN_STATION_TOKENS) */
		PNDR_RETURN_STATION_TOKENS : function(payload) {
			var tokens = pandora.processStationTokens(payload);
			console.log("PNDR_RETURN_STATION_TOKENS---> station tokens : " + tokens);
			console.log("PNDR_RETURN_STATION_TOKENS---> station count : " + Pandora.Models.RESP.getStationsCount());
			if (tokens != null) {
				pandora.getStationInfo(tokens);
				pandora.getStationArt(tokens);
			} else {
				pandora.getAllStationTokens();
			}
		},
		
		/* Return Station Info (0xB4   PNDR_RETURN_STATION_INFO) 180*/
		PNDR_RETURN_STATION_INFO : function(payload) {
			var stations = pandora.processStations(payload);
			if (stations.length > 0) {
				Pandora.Models.RESP.updateStations(stations);
				if (!this._stationList) {
					that._stationList = new can.Observe({
						info : Pandora.Models.RESP.getStations(),
						images : Pandora.Models.RESP.getStationArt()
					});
				} else
					this._stationList.attr("info", stations);
				for (var i = 0; i < stations.length; i++) {
					var sToken = stations[i].sToken;
					if (sToken == Pandora.Models.RESP.getActiveStation()) {
						nowPlayingStation = stations[i].name;
						header.updateTitle(nowPlayingStation);
						pandora.getTrackInfoExtended();
						pandora.getTrackAlbumArt();
						console.log("PNDR_RETURN_STATION_INFO---> nowPlayingStation:" + nowPlayingStation);
					}
				}
			}
		},
		
		/* Update Station Deleted (0xB7   PNDR_UPDATE_STATION_DELETED) */
		PNDR_UPDATE_STATION_DELETED : function(payload) {
			var stationToken = pandora.processUpdateStationDelete(payload);
			Pandora.Models.RESP.deleteStation(stationToken);
			if (this._stationList) {
				console.log("PNDR_UPDATE_STATION_DELETED -- > " + this._stationList.attr("info").length);
				this._stationList.attr("info", Pandora.Models.RESP.getStations());
				console.log("after delete this token , current list is : " + JSON.stringify(Pandora.Models.RESP.getStations()));
				console.log("PNDR_UPDATE_STATION_DELETED -- > " + this._stationList.attr("info").length);
			}
		},
		
		/* Return Station Art Segment (0xB8   PNDR_RETURN_STATION_ART_SEGMENT) 184 */
		PNDR_RETURN_STATION_ART_SEGMENT : function(payload) {
			var stationArt = pandora.processStationArt(payload);
			if (stationArt.encodedImages != null) {
				console.log("PNDR_RETURN_STATION_ART_SEGMENT---> token : " + stationArt.stationToken);
				console.log("PNDR_RETURN_STATION_ART_SEGMENT---> image : " + stationArt.encodedImages);
				Pandora.Models.RESP.saveStationArt(stationArt);
				if (!this._stationList) {
					this._stationList = new can.Observe({
						info : Pandora.Models.RESP.getStations(),
						images : Pandora.Models.RESP.getStationArt()
					});
				} else
					this._stationList.attr("images", Pandora.Models.RESP.getStationArt());
			}
		},
		
		/* Update Search (0xD0   PNDR_UPDATE_SEARCH) */
		PNDR_UPDATE_SEARCH : function(payload) {
			var search = pandora.processUpdateSearch(payload);
			console.log("PNDR_UPDATE_SEARCH---> searchId:" + search[0].searchId);
			console.log("PNDR_UPDATE_SEARCH---> musicTokens:" + search[0].musicTokens);
			if (search.length > 0) {
				pandora.getSearchResultInfo(search[0].searchId, search[0].musicTokens);
			}
		},
		
		/* Return Search Result Info (0xD1   PNDR_RETURN_SEARCH_RESULT_INFO) */
		PNDR_RETURN_SEARCH_RESULT_INFO : function(payload) {
			var results = pandora.processSearchResultInfo(payload);
			if (results.length > 0) {
				Pandora.Models.RESP.saveSearchResults(results);
				console.log("PNDR_RETURN_SEARCH_RESULT_INFO---> results: " + JSON.stringify(results));
				$('#header').show();
				this.displaySearchResult();
			}
		},
		
		/* Update Station Added (0xD2   PNDR_UPDATE_STATION_ADDED) */
		PNDR_UPDATE_STATION_ADDED : function(payload) {
			var stationToken = pandora.processUpdateStationAdd(payload);
			//get station info by given token
			pandora.getStationInfo(BinaryUtils.getArrayAtInt(stationToken), 1);
			console.log("PNDR_UPDATE_STATION_ADDED---> Station with this token :" + stationToken + "has been added!");

			pandora.getAllStationTokens();
			pandora.getStationActive();
		},
		
		/* Update Station Active (0xBA   PNDR_UPDATE_STATION_ACTIVE) 186*/
		PNDR_UPDATE_STATION_ACTIVE : function(payload) {
			var sToken = pandora.processUpdateStationActive(payload);
			if (sToken != null) {
				Pandora.Models.RESP.setActiveStation(sToken);
				pandora.getStationInfo(sToken);
			} else {
				pandora.getStationActive();
			}
		},
		
		/* Return Track Info Extended (0x9D – PNDR_RETURN_TRACK_INFO_EXTENDED)  */
		PNDR_RETURN_TRACK_INFO_EXTENDED : function(payload) {
			var trackInfoExt = pandora.processTrackInfoExtended(payload);
			console.log("PNDR_RETURN_TRACK_INFO_EXTENDED---> trackInfoExt : " + JSON.stringify(trackInfoExt));
			Pandora.Models.RESP.setTrackInfoExt(trackInfoExt);
			this._curSongInfo.attr("title", Pandora.Models.RESP.getTrackInfoExt().title);
			this._curSongInfo.attr("artist", Pandora.Models.RESP.getTrackInfoExt().artist);
			this._curSongInfo.attr("album", Pandora.Models.RESP.getTrackInfoExt().album);
			this._curSongInfo.attr("duration", secondFormat(Pandora.Models.RESP.getTrackInfoExt().duration));
			this._curSongInfo.attr("elapsed", secondFormat(Pandora.Models.RESP.getTrackInfoExt().elapsed));
			this._curSongInfo.attr("rating", Pandora.Models.RESP.getTrackInfoExt().rating);
		},
		
		/* Update Track Elapsed (0x97 – PNDR_UPDATE_TRACK_ELAPSED) */
		PNDR_UPDATE_TRACK_ELAPSED : function(payload){
			var elapsed = pandora.processUpdateTrackElapsed();
			if(elapsed){
				this._curSongInfo.attr("elapsed", elapsed);
			}
		},

		/* Update Track Rating (0x98 – PNDR_UPDATE_TRACK_RATING) */		
		PNDR_UPDATE_TRACK_RATING : function(payload){
			var trackRating = pandora.processUpdateTrackRating(payload);
			if(trackRating){
			//TODO
			}
		},
		
		/* Update Track Explain (0x99 – PNDR_UPDATE_TRACK_EXPLAIN) */
		PNDR_UPDATE_TRACK_EXPLAIN : function(payload){
			
		},
		
		/* Update Track Bookmark Track (0x9B – PNDR_UPDATE_TRACK_BOOKMARK_TRACK) */
		PNDR_UPDATE_TRACK_BOOKMARK_TRACK : function(payload){
			//TODO
		},
		
		/* Update Track Bookmark Artist (0x9C – PNDR_UPDATE_TRACK_BOOKMARK_ARTIST) */
		PNDR_UPDATE_TRACK_BOOKMARK_ARTIST : function(payload){
			//TODO
		},
		
		/* Update Stations Order (0xB6 – PNDR_UPDATE_STATIONS_ORDER) */
		PNDR_UPDATE_STATIONS_ORDER : function(payload) {
			var order = pandora.processUpdateStationsOrder(payload);
			console.log("PNDR_UPDATE_STATIONS_ORDER---> order :" + order);
			if (order) {
				pandora.getAllStationTokens();
				this.showListPage();
			}
		},
		
		/* Return Stations Order (0xB5 – PNDR_RETURN_STATIONS_ORDER) */
		PNDR_RETURN_STATIONS_ORDER : function() {
			var order = pandora.processUpdateStationsOrder(payload);
			console.log("PNDR_RETURN_STATIONS_ORDER---> order :" + order);
			if (order) {
				pandora.getAllStationTokens();
			}
		},

		registerHandler : function() {
			pandora.registerFunction(0x81, this.PNDR_UPDATE_STATUS.bind(this));
			pandora.registerFunction(0x82, this.PNDR_RETURN_STATUS.bind(this));
			pandora.registerFunction(0x83, this.PNDR_UPDATE_NOTICE.bind(this));
			pandora.registerFunction(0x90, this.PNDR_UPDATE_TRACK.bind(this));
			pandora.registerFunction(0x91, this.PNDR_RETURN_TRACK_INFO.bind(this));
			pandora.registerFunction(0x92, this.PNDR_RETURN_TRACK_TITLE.bind(this));
			pandora.registerFunction(0x93, this.PNDR_RETURN_TRACK_ARTIST.bind(this));
			pandora.registerFunction(0x94, this.PNDR_RETURN_TRACK_ALBUM.bind(this));
			pandora.registerFunction(0x95, this.PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT.bind(this));
			pandora.registerFunction(0xB1, this.PNDR_RETURN_STATION_ACTIVE.bind(this));
			pandora.registerFunction(0xB2, this.PNDR_RETURN_STATION_COUNT.bind(this));
			pandora.registerFunction(0xB3, this.PNDR_RETURN_STATION_TOKENS.bind(this));
			pandora.registerFunction(0xB4, this.PNDR_RETURN_STATION_INFO.bind(this));
			pandora.registerFunction(0xB7, this.PNDR_UPDATE_STATION_DELETED.bind(this));
			pandora.registerFunction(0xB8, this.PNDR_RETURN_STATION_ART_SEGMENT.bind(this));
			pandora.registerFunction(0xBA, this.PNDR_UPDATE_STATION_ACTIVE.bind(this));
			pandora.registerFunction(0xD0, this.PNDR_UPDATE_SEARCH.bind(this));
			pandora.registerFunction(0xD1, this.PNDR_RETURN_SEARCH_RESULT_INFO.bind(this));
			pandora.registerFunction(0xD2, this.PNDR_UPDATE_STATION_ADDED.bind(this));
			pandora.registerFunction(0x9D, this.PNDR_RETURN_TRACK_INFO_EXTENDED.bind(this));
			pandora.registerFunction(0x9A, this.PNDR_RETURN_TRACK_EXPLAIN_SEGMENT.bind(this));
			pandora.registerFunction(0xB6, this.PNDR_UPDATE_STATIONS_ORDER.bind(this));
			pandora.registerFunction(0xB5, this.PNDR_RETURN_STATIONS_ORDER.bind(this));
			pandora.registerFunction(0x96, this.PNDR_UPDATE_TRACK_ALBUM_ART.bind(this));
			pandora.registerFunction(0x97, this.PNDR_UPDATE_TRACK_ELAPSED.bind(this));
			pandora.registerFunction(0x9B, this.PNDR_UPDATE_TRACK_BOOKMARK_TRACK.bind(this));
			pandora.registerFunction(0x9C, this.PNDR_UPDATE_TRACK_BOOKMARK_ARTIST.bind(this));
			pandora.registerFunction(0x99, this.PNDR_UPDATE_TRACK_EXPLAIN.bind(this));
			pandora.registerFunction(0x98, this.PNDR_UPDATE_TRACK_RATING.bind(this));
		},

		destroy : function() {
			pandora.sessionTerminate();
		}
	});

	var initPlayPauseButton = function() {
		if (Pandora.Models.RESP.getPlayStatus()) {
			$("#np-play-icon").removeClass("np-play-icon");
			$("#np-play-icon").addClass("np-pause-icon");
		} else {
			$("#np-play-icon").addClass("np-play-icon");
			$("#np-play-icon").removeClass("np-pause-icon");
		}
	};
	var initThumbButton = function() {
		if (Pandora.Models.RESP.getTrackInfoExt().rating == 1) {
			$("#np-up-icon").removeClass("np-up-icon");
			$("#np-up-icon").addClass("np-up-done-icon");
			$("#np-down-icon").removeClass("np-down-done-icon");
			$("#np-down-icon").addClass("np-down-icon");
		} else if (Pandora.Models.RESP.getTrackInfoExt().rating == 2) {
			$("#np-up-icon").removeClass("np-up-done-icon");
			$("#np-up-icon").addClass("np-up-icon");
			$("#np-down-icon").removeClass("np-down-icon");
			$("#np-down-icon").addClass("np-down-done-icon");
		} else {
			$("#np-up-icon").removeClass("np-up-done-icon");
			$("#np-up-icon").addClass("np-up-icon");
			$("#np-down-icon").removeClass("np-down-done-icon");
			$("#np-down-icon").addClass("np-down-icon");
		}
	};
	var secondFormat = function(secondFormat) {
		if (!secondFormat)
			return;
		var format = Math.floor(secondFormat / 60) + ":";
		format += secondFormat % 60 > 9 ? secondFormat % 60 : "0" + secondFormat % 60;
		console.log("seconde after format is : " + format);
		return format;
	};
	pandora = new Pandora.Models.API();
	header = new Pandora.Header("#header", {});
	pagecontent = new Pandora.Pagecontent("#pagecontent", {});

	window.onbeforeunload = function() {
		pandora.sessionTerminate();
	}
});
