$(function() {
	Pandora.Models.RESP = can.Model(
	/* @Static */
	{
		defaults : {
			isPlaying : false,
			trackTitle : null,
			trackArtist : null,
			trackAlbum : null,
			trackToken : null,
			trackRate : 0,
			trackImage : null,
			trackDescription : "",
			/*
			 trackInfo : {
			 trackToken : null,
			 albumArtLength : null,
			 duration : null,
			 elapsed : null,
			 rating : null,
			 permissionFlags : null,
			 identityFlags : null
			 },*/

			trackInfoExt : {
				trackToken : null,
				albumArtLength : null,
				duration : null,
				elapsed : null,
				rating : null,
				permissionFlags : null,
				identityFlags : null,
				title : null,
				artist : null,
				album : null
			},
			userStationsCount : -1,
			activeStation : -1,
			stations : [], 
			stationArt : [],
			searchResults : [], 
			/*
			 {
			 "mToken" : 0,
			 "flag" : 1,
			 "description" : "2 Tha Top by Don Greco",
			 "searchId" : 4
			 }, {
			 "mToken" : 1,
			 "flag" : 1,
			 "description" : "2012 (Twenty-Twelve) by The Mystery Lights",
			 "searchId" : 4
			 }, {
			 "mToken" : 2,
			 "flag" : 1,
			 "description" : "2012 Blues by Thomas Function",
			 "searchId" : 4
			 }*/
			categoryNames : [],
		},

		getPlayStatus : function() {
			return this.defaults.isPlaying;
		},
		setPlayStatus : function(data) {
			this.defaults.isPlaying = data;
		},

		getTrackTitle : function() {
			return this.defaults.trackTitle;
		},
		setTrackTitle : function(data) {
			this.defaults.trackTitle = data;
		},

		getTrackArtist : function() {
			return this.defaults.trackArtist;
		},
		setTrackArtist : function(data) {
			this.defaults.trackArtist = data;
		},

		getTrackAlbum : function() {
			return this.defaults.trackAlbum;
		},
		setTrackAlbum : function(data) {
			this.defaults.trackAlbum = data;
		},

		getTrackToken : function() {
			return this.defaults.trackToken;
		},
		setTrackToken : function(data) {
			this.defaults.trackToken = data;
		},

		getTrackRate : function() {
			return this.defaults.trackRate;
		},
		setTrackRate : function(data) {
			this.defaults.trackRate = data;
		},

		getTrackImage : function() {
			return this.defaults.trackImage;
		},
		setTrackImage : function(data) {
			this.defaults.trackImage = data;
		},

		/*
		 getTrackInfo : function() {
		 return this.defaults.trackInfo;
		 },
		 setTrackInfo : function(data) {
		 this.defaults.trackInfo = data;
		 },
		 */

		getTrackInfoExt : function() {
			return this.defaults.trackInfoExt;
		},
		setTrackInfoExt : function(data) {
			this.defaults.trackInfoExt = data;
		},

		getStationsCount : function() {
			return this.defaults.userStationsCount;
		},
		setStationsCount : function(data) {
			this.defaults.userStationsCount = data;
		},
		/* reset the stations list */
		setStations : function(stations) {
			this.defaults.stations = stations;
		},
		/* save a station */
		saveStation : function(station) {
			this.defaults.stations.push(stations);
		},
		getStations : function(data) {
			return this.defaults.stations;
		},
		updateStations : function(data) {
			this.defaults.stations = data;
		},
		deleteStation : function(sToken) {
			// loop through JSON and find position of station and remove it.
			for (var x in this.defaults.stations) {				
				if (this.defaults.stations[x].sToken == sToken) {
					this.defaults.stations.splice(x, 1);
				}
			}
			console.log("after delete this token : " + sToken + " current list is : " + JSON.stringify(this.defaults.stations));
		},

		saveStationArt : function(stationArt) {
			for (var x in this.defaults.stationArt) {				
				if (this.defaults.stationArt[x].stationToken == stationArt.stationToken) {
					this.defaults.stationArt.splice(x, 1);
				}
			}
			this.defaults.stationArt.push(stationArt);
		},
		getStationArt : function() {
			return this.defaults.stationArt;
		},

		getTrackDescription : function() {
			return this.defaults.trackDescription;
		},
		setTrackDescription : function(data) {
			this.defaults.trackDescription = data;
		},

		saveSearchResults : function(data) {
			this.defaults.searchResults = data;
		},
		getSearchResults : function() {
			return this.defaults.searchResults;
		},

		setActiveStation : function(data) {
			this.defaults.activeStation = data;
		},
		getActiveStation : function() {
			return this.defaults.activeStation;
		}
	}, {});
});

