var Pandora = {};
Pandora.Models = {};

$(function() {
	Pandora.Models.API = can.Model(
	/* @Static */
	{
		defaults : {
			_dataPool : [],
			_payloads : [],
			_timer : null
		},

		trackArt : {
			_trackArtPool : [],
			_trackArtPoolCount : 0,
			_timer : null
		},

		stationArt : {
			_stationArtPool : [],
			_stationArtPoolCount : 0,
			_timer : null
		},

		trackExplain : {
			_trackExplainPool : [],
			_trackExplainPoolCount : 0,
			_timer : null
		}
	}, {
		_handlers : [],
		_socket : null,
		registerFunction : function(commandId, fun) {
			this._handlers[commandId] = fun;
		},
		/* Socket connection with hup service */
		_connect : function() {
			console.warn("come into _connect()!!!! ");
			var that = this;
			if (!that._socket) {
				that._socket = io.connect("/CommandControl").send("Pandora");
				that._socket.on('AsyncEvent', function(data) {
					console.warn("AsyncEvent - _socket.on Returned!!!!!!!!!!!! ");
					that._plog(data);
					that._handleData(data);
					console.warn("END AsyncEvent");
				});
			}
		},
		/* Print data log */
		_plog : function(data) {
			var str = "";
			$(data).each(function(index, item) {
				var hexString = parseInt(item).toString(16);
				while (hexString.length < 2) {
					hexString = "0" + hexString;
				}
				str += hexString + " ";
			})
			console.log("_plog " + str.toUpperCase());
		},
		/* Asynchronous data handler */
		_handleData : function(data) {
			var tmp = [];
			for (var i = 0; i < data.length; i++) {
				if (data[i] == 0x7D) {//the data must be escaped before sending to the Mobile App
					if (data[i + 1] == 0x5C) {
						tmp.push(0x7C);
						i++;
					} else if (data[i + 1] == 0x5D) {
						tmp.push(0x7D);
						i++;
					} else if (data[i + 1] == 0x5E) {
						tmp.push(0x7E);
						i++;
					} else {
						tmp.push(data[i]);
					}
				} else {
					tmp.push(data[i]);
				}
			}
			Pandora.Models.API.defaults._dataPool = Pandora.Models.API.defaults._dataPool.concat(tmp);
			this._processDataPool();
		},
		/*
		 * Process call related handler for response payload messages
		 */
		_processPayloads : function() {
			while (Pandora.Models.API.defaults._payloads.length > 0) {
				var payload = Pandora.Models.API.defaults._payloads.shift();
				if (payload && payload.length > 0) {
					var handler = this._handlers[payload[0]];
					if (handler && typeof handler === 'function') {
						handler(payload);
					}
				}
			}
		},
		/*
		 * Process all Async messages
		 */
		_processDataPool : function() {
			var haveMessage = Pandora.Models.API.defaults._dataPool.length >= 10;
			while (haveMessage) {
				if (Pandora.Models.API.defaults._timer) {
					clearTimeout(Pandora.Models.API.defaults._timer);
				}
				//7E(Start) 00(Type) 00(Sequence Number) 00 00 00 05(Payload Length) BA 00 03 28 CE(Payload) 11 03(CRC Code) 7C(End)
				if (Pandora.Models.API.defaults._dataPool[0] == 0x7E && Pandora.Models.API.defaults._dataPool[1] == 0x00 && Pandora.Models.API.defaults._dataPool[2] == 0x00) {
					var length = BinaryUtils.getIntAtArray(Pandora.Models.API.defaults._dataPool, 3);
					if (Pandora.Models.API.defaults._dataPool.length >= 10 + length) {
						var message = Pandora.Models.API.defaults._dataPool.splice(0, 10 + length);
						var payload = message.slice(7, 7 + length);
						var crcData = message.slice(1, 7 + length);
						var crcCode = message.slice(message.length - 3, message.length - 2);
						Pandora.Models.API.defaults._payloads.push(payload);
					} else {
						haveMessage = false;
						var that = this;
						Pandora.Models.API.defaults._timer = setTimeout(function() {
							Pandora.Models.API.defaults._dataPool = [];
						}, 5000);
					}
				} else {
					//The data pool is error. Reset the data
					Pandora.Models.API.defaults._dataPool = [];
					haveMessage = false;
				}
			}
			this._processPayloads();
		},
		/* Add message shell for every command */
		formatRequest : function(payload) {
			var crcdata = [];
			crcdata.push(0x00);
			crcdata.push(0x00);
			crcdata = crcdata.concat(BinaryUtils.getArrayAtInt(payload.length));
			crcdata = crcdata.concat(payload);
			var crcArray = BinaryUtils.getCRC16Value(crcdata);
			var command = [];
			command.push(0x7E);
			command = command.concat(crcdata);
			command = command.concat(crcArray);
			command.push(0x7C);
			return command;
		},
		/* Send command control message */
		send : function(cmd) {
			//this._connect();
			//Should only connect once.
			var data = this.formatRequest(cmd);
			console.warn("++++++++send command - data");
			console.warn(data);
			this._socket.emit("Command", data);
		},
		/*
		 * Session start command
		 */
		sessionStart : function(apiVersion, cId, albumArtDimension, stationArtDimensionn) {
			if (!apiVersion)
				apiVersion = 3;
			if (!cId)
				cId = "APITOOL0";
			if (!albumArtDimension)
				albumArtDimension = 200;
			if (!stationArtDimensionn)
				stationArtDimensionn = 44;

			var payload = [];
			payload.push(0x00);
			//command
			payload = payload.concat(BinaryUtils.getArrayAtShort(apiVersion));
			//api_version
			var payloadTextInfo = BinaryUtils.strToCharArray(cId);
			payload = payload.concat(payloadTextInfo);
			//accessory_id
			payload = payload.concat(BinaryUtils.getArrayAtShort(albumArtDimension));
			//album_art_dimension
			payload.push(0x02);
			//image_type
			payload.push(0x00);
			//flags
			payload = payload.concat(BinaryUtils.getArrayAtShort(stationArtDimensionn));
			//text
			this.send(payload);
		},
		/*
		 * Requests the current applicate state of the Mobile App, to be returned via PNDR_RETURN_STATUS.
		 */
		getStatus : function() {
			var payload = [];
			payload.push(0x03);
			this.send(payload);
		},
		/*
		 * Terminate the PandoraLink session, stopping communication.
		 */
		sessionTerminate : function() {
			var payload = [];
			payload.push(0x05);
			this.send(payload);
		},
		/*
		 * Requests the current album art to be returned via one or more consecutive PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT commands
		 */
		getTrackAlbumArt : function() {
			var payload = [];
			payload.push(0x14);
			payload = payload.concat(BinaryUtils.getArrayAtInt(4000));
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App of the user’s intention to resume playing audio.
		 */
		eventTrackPlay : function() {
			var payload = [];
			payload.push(0x30);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App of the user’s intention to pause audio.
		 */
		eventTrackPause : function() {
			var payload = [];
			payload.push(0x31);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to skip to the next audio track.
		 */
		eventTrackSkip : function() {
			var payload = [];
			payload.push(0x32);
			this.send(payload);
		},
		/*
		 * Requests the track token, album art length, flags, duration, elapsed play time in seconds,
		 * and rating for the current track to be returned via PNDR_RETURN_TRACK_INFO.
		 */
		getTrackInfo : function() {
			var payload = [];
			payload.push(0x10);
			this.send(payload);
		},
		/*
		 * Requests the title of the currently playing track to be returned via PNDR_RETURN_TRACK_TITLE.
		 */
		getTrackTitle : function() {
			var payload = [];
			payload.push(0x11);
			this.send(payload);
		},
		/*
		 * Requests the artist for the currently playing track to be returned via PNDR_RETURN_TRACK_ARTIST.
		 */
		getTrackArtist : function() {
			var payload = [];
			payload.push(0x12);
			this.send(payload);
		},
		/*
		 * Requests the album for the currently playing track to be returned via PNDR_RETURN_TRACK_ALBUM.
		 */
		getTrackAlbum : function() {
			var payload = [];
			payload.push(0x13);
			this.send(payload);
		},
		/*
		 * Requests that all current track metadata be returned in one response:
		 *track token, album art length, flags, duration, elapsed play time in seconds, rating, title, artist and album.
		 */
		getTrackInfoExtended : function() {
			var payload = [];
			payload.push(0x16);
			this.send(payload);
		},
		/*
		 * Requests track explanation to be returned via one or more consecutive PNDR_RETURN_TRACK_EXPLAIN_SEGMENT commands
		 */
		getTrackExplanation : function() {
			var payload = [];
			payload.push(0x36);
			payload = payload.concat(BinaryUtils.getArrayAtInt(4000));
			this.send(payload);
		},
		/*
		 * Requests the currently playing station token
		 */
		getStationActive : function() {
			var payload = [];
			payload.push(0x40);
			this.send(payload);
		},
		/*
		 * Requests the art for each station token in an array of station_tokens to be returned via one or more PNDR_RETURN_STATION_ART_SEGMENT payloads.
		 */
		getStationArt : function(stationToken) {
			var payload = [];
			payload.push(0x4B);
			payload = payload.concat(stationToken);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to give the current track a "thumbs up."
		 */
		eventTrackRatePositive : function() {
			var payload = [];
			payload.push(0x33);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to give the current track a "thumbs down."
		 */
		eventTrackRateNegative : function() {
			var payload = [];
			payload.push(0x34);
			this.send(payload);
		},
		/*
		 * 0x37 – PNDR_EVENT_TRACK_BOOKMARK_TRACK
		 */
		eventTrackBookmarkTrack : function() {
			var payload = [];
			payload.push(0x37);
			this.send(payload);
		},
		/*
		 * 0x38 – PNDR_EVENT_TRACK_BOOKMARK_ARTIST
		 */
		eventTrackBookmarkArtist : function() {
			var payload = [];
			payload.push(0x38);
			this.send(payload);
		},
		/*
		 * Event Station Create From Current Artist (0x49 – PNDR_EVENT_STATION_CREATE_FROM_CURRENT_ARTIST)
		 */
		eventStationCreateFromCurrentArtist : function() {
			var payload = [];
			payload.push(0x49);
			this.send(payload);
		},
		/*
		 * Event Station Create From Current Track (0x4A – PNDR_EVENT_STATION_CREATE_FROM_CURRENT_TRACK)
		 */
		eventStationCreateFromCurrentTrack : function() {
			var payload = [];
			payload.push(0x4A);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to begin playing the given station.
		 */
		eventStationSelect : function(stationToken) {
			var payload = [];
			payload.push(0x47);
			payload = payload.concat(BinaryUtils.getArrayAtInt(stationToken));
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to delete the given station.
		 */
		eventStationDelete : function(stationToken) {
			var payload = [];
			payload.push(0x48);
			payload = payload.concat(BinaryUtils.getArrayAtInt(stationToken));
			this.send(payload);
		},
		/*
		 * Requests extended search results for the given search text to the accessory.
		 */
		eventSearchExtended : function(searchId, searchText) {
			var payload = [];
			payload.push(0x61);
			payload = payload.concat(BinaryUtils.getArrayAtInt(searchId));
			payload = payload.concat(BinaryUtils.strToCharArray(searchText));
			this.send(payload);
		},
		/*
		 * Requests the result info for each music token in the given array to be returned via PNDR_RETURN_SEARCH_RESULT_INFO.
		 */
		getSearchResultInfo : function(searchId, musicTokens) {
			var payload = [];
			payload.push(0x62);
			payload = payload.concat(BinaryUtils.getArrayAtInt(searchId));
			payload = payload.concat(musicTokens);
			this.send(payload);
		},
		/*
		 * Requests station creation based on a selection from a previously returned search results.
		 */
		eventSearchSelect : function(searchId, musicId) {
			var payload = [];
			payload.push(0x63);
			payload = payload.concat(BinaryUtils.getArrayAtInt(searchId));
			payload = payload.concat(BinaryUtils.getArrayAtInt(musicId));
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to sort stations in the given order.
		 */
		eventStationsSort : function(sort_order) {
			var payload = [];
			payload.push(0x46);
			payload = payload.concat(sort_order);
			this.send(payload);
		},
		/*
		 * Requests the name and flags for each station token in an array of station_tokens to be returned via PNDR_RETURN_STATION_INFO.
		 */
		getStationsOrder : function() {
			var payload = [];
			payload.push(0x45);
			this.send(payload);
		},
		/*
		 * Requests number of stations for the current user to be returned via PNDR_RETURN_STATION_COUNT.
		 */
		getStationCount : function() {
			var payload = [];
			payload.push(0x41);
			this.send(payload);
		},
		/*
		 * Requests all of the user's station tokens to be returned via PNDR_RETURN_STATION_TOKENS.
		 */
		getAllStationTokens : function() {
			var payload = [];
			payload.push(0x43);
			this.send(payload);
		},
		/*Requests the name and flags for each station token in an array of station_tokens to be returned*/
		getStationInfo : function(stationTokens) {
			var payload = [];
			payload.push(0x44);
			payload = payload.concat(stationTokens);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to send the specified number of station names for a genre category starting from the specified index to be returned
		 * via PNDR_RETURN_GENRE_STATION_NAMES.
		 */
		getGenreStationNames : function(cId, startIndex, count) {
			var payload = [];
			payload.push(0x51);
			payload = payload.concat(BinaryUtils.getArrayAtInt(cId));
			payload = payload.concat(BinaryUtils.getArrayAtInt(startIndex));
			payload = payload.concat(BinaryUtils.getArrayAtInt(count));
			this.send(payload);
		},
		/*
		 * Requests the art for each genre station index starting from the specified index to count,
		 * to be returned via one or more PNDR_RETURN_GENRE_STATION_ART_SEGMENT payloads.
		 */
		getGenreStationArt : function(cId, startIndex, count) {
			var payload = [];
			payload.push(0x53);
			payload = payload.concat(BinaryUtils.getArrayAtInt(4000));
			payload = payload.concat(BinaryUtils.getArrayAtInt(cId));
			payload = payload.concat(BinaryUtils.getArrayAtInt(startIndex));
			payload = payload.concat(BinaryUtils.getArrayAtInt(count));
			this.send(payload);
		},
		/*
		 * Requests an array of all genre categories, to be returned via PNDR_RETURN_GENRE_CATEGORY_NAMES.
		 */
		getAllGenreCategoryNames : function() {
			var payload = [];
			payload.push(0x4F);
			this.send(payload);
		},
		/*
		 * Creates a new user station based on the specified genre station.
		 */
		eventSelectGenreStation : function(category_index, station_index) {
			var payload = [];
			payload.push(0x52);
			payload = payload.concat(BinaryUtils.getArrayAtInt(category_index));
			payload = payload.concat(BinaryUtils.getArrayAtInt(station_index));
			this.send(payload);
		},

		/*
		 * 0x95 – PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT
		 */
		processTrackAlbumArt : function(payload) {
			var encodedImages = null;
			if (Pandora.Models.API.trackArt._timer) {
				clearTimeout(Pandora.Models.API.trackArt._timer);
			}
			Pandora.Models.API.trackArt._timer = setTimeout(function() {
				Pandora.Models.API.trackArt._trackArtPool = [];
				Pandora.Models.API.trackArt._trackArtPoolCount = 0;
			}, 5000);

			if (payload.length > 7) {
				if (payload[0] == 0x95) {
					var trackToken = BinaryUtils.getIntAtArray(payload, 1);
					console.log("processTrackAlbumArt---> trackToken:" + trackToken);
					var segmentIndex = payload[5];
					console.log("processTrackAlbumArt---> segmentIndex:" + segmentIndex);
					var totalSegments = payload[6];
					console.log("processTrackAlbumArt---> totalSegments:" + totalSegments);
					var body = payload.slice(7);
					Pandora.Models.API.trackArt._trackArtPool[segmentIndex] = body;
					Pandora.Models.API.trackArt._trackArtPoolCount++;
					if (Pandora.Models.API.trackArt._trackArtPoolCount == totalSegments) {
						var images = [];
						var i = 0;
						while (i < totalSegments) {
							images = images.concat(Pandora.Models.API.trackArt._trackArtPool[i++]);
						}
						encodedImages = BinaryUtils.binaryToBase64(images);
						
						Pandora.Models.API.trackArt._trackArtPool = [];
						Pandora.Models.API.trackArt._trackArtPoolCount = 0;
					}
				}
			}
			return encodedImages;
		},
		/*
		 * 0xBB   PNDR_RETURN_GENRE_CATEGORY_NAMES
		 */
		processAllGenreCategoryNames : function(payload) {
			var names = "";
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xBB) {
					var startIndex = parseInt(payload[1]);
					var body = payload.slice(2).join(",");
					//body = body.replace(/,0,/g , ",44,44,44,").replace(/,0/g , "");
					names = BinaryUtils.bin2String(body);
					console.log("processAllGenreCategoryNames---> names:" + names);
				}
			}
			return names;
		},
		/*
		 * 0xB4   PNDR_RETURN_STATION_INFO
		 */
		processStations : function(payload) {
			var stations = [];
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xB4) {
					var tempStations = payload.slice(1);
					var sToken = -1, flag = -1, name = "";
					for (var i = 0; i < tempStations.length; i++) {
						if (i > 4) {
							if (tempStations[i] == 0) {
								sToken = BinaryUtils.getIntAtArray(tempStations, 0);
								console.log("processStations---> sToken:" + sToken);
								flag = parseInt(tempStations[4]);
								console.log("processStations---> flag:" + flag);
								name = BinaryUtils.bin2String(tempStations.slice(5, i));
								console.log("processStations---> name:" + name);
								stations.push({
									"sToken" : sToken,
									"flag" : flag,
									"name" : name
								});
								console.log("processStations---> stations:" + JSON.stringify(stations));
								tempStations = tempStations.slice(i + 1);
								i = -1;
							}
						}
					}
				}
			}
			return stations;
		},
		/*
		 * 0xB8   PNDR_RETURN_STATION_ART_SEGMENT
		 */
		processStationArt : function(payload) {
			console.log("processStationArt start");
			var stationArt = {
				stationToken : null,
				encodedImages : null
			};

			if (Pandora.Models.API.stationArt._timer) {
				clearTimeout(Pandora.Models.API.stationArt._timer);
			}
			Pandora.Models.API.stationArt._timer = setTimeout(function() {
				Pandora.Models.API.stationArt._stationArtPool = [];
				Pandora.Models.API.stationArt._stationArtPoolCount = 0;
			}, 5000);

			if (payload.length > 7) {
				if (payload[0] == 0xB8) {
					stationArt.stationToken = BinaryUtils.getIntAtArray(payload, 1);
					var artLength = BinaryUtils.getIntAtArray(payload, 5);
					var segmentIndex = payload[9];
					var totalSegments = payload[10];
					var body = payload.slice(11);
					
					Pandora.Models.API.stationArt._stationArtPool[segmentIndex] = body;
					Pandora.Models.API.stationArt._stationArtPoolCount++;
					
					if (Pandora.Models.API.stationArt._stationArtPoolCount == totalSegments) {
						var images = [];
						var i = 0;
						while (i < totalSegments) {
							images = images.concat(Pandora.Models.API.stationArt._stationArtPool[i++]);
						}
						stationArt.encodedImages = BinaryUtils.binaryToBase64(images);
						Pandora.Models.API.stationArt._stationArtPool = [];
						Pandora.Models.API.stationArt._stationArtPoolCount = 0;
					}
				}
			}
			return stationArt;
		},
		/*
		 * 0xB3   PNDR_RETURN_STATION_TOKENS
		 */
		processStationTokens : function(payload) {
			var tokens = null;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xB3) {
					var startIndex = parseInt(payload[1]);
					tokens = payload.slice(2);
				}
			}
			return tokens;
		},
		/*
		 * 0xB2   PNDR_RETURN_STATION_COUNT
		 */
		processStationCount : function(payload) {
			var count = -1;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xB2) {
					count = parseInt(payload[1]);
					console.log("processStationCount---> count:" + count);
				}
			}
			return count;
		},
		/*
		 * 0xD0   PNDR_UPDATE_SEARCH
		 */
		processUpdateSearch : function(payload) {
			var search = [];
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xD0) {
					var searchId = BinaryUtils.getIntAtArray(payload, 1);
					console.log("processUpdateSearch---> searchId:" + searchId);
					var musicTokens = payload.slice(5);
					console.log("processUpdateSearch---> musicTokens:" + musicTokens);
					search.push({
						"searchId" : searchId,
						"musicTokens" : musicTokens
					});
				}
			}
			return search;
		},
		/*
		 * 0xD1   PNDR_RETURN_SEARCH_RESULT_INFO
		 */
		processSearchResultInfo : function(payload) {
			var results = [];
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xD1) {
					var searchId = BinaryUtils.getIntAtArray(payload, 1);
					var tempResults = payload.slice(5);
					console.log("processSearchResultInfo---> tempResults:" + tempResults);

					var mToken = -1, flag = -1, description = "";
					for (var i = 0; i < tempResults.length; i++) {
						if (i > 4) {
							if (tempResults[i] == 0) {
								mToken = BinaryUtils.getIntAtArray(tempResults, 0);
								console.log("processSearchResultInfo---> mToken:" + mToken);
								flag = parseInt(tempResults[4]);
								console.log("processSearchResultInfo---> flag:" + flag);
								description = BinaryUtils.bin2String(tempResults.slice(5, i));
								console.log("processSearchResultInfo---> description:" + description);
								results.push({
									"mToken" : mToken,
									"flag" : flag,
									"description" : description,
									"searchId" : searchId
								});
								console.log("processSearchResultInfo---> results:" + JSON.stringify(results));
								tempResults = tempResults.slice(i + 1);
								console.log("processSearchResultInfo---> tempResults:" + tempResults);
								i = -1;
							}
						}
					}
				}
			}
			return results;
		},
		/*
		 * 0xBD   PNDR_RETURN_GENRE_STATION_NAMES
		 */
		processGenreStations : function(payload) {
			var names = "";
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xBD) {
					var cId = parseInt(payload[1]);
					var startIndex = parseInt(payload[2]);
					var body = payload.slice(3).join(",");

					names = BinaryUtils.bin2String(body);
					console.log("processGenreStations---> names:" + names);

					stationArt._stationsArtPool = [];
					stationArt._stationsArtPoolCount = 0;
					//TODO this.getGenreStationArt(cId, startIndex, names.length);
				}
			}
			return names;
		},
		/*
		 * 0xBE   PNDR_RETURN_GENRE_STATION_ART_SEGMENT
		 */
		processGenreStationArt : function(payload) {
			//TODO
		},
		/*
		 * 0xB7   PNDR_UPDATE_STATION_DELETED
		 */
		processUpdateStationDelete : function(payload) {
			var stationToken = null;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xB7) {
					stationToken = BinaryUtils.getIntAtArray(payload, 1);
					console.log("processUpdateStationDelete---> stationToken:" + stationToken);
				}
			}
			return stationToken;
		},
		/*
		 * 0xD2   PNDR_UPDATE_STATION_ADDED
		 */
		processUpdateStationAdd : function(payload) {
			var stationToken = null;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xD2) {
					stationToken = parseInt(payload[1]);
					console.log("processUpdateStationAdd---> stationToken:" + stationToken);
				}
			}
			return stationToken;
		},
		/*
		 * 0x81   PNDR_UPDATE_STATUS
		 */
		processUpdateStatus : function(payload) {
			var status = 4;
			if (payload.length > 1) {
				if (parseInt(payload[0]) == 0x81) {
					status = parseInt(payload[1]);
				}
			}
			return status;
		},
		/*
		 * 0x82   PNDR_RETURN_STATUS
		 */
		processReturnStatus : function(payload) {
			var status = 4;
			if (payload.length > 1) {
				if (parseInt(payload[0]) == 0x82) {
					status = parseInt(payload[1]);
					console.log("processReturnStatus---> status:" + status);
				}
			}
			return status;
		},
		/*
		 * 0x90   PNDR_UPDATE_TRACK
		 */
		processUpdateTrack : function(payload) {
			var tToken = 0;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0x90) {
					tToken = BinaryUtils.getIntAtArray(payload, 1);
					console.log("processUpdateTrack---> sToken:" + tToken);
				}
			}
			return tToken;
		},
		/*
		 * 0x91   PNDR_RETURN_TRACK_INFO
		 */
		processTrackInfo : function(payload) {
			var trackInfo = {
				trackToken : null,
				albumArtLength : null,
				duration : null,
				elapsed : null,
				rating : null,
				permissionFlags : null,
				identityFlags : null
			};
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0x91) {
					trackInfo.trackToken = BinaryUtils.getIntAtArray(payload, 1);
					trackInfo.albumArtLength = BinaryUtils.getIntAtArray(payload, 5);
					trackInfo.duration = BinaryUtils.getShortAtArray(payload, 9);
					trackInfo.elapsed = BinaryUtils.getShortAtArray(payload, 11);
					trackInfo.rating = parseInt(payload[13]);
					trackInfo.permissionFlags = parseInt(payload[14]);
					trackInfo.identityFlags = parseInt(payload[15]);
				}
			}
			return trackInfo;
		},
		/*
		 * 0x92   PNDR_RETURN_TRACK_TITLE
		 */
		processTrackTitle : function(payload) {
			var title = "";
			if (payload.length > 5) {
				if (parseInt(payload[0]) == 0x92) {
					var trackToken = BinaryUtils.getIntAtArray(payload, 1);
					var body = payload.slice(5);
					if (body != null && body.length > 1) {
						body.pop();
						title = BinaryUtils.bin2String(body);
					}
				}
			}
			return title;
		},
		/*
		 * 0x93   PNDR_RETURN_TRACK_ARTIST
		 */
		processTrackArtist : function(payload) {
			var artist = "";
			if (payload.length > 5) {
				if (parseInt(payload[0]) == 0x93) {
					var trackToken = BinaryUtils.getIntAtArray(payload, 1);
					var body = payload.slice(5);
					if (body != null && body.length > 1) {
						body.pop();
						artist = BinaryUtils.bin2String(body);
					}
				}
			}
			return artist;
		},
		/*
		 * 0x94   PNDR_RETURN_TRACK_ALBUM
		 */
		processTrackAlbum : function(payload) {
			var album = "";
			if (payload.length > 5) {
				if (parseInt(payload[0]) == 148) {
					var trackToken = BinaryUtils.getIntAtArray(payload, 1);
					var body = payload.slice(5);
					console.log("processTrackAlbum---> body:" + body);
					if (body != null && body.length > 1) {
						body.pop();
						album = BinaryUtils.bin2String(body);
					}
				}
			}
			return album;
		},
		/*
		 * Return Track Info Extended (0x9D – PNDR_RETURN_TRACK_INFO_EXTENDED)
		 */
		processTrackInfoExtended : function(payload) {
			var trackInfoExt = {
				trackToken : null,
				albumArtLength : null,
				duration : null,
				elapsed : null,
				rating : null,
				permissionFlags : null,
				identityFlags : null,
				title : null,
				artist : null,
				album : null
			};
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0x9D) {
					trackInfoExt.trackToken = BinaryUtils.getIntAtArray(payload, 1);
					trackInfoExt.albumArtLength = BinaryUtils.getIntAtArray(payload, 5);
					trackInfoExt.duration = BinaryUtils.getShortAtArray(payload, 9);
					trackInfoExt.elapsed = BinaryUtils.getShortAtArray(payload, 11);
					trackInfoExt.rating = parseInt(payload[13]);
					trackInfoExt.permissionFlags = parseInt(payload[14]);
					trackInfoExt.identityFlags = parseInt(payload[15]);
					
					var tempResults = payload.slice(16);
					var tempArr = [];
					for (var i = 0, j = 0; i < tempResults.length; i++) {
						if (tempResults[i] == 0) {
							tempArr.push(BinaryUtils.bin2String(tempResults.slice(j, i)));
							j = i + 1;
						}
					}

					trackInfoExt.title = tempArr[0];
					trackInfoExt.artist = tempArr[1];
					trackInfoExt.album = tempArr[2];
				}
			}
			return trackInfoExt;
		},
		/*
		 * Return Track Explain Segment (0x9A – PNDR_RETURN_TRACK_EXPLAIN_SEGMENT)
		 */
		processTrackExplainSegment : function(payload) {
			var explain = [];
			if (Pandora.Models.API.trackExplain._timer) {
				clearTimeout(Pandora.Models.API.trackExplain._timer);
			}
			Pandora.Models.API.trackExplain._timer = setTimeout(function() {
				Pandora.Models.API.trackExplain._trackExplainPool = [];
				Pandora.Models.API.trackExplain._trackExplainPoolCount = 0;
			}, 5000);

			if (payload.length > 7) {
				if (payload[0] == 0x9A) {
					var trackToken = BinaryUtils.getIntAtArray(payload, 1);
					console.log("processTrackExplainSegment---> trackToken:" + trackToken);
					var segmentIndex = payload[5];
					console.log("processTrackExplainSegment---> segmentIndex:" + segmentIndex);
					var totalSegments = payload[6];
					console.log("processTrackExplainSegment---> totalSegments:" + totalSegments);
					var body = payload.slice(7);
					Pandora.Models.API.trackExplain._trackExplainPool[segmentIndex] = body;
					Pandora.Models.API.trackExplain._trackExplainPoolCount++;
					if (Pandora.Models.API.trackExplain._trackExplainPoolCount == totalSegments) {
						var i = 0;
						while (i < totalSegments){
							explain = explain.concat(Pandora.Models.API.trackExplain._trackExplainPool[i++]);
						}
						Pandora.Models.API.trackExplain._trackExplainPool = [];
						Pandora.Models.API.trackExplain._trackExplainPoolCount = 0;
					}
				}
			}
			return BinaryUtils.bin2String(explain);
		},
		/*
		 * 0xBA   PNDR_UPDATE_STATION_ACTIVE
		 */
		processUpdateStationActive : function(payload) {
			var sToken = null;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xBA) {
					sToken = BinaryUtils.getIntAtArray(payload, 1);
					console.log("processUpdateStationActive---> sToken:" + sToken);
				}
			}
			return sToken;
		},
		/*
		 * 0xB1 – PNDR_RETURN_STATION_ACTIVE
		 */
		processStationActive : function(payload){
			var sToken = null;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xB1) {
					sToken = BinaryUtils.getIntAtArray(payload, 1);
					console.log("processStationActive---> sToken:" + sToken);
				}
			}
			return sToken;
		},
		/*
		 * Return Stations Order (0xB5 – PNDR_RETURN_STATIONS_ORDER)
		 */
		processReturnStationsOrder : function(payload){
			var order = null;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xB5) {
					order =  parseInt(payload[1]);
					console.log("processReturnStationsOrder---> order:" + order);
				}
			}
			return order;
		},
		/*
		 * Update Stations Order (0xB6 – PNDR_UPDATE_STATIONS_ORDER)
		 */
		processUpdateStationsOrder : function(payload){
			var order = null;
			if (payload.length > 0) {
				if (parseInt(payload[0]) == 0xB6) {
					order = parseInt(payload[1]);
					console.log("processUpdateStationsOrder---> order:" + order);
				}
			}
			return order;
		}
	});
});
