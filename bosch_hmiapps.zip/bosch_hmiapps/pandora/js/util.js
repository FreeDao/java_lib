var BinaryUtils = {
	binaryToBase64 : function(input) {
		var base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
		var ret = new Array();
		var i = 0;
		var j = 0;
		var char_array_3 = new Array(3);
		var char_array_4 = new Array(4);
		var in_len = input.length;
		var pos = 0;
		while(in_len--) {
			char_array_3[i++] = input[pos++];
			if(i == 3) {
				char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
				char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
				char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
				char_array_4[3] = char_array_3[2] & 0x3f;

				for( i = 0; (i < 4); i++)
					ret += base64_chars.charAt(char_array_4[i]);
				i = 0;
			}
		}
		if(i) {
			for( j = i; j < 3; j++)
				char_array_3[j] = 0;

			char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
			char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
			char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
			char_array_4[3] = char_array_3[2] & 0x3f;

			for( j = 0; (j < i + 1); j++)
				ret += base64_chars.charAt(char_array_4[j]);

			while((i++ < 3))
			ret += '=';

		}
		return ret;
	},
	getLongAtArray : function(arr, index) {
		return ((parseFloat(arr[0 + index], 10) & 0xff) * 0x100000000000000) + ((parseFloat(arr[1 + index], 10) & 0xff) * 0x1000000000000) + ((parseFloat(arr[2 + index], 10) & 0xff) * 0x10000000000) + ((parseFloat(arr[3 + index], 10) & 0xff) * 0x100000000) + ((parseFloat(arr[4 + index], 10) & 0xff) * 0x1000000) + ((parseFloat(arr[5 + index], 10) & 0xff) * 0x10000) + ((parseFloat(arr[6 + index], 10) & 0xff) * 0x100) + (parseFloat(arr[7 + index], 10) & 0xFF);
	},
	getIntAtArray : function(arr, index) {
		return ((parseFloat(arr[0 + index], 10) & 0xff) * 0x1000000) + ((parseFloat(arr[1 + index], 10) & 0xff) * 0x10000) + ((parseFloat(arr[2 + index], 10) & 0xff) * 0x100) + (parseFloat(arr[3 + index], 10) & 0xFF);
	},
	getShortAtArray : function(arr, index) {
		return ((parseFloat(arr[0 + index], 10) & 0xff) * 0x100) + (parseFloat(arr[1 + index], 10) & 0xff);
	},
	getArrayAtLong : function(longVal) {
		var o = [];
		var temp = longVal;
		o[0] = this.getInt(parseFloat(temp / 0x100000000000000));
		temp = temp % 0x100000000000000;
		o[1] = this.getInt(parseFloat(temp / 0x1000000000000));
		temp = temp % 0x1000000000000;
		o[2] = this.getInt(parseFloat(temp / 0x10000000000));
		temp = temp % 0x10000000000;
		o[3] = this.getInt(parseFloat(temp / 0x100000000));
		temp = temp % 0x100000000;
		o[4] = this.getInt(parseFloat(temp / 0x1000000));
		temp = temp % 0x1000000;
		o[5] = this.getInt(parseFloat(temp / 0x10000));
		temp = temp % 0x10000;
		o[6] = this.getInt(parseFloat(temp / 0x100));
		temp = temp % 0x100;
		o[7] = this.getInt(parseFloat(temp));
		for(var i = 0; i < o.length; i++) {
			if(o[i] >= 128)
				o[i] = o[i] - 256;
		}
		return o;
	},
	getArrayAtInt : function(intVal) {
		var o = [];
		var temp = intVal;
		o[0] = this.getInt(parseFloat(temp / 0x1000000));
		temp = temp % 0x1000000;
		o[1] = this.getInt(parseFloat(temp / 0x10000));
		temp = temp % 0x10000;
		o[2] = this.getInt(parseFloat(temp / 0x100));

		temp = temp % 0x100;
		o[3] = this.getInt(parseFloat(temp));

		for(var i = 0; i < o.length; i++) {
			if(o[i] >= 128) {
				o[i] = o[i] - 256;
			}
		}
		return o;
	},
	getArrayAtShort : function(shortVal) {
		var obj = [];
		var temp = shortVal;
		obj[0] = this.getInt(parseFloat(temp / 0x100));
		temp = temp % 0x100;
		obj[1] = this.getInt(parseFloat(temp));
		for(var i = 0; i < obj.length; i++) {
			if(obj[i] >= 128) {
				obj[i] = obj[i] - 256;
			}
		}
		return obj;
	},
	strToCharArray : function(str) {
		var arrObj = [];
		if(str) {
			for(var i = 0; i < str.length; i++) {
				arrObj[i] = str.charCodeAt(i);
			}
		}
		return arrObj;
	},
	getInt : function(val) {
		if(val == null || val < 1 || (val + "").indexOf('E') >= 0 || (val + "").indexOf('e') >= 0) {
			val = 0;
		} else {
			val = parseInt(val, 10);
		}
		return val;
	},
	getCRC16Value : function(bytes) {
		if(bytes) {
			var crc = 0xffff;
			var polynomial = 0x1021;
			var bit;
			var c15;
			for(var b in bytes) {
				for(var i = 0; i < 8; i++) {
					bit = ((bytes[b] >> (7 - i) & 1) == 1);
					c15 = ((crc >> 15 & 1) == 1);
					crc <<= 1;
					if(c15 ^ bit) {
						crc ^=polynomial;
					}
				}
			}
			crc &= 0xffff;
			var high = (crc & 0xff00) >>> 8;
			var low = crc & 0x00ff;
			return [high, low];
		} else {
			return null;
		}
	},
	bin2String : function(array) {
		return String.fromCharCode.apply(String, array);
	}
};
