var Pandora = {};
Pandora.Models = {};

$(function() {
	Pandora.Models.API = can.Model(
	/* @Static */
	{
		defaults : {
			_dataPool : [],
			_payloadObjs : [],
			_timer : null
		},

		trackArt : {
			_trackArtPool : [],
			_trackArtPoolCount : 0,
			_timer : null
		},

		stationArt : {
			_stationArtPool : [],
			_stationArtPoolCount : 0,
			_timer : null
		},

		trackExplain : {
			_trackExplainPool : [],
			_trackExplainPoolCount : 0,
			_timer : null
		}
	}, {
		_handlers : [],
		_socket : null,
		registerFunction : function(commandId, fun) {
			this._handlers[commandId] = fun;
		},
		/* Socket connection with hup service */
		_connect : function() {
			console.warn("come into _connect()!!!! ");
			var that = this;
			if (!that._socket) {
				that._socket = io.connect("/CommandControl").send("Pandora");
				that._socket.on('AsyncEvent', function(data) {
					console.warn("AsyncEvent - _socket.on Returned!!!!!!!!!!!! ");
					that._plog(data);
					that._handleData(data);
					console.warn("END AsyncEvent");
				});
			}
		},
		/* Print data log */
		_plog : function(data) {
			var str = "";
			$(data).each(function(index, item) {
				var hexString = parseInt(item).toString(16);
				while (hexString.length < 2) {
					hexString = "0" + hexString;
				}
				str += hexString + " ";
			})
			console.log("_plog " + str.toUpperCase());
		},
		/* Asynchronous data handler */
		_handleData : function(data) {
			Pandora.Models.API.defaults._dataPool = Pandora.Models.API.defaults._dataPool.concat(EscapeTool.unescape(data));
			this._processDataPool();
		},

		_processDataPool : function() {
			var haveMessage = Pandora.Models.API.defaults._dataPool.length >= 10;
			while (haveMessage) {
				if (Pandora.Models.API.defaults._timer) {
					clearTimeout(Pandora.Models.API.defaults._timer);
				}
				if (Pandora.Models.API.defaults._dataPool[0] == 0x7E && Pandora.Models.API.defaults._dataPool[1] == 0x00 && Pandora.Models.API.defaults._dataPool[2] == 0x00) {
					var length = BinaryUtils.getIntAtArray(Pandora.Models.API.defaults._dataPool, 3);
					if (Pandora.Models.API.defaults._dataPool.length >= 10 + length) {
						//get the real frame
						var message = Pandora.Models.API.defaults._dataPool.splice(0, 10 + length);						
						var parser = new Parser();
						var parsedFrame = parser.parse(message);
						Pandora.Models.API.defaults._payloadObjs.push(parsedFrame.getPayload());						
					} else {
						haveMessage = false;
						var that = this;
						Pandora.Models.API.defaults._timer = setTimeout(function() {
							Pandora.Models.API.defaults._dataPool = [];
						}, 5000);
					}
				} else {
					//The data pool is error. Reset the data
					Pandora.Models.API.defaults._dataPool = [];
					haveMessage = false;
				}
			}
			this._processPayloads();
		},
		/*
		 * Process call related handler for response payload messages
		 */
		_processPayloads : function() {
			while (Pandora.Models.API.defaults._payloadObjs.length > 0) {
				var payloadObj = Pandora.Models.API.defaults._payloadObjs.shift();
				console.log("payloadObj:" + JSON.stringify(payloadObj));
				console.log("payloadObj.getCommand():" + payloadObj.getCommand());
				if (payloadObj) {
					var handler = this._handlers[payloadObj.getCommand()];
					if (handler && typeof handler === 'function') {
						handler(payloadObj);
					}
				}
			}
		},
		/*
		 * Add message shell for every command
		 */
		formatRequest : function(payload) {
			var _payload = new Payload(payload);
			var _frame = Frame.DATA(_payload);
			_frame.setSequence(0);
			var command = _frame.toByte();
			return command;
		},
		/*
		 * Send command control message
		 */
		send : function(cmd) {
			//this._connect();
			var data = this.formatRequest(cmd);
			console.warn("send command : ");
			this._plog(data);
			this._socket.emit("Command", data);
		},
		/*
		 * Session start command
		 */
		sessionStart : function(apiVersion, cId, albumArtDimension, stationArtDimensionn) {
			if (!apiVersion)
				apiVersion = 3;
			if (!cId)
				cId = "APITOOL0";
			if (!albumArtDimension)
				albumArtDimension = 200;
			if (!stationArtDimensionn)
				stationArtDimensionn = 44;

			var payload = [];
			payload.push(0x00);
			//command
			payload = payload.concat(BinaryUtils.getArrayAtShort(apiVersion));
			//api_version
			var payloadTextInfo = BinaryUtils.strToCharArray(cId);
			payload = payload.concat(payloadTextInfo);
			//accessory_id
			payload = payload.concat(BinaryUtils.getArrayAtShort(albumArtDimension));
			//album_art_dimension
			payload.push(0x02);
			//image_type
			payload.push(0x00);
			//flags
			payload = payload.concat(BinaryUtils.getArrayAtShort(stationArtDimensionn));
			//text
			this.send(payload);
		},
		/*
		 * Requests the current applicate state of the Mobile App, to be returned via PNDR_RETURN_STATUS.
		 */
		getStatus : function() {
			var payload = [];
			payload.push(0x03);
			this.send(payload);
		},
		/*
		 * Terminate the PandoraLink session, stopping communication.
		 */
		sessionTerminate : function() {
			var payload = [];
			payload.push(0x05);
			this.send(payload);
		},
		/*
		 * Requests the current album art to be returned via one or more consecutive PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT commands
		 */
		getTrackAlbumArt : function() {
			var payload = [];
			payload.push(0x14);
			payload = payload.concat(BinaryUtils.getArrayAtInt(4090));
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App of the user’s intention to resume playing audio.
		 */
		eventTrackPlay : function() {
			var payload = [];
			payload.push(0x30);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App of the user’s intention to pause audio.
		 */
		eventTrackPause : function() {
			var payload = [];
			payload.push(0x31);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to skip to the next audio track.
		 */
		eventTrackSkip : function() {
			var payload = [];
			payload.push(0x32);
			this.send(payload);
		},
		/*
		 * Requests the track token, album art length, flags, duration, elapsed play time in seconds,
		 * and rating for the current track to be returned via PNDR_RETURN_TRACK_INFO.
		 */
		getTrackInfo : function() {
			var payload = [];
			payload.push(0x10);
			this.send(payload);
		},
		/*
		 * Requests the title of the currently playing track to be returned via PNDR_RETURN_TRACK_TITLE.
		 */
		getTrackTitle : function() {
			var payload = [];
			payload.push(0x11);
			this.send(payload);
		},
		/*
		 * Requests the artist for the currently playing track to be returned via PNDR_RETURN_TRACK_ARTIST.
		 */
		getTrackArtist : function() {
			var payload = [];
			payload.push(0x12);
			this.send(payload);
		},
		/*
		 * Requests the album for the currently playing track to be returned via PNDR_RETURN_TRACK_ALBUM.
		 */
		getTrackAlbum : function() {
			var payload = [];
			payload.push(0x13);
			this.send(payload);
		},
		
		/*		 
		 * Instructs the Mobile App to enable or disable automatic elapsed time updates.
		 * */
		setTrackElapsedPolling : function(enable){
			var payload = [];
			payload.push(0x15);
			payload = payload.concat(enable);
			this.send(payload);
		},
		/*
		 * Requests that all current track metadata be returned in one response:
		 *track token, album art length, flags, duration, elapsed play time in seconds, rating, title, artist and album.
		 */
		getTrackInfoExtended : function() {
			var payload = [];
			payload.push(0x16);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to send informative text regarding why this track was chosen.
		 */
		eventTrackExplain : function() {
			var payload = [];
			payload.push(0x35);
			this.send(payload);
		},
		/*
		 * Requests track explanation to be returned via one or more consecutive PNDR_RETURN_TRACK_EXPLAIN_SEGMENT commands. 
		 */
		getTrackExplain : function(){
			var payload = [];
			payload.push(0x36);
			payload = payload.concat(BinaryUtils.getArrayAtInt(4090));
			this.send(payload);
		},
		/*
		 * Requests the currently playing station token
		 */
		getStationActive : function() {
			var payload = [];
			payload.push(0x40);
			this.send(payload);
		},
		/*
		 * Requests the art for each station token in an array of station_tokens to be returned via one or more PNDR_RETURN_STATION_ART_SEGMENT payloads.
		 */
		getStationArt : function(stationTokens) {
			var payload = [];
			payload.push(0x4B);
			for (var x in stationTokens) {
				payload = payload.concat(stationTokens[x]);
			}
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to give the current track a "thumbs up."
		 */
		eventTrackRatePositive : function() {
			var payload = [];
			payload.push(0x33);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to give the current track a "thumbs down."
		 */
		eventTrackRateNegative : function() {
			var payload = [];
			payload.push(0x34);
			this.send(payload);
		},
		/*
		 * 0x37 – PNDR_EVENT_TRACK_BOOKMARK_TRACK
		 */
		eventTrackBookmarkTrack : function() {
			var payload = [];
			payload.push(0x37);
			this.send(payload);
		},
		/*
		 * 0x38 – PNDR_EVENT_TRACK_BOOKMARK_ARTIST
		 */
		eventTrackBookmarkArtist : function() {
			var payload = [];
			payload.push(0x38);
			this.send(payload);
		},
		/*
		 * Event Station Create From Current Artist (0x49 – PNDR_EVENT_STATION_CREATE_FROM_CURRENT_ARTIST)
		 */
		eventStationCreateFromCurrentArtist : function() {
			var payload = [];
			payload.push(0x49);
			this.send(payload);
		},
		/*
		 * Event Station Create From Current Track (0x4A – PNDR_EVENT_STATION_CREATE_FROM_CURRENT_TRACK)
		 */
		eventStationCreateFromCurrentTrack : function() {
			var payload = [];
			payload.push(0x4A);
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to begin playing the given station.
		 */
		eventStationSelect : function(stationToken) {
			var payload = [];
			payload.push(0x47);
			payload = payload.concat(BinaryUtils.getArrayAtInt(stationToken));
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to delete the given station.
		 */
		eventStationDelete : function(stationToken) {
			var payload = [];
			payload.push(0x48);
			payload = payload.concat(BinaryUtils.getArrayAtInt(stationToken));
			this.send(payload);
		},
		/*
		 * Requests extended search results for the given search text to the accessory.
		 */
		eventSearchExtended : function(searchId, searchText) {
			var payload = [];
			payload.push(0x61);
			payload = payload.concat(BinaryUtils.getArrayAtInt(searchId));
			payload = payload.concat(BinaryUtils.strToCharArray(searchText));
			this.send(payload);
		},
		/*
		 * Requests the result info for each music token in the given array to be returned via PNDR_RETURN_SEARCH_RESULT_INFO.
		 */
		getSearchResultInfo : function(searchId, musicTokens) {
			var payload = [];
			payload.push(0x62);
			payload = payload.concat(BinaryUtils.getArrayAtInt(searchId));
			payload = payload.concat(musicTokens);
			this.send(payload);
		},
		/*
		 * Requests station creation based on a selection from a previously returned search results.
		 */
		eventSearchSelect : function(searchId, musicId) {
			var payload = [];
			payload.push(0x63);
			payload = payload.concat(BinaryUtils.getArrayAtInt(searchId));
			payload = payload.concat(BinaryUtils.getArrayAtInt(musicId));
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to sort stations in the given order.
		 */
		eventStationsSort : function(sort_order) {
			var payload = [];
			payload.push(0x46);
			payload = payload.concat(sort_order);
			this.send(payload);
		},
		/*
		 * Requests the name and flags for each station token in an array of station_tokens to be returned via PNDR_RETURN_STATION_INFO.
		 */
		getStationsOrder : function() {
			var payload = [];
			payload.push(0x45);
			this.send(payload);
		},
		/*
		 * Requests number of stations for the current user to be returned via PNDR_RETURN_STATION_COUNT.
		 */
		getStationCount : function() {
			var payload = [];
			payload.push(0x41);
			this.send(payload);
		},
		/*
		 * Requests all of the user's station tokens to be returned via PNDR_RETURN_STATION_TOKENS.
		 */
		getAllStationTokens : function() {
			var payload = [];
			payload.push(0x43);
			this.send(payload);
		},
		/*Requests the name and flags for each station token in an array of station_tokens to be returned*/
		getStationInfo : function(stationTokens) {
			var payload = [];
			payload.push(0x44);
			console.log("getStationInfo --- >stationTokens: " + stationTokens);
			for (var x in stationTokens) {
				payload = payload.concat(stationTokens[x]);
			}
			this.send(payload);
		},
		/*
		 * Instructs the Mobile App to send the specified number of station names for a genre category starting from the specified index to be returned
		 * via PNDR_RETURN_GENRE_STATION_NAMES.
		 */
		getGenreStationNames : function(cId, startIndex, count) {
			var payload = [];
			payload.push(0x51);
			payload = payload.concat(BinaryUtils.getArrayAtInt(cId));
			payload = payload.concat(BinaryUtils.getArrayAtInt(startIndex));
			payload = payload.concat(BinaryUtils.getArrayAtInt(count));
			this.send(payload);
		},
		/*
		 * Requests the art for each genre station index starting from the specified index to count,
		 * to be returned via one or more PNDR_RETURN_GENRE_STATION_ART_SEGMENT payloads.
		 */
		getGenreStationArt : function(cId, startIndex, count) {
			var payload = [];
			payload.push(0x53);
			payload = payload.concat(BinaryUtils.getArrayAtInt(4000));
			payload = payload.concat(BinaryUtils.getArrayAtInt(cId));
			payload = payload.concat(BinaryUtils.getArrayAtInt(startIndex));
			payload = payload.concat(BinaryUtils.getArrayAtInt(count));
			this.send(payload);
		},
		/*
		 * Requests an array of all genre categories, to be returned via PNDR_RETURN_GENRE_CATEGORY_NAMES.
		 */
		getAllGenreCategoryNames : function() {
			var payload = [];
			payload.push(0x4F);
			this.send(payload);
		},
		/*
		 * Creates a new user station based on the specified genre station.
		 */
		eventSelectGenreStation : function(category_index, station_index) {
			var payload = [];
			payload.push(0x52);
			payload = payload.concat(BinaryUtils.getArrayAtInt(category_index));
			payload = payload.concat(BinaryUtils.getArrayAtInt(station_index));
			this.send(payload);
		},

		/*
		 * 0x95 – PNDR_RETURN_TRACK_ALBUM_ART_SEGMENT
		 */
		processTrackAlbumArt : function(payloadObj) {
			var encodedImages = null;
			if (Pandora.Models.API.trackArt._timer) {
				clearTimeout(Pandora.Models.API.trackArt._timer);
			}
			Pandora.Models.API.trackArt._timer = setTimeout(function() {
				Pandora.Models.API.trackArt._trackArtPool = [];
				Pandora.Models.API.trackArt._trackArtPoolCount = 0;
			}, 5000);

			if (payloadObj) {
				if (payloadObj.getCommand() == 0x95) {
					var trackToken = payloadObj.getTrackToken();
					console.log("processTrackAlbumArt---> trackToken:" + trackToken);
					var segmentIndex = payloadObj.getSegmentIndex();
					console.log("processTrackAlbumArt---> segmentIndex:" + segmentIndex);
					var totalSegments = payloadObj.getTotalSegments();
					console.log("processTrackAlbumArt---> totalSegments:" + totalSegments);
					var imgData = payloadObj.getImageData();
					console.log("processTrackAlbumArt---> imgData:" + imgData);
					Pandora.Models.API.trackArt._trackArtPool[segmentIndex] = imgData;
					Pandora.Models.API.trackArt._trackArtPoolCount++;
					if (Pandora.Models.API.trackArt._trackArtPoolCount == totalSegments) {
						var images = [];
						var i = 0;
						while (i < totalSegments) {
							images = images.concat(Pandora.Models.API.trackArt._trackArtPool[i++]);
						}
						encodedImages = BinaryUtils.binaryToBase64(images);
						console.log("processTrackAlbumArt---> encodedImages:" + encodedImages);
						Pandora.Models.API.trackArt._trackArtPool = [];
						Pandora.Models.API.trackArt._trackArtPoolCount = 0;

					}
				}
			}
			return encodedImages;
		},
		/*
		 * 0xBB   PNDR_RETURN_GENRE_CATEGORY_NAMES
		 */
		processAllGenreCategoryNames : function(payloadObj) {
			var names = "";
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xBB) {
					names = payloadObj.getNamesArray();
					console.log("processAllGenreCategoryNames---> names:" + names);
				}
			}
			return names;
		},
		/*
		 * 0xB4   PNDR_RETURN_STATION_INFO
		 */
		processStations : function(payloadObj) {
			var stations = [];
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB4) {
					stations = payloadObj.getStationInfoList();
					console.log("processStations---> stations:" + JSON.stringify(stations));
				}
			}
			return stations;
		},
		/*
		 * 0xB8   PNDR_RETURN_STATION_ART_SEGMENT
		 */
		processStationArt : function(payloadObj) {
			var stationArt = {
				stationToken : null,
				encodedImages : null
			};

			if (Pandora.Models.API.stationArt._timer) {
				clearTimeout(Pandora.Models.API.stationArt._timer);
			}
			Pandora.Models.API.stationArt._timer = setTimeout(function() {
				Pandora.Models.API.stationArt._stationArtPool = [];
				Pandora.Models.API.stationArt._stationArtPoolCount = 0;
			}, 5000);

			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB8) {
					stationArt.stationToken = payloadObj.getStationToken();
					var artLength = payloadObj.getArtLength();
					var segmentIndex = payloadObj.getSegmentIndex();
					var totalSegments = payloadObj.getTotalSegments();
					
					var imgData = payloadObj.getImageData();
					console.log("processStationArt---> imgData:" + imgData);
					
					Pandora.Models.API.stationArt._stationArtPool[segmentIndex] = imgData;
					Pandora.Models.API.stationArt._stationArtPoolCount++;

					if (Pandora.Models.API.stationArt._stationArtPoolCount == totalSegments) {
						var images = [];
						var i = 0;
						while (i < totalSegments) {
							images = images.concat(Pandora.Models.API.stationArt._stationArtPool[i++]);
						}
						stationArt.encodedImages = BinaryUtils.binaryToBase64(images);
						console.log("processTrackAlbumArt---> stationArt.encodedImages:" + stationArt.encodedImages);
						Pandora.Models.API.stationArt._stationArtPool = [];
						Pandora.Models.API.stationArt._stationArtPoolCount = 0;
					}
				}
			}
			return stationArt;
		},
		/*
		 * 0xB3   PNDR_RETURN_STATION_TOKENS
		 */
		processStationTokens : function(payloadObj) {
			var tokens = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB3) {
					var startIndex = payloadObj.getStartIndex();
					tokens = payloadObj.getStationTokens();
					console.log("processStationTokens---> tokens:" + tokens);
				}
			}
			return tokens;
		},
		/*
		 * 0xB2   PNDR_RETURN_STATION_COUNT
		 */
		processStationCount : function(payloadObj) {
			var count = -1;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB2) {
					count = payloadObj.getCount();
					console.log("processStationCount---> count:" + count);
				}
			}
			return count;
		},
		/*
		 * 0xD0   PNDR_UPDATE_SEARCH
		 */
		processUpdateSearch : function(payloadObj) {
			var search = [];
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xD0) {
					var searchId = payloadObj.getSearchId();
					console.log("processUpdateSearch---> searchId:" + searchId);
					var musicTokens = payloadObj.getMusicTokens();
					console.log("processUpdateSearch---> musicTokens:" + musicTokens);
					search.push({
						"searchId" : searchId,
						"musicTokens" : musicTokens
					});
				}
			}
			return search;
		},
		/*
		 * 0xD1   PNDR_RETURN_SEARCH_RESULT_INFO
		 */
		processSearchResultInfo : function(payloadObj) {
			var results = [];
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xD1) {
					console.log("processSearchResultInfo---> results:" + results);
					results = payloadObj.getSearchResult();
				}
			}
			return results;
		},
		/*
		 * 0xBD   PNDR_RETURN_GENRE_STATION_NAMES
		 */
		processGenreStations : function(payloadObj) {
			var names = "";
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xBD) {
					var cId = payloadObj.getCategoryIndex();
					var startIndex = payloadObj.getStartIndex();
					names = payloadObj.getNamesArray();
					console.log("processGenreStations---> names:" + names);
				}
			}
			return names;
		},
		/*
		 * 0xB7   PNDR_UPDATE_STATION_DELETED
		 */
		processUpdateStationDelete : function(payloadObj) {
			var stationToken = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB7) {
					stationToken = payloadObj.getStationToken();
					console.log("processUpdateStationDelete---> stationToken:" + stationToken);
				}
			}
			return stationToken;
		},
		/*
		 * 0xD2   PNDR_UPDATE_STATION_ADDED
		 */
		processUpdateStationAdd : function(payloadObj) {
			var notification = {};
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xD2) {
					var stationToken = payloadObj.getStationToken();
					var index = payloadObj.getIndex();
					notification = {
						stationToken : stationToken,
						index : index
					};
					console.log("processUpdateStationAdd---> notification:" + JSON.stringify(notification));
				}
			}
			return notification;
		},
		/*
		 * 0x81   PNDR_UPDATE_STATUS
		 */
		processUpdateStatus : function(payloadObj) {
			var status = -1;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x81) {
					status = payloadObj.getCode();
				}
			}
			return status;
		},
		/*
		 * 0x82   PNDR_RETURN_STATUS
		 */
		processReturnStatus : function(payloadObj) {
			var status = -1;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x82) {
					status = payloadObj.getCode();
					console.log("processReturnStatus---> status:" + status);
				}
			}
			return status;
		},
		/*
		 * 0x90   PNDR_UPDATE_TRACK
		 */
		processUpdateTrack : function(payloadObj) {
			var tToken = 0;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x90) {
					tToken = payloadObj.getTrackToken();
					console.log("processUpdateTrack---> sToken:" + tToken);
				}
			}
			return tToken;
		},
		/*
		 * 0x91   PNDR_RETURN_TRACK_INFO
		 */
		processTrackInfo : function(payloadObj) {
			var trackInfo = {
				trackToken : null,
				albumArtLength : null,
				duration : null,
				elapsed : null,
				rating : null,
				permissionFlags : null,
				identityFlags : null
			};
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x91) {
					trackInfo.trackToken = payloadObj.getTrackToken();
					trackInfo.albumArtLength = payloadObj.getAlbumArtLength();
					trackInfo.duration = payloadObj.getDuration();
					trackInfo.elapsed = payloadObj.getElapsed();
					trackInfo.rating = payloadObj.getRating();
					trackInfo.permissionFlags = payloadObj.getPermissionFlags();
					trackInfo.identityFlags = payloadObj.getIdentityFlags();
				}
			}
			return trackInfo;
		},
		/*
		 * 0x92   PNDR_RETURN_TRACK_TITLE
		 */
		processTrackTitle : function(payloadObj) {
			var title = "";
			if (payloadObj)
				if (payloadObj.getCommand() == 0x92)
					title = payloadObj.getTrackName();
			return title;
		},
		/*
		 * 0x93   PNDR_RETURN_TRACK_ARTIST
		 */
		processTrackArtist : function(payloadObj) {
			var artist = "";
			if (payloadObj)
				if (payloadObj.getCommand() == 0x93)
					artist = payloadObj.getArtistName();
			return artist;
		},
		/*
		 * 0x94   PNDR_RETURN_TRACK_ALBUM
		 */
		processTrackAlbum : function(payloadObj) {
			var album = "";
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x94) {
					console.log("processTrackAlbum---> body:" + body);
					album = payloadObj.getAlbumName();
				}
			}
			return album;
		},
		/*
		 * Update Track Album Art (0x96 – PNDR_UPDATE_TRACK_ALBUM_ART)
		 */
		processUpdateTrackAlbumArt : function(payloadObj){
			var albumArt = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x96) {					
					var trackToken = payloadObj.getTrackToken();
					console.log("processUpdateTrackAlbumArt---> trackToken:" + trackToken);
					var albumArtLength = payloadObj.getAlbumArtLength();
					console.log("processUpdateTrackAlbumArt---> albumArtLength:" + albumArtLength);
					albumArt = {
						trackToken : trackToken,
						albumArtLength : albumArtLength 
					};
				}
			}
			return albumArt;
		},
		/*
		 * Return Track Info Extended (0x9D – PNDR_RETURN_TRACK_INFO_EXTENDED)
		 */
		processTrackInfoExtended : function(payloadObj) {
			var trackInfoExt = {
				trackToken : null,
				albumArtLength : null,
				duration : null,
				elapsed : null,
				rating : null,
				permissionFlags : null,
				identityFlags : null,
				title : null,
				artist : null,
				album : null
			};
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x9D) {
					trackInfoExt.trackToken = payloadObj.getTrackToken();
					trackInfoExt.albumArtLength = payloadObj.getAlbumArtLength();
					trackInfoExt.duration = payloadObj.getDuration();
					trackInfoExt.elapsed = payloadObj.getElapsed();
					trackInfoExt.rating = payloadObj.getRating();
					trackInfoExt.permissionFlags = payloadObj.getPermissionFlags();
					trackInfoExt.identityFlags = payloadObj.getIdentityFlags();
					trackInfoExt.title = payloadObj.getTrackName();
					trackInfoExt.artist = payloadObj.getArtistName();
					trackInfoExt.album = payloadObj.getAlbumName();
				}
			}
			return trackInfoExt;
		},
		/*
		 * Update Track Elapsed (0x97 – PNDR_UPDATE_TRACK_ELAPSED)
		 */
		processUpdateTrackElapsed : function(payloadObj){
			var elapsed = "";
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x97) {
					console.log("processUpdateTrackElapsed---> body:" + body);
					elapsed = payloadObj.getTimeElapsed();
				}
			}
			return elapsed;
		},
		/*
		 * Return Track Explain Segment (0x9A – PNDR_RETURN_TRACK_EXPLAIN_SEGMENT)
		 */
		processTrackExplainSegment : function(payloadObj) {
			var explain = [];
			if (Pandora.Models.API.trackExplain._timer) {
				clearTimeout(Pandora.Models.API.trackExplain._timer);
			}
			Pandora.Models.API.trackExplain._timer = setTimeout(function() {
				Pandora.Models.API.trackExplain._trackExplainPool = [];
				Pandora.Models.API.trackExplain._trackExplainPoolCount = 0;
			}, 5000);

			if (payloadObj) {
				if (payloadObj.getCommand() == 0x9A) {
					var trackToken = payloadObj.getTrackToken();
					console.log("processTrackExplainSegment---> trackToken:" + trackToken);
					var segmentIndex = payloadObj.getSegmentIndex();
					console.log("processTrackExplainSegment---> segmentIndex:" + segmentIndex);
					var totalSegments = payloadObj.getTotalSegments();
					console.log("processTrackExplainSegment---> totalSegments:" + totalSegments);
					var body = payloadObj.getData();
					Pandora.Models.API.trackExplain._trackExplainPool[segmentIndex] = body;
					Pandora.Models.API.trackExplain._trackExplainPoolCount++;
					if (Pandora.Models.API.trackExplain._trackExplainPoolCount == totalSegments) {
						var i = 0;
						while (i < totalSegments) {
							explain = explain.concat(Pandora.Models.API.trackExplain._trackExplainPool[i++]);
						}
						Pandora.Models.API.trackExplain._trackExplainPool = [];
						Pandora.Models.API.trackExplain._trackExplainPoolCount = 0;
					}
				}
			}
			return BinaryUtils.bin2String(explain);
		},
		/*
		 * 0xBA   PNDR_UPDATE_STATION_ACTIVE
		 */
		processUpdateStationActive : function(payloadObj) {
			var sToken = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xBA) {
					console.log("processUpdateStationActive---> payloadObj:" + payloadObj);
					sToken = payloadObj.getStationToken();
					console.log("processUpdateStationActive---> sToken:" + sToken);
				}
			}
			return sToken;
		},
		/*
		 * 0xB1 – PNDR_RETURN_STATION_ACTIVE
		 */
		processStationActive : function(payloadObj) {
			var sToken = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB1) {
					sToken = payloadObj.getStationToken();
					console.log("processStationActive---> sToken:" + sToken);
				}
			}
			return sToken;
		},
		/*
		 * Return Stations Order (0xB5 – PNDR_RETURN_STATIONS_ORDER)
		 */
		processReturnStationsOrder : function(payloadObj) {
			var order = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB5) {
					order = payloadObj.getOrder();
					console.log("processReturnStationsOrder---> order:" + order);
				}
			}
			return order;
		},
		/*
		 * Update Stations Order (0xB6 – PNDR_UPDATE_STATIONS_ORDER)
		 */
		processUpdateStationsOrder : function(payloadObj) {
			var order = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0xB6) {
					order = payloadObj.getOrder();
					console.log("processUpdateStationsOrder---> order:" + order);
				}
			}
			return order;
		},
		/*
		 * Update Notice (0x83 – PNDR_UPDATE_NOTICE)
		 */
		processUpdateNotice : function(payloadObj){
			var code = -1;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x83) {
					order = payloadObj.getCode();
					console.log("processUpdateNotice---> code:" + order);
				}
			}
			return code;
		},
		/*
		 * Update Track Rating (0x98 – PNDR_UPDATE_TRACK_RATING)
		 */
		processUpdateTrackRating : function(payloadObj){
			var trackRating = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x98) {
					var trackToken = payloadObj.getTrackToken();
					console.log("processUpdateTrackRating---> trackToken:" + trackToken);
					var trackRating = payloadObj.getTrackRating();
					console.log("processUpdateTrackRating---> trackRating:" + trackRating);
					trackRating = {
						trackToken : trackToken,
						trackRating : trackRating
					};
				}
			}
			return trackRating;
		},
		
		/* 
		 * Update Track Bookmark Track (0x9B – PNDR_UPDATE_TRACK_BOOKMARK_TRACK)
		 */
		processUpdateTrackBookmarkTrack : function(payloadObj){
			var trackMarked = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x9B) {
					var trackToken = payloadObj.getTrackToken();
					console.log("processUpdateTrackBookmarkTrack---> trackToken:" + trackToken);
					var is_marked = payloadObj.getIsBookmarked();
					console.log("processUpdateTrackBookmarkTrack---> is_marked:" + is_marked);
					trackMarked = {
						trackToken : trackToken,
						is_marked : is_marked
					};
				}
			}
			return trackMarked;
		},
		
		/*
		 * Update Track Bookmark Artist (0x9C – PNDR_UPDATE_TRACK_BOOKMARK_ARTIST)
		 */
		processUpdateTrackBookmarkArtist : function(payloadObj){
			var trackMarked = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x9B) {
					var trackToken = payloadObj.getTrackToken();
					console.log("processUpdateTrackBookmarkTrack---> trackToken:" + trackToken);
					var is_marked = payloadObj.getIsBookmarked();
					console.log("processUpdateTrackBookmarkTrack---> is_marked:" + is_marked);
					trackMarked = {
						trackToken : trackToken,
						is_marked : is_marked
					};
				}
			}
			return trackMarked;
		},
		
		/*
		 * Update Track Explain (0x99 – PNDR_UPDATE_TRACK_EXPLAIN)
		 */
		processUpdateTrackExplain : function(payloadObj){
			var trackExplain = null;
			if (payloadObj) {
				if (payloadObj.getCommand() == 0x99) {
					
				}
			}
			return trackExplain;
		}
	});
});
