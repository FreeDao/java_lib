var pandora = can.Construct({}, {

	/**
	 * Initialize the home app
	 */
	init : function() {
		$('aqapp').html('pandora/views/init.ejs', {});
	}
});

APP.pandora = new pandora();

AQ.loadStylesheet("pandora/pandora.css");

$.jsperanto.init(function(t){

	AQ.loadScript("pandora/js/util.js", function() {
		AQ.loadScript(["pandora/parser/resources.js", "pandora/parser/EscapeTool.js", "pandora/parser/Conversion.js", "pandora/parser/Class.js", "pandora/parser/Frame.js", "pandora/parser/Parser.js"], function() {
			AQ.loadScript(["pandora/parser/payload/Payload.js", 
			"pandora/parser/payload/ReturnStatusPayload.js",
			"pandora/parser/payload/ReturnStationActivePayload.js", 
			"pandora/parser/payload/ReturnStationsOrderPayload.js",
			"pandora/parser/payload/ReturnTrackExplainSegmentPayload.js",		
			"pandora/parser/payload/SearchResultInfoPayload.js",
			"pandora/parser/payload/SessionStartPayload.js",		
			"pandora/parser/payload/StationCountPayload.js",
			"pandora/parser/payload/StationDeletePayload.js",
			"pandora/parser/payload/StationInfoPayload.js",
			"pandora/parser/payload/StationSelectPayload.js",
			"pandora/parser/payload/StationSortPayload.js",
			"pandora/parser/payload/StationTokensPayload.js",
			"pandora/parser/payload/StationArtSegmentPayload.js",		
			"pandora/parser/payload/TrackAlbumArtSegmentPayload.js",
			"pandora/parser/payload/TrackAlbumPayload.js",
			"pandora/parser/payload/TrackArtistPayload.js",
			"pandora/parser/payload/TrackElapsedPayload.js",
			"pandora/parser/payload/TrackInfoPayload.js",
			"pandora/parser/payload/TrackTitlePayload.js",
			"pandora/parser/payload/UpdateNoticePayload.js",
			"pandora/parser/payload/UpdateSearchPayload.js",
			"pandora/parser/payload/UpdateStationAddedPayload.js",
			"pandora/parser/payload/UpdateStationDeletedPayload.js",
			"pandora/parser/payload/UpdateStationsOrderPayload.js",
			"pandora/parser/payload/UpdateStatusPayload.js",
			"pandora/parser/payload/UpdateTrackAlbumArtPayload.js",
			"pandora/parser/payload/TrackInfoExtendedPayload.js",	
			"pandora/parser/payload/UpdateTrackPayload.js",
			"pandora/parser/payload/UpdateTrackRatingPayload.js",
			"pandora/parser/payload/UpdateTrackBookmarkPayload.js",
			"pandora/parser/payload/UpdateTrackExplainPayload.js"], function() {
				AQ.loadScript("pandora/js/modelWithParser.js", function() {//TODO it's for that case : model with Parser classes including -- AQ.loadScript("pandora/js/modelWithParser.js", function() {
					AQ.loadScript(["pandora/js/resp.js", "pandora/js/fixture.js"], function() {
						AQ.loadScript("pandora/js/controller.js");
					});
				});

			});

		});
	});

}, {
	appName: 'Pandora',
	lang: AQ.language 
});



