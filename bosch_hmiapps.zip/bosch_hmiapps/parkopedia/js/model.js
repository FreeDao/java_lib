var PO = {};
PO.Models = {};

$(function() {
	PO.Models.API = can.Model({
		
		defaults : {
			FAVORITES_URL : '',
			SORT_FAVORITES_URL : '',
			NEARBY_PARKING_URL : '',
			SORT_NEARBY_PARKING_URL : ''
		},

		sendHttpRequest : function(args, type, dataType) {
			$.ajax({
				url : args.url,
				data : args.data,
				type : type ? type : 'POST',
				dataType : dataType ? dataType : 'JSON',
				success : args.success,
				error : args.error
			});
		},
		/* Nearby parking */
		getNearbyParking : function(args){
			args.url = can.fixture.on ? '/nearby_parking' : PO.Models.API.defaults.NEARBY_PARKING_URL;
			this.sendHttpRequest(args);
		},
		
		/*sort nearby parking*/		
		getSortNearbyParking : function(args){
			args.url = can.fixture.on ? '/sort_nearby_parking' : PO.Models.API.defaults.SORT_NEARBY_PARKING_URL;
			this.sendHttpRequest(args);
		},
		
		/* Favorites */
		getFavorites : function(args) {
			args.url = can.fixture.on ? '/favorites' : PO.Models.API.defaults.FAVORITES_URL;
            this.sendHttpRequest(args);
		},
		
		/* Sort Favorites */
		getSortFavorites : function(args) {
			args.url = can.fixture.on ? '/favorites' :PO.Models.API.defaults.SORT_FAVORITES_URL;
            this.sendHttpRequest(args);
		},
		
		/* Details */
		getDetail : function(args){
//			arg.url = can.fixture.on ?''
			this.sendHttpRequest(args);
		},
	
	}, { });
});
