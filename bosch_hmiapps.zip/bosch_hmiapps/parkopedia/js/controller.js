$(function() {
	
	/* Controller - Header */
	PO.Header = can.Control({
		defaults : { }
	}, {
		header : new can.Observe({
			title : '',
		}),		
		
		init : function(el) {
			this.header.attr('title', 'Nearby Parking');
			$("#header").html(can.view("parkopedia/views/header-views/common.ejs", {
				data : this.header
			}));
		},
		
		updateTitle : function(title) {
			this.header.attr("title", title);
		},

		"#header-title click" : function() {
			can.route.attr({ type : "parkopedia", page : "home" });
		}
	});

	/* Controller - PageContent */
	PO.Pagecontent = can.Control({
		defaults : { 
			mainMenu :["Sort by Price","favorites","Use Current Location","Use Navigation Destination"],
			favoriteMenu :["Sort by Price","Edit Favorite"]
		}
	}, {		
		vo_nearby_parking : new can.Observe.List([]),
		vo_sort_nearby_parking : new can.Observe.List([]),
		vo_favorites : new can.Observe.List([]),
		vo_sort_favorites : new can.Observe.List([]),
		
		//observe station
		vo_station : new can.Observe(),
		//observe popup
		vo_popup : new can.Observe(),
		
		init : function(){
			this.loadNearbyParking();
		},
		
		loadNearbyParking : function(){
			var self = this;
			var success = function(res){
				for(var i in res.Parkingspaces){
					self.vo_nearby_parking.push(res.Parkingspaces[i]);
				}
				console.log(">>>>>>" + JSON.stringify(self.vo_nearby_parking));
				
				$('#pagecontent').html(can.view('parkopedia/views/pagecontent-views/list.ejs', {
					data : self.vo_nearby_parking,
					pageId : "nearby_parking_menu"
				}));				
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			
			var error = function(err) {
				console.log("Get Nearbyparking request caught error : " + JSON.stringify(err));
			};
			
			PO.Models.API.getNearbyParking({
				data : {
					"type" : 'NearbyParking'
				},
				success : success,
				error : error
			});
			
		},
		
	
		/*load Favorites */
		loadFavorites : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.Parkingspaces) {
					self.vo_favorites.push(res.Parkingspaces[i]);
					
				}
				console.log(">>>>>>" + JSON.stringify(self.vo_favorites));
				
				$('#pagecontent').html(can.view('parkopedia/views/pagecontent-views/list.ejs', {
					data : self.vo_favorites,
					pageId : "favorites"
				}))
				
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};

			var error = function(res) {
				console.log("Get Favorites request caught error : " + JSON.stringify(res));
			};
			
			PO.Models.API.getFavorites({
				data : {
					"type" : 'Favorites'
				},
				success : success,
				error : error
			});
			
		},
		
	//nearby parking menu event
		"#sort_nearby_parking #menu_signal , #nearby_parking_menu #menu_signal click" : function(){
			header.updateTitle("Menu");
			$("#pagecontent").html(can.view("parkopedia/views/pagecontent-views/menu.ejs", {
				data : PO.Pagecontent.defaults.mainMenu,
				pageId : "menu"
			}));
		},
		
		
	//use current location event
		"#menu #use_current_location click" : function(){		
			header.updateTitle("Nearby Parking");
			$('#pagecontent').html(can.view('parkopedia/views/pagecontent-views/list.ejs', {
				data : this.vo_nearby_parking,
				pageId : "nearby_parking_menu"
			}));				
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},
	
	//favorites event
		"#menu #favorites click" : function(){	
			header.updateTitle("Favorites");
			this.loadFavorites();
		},
	
	//the main menu sort by price event
		"#menu #sort_by_price click" : function(){
			var self = this;
			var success = function(res){
				for(var i in res.Parkingspaces){
					self.vo_sort_nearby_parking.push(res.Parkingspaces[i]);
				}
				console.log(">>>>>>>>" + JSON.stringify(self.vo_sort_nearby_parking));
				$('#pagecontent').html(can.view('parkopedia/views/pagecontent-views/list.ejs', {
					data : self.vo_sort_nearby_parking,
					pageId: "sort_nearby_parking"
				}));	
					
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			
			var error = function(res) {
				console.log("Get Sort Nearby Parking request caught error : " + JSON.stringify(res));
			};
			
			PO.Models.API.getSortNearbyParking({
				data : {
					"type" : 'SortNearbyParking'
				},
				success : success,
				error : error
			});
			
		},
		
		// load favorite's menu event
		"#sort_favorites #menu_signal , #favorites #menu_signal click" : function(){
			header.updateTitle("Favorites Menu");
			$("#pagecontent").html(can.view("parkopedia/views/pagecontent-views/menu.ejs", {
				data : PO.Pagecontent.defaults.favoriteMenu,
				pageId : "favorites_menu"
			}));
		},
		
		// sort favorites list by price 
		"#favorites_menu #sort_by_price click" : function(){
		
			var self = this;
			
			var success = function(res){
				//self.vo_favorites.concat(res.sections);
				for (var i in res.Parkingspaces) {
					self.vo_sort_favorites.push(res.Parkingspaces[i]);
					
				}
				console.log(">>>>>>" + JSON.stringify(self.vo_sort_favorites));
				
				$('#pagecontent').html(can.view('parkopedia/views/pagecontent-views/list.ejs', {
					data : self.vo_sort_favorites,
					pageId: "sort_favorites"
				}));	
					
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			
			var error = function(res) {
				console.log("Get Sort Favorites request caught error : " + JSON.stringify(res));
			};
			
			PO.Models.API.getSortFavorites({
				data : {
					"type" : 'Favorites'
				},
				success : success,
				error : error
			});
		},
		
		//edit favorites
		"#favorites_menu #edit_favorite click" : function(){
			var self = this
			header.updateTitle("Delete Favorites");
			$('#pagecontent').html(can.view('parkopedia/views/pagecontent-views/list.ejs', {
				data : self.vo_favorites,
				pageId :"edit_favorite_list"
				
			}));			
			$("#menu_signal").hide();
			new scrollbar_control("#scrollbar", {viewport : $(".scroll-main"),
			});
		},
		
		"#edit_favorite_list .entry_style0 click" : function(el){			
			this.vo_station = el.data("station");
			this.vo_popup.attr({'text' : "Do you want to delete" + this.vo_station.name});
			$('#pagecontent').append(can.view('parkopedia/views/pagecontent-views/popup.ejs', {
				data : this.vo_popup
			}));
			$('#popup-container').slideDown(500, function() { });
		},
		
		'#no_btn click' : function(){
			$('#popup-container').slideUp(500,function(){});
		},
		
		'#yes_btn click' : function(){
			//here will write the event later
		},
		
		"#sort_favorites .entry ,#favorites .entry , #sort_nearby_parking .entry , #nearby_parking_menu .entry click" : function(el){
			
			this.vo_station = el.data("station");
			$('#pagecontent').html(can.view('parkopedia/views/pagecontent-views/po-detail-view.ejs', {
				data : this.vo_station
				
			}));
			
			var success = function(data){
				console.log("Get the detail page success");				
			};
			
			var error = function(res){
				console.log("Get the detail caught error");
			};
			
			PO.Models.API.getDetail({
				data : {
					"type" : "detail",
					"stationId" : this.stationId
				},
				success : success,
				error : error	
			});	
		},		
		
		
		/**
		 * Handle the Call button on details page
		 */
		
		"#po-call click" : function(){
			
		},
		/**
		 * Handle the Start button on details page
		 */
		"#po-start click" : function(){
			
		},
		
		/**
		 * Handle the Favorite button on details page
		 */
		"#po-favorite click" : function(){
			
		},
		
		
	});
	
	var  header = new PO.Header("#header", {});
	 var pagecontent = new PO.Pagecontent("#pagecontent", {});
});
