$(document).ready(function($) {

	can.fixture.on = true;
	var NEARBYPARKING = {
		Parkingspaces : [ {
			'id' : '21',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Rainer Square Garage ',
			'price' : '$9.00 / 20min',
			'color' : 'yellow',
			'distance' : '0.16',
			'unit' : 'mi',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '75',
			'available_space' : '43',
			'address' : '409 Union  Street Seattle,WA 98101 206-624-9096'
		}, {
			'id' : '103',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Ave Between U',
			'price' : '$9.00 / 35min',
			'color' : 'red',
			'distance' : '0.7',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Greet ABQ in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '95',
			'available_space' : '43',
			'address' : '510 Ningshuan  Street NJ,NA 98145551 206-624-9096'
		}, {
			'id' : '14552',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Park Place Building',
			'price' : '$7.00 / 30min',
			'color' : 'blue',
			'distance' : '0.18',
			'unit' : 'km',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Hell World.No in and out privileges.Late release fee - $31.00. Payment accepted: Bruce,ANdby,Card',
			'total_space' : '85',
			'available_space' : '33',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		}, {
			'id' : '53222',
			'type' : 'meter',
			'isAvaiable' : 'fale',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Gppd Square Garage',
			'price' : '$7.00 / 23min',
			'color' : 'yellow',
			'distance' : '0.48',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '55',
			'available_space' : '13',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		} ]
	};

	var SORTNEARBYPARKING = {
		Parkingspaces : [ {
			'id' : '53222',
			'type' : 'meter',
			'isAvaiable' : 'false',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Gppd Square Garage',
			'price' : '$7.00 / 23min',
			'color' : 'yellow',
			'distance' : '0.48',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '55',
			'available_space' : '13',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		}, {
			'id' : '14552',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Park Place Building',
			'price' : '$7.00 / 30min',
			'color' : 'blue',
			'distance' : '0.18',
			'unit' : 'km',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '85',
			'available_space' : '33',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		}, {
			'id' : '21',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Rainer Square Garage ',
			'price' : '$9.00 / 20min',
			'color' : 'yellow',
			'distance' : '0.16',
			'unit' : 'mi',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '75',
			'available_space' : '43',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'

		}, {
			'id' : '103',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Ave Between U',
			'price' : '$9.00 / 35min',
			'color' : 'red',
			'distance' : '0.7',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '95',
			'available_space' : '43',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'

		} ]

	};

	var FAVORITES = {

		Parkingspaces : [ {
			'id' : '12',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Square Garage ',
			'price' : '$6.00 / 30min',
			'color' : 'yellow',
			'distance' : '0.16',
			'unit' : 'mi',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '75',
			'available_space' : '43',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'

		}, {
			'id' : '1433',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Garage Rainier Square',
			'price' : '$4.00 / 29min',
			'color' : 'red',
			'distance' : '0.7',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '95',
			'available_space' : '43',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'


		}, {
			'id' : '14552',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Rainier Square Garage',
			'price' : '$8.00 / 30min',
			'color' : 'blue',
			'distance' : '0.18',
			'unit' : 'km',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '85',
			'available_space' : '33',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		}, {
			'id' : '53222',
			'type' : 'meter',
			'isAvaiable' : 'fale',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Gppd Square Garage',
			'price' : '$7.00 / 20min',
			'color' : 'yellow',
			'distance' : '0.48',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '55',
			'available_space' : '13',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		} ]
	};

	var SORTFAVORITES = {
		Parkingspaces : [ {
			'id' : '53222',
			'type' : 'meter',
			'isAvaiable' : 'fale',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Gppd Square Garage',
			'price' : '$7.00 / 20min',
			'color' : 'yellow',
			'distance' : '0.48',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '61',
			'available_space' : '24',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		}, {	
			'id' : '1433',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Garage Rainier Square',
			'price' : '$4.00 / 29min',
			'color' : 'red',
			'distance' : '0.7',
			'unit' : 'm',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '40',
			'available_space' : '23',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		}, {
			'id' : '14552',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Rainier Square Garage',
			'price' : '$8.00 / 30min',
			'color' : 'blue',
			'distance' : '0.18',
			'unit' : 'km',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '66',
			'available_space' : '13',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		}, {
			'id' : '12',
			'type' : 'meter',
			'isAvaiable' : 'true',
			'icon' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Square Garage ',
			'price' : '$6.00 / 30min',
			'color' : 'yellow',
			'distance' : '0.16',
			'unit' : 'mi',
			'direction' : '',
			'rationg' : '',
			'number_ratings' : '',
			'info' : 'Tax included in all prices.No in and out privileges.Late release fee - $35.00. Payment accepted: Coins,Bills,Card',
			'total_space' : '35',
			'available_space' : '21',
			'address' : '166 Software  Street NJ,NA 98145551 1226-624-9096'
		} ]
	};

	can.fixture('POST /nearby_parking', function() {
		return NEARBYPARKING;
	});

	can.fixture('POST /sort_nearby_parking', function() {
		return SORTNEARBYPARKING;
	});

	can.fixture('POST /favorites', function() {
		return FAVORITES;
	});

	can.fixture('POST /sort_favorites', function() {
		return SORTFAVORITES;
	});

});
