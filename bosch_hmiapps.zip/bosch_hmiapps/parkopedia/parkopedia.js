var parkopedia = can.Construct({}, {
	init : function() {
		$('aqapp').html('parkopedia/views/init.ejs', {});
	}
});

APP.parkopedia = new parkopedia();

AQ.loadStylesheet("parkopedia/parkopedia.css");

AQ.loadScript("parkopedia/js/fixture.js", function() {
	AQ.loadScript("parkopedia/js/model.js", function() {
		AQ.loadScript([ "parkopedia/js/controller.js", "parkopedia/js/util.js" ]);
	});
});

