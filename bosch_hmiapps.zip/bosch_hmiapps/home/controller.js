var root = this;
var HOME = {};

$(function() {

	/* Controller - PageContent - Now includes the header*/
	HOME.Pagecontent = can.Control({},{
		defaults : {
			homeButtons : {
				page0 : ["Facebook", "NBCNews", "Google", "Pandora", "iHeartRadio", "Next Page1"],
				page1 : ["Previous Page1", "TuneIn", "Slacker", "Twitter", "Stitcher", "Next Page2"],
				page2 : ["Previous Page2","Ironman","Parkopedia"]
			}
		},
		pageIndex : 0,
	
		init : function() {
			
			var currentPage = can.route.attr().page;
			if(currentPage != "nextpage") {
				can.route.attr({type:"home",page:"home"});
				var that = this;
				this.loadHome();
			}
			
		},
		loadHome : function() {
			
			//Header 
			$('#header').html(can.view("home/views/header-views/header.ejs", {
				"data" : "Apps"
			}));
			
			//Pagecontent
			$('#pagecontent').html(can.view("home/views/pagecontent-views/main_home.ejs", {
				"data" : HOME.Pagecontent.prototype.defaults.homeButtons["page" + HOME.Pagecontent.prototype.pageIndex]
			}));	
		},
				
		"#lnk_next_page1 click" : function() {
			can.route.attr({type:"home",page:"nextpage1"});
		},
		
		loadNextPage1 : function() {
			
			if(HOME.Pagecontent.prototype.pageIndex != 1 ) HOME.Pagecontent.prototype.pageIndex++;
			
			this.loadHome();
		},
		
		"#lnk_next_page2 click" : function(){
			can.route.attr({type:"home",page:"nextpage2"});
		},
		
		loadNextPage2 : function() {
			if(HOME.Pagecontent.prototype.pageIndex != 2 ) HOME.Pagecontent.prototype.pageIndex++;			
			this.loadHome();
		},
		
		"#lnk_previous_page1 click" : function() {
			can.route.attr({type:"home",page:"home1"});
		},
		
		loadPrevPage1 : function() {
			if(HOME.Pagecontent.prototype.pageIndex != 0) HOME.Pagecontent.prototype.pageIndex--;
			this.loadHome();
		},
		
		"#lnk_previous_page2 click" : function() {
			can.route.attr({type:"home",page:"home2"});
		},
		
		loadPrevPage2 : function() {
			if(HOME.Pagecontent.prototype.pageIndex != 1) HOME.Pagecontent.prototype.pageIndex--;
			this.loadHome();
		},
		
		
		"#lnk_facebook click" : function() {
			can.route.attr({type:"facebook",page:"home"});
		},
		"#lnk_google click" : function() {
			can.route.attr({type:"googleplaces",page:"home"});
		},
		"#lnk_iheartradio click" : function() {
			can.route.attr({type:"iheartradio",page:"home"});
		},
		"#lnk_pandora click" : function() {
			can.route.attr({type:"pandora",page:"home"});
		},
		"#lnk_nbcnews click" : function() {
			can.route.attr({type:"nbcnews",page:"home"});
		},
		"#lnk_ironman click" : function() {
			can.route.attr({type:"ironman", page:"home"});
		},
		"#lnk_tunein click" : function() {
			can.route.attr({type:"tunein", page:"home"});
		},
		"#lnk_parkopedia click" : function(){	
			can.route.attr({type:"parkopedia", page:"home"});
		},
		
		//Route for HOME app - pages in home app
		"route" : function(data) {			
			var type = data.type;
			var page = data.page;
			
			if(type == "home" || typeof type == "undefined") {
				
				switch(page) {
					case "nextpage1":
						HOME.Pagecontent.prototype.loadNextPage1();
						break;
					
					case "home1":
						HOME.Pagecontent.prototype.loadPrevPage1();
						break;
						
					case "nextpage2":
						HOME.Pagecontent.prototype.loadNextPage2();
						break;
					
					case "home2":
						HOME.Pagecontent.prototype.loadPrevPage2();
						break;
									
					default:
						HOME.Pagecontent.prototype.loadHome();
				}
			} else {
				console.warn("HOME can.control.route: type is not home. type: " + type);
			}
		}
	});
	
	
	/***  ROUTING  ***/

	//Route for apps
	var routeHandler = function( ev, newVal ) {
		var app = newVal;
		
		if(typeof app == "undefined") {
			HOME.Pagecontent.prototype.loadHome();
		} else if(app != AQ.loadedApp) {
			AQ.switchApp(app);
		}
	};
	
	if(!AQ.initialized) {
		can.route.bind( 'type', routeHandler);
		AQ.initialized = true;
	};
	
	new HOME.Pagecontent("#pagecontent", {});
			
	
});
