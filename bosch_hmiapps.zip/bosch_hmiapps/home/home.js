$(function() {

	var home = can.Construct({}, {
		
		/**
		 * Initialize the home app
		 */
		init: function()
		{
			$('aqapp').html( 'home/views/init.ejs', {} );
		}
	});

	APP.home = new home();

	AQ.loadStylesheet("home/home.css");

	$.jsperanto.init(function(t){
		AQ.loadScript("home/controller.js");
	}, {
		appName: 'Home',
		lang: AQ.language 
	});

	
});
