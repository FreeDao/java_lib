//FIXME: When browsing restaurant items and switch category to something different from the filter on top, the result doesn't change.

var root = this;

$(function() {

	/**
	 * The header controller
	 */
	var head_control = can.Control({
		defaults : {
			title : "Places"
		}
	}, {
		/**
		 * Initialize the header controller
		 */
		init : function(el) {
			$("#header").html(can.view("googleplaces/views/header-views/common.ejs", {
				title : head_control.defaults.title,
				icon : "RESERVED for icon url or anything else"
			}));
		},

		updateTitle : function(newTitle) {
			head_control.defaults.title = newTitle;
			$('#header-text').html(newTitle);
		},

		"#header-title click" : function() {
			can.route.attr({type:"googleplaces",page:"home"});
		}
	});

	/**
	 * Page content controller
	 */
	var pagecontent_control = can.Control({}, {
		defaults : {
			homeButtons : [["Search", "Voice Search", "Categories", "Restaurants", "Cafe", "Next Page"], ["Previous Page", "Bars", "Attractions"]],
			categories : ['Restaurant', 'Food', 'Bar', 'Gas station', 'Establishment', 'RV Park', 'Park', 'Lodging', 'Airport', 'Transit Station', 'Police', 'Doctor', 'Health', 'School', 'Church', 'Store', 'Car Repair'],
			pageIndex : 0,
			temp_timer : null, //temporarily used to simulate the processing time in VR
			details_reference : null,//A textual identifier that uniquely identifies a place
			currentControl : null,
			searchResults : [],
			recentCategory : "Category",
			recentDistance : "Distance",
			distance : 0,
			category : null,
			language : "en",//The language in which to return results, default value is en
			lat : 47.604588,//latitude of the location
			longtd : -122.337750,//longitude of the location
			keyword : null,
			unit : null,//The distance unit
			searchResultsDetails : [],
			getSearchResultsResponse : null,
		},

		init : function(el) {
			can.route.attr({type:"googleplaces",page:"home"});
			this.loadHome();
		},
		
		/**
		 * Loads the homepage of the app based on the current page
		 */
		loadHome : function() {
			root.header.updateTitle("Places");			
			var that = this;
			var pageIndex = this.defaults.pageIndex;
			console.warn('pageIndex ' + pageIndex);
			var homeButtons = this.defaults.homeButtons;

			$('#pagecontent').html(can.view("googleplaces/views/pagecontent-views/main_home.ejs", {
				"data" : homeButtons[pageIndex]
			}));
		},

		/**
		 * Next Page
		 */
		"#next_page_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"nextpage"});
		},
		loadNextPage : function() {
			this.defaults.pageIndex++;
			this.loadHome();
		},

		/**
		 * Previous Page
		 */
		"#previous_page_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"prevpage"});
		},
		loadPrevPage : function() {
			this.defaults.pageIndex--;
			this.loadHome();
		},

		/**
		 * Search
		 */
		"#search_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"search"});
		},

		/*Voice Search*/
		"#voice_search_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"voiceSearch"});
		},
		loadVoiceSearch : function() {
			header.updateTitle("Search");
			this.loadVR({
				isProcessing : false
			});	
		},

		/* Categories */
		"#categories_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"categories"});
		},

		/**
		 * Load the Restaurants results
		 */
		"#restaurants_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"restaurants"});
		},
		loadRestaurants : function() {
			this.defaults.category = "restaurant"
			getAllResults();
			var results = this.filterResults(this.defaults.category);
			this.showSearchResults(results);
			header.updateTitle("Results");
		},
		

		/**
		 * Load the Cafe category results
		 */
		"#cafe_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"cafe"});
		},
		loadCafe : function() {
			this.defaults.category = "food"
			getAllResults();
			var results = this.filterResults(this.defaults.category);
			this.showSearchResults(results);
			header.updateTitle("Results");
		},

		/**
		 * Load the Bar category results
		 */
		"#bars_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"bars"});
		},
		loadBars : function() {
			this.defaults.category = "bar"
			getAllResults();
			var results = this.filterResults(this.defaults.category);
			this.showSearchResults(results);
			header.updateTitle("Results");
		},

		/**
		 * Load the Attractions category results
		 */
		"#attractions_btn click" : function() {
			can.route.attr({type:"googleplaces",page:"attractions"});
		},
		loadAttractions : function() {
			this.defaults.category = ""
			getAllResults();
			var results = this.filterResults(this.defaults.category);
			this.showSearchResults(results);
			header.updateTitle("Results");
		},

		/*filter results*/
		filterResults : function(category) {

			var distanceFilter = [];
			var resultFilter = [];
			var allResults = this.defaults.searchResults;
			var distance = this.defaults.recentDistance;

			if (distance.length) {
				for (x in allResults) {
					if (allResults[x].distance < distance) {
						distanceFilter.push(allResults[x]);
					}
				}
			}

			var categoryFilter = (distanceFilter.length) ? distanceFilter : allResults;

					for (x in categoryFilter) {
						if (categoryFilter[x].category == category.toLowerCase()) {
							resultFilter.push(categoryFilter[x]);
						}
					}
			resultFilter.sort(sortDistance);
			// results = resultFilter;
			return resultFilter;

		},

		/**
		 * Gets the search results based on the given criteria
		 */
		showSearchResults : function(data) {
			var that = this;
			var defaults = {
				distance : this.defaults.distance,
				category : this.defaults.category,
				language : this.defaults.language,
				lat : this.defaults.lat,
				longtd : this.defaults.longtd,
				keyword : this.defaults.keyword,
				unit : this.defaults.unit
			};

			data = $.extend({}, defaults, data);

			console.warn("About to get the search results with:", data);

			var req = {
				data : data,
				success : function(resp) {
					console.log("showSearchResults Success", resp);

					for (var x in resp.results) {
						resp.results[x].distance = Math.round(resp.results[x].distance * 10) / 10;
						var unit = resp.results[x].unit.toUpperCase();

						if (unit == "M") {
							resp.results[x].unit = "mi";
						} else if (unit == "K") {
							resp.results[x].unit = "km";
						} else {
							resp.results[x].unit = "mi";
						}
					}

					that.defaults.getSearchResultsResponse = resp.results;
					that.loadSearchResults(resp.results);
				},
				error : function(jqXHR) {
					console.log("showSearchResults Fail", JSON.stringify(jqXHR));
				}
			};

			//Call the API in the model to get the content
			GPAPI.getSearchResults(req);
		}, //end of showSearchResults()

		/**
		 * Opens the category selection page to filter the data
		 */
		"#result_category_btn click" : function() {
			this.loadCategoriesPage(this.defaults.categories);
		},

		/**
		 * Sorts the displayed results based on the distance
		 */
		"#result_distance_btn click" : function() {
			var results = this.defaults.getSearchResultsResponse;

			results.sort(sortDistance);

			this.loadSearchResults(results);
		},

		/**
		 * Sorts the displayed results based on the ratings
		 */
		"#result_ratings_btn click" : function() {
			var allResults = this.defaults.getSearchResultsResponse;
			allResults.sort(sortRatings);
			this.loadSearchResults(allResults);
		},

		/**
		 * Handle the clicks on the content to load more details
		 */
		".entry.content click" : function(el) {
			this.getSearchResultsDetails(el);
		},

		/**
		 * Handle the click on the "Load more" button
		 * TODO: Need to load more content
		 */
		"#loadmore_btn click" : function(el, ev) {
			ev.stopPropagation();
			console.log("Load more...");
		},

		/**
		 * Loads/populates the given data to the template and update the screen
		 */
		loadSearchResults : function(data) {
			$("#header").show();

			$('#pagecontent').html(can.view('googleplaces/views/pagecontent-views/search_result.ejs', {
				data : data
			}));

			new scrollbar_control("#scrollbar", {
				viewport : $("aqul")
			});
		}, //end of loadSearchResults()

		/**
		 * Handle the cancel button during VR processing
		 */
		"#vr_cancel_btn click" : function(el, ev) {
			clearTimeout(this.defaults.temp_timer);
			this.loadVR({
				isProcessing : false
			});
		},

		"#s_mic_btn click" : function(el, ev) {
			var that = this;

			console.log("start recording...");
			//change the face
			$("#face_indicator").css("background-image", "url(googleplaces/images/face1.png)");
			$("#vr_output > textarea").attr("placeholder", "Start speaking.")

			//initiate the timer
			this.temp_timer = setTimeout(function() {
				that.loadVR({
					isProcessing : true
				});
			}, 4000);
		},

		/**
		 * Loads the VR page
		 */
		loadVR : function(args) {
			var that = this;
			var defaults = {
				isProcessing : false
			};
			var args = $.extend({}, defaults, args);

			$("#header").show();

			//Show the relevant template based on whether the VR is being processed or not
			if (args.isProcessing) {
				$('#pagecontent').html(can.view('googleplaces/views/pagecontent-views/vr_search_ing.ejs', {}));
				//initiate the timer
				this.temp_timer = setTimeout(function() {
					//TODO: Once the VR works, change this to that.loadSearchResults()
					that.showSearchResults();
					header.updateTitle("Results");
				}, 2000);
			} else {
				$('#pagecontent').html(can.view('googleplaces/views/pagecontent-views/vr_search.ejs', {}));
			}
		}, //end of loadVR()

		/**
		 * Handle the navigation button on details page
		 */
		"#navi_btn click" : function(el, ev) {
			ev.stopPropagation();
		},

		/**
		 * Handle the call button on details page
		 */
		"#call_btn click" : function(el, ev) {
			ev.stopPropagation();
		},

		/**
		 * Handle the page up button on details page
		 */
		"#gp-page-up click" : function(el, ev) {
			//ev.stopPropagation();
			//$("#up-scroll-button").trigger("click");

			$(".container").scrollTop($(".container").scrollTop() - 50);

		},

		/**
		 * Handle the page down button on details page
		 */
		"#gp-page-down click" : function(el, ev) {
			//ev.stopPropagation();
			//$("#down-scroll-button").trigger("click");

			$(".container").scrollTop($(".container").scrollTop() + 50);

		},

		getSearchResultsDetails : function(el) {
			var that = this;
			var reference = el.find(".search-results-reference").text().trim();
			var distance = el.find(".distance").text().trim();
			var unit = el.find(".unit").text().trim();

			this.details_reference = reference;
			console.log("Reference: " + reference);

			var req = {
				data : {
					reference : this.details_reference,
					language : this.language
				},
				success : function(resp) {
					console.log("getPlaceDetails Success");

					resp.distance = Math.round(distance * 10) / 10;
					resp.unit = unit;
					resp.categories[0] = capitalizeFirst(resp["categories"][0]);
					//console.warn(resp.categories);
					that.loadDetailsPage(resp);
				},
				error : function(jQXHR) {
					console.error("getPlaceDetails Fail", jQXHR);
				}
			};

			GPAPI.getPlaceDetails(req);

		},

		/**
		 * Loads the result details page with the given data
		 */
		loadDetailsPage : function(data) {
			/*
			$('#pagecontent').html(can.view('googleplaces/views/pagecontent-views/result_view.ejs', {
			data : data
			}));*/
			GPAPI.currentDetailsObj = data;

			root.template.buildListTemplate("result_detail_view", data, "googleplaces/views/pagecontent-views/gp-result-view.ejs", "detailWithFiveButtons", "Navigate", "gp-navigate", "Call", "gp-call", "Hidden", "gp-hidden", "Pg", "page-down", "Pg", "page-up");
			
			pagingControl.init();

			$("#scrollbar").hide();

			new scrollbar_control("#scrollbar", {
				viewport : $("aqul"),
			});
		}, //End of loadDetailsPage()

		/**
		 * Loads the search page
		 */
		loadSearchPage : function() {
			$("#header").hide();

			//el.html(can.view('googleplaces/views/pagecontent-views/search_board.ejs', {}));
			//root.template.buildListTemplate("search_board", null, "", "keyboard", "Search", "input-text", "", "status-input", "", "micButton", "123/ABC", "numExchange", "Delete", "delete");
			root.template.buildListTemplate("search_board", null, "", "keyboard", "Search", "input-text", "", "status-input", "", "micButton", "123/ABC", "numExchange", "Delete", "delete");
			$('#micButton').hide();
		},

		"#status-input click" : function() {
		
		},

		"#search_board #micButton click" : function(el, ev) {
			ev.stopPropagation();
			this.loadVR({
				isProcessing : false
			});
		},
		"#search_board #numExchange click" : function(el, ev) {
			//ev.stopPropagation();
		},
		"#search_board #delete click" : function(el, ev) {
			//ev.stopPropagation();
		},
		"#search_board #ok click" : function(el, ev) {
			ev.stopPropagation();
			header.updateTitle("Results");
			this.showSearchResults();
		},

		loadCategoriesPage : function(data) {
			console.log(data);

			$('#pagecontent').html(can.view('googleplaces/views/pagecontent-views/filter_list.ejs', {
				data : data
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $("aqul")
			});
		},

		"aqli.category click" : function(el) {
			var category = el.find(".entry_title_cate").text().trim();
			this.defaults.category = category.toLowerCase().replace(" ", "_");
			
			can.route.attr({type:"googleplaces",page:category.toLowerCase()});

			this.showSearchResults();
			header.updateTitle("Results");
		},
		loadACategory : function(el) {
			
		},
		
		"#gp-navigate click" : function(el) {
			var address = GPAPI.currentDetailsObj;
			aqinteractions.sendHuMessage('huNavSetDestination',address);
		},
		"#gp-call click" : function(el) {
			var phone = GPAPI.currentDetailsObj.phoneNumber;
			aqinteractions.sendHuMessage('huDialPhoneNumber',phone);
		},
		
		
		/***  ROUTING  ***/
		"route" : function(data) {
			console.log("#################### Begin GP Routing ####################");
			console.log("data");
			console.log(data);
			console.log("#################### END GP Routing ####################");
			
			var page = data.page;
			
			switch(page) {
				case "home":
					root.pagecontent.defaults.pageIndex = 0;
					root.pagecontent.loadHome();
					break;
					
				case "nextpage":
					root.pagecontent.loadNextPage();
					break;
					
				case "prevpage":
					root.pagecontent.loadPrevPage();
					break;				
				
				case "search":
					root.pagecontent.loadSearchPage();
					break;
				
				case "voicesearch":
					root.pagecontent.loadVoiceSearch();
					break;
				
				case "categories":
					root.pagecontent.loadCategoriesPage(root.pagecontent.defaults.categories);
					root.header.updateTitle("Categories");
					break;
				
				case "restaurants":
					root.pagecontent.loadRestaurants();
					break;

				case "cafe":
					root.pagecontent.loadCafe();
					break;
					
				case "bars":
					root.pagecontent.loadBars();
					break;

				case "attractions":
					root.pagecontent.loadAttractions();
					break;
									
				default:
					root.pagecontent.loadHome();
			}
		}
		/***  End ROUTING  ***/
		
	});
	/** End of the main_control **/

	/**
	 * Function to be passed to sort the results based on the distance.
	 * Use parseFloat() since distance is a float number, eg. 0.5
	 * ASC - 1,2,3
	 */
	function sortDistance(a, b) {
		return parseFloat(a.distance) - parseFloat(b.distance);
	};

	/**
	 * Function to be passed to sort the results based on the ratings.
	 * Use parseFloat() since ratings is a float number, eg. 3.5
	 * DESC - 3,2,1
	 */
	function sortRatings(a, b) {
		return parseFloat(b.rating) - parseFloat(a.rating);
	};

	function getAllResults() {
		pagecontent_control.defaults.searchResults = root.fixture.searchResults;
	};

	function capitalizeFirst(str) {
		return (str.charAt(0).toUpperCase() + str.slice(1)).replace("_", " ");
	}; 

	root.header = new head_control("#header");
	root.pagecontent = new pagecontent_control("#pagecontent");
	
	
			
	
});
