$(function() {
	window.m_history = [];
	window.historiesMap = [];
    
	GPAPI = can.Model(
	/* @Static */
	{
		defaults : {
			NearByPlacesAPI : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/places/mipId/%MIPID%?sensor=true&latitude=%lat%&longitude=%long%&keyword=%keyword%&unit=%unit%&language=%lang%",
				"requestMethod" : "GET"
			},
			PlaceDetailsAPI : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/places/detail/mipId/%MIPID%?reference=%ref%&sensor=true&language=%lang%",
				"requestMethod" : "GET"
			}
		},
		currentDetailsObj : {},
		
		getSearchResults : function(args) {
			var searchAPI = this.defaults.NearByPlacesAPI;
			var categoryPart = "&category=%cat%";
			var distancePart =  "&distance=%dist%";
			
			// The API should append distance parameter only if it is provided otherwise donot use it
			var distance = args.data.distance || null;
			if(distance) {
				distancePart = distancePart.replace("%dist%", distance);
				searchAPI["requestUri"] += distancePart;
			}
			// The API should append category parameter only if it is provided otherwise donot use it
			var category = args.data.category;
			if(category){
				categoryPart = categoryPart.replace("%cat%", category);
				searchAPI["requestUri"] += categoryPart;
			}
			
			var language = args.data.language || "en";
			var lat = args.data.lat;
			var longtd = args.data.longtd;
			var keyword = args.data.keyword || "*";
			var unit  = args.data.unit || "M";
			
			searchAPI["requestUri"] = searchAPI["requestUri"].replace("%long%", longtd);
			searchAPI["requestUri"] = searchAPI["requestUri"].replace("%lat%", lat);
			searchAPI["requestUri"] = searchAPI["requestUri"].replace("%lang%", language);
			searchAPI["requestUri"] = searchAPI["requestUri"].replace("%keyword%", keyword);
			searchAPI["requestUri"] = searchAPI["requestUri"].replace("%unit%", unit);
            			
			AQ.Com.Model.sendHttpRequest({				
				//REAL
				url : '/gateway',
				type : 'POST',
				dataType: 'json',
				data : searchAPI,
				success : args.success,
				error : args.error

				//FIXTURE
				//url : "/results",
				
			});
		},
		getPlaceDetails : function(args) {
			var reference = args.data.reference;
			var language = args.data.language;

			var getTopicStoryRequest = this.defaults.PlaceDetailsAPI;
			getTopicStoryRequest["requestUri"] = getTopicStoryRequest["requestUri"].replace("%ref%", reference);
			getTopicStoryRequest["requestUri"] = getTopicStoryRequest["requestUri"].replace("%lang%", language);

			AQ.Com.Model.sendHttpRequest({
				//REAL
				url : '/gateway',
				type : 'POST',
				dataType: 'json',
				data : getTopicStoryRequest,
				success : args.success,
				error : args.error
				
				//FIXTURE
				//url : "/details",

			});
		},
		
	}, {});
});
