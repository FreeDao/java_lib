var googleplaces = can.Construct({}, {
	
	/**
     * Initialize the home app
     */
    init: function()
    {
        $('aqapp').html( 'googleplaces/views/init.ejs', {} );
    }
});

APP.googleplaces = new googleplaces();

AQ.loadStylesheet("googleplaces/googleplaces.css");

AQ.loadScript("googleplaces/js/model.js", function() {
	AQ.loadScript(["googleplaces/js/fixture.js","googleplaces/js/controller.js"]);
});
