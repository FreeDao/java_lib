var facebook = can.Construct({}, {
	
	/**
     * Initialize the home app
     */
	init : function() {
        $('aqapp').html( 'facebook/views/init.ejs', {} );
    }
});

APP.facebook = new facebook();

AQ.loadStylesheet("facebook/facebook.css");

//AQ.loadScript("facebook/js/model.js", function() {
//	AQ.loadScript(["facebook/js/controller.js","facebook/js/fixture.js","facebook/js/util.js"]);
//});

AQ.loadScript("facebook/js/fixture.js", function() {
	AQ.loadScript("facebook/js/model.js", function() {
		AQ.loadScript(["facebook/js/controller.js","facebook/js/fixture.js","facebook/js/util.js"]);
	});
});

