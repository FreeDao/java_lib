var root = this;

$(function() {

	var ttsPlaying = false;

	//TODO temporary params for store response data, will refine later
	var LIVEFEED = null;
	var curId = null;
	var NEARBYPLACES = null;

	var currentControl = null;
	//store current control name

	//TODO for back mechanism
	window.m_history = [];
	function storeHistory(history) {
		if (window.m_history[window.m_history.length - 1] != history) {
			window.m_history.push(history);
		} else {
			console.log("SAME HISTORY...");
		}
	};

	/*** Controller - Header ***/
	FB.Header = can.Control({
		defaults : {}
	}, {
		_header : null,
		updateTitle : function(title) {
			this._header.attr("title", title);
		},
		init : function() {
			var that = this;
			if (!that._header)
				that._header = new can.Observe({
					title : "Facebook",
					time : "00:00:00",
					icon : "RESERVED for icon url or anything else"
				});
			$("#header").html(can.view("facebook/views/header-views/common.ejs", {
				data : that._header
			}));
		},
		"#header-title click" : function() {
			//If not on newsfeed detail screen, there is no next screen.
			AQ.isNextAvailable = false;
			FB.Pagecontent.defaults.arrNewsFeedIDs = [];
			
			//Load home.  True removes params not in data. Ex: removes the news feed ID.
			can.route.attr({type:"facebook",page:"home"},true);
		}
	});

	/*** Controller - PageContent ***/
	FB.Pagecontent = can.Control({
		/** @Static */
		defaults : {
			homeButtons : {
				page0 : ["News Feed", "Status", "Events", "Nearby", "Check-In", "Next Page"],
				page1 : ["Previous Page", "Message", "Friends"]
			},
			
			/** Status **/
			status : ["I'm in the car", "Out saving the world", "Heading home now!", "Pre-written status message", "Pre-written status message"],
			
			/** Events **/
			events : ["Future", "Past", "Birthdays"],
			
			data : {},
			
			/** Nearby **/
			checkins :{},
			
			/** Checkin **/
			
			/** Message **/
			phoneNumberList : ["000-000-0000", "000-000-0000", "000-000-0000"],
			messages : {},
			
			/** Friends **/
			friends : {},
			
			/** Comment **/
			customComments : ["Custom Message1", "Custom Message2", "Custom Message3", "Custom Message4", "Custom Message5"],
			
			/** News Feed Detail Vars **/
			curNewsFeedID : 0,
			curNewsFeedArrId : 0,
			arrNewsFeedIDs : []
		}
	}, {
		
		/*** APP INIT ***/
		init : function() {
			this.loadHome();
		},
	

		/***  ROUTING  ***/
		"route" : function(data) {
			console.log("#################### Begin FB Routing ####################");
			console.log("data");
			console.log(data);
			console.log("#################### END FB Routing ####################");
			
			var page = data.page;
			var id = data.id;
			
			if(page != "keyboard") {
				$("#header").show();
			}
			
			switch(page) {
				case "home":
					this.loadPrevPage();
					break;
				
				case "newsfeed":
					//Load news feed
					console.log("========click newsfeed========");
					console.log("==========id=======>"+id);
					if(typeof id == "undefined" || id == "") {
						this.loadNewsFeed();
						
					//Load a news feed detail
					} else {
						this.loadCurFeedDetail(id);
					}
					break;
					
				case "status":
					this.loadPresets();
					break;
					
				case "keyboard":
					this.loadKeyboard();
					break;
					
				case "presets":
					this.loadPresets(id);
					break;
					
				case "editpresets":
					this.editPresets();	
					break;					
					
				case "events":
					//Load main events page
					if(typeof id == "undefined") {
						header.updateTitle("Events");
						this.loadEvents();
					//Load birthday events
					} else if(id == "birthdays") {
						header.updateTitle("Events: Birthdays");
						this.getFriendsBirthday();
					//Load other events
					} else if(id == "future" || id == "past") {
						header.updateTitle("Events: " + id.charAt(0).toUpperCase() + id.slice(1));
						//TODO:  Differentiate between past and present events.
						this.getEvents();
					//Load an event detail
					} else {
						this.loadEventDetail(id);
					}				
					break;

				case "nearby":
					this.loadNearby();
					break;
									
				case "checkin":
					this.loadCheckIn();
					break;									
					
				case "nextpage":
					this.loadNextPage();
					break;														

				case "prevpage":
					this.loadPrevPage();
					break;	
					
				case "messages":
					this.loadMessages();
					break;
					
				case "friends":
					this.loadFriends();
					break;
									
				default:
					this.loadPrevPage();
			}
		},
		
		
		/** Home **/
		_pageIndex : 0,
		loadHome : function() {
			var that = this;
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/main_home.ejs', {
				"data" : FB.Pagecontent.defaults.homeButtons["page" + that._pageIndex]
			}));
		},
		".next_page click" : function() {
			can.route.attr({type:"facebook",page:"nextpage"});
		},
		loadNextPage : function() {
			if(this._pageIndex != 1) this._pageIndex++;
			this.loadHome();
		},		
		".previous_page click" : function() {
			can.route.attr({type:"facebook",page:"prevpage"});			
		},
		loadPrevPage : function() {
			if(this._pageIndex != 0) this._pageIndex--;
			this.loadHome();
		},

		
		/** News Feed **/
		"#news_feed click" : function() {
			can.route.attr({type:"facebook",page:"newsfeed"});
		},		
		loadNewsFeed : function() {
			console.log("========first request newsfeed0==========");
			header.updateTitle("Newsfeed");
			var self = this;
			var func = function() {
				self.getNewsfeedList(self.loadNewsfeedList);
			};
			AQ.loadWait(null, func);
		},		
		loadNewsfeedList : function() {
			console.warn(LIVEFEED.data);
			root.template.buildListTemplate("newsfeed_list_view", LIVEFEED.data, "facebook/views/pagecontent-views/aqliviews/fb-newsfeed-list.ejs", "shortScrollbarList", "Refresh", "refresh");

			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},
		getNewsfeedList : function(handler) {
			console.log("========first request newsfeed1==========");
			var error = function(err) {
				console.log("Get news feed caught error : " + JSON.stringify(err));
			};

			FB.Models.API.getNewsFeed({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					maxMessages : 20,
					includeImages : true
				},
				success : function(data) {
					console.log("Get news feed success!");
					LIVEFEED = data;
					if (handler)
						handler();
				},
				error : error
			});
		},		
		"#newsfeed_list_view aqli click" : function(el) {
			can.route.attr({type:"facebook",page:"newsfeed",id:el.children('p').attr('id')});
		},
		
		/*
		loadNewsfeedDetail : function() {
			console.log("loadNewsfeedDetail");
			$("#header").show();
			var func = function() {
			if (currentControl)
				currentControl.destroy();
			currentControl = new FB.NewsFeed();

			};
			AQ.loadWait(null, func);
			currentControl.loadCurFeedDetail(curId);
			//TODO exist issue, jump to detail page directly
			header.updateTitle("Newsfeed");
		},*/
		loadNextFeedDetail : function() {
			if(FB.Pagecontent.defaults.curNewsFeedArrId+1 < FB.Pagecontent.defaults.arrNewsFeedIDs.length) {
				FB.Pagecontent.defaults.curNewsFeedArrId++;	
				this.loadCurFeedDetail(FB.Pagecontent.defaults.arrNewsFeedIDs[FB.Pagecontent.defaults.curNewsFeedArrId]);
			}
		},
		loadPrevFeedDetail : function() {
			if(FB.Pagecontent.defaults.curNewsFeedArrId-1 >= 0) {
				FB.Pagecontent.defaults.curNewsFeedArrId--;
				this.loadCurFeedDetail(FB.Pagecontent.defaults.arrNewsFeedIDs[FB.Pagecontent.defaults.curNewsFeedArrId]);
			}
		},
		
		loadCurFeedDetail : function(id) {
			console.log("=========go into newsfeed========");
			header.updateTitle("Newsfeed");
			
			//Variable that allows for the next hard button to work.
			AQ.isNextAvailable = true;
			
			var that = this;
			var curFeed = that.getNewsFeedById(id, LIVEFEED);
			
			var func = function() {
				root.template.buildListTemplate("newsfeed_detail_view", that.getNewsFeedById(id, LIVEFEED), "facebook/views/pagecontent-views/aqliviews/fb-newsfeed-detail.ejs", "detailWithFiveButtons", "PlayTTS", "fb-playtts", "Like", "fb-like", "Comment", "fb-comment", "Pg", "page-up", "Pg", "page-down");
				displayPlayorPause();
				pagingControl.init();
			};
			AQ.loadWait(null, func);
		},		
		getNewsFeedById : function(id, livefeed) {
			var root = this;
			var feed = null;
			var arrIds = [];
			$.each(livefeed.data, function(i) {
				arrIds.push(this.id);
				if (this.id == id) {
					feed = this;
				}
			});
			
			//Store array of newsfeed IDs for later use.
			FB.Pagecontent.defaults.arrNewsFeedIDs = arrIds;
			
			console.log("get news feed by id : " + JSON.stringify(feed));
			return feed;
		},
		/*
		createNewsFeedIdArray : function() {
			$.each(LIVEFEED.data, function() {
				FB.Pagecontent.defaults.arrNewsFeedIDs.push(this.id);
			});
		},*/
		"#refresh click" : function() {
			$('#pagecontent').hide();
			this.getNewsfeedList();
			$('#pagecontent').fadeIn(300);
		},
		"#fb-playtts click" : function() {
			ttsPlaying = !ttsPlaying;
			displayPlayorPause();
		},
		"#fb-like-icon click" : function(el) {
			//var id = $(".container").attr('id');
			var id = curId;
			//put like request
			var success = function(data) {
				this.getNewsfeedList();
				//get feed counts agagin

				var origin = parseInt($(".likes-count").text());
				console.log("origin likes:" + origin);
				$(".likes-count").text(origin + 1);
			};

			FB.Models.API.postLike({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					id : id
				},
				success : success,
				error : function(err) {
					console.log("Put 'Like' caught error : " + JSON.stringify(err));
				}
			});
		},
		"#fb-comment click" : function() {
			can.route.attr({type:"facebook",page:"presets"});
		},
		
		
		/** Status Post **/
		"#status click" : function() {
			can.route.attr({type:"facebook",page:"presets"});
		},
		loadStatus : function() {
			this.loadPresets();
		},
	
				
		/** Post Status **/
		"#post_status #ok click" : function() {
			//updating facebook status
			var msg = $("#status-input").val();
			if (!msg || msg == "Enter status update")
				return;
			this.postStatus(msg);
		},
		postStatus : function(msg) {
			var root = this;
			
			var success = function(data) {
				can.route.attr({type:"facebook",page:"newsfeed"});
			};
			var error = function(err) {
				console.log("Commenting a post caught error : " + JSON.stringify(err));
			};

			FB.Models.API.postStatus({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					message : msg
				},
				success : success,
				error : error
			});
		},
		
		
		/* Post Comment */
		postComment : function(id, msg, success) {
			FB.Models.API.postComment({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					id : id,
					message : msg
				},
				success : function(data) {
					FB.Pagecontent.defaults.curNewsFeedID = 0;
					can.route.attr({type:"facebook",page:"newsfeed",id:id});
				},
				error : function(err) {
					console.log("Commenting a post caught error : " + JSON.stringify(err));
				}
			});
		},


		/** Keyboard **/
		"#keyboard click" : function() {
			can.route.attr({type:"facebook",page:"keyboard"});
		},
		loadKeyboard : function() {
			$("#header").hide();
			//change
			root.template.buildListTemplate("keyboard_main", null, "", "keyboard", "Search", "input-text", "", "status-input", "Preset", "preset", "123/ABC", "numExchange", "Delete", "delete");
		},
		"#keyboard_main #ok click" : function() {
			var msg = $("#status-input").val();
			if (!msg || msg == "Enter status update")
				return;

			this.postStatus(msg);
		},

		
		/** Presets **/
		"#preset click" : function() {
			can.route.attr({type:"facebook",page:"presets"});
		},
		loadPresets : function(id) {
			FB.Pagecontent.defaults.curNewsFeedID = id;
			header.updateTitle("Preset Status");
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/presets.ejs', {
				data : FB.Pagecontent.defaults.status
			}));
		},
		".preset-list .list-text click" : function(el) {
			if (el.parent().parent().hasClass("top_command")) {
			} else {
				var msg = el.text();
				if (!msg) return;
				var id = FB.Pagecontent.defaults.curNewsFeedID;

				//Posting a regular preset message
				if (id != 0) {
					this.postStatus(msg);
				//Posting a comment preset message
				} else {
					this.postComment(id, msg);
				}
			}
		},		
		".preset-list #edit_presets click" : function() {
			can.route.attr({type:"facebook",page:"editpresets"});
		},
		editPresets : function() {
			header.updateTitle("Edit Presets");
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/preset-edit.ejs', {
				data : FB.Pagecontent.defaults.status
			}));
		},
		".preset-edit .list-text click" : function(el) {
			var customComment = el.text().trim();
			$("#header").hide();
			root.template.buildListTemplate("preset_edit_keyboard", null, "", "keyboard", "Search", "input-text", customComment, "status-input", "Preset", "preset", "123/ABC", "numExchange", "Delete", "delete");
		},
		"#preset_edit_keyboard #ok click" : function() {
			can.route.attr({type:"facebook",page:"presets"});	
		},
		

		/** Events **/
		"#events click" : function() {
			can.route.attr({type:"facebook",page:"events"});
		},
		loadEvents : function() {
			header.updateTitle("Events");
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/event-menu.ejs', {
				data : FB.Pagecontent.defaults.events
			}));
		},
		".events-list .list-text click" : function(el) {
			var ev = el.text();
			header.updateTitle("Events: " + ev);
			if (ev == "Birthdays") {
				//get friends birthday
				can.route.attr({type:"facebook",page:"events",id:"birthdays"});
			} else if (ev == "Future") {
				//get future events
				can.route.attr({type:"facebook",page:"events",id:"future"});
			} else if (ev == "Past") {
				//get past events
				can.route.attr({type:"facebook",page:"events",id:"past"});
			}
		},
		//TODO: Need code to differentiate between past and future events.  Also add to router below.
		getEvents : function() {
			var daysBack = 90;

			FB.Models.API.getEventsRequest({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					daysBack : daysBack
				},
				success : function(data) {
					console.log("Retrieving the events birthday success!" + JSON.stringify(data));
					
					$('#pagecontent').html(can.view('facebook/views/pagecontent-views/event-menu-list.ejs', {
						data : data.events //TODO get data from fixture 
					}));						
					
					FB.Pagecontent.defaults.data = data;
				},
				error : function(err) {
					console.log("Retrieving the events caught error : " + JSON.stringify(err));
				}
			});
		},
		//GET Friends Birthday
		getFriendsBirthday : function() {
			var offset = '';
			var limit = '';

			var success = function(message) {
				console.log("Retrieving the friends birthday success!" + JSON.stringify(message));
			
				$('#pagecontent').html(can.view('facebook/views/pagecontent-views/event-menu-bir-list.ejs', {
					data : message.data 
				}));
			};
			var error = function(err) {
				console.log("Retrieving the friends caught error : " + JSON.stringify(err));
			};

			FB.Models.API.getFriendsBirthday({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					limit : limit,
					offset : offset
				},
				success : success,
				error : error
			});
		},
		".event-common aqli click" : function(el) {
			can.route.attr({type:"facebook",page:"events",id:el.index()});
		},
		loadEventDetail : function(index) {
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/event-detail.ejs', {
				data: FB.Pagecontent.defaults.data.events[index] 
			}));
			pagingControl.init();			
		},

		
		/** Nearby **/
		"#nearby click" : function() {
			can.route.attr({type:"facebook",page:"nearby"});
		},
		loadNearby : function() {
			header.updateTitle("Nearby Friends");
			this.loadNearbyList();
		},
		loadNearbyList : function() {
			//searching checkin of friends
			var success = function(data) {
				FB.Pagecontent.defaults.checkins = data;
				console.log("Searching checkin of friends success!");

				$('#pagecontent').html(can.view('facebook/views/pagecontent-views/nearby-list.ejs', {
					"data" : data.checkins 
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			var error = function(err) {
				console.log("Searching checkin of friends caught error : " + JSON.stringify(err));
			};

			FB.Models.API.getNearbyFriends({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					latitude : 47.6045,
					longitude : -122.3378,
					distance : 100
				},
				success : success,
				error : error
			});

		},
		".nearby-list aqli click" : function(el) {
			var location = el.find($(".placeName")).text();
			overlay("popup_nearby_location.ejs", location);
		},
		"#navigate-nearby-yes click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
		},
		"#navigate-nearby-no click" : function() {
			$('#overlay-container').slideUp(500, function() {});
			header.updateTitle("Nearby Friends");
			
			root.template.buildListTemplate("nearby_detail_view", null, "facebook/views/pagecontent-views/aqliviews/fb-nearby-detail.ejs", "detailWithFiveButtons", "Like", "fb-like", "Start", "fb-start", "Comment", "fb-comment", "Pg", "page-up", "Pg", "page-down");
			pagingControl.init();
		},		

		
		/** Checkin **/
		"#check-in click" : function() {
			can.route.attr({type:"facebook",page:"checkin"});
		},		
		loadCheckIn : function() {
			header.updateTitle("Check In");
			this.getNearbyPlaces(this.loadNearbyPlacesList);
		},
		loadNearbyPlacesList : function(data) {
			NEARBYPLACES = data;
			console.log("Searching nearby places success!");

			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/check-in-list.ejs', {
				data : NEARBYPLACES.data
			}));

			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},
		getNearbyPlaces : function(success) {
			FB.Models.API.getNearbyPlaces({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					name : '',
					latitude : 47.6045,
					longitude : -122.3378,
					limit : 10,
					afterId : '',
					offset : ''
				},
				success : success,
				error : function(err) {
					console.log("Searching nearby places caught error : " + JSON.stringify(err));
				}
			});
		},		
		".check-in-list .list-text click" : function(el) {
			var id = el.attr("id");
			var nearbyPlace = this.getNearbyPlaceById(id, NEARBYPLACES);
			console.log("checkin post view" + JSON.stringify(nearbyPlace));

			root.template.buildListTemplate("post_checkin_view", nearbyPlace, "facebook/views/pagecontent-views/aqliviews/fb-post-checkin-msg.ejs", "detailWithTwoButtons", "Post", "nf_button_post", "Cancel", "nf_button_cancel");

		},
		getNearbyPlaceById : function(id, checkins) {
			var place = null;
			$.each(checkins.data, function(i) {
				if (this.id == id) {
					place = this;
				}
			});
			console.log("get nearby place by id : " + JSON.stringify(place));
			return place;
		},
		"#nf_button_post click" : function(el) {
			overlay("popup-post.ejs", null);
		},
		"#post-checkIn-yes click":function(){
			var root = this;
			var placeId = $("aqul").attr("id");
			var success = function() {
				console.log("Put checkin success!");
				root.loadHome();
				header.updateTitle("Facebook");
			};

			var error = function(err) {
				console.log("Put checkin caught error : " + JSON.stringify(err));
			};

			FB.Models.API.postCheckIn({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					placeId : placeId,
					message : '',
					latitude : 47.6045,
					longitude : -122.3378,
				},
				success : success,
				error : error
			});
			//put checkin,when post success,should slide up popup page.whenever success or error.
			$('#overlay-container').slideUp(500, function() {
			});
		},
		
		"#post-checkIn-no click":function(){
			$('#overlay-container').slideUp(500, function() {
			});
		},
		
		"#nf_button_cancel click" : function() {
			header.updateTitle("Check In");
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/check-in-list.ejs', {
				data : NEARBYPLACES.data
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		
		/** Messages **/
		"#message click" : function() {
			can.route.attr({type:"facebook",page:"messages"});
		},
		loadMessages : function() {
			header.updateTitle("Messages");
			this.getPrivateMessage();
		},
		getPrivateMessage : function() {

			var success = function(data) {
				FB.Pagecontent.defaults.messages = data;
				console.log("GET inbox message success!");

				$('#pagecontent').html(can.view('facebook/views/pagecontent-views/messages.ejs', {
					data : data.data //data.data
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			var error = function(err) {
				console.log("GET inbox message caught error : " + JSON.stringify(err));
			};

			FB.Models.API.getPrivateMessage({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {},
				success : success,
				error : error
			});
		},		
		".message-list aqli click" : function() {
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/message-detail.ejs', {}));

			displayPlayorPause();
			pagingControl.init();
		},		
		"#nf_button_call click" : function() {
			header.updateTitle("Select Number");
			$('#pagecontent').html(can.view('facebook/views/pagecontent-views/phone-number-list.ejs', {
				data : FB.Pagecontent.defaults.phoneNumberList
			}));
		},
		".phone-list .list-text click" : function(el) {
			var phonenumber = el.text();
			overlay("popup-calling.ejs", phonenumber);
		},
		"#call-cancel click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
		},
		"#fb-playtts click" : function() {
			ttsPlaying = !ttsPlaying;
			displayPlayorPause();
		},
		
		
		/** Friends **/
		"#friends click" : function() {
			can.route.attr({type:"facebook",page:"friends"});
		},
		loadFriends : function() {
			header.updateTitle("Friends");
			this.getFriendsRequest();
			$('aqapp').append('<div id="sort-az-popup"><div class="sorter"></div></div>');
		},
		getFriendsRequest : function() {
			//retrieving the friends
			var offset = '';

			var success = function(data) {
				FB.Pagecontent.defaults.friends = data;
				console.log("Retrieving the friends success!");
				$('#pagecontent').html(can.view('facebook/views/pagecontent-views/friends-list.ejs', {
					data : data.data
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
				});
			};
			var error = function(err) {
				console.log("Retrieving the friends caught error : " + JSON.stringify(err));
			};

			FB.Models.API.getFriendsRequest({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					offset : offset
				},
				success : success,
				error : error
			});
		},
		".friends-list .list-text click" : function(el) {
			var name = el.text();
			header.updateTitle(name);
			if (!LIVEFEED) {
				this.getNewsfeedList(this.loadNewsfeedList);
			}
		},
		"#sort-az click" : function() {
			//Preload the hover images
			image = new Image(); 
			image.src = "images/shared/480x272/list_scroller_right.png";
			image.src = "images/shared/480x272/list_scroller_left.png";
			image.src = "images/shared/800x480/list_scroller_right.png";
			image.src = "images/shared/800x480/list_scroller_left.png";
			
			$('#sort-az-popup .sorter').text('A');
			$('#sort-az-popup').toggle();
		},
	});

	var displayPlayorPause = function() {
		if (ttsPlaying) {
			$("#fb-playtts-icon").removeClass("nf-play-icon");
			$("#fb-playtts-icon").addClass("nf-pause-icon");
		} else {
			$("#fb-playtts-icon").addClass("nf-play-icon");
			$("#fb-playtts-icon").removeClass("nf-pause-icon");
		}
	};

	var overlay = function(overlay, location) {
		$('#overlay-container').remove();
		$('#pagecontent').append(can.view('facebook/views/pagecontent-views/overlay.ejs', {
			"overlay" : overlay,
			"location" : location
		}));
		$('#overlay-container').slideDown(500, function() {
		});
	};

	var header = new FB.Header("#header", {});
	var pagecontent = new FB.Pagecontent("#pagecontent", {});
});
