$(document).ready(function($) {
can.fixture.on = true;

	can.fixture('GET /newsfeed', 'facebook/js/newsfeed.json');
	can.fixture('GET /nearbyplaces', 'facebook/js/searchnearby.json');

var CHECKINSEARCH = {
	"checkins" : [{
		"checkin_id" : "113914065400822",
		"author_uid" : "100003466874382",
		"authorName" : "Matty Damon",
		"page_id" : "121814297829270",
		"placeName" : "Seattle\u0027s Best Coffee",
		"timestamp" : "1329421550",
		"coords" : {
			"longitude" : "-122.33667809732",
			"latitude" : "47.60989234441"
		}
	}, {
		"checkin_id" : "133026996824472",
		"author_uid" : "100003515170743",
		"authorName" : "Jill",
		"page_id" : "114792641936871",
		"placeName" : "Seattle Ferry Terminal",
		"timestamp" : "1331697365",
		"coords" : {
			"longitude" : "-122.33896652781",
			"latitude" : "47.602848032316"
		}
	}, {
		"checkin_id" : "112243682236137",
		"author_uid" : "100003515170743",
		"authorName" : "Jill",
		"page_id" : "74993773631",
		"placeName" : "Kells Irish Restaurant \u0026 Pub",
		"timestamp" : "1329460303",
		"coords" : {
			"longitude" : "-122.34234181855",
			"latitude" : "47.610378593978"
		}
	}, {
		"checkin_id" : "111893212271184",
		"author_uid" : "100003515170743",
		"authorName" : "Jill",
		"page_id" : "114792641936871",
		"placeName" : "Seattle Ferry Terminal",
		"timestamp" : "1329420153",
		"coords" : {
			"longitude" : "-122.33896652781",
			"latitude" : "47.602848032316"
		}
	}, {
		"checkin_id" : "106369536156885",
		"author_uid" : "100003515170743",
		"authorName" : "Jill",
		"page_id" : "115622245134654",
		"placeName" : "Boka Kitchen \u0026 Bar",
		"timestamp" : "1328747743",
		"coords" : {
			"longitude" : "-122.33629243231",
			"latitude" : "47.604880040487"
		}
	}]
};

var EVENTSLIST = {
	"events" : [{
		"eid" : 133648400115986,
		"name" : "Abq Team Building!",
		"description" : "We are having a team building party! We are having a team building party! We are having a team building party! We are having a team building party! We are having a team building party! We are having a team building party! We are having a team building party! We are having a team building party!",
		"start_time" : 1351996200,
		"end_time" : 1352007000,
		"pic_small" : "http://profile.ak.fbcdn.net/static-ak/rsrc.php/v2/yy/r/XcB-JGXohjk.png",
		"pic_big" : "http://profile.ak.fbcdn.net/static-ak/rsrc.php/v2/yn/r/5uwzdFmIMKQ.png",
		"location" : "Nanjing, Jiangsu",
		"address" : {
			"street" : "",
			"zip" : "",
			"latitude" : 32.05,
			"longitude" : 118.767
		},
		"RSVPStatus" : "attending"
	}, {
		"eid" : 546330478727244,
		"name" : "Concert",
		"description" : "The Business Man's Blues Band",
		"start_time" : 1351771200,
		"end_time" : 1351782000,
		"pic_small" : "http://profile.ak.fbcdn.net/static-ak/rsrc.php/v2/yy/r/XcB-JGXohjk.png",
		"pic_big" : "http://profile.ak.fbcdn.net/static-ak/rsrc.php/v2/yn/r/5uwzdFmIMKQ.png",
		"location" : "Showbox",
		"address" : {
			"street" : "1426 1st Ave (Market) and 1700 1st Ave S. (SoDo)",
			"city" : "Seattle",
			"state" : "WA",
			"country" : "United States",
			"zip" : "98101",
			"latitude" : 47.608519127873,
			"longitude" : -122.33944339346
		},
		"RSVPStatus" : "attending"
	},{
		"eid" : 546330478727245,
		"name" : "Basketball team building",
		"description" : "In the jingma restarant",
		"start_time" : 1341771200,
		"end_time" : 1341782000,
		"pic_small" : "http://profile.ak.fbcdn.net/static-ak/rsrc.php/v2/yy/r/XcB-JGXohjk.png",
		"pic_big" : "http://profile.ak.fbcdn.net/static-ak/rsrc.php/v2/yn/r/5uwzdFmIMKQ.png",
		"location" : "Showbox",
		"RSVPStatus" : "attending"
	}]
};

var MESSAGES = {
	"data" : [{
		"id" : "140077296125820",
		"unread" : 0,
		"unseen" : 0,
		"updated_time" : "2012-06-27T20:51:28+0000",
		"comments" : {
			"paging" : {
				"previous" : "https://graph.facebook.com/140077296125820/comments?access_token\u003dAAACZBsR8HZByMBAPiEueDrZBP0ZAjCRaxGWa1H2yFRVon82IlvUmfZCumj46J2R3F1G3Ena8VW8LP7cyg0zI6GWT3NBf3nYa6H2665ediZBwZDZD\u0026limit\u003d25\u0026since\u003d1340830288\u0026__paging_token\u003d140077296125820_29\u0026__previous\u003d1",
				"next" : "https://graph.facebook.com/140077296125820/comments?access_token\u003dAAACZBsR8HZByMBAPiEueDrZBP0ZAjCRaxGWa1H2yFRVon82IlvUmfZCumj46J2R3F1G3Ena8VW8LP7cyg0zI6GWT3NBf3nYa6H2665ediZBwZDZD\u0026limit\u003d25\u0026until\u003d1340830288\u0026__paging_token\u003d140077296125820_29"
			},
			"data" : [{
				"id" : "140077296125820_5",
				"from" : {
					"id" : "100003565959876",
					"name" : "Nissan Denso"
				},
				"message" : "6",
				"created_time" : "2012-06-27T20:48:04+0000"
			}, {
				"id" : "140077296125820_6",
				"from" : {
					"id" : "100003146635856",
					"name" : "Bosch Mip"
				},
				"message" : "7",
				"created_time" : "2012-06-27T20:48:09+0000"
			}, {
				"id" : "140077296125820_7",
				"from" : {
					"id" : "100003565959876",
					"name" : "Nissan Denso"
				},
				"message" : "8",
				"created_time" : "2012-06-27T20:48:12+0000"
			}, {
				"id" : "140077296125820_8",
				"from" : {
					"id" : "100003146635856",
					"name" : "Bosch Mip"
				},
				"message" : "9",
				"created_time" : "2012-06-27T20:48:20+0000"
			}, {
				"id" : "140077296125820_9",
				"from" : {
					"id" : "100003565959876",
					"name" : "Nissan Denso"
				},
				"message" : "10",
				"created_time" : "2012-06-27T20:48:26+0000"
			}, {
				"id" : "140077296125820_10",
				"from" : {
					"id" : "100003146635856",
					"name" : "Bosch Mip"
				},
				"message" : "11",
				"created_time" : "2012-06-27T20:48:31+0000"
			}, {
				"id" : "140077296125820_11",
				"from" : {
					"id" : "100003565959876",
					"name" : "Nissan Denso"
				},
				"message" : "12",
				"created_time" : "2012-06-27T20:48:35+0000"
			}, {
				"id" : "140077296125820_12",
				"from" : {
					"id" : "100003146635856",
					"name" : "Bosch Mip"
				},
				"message" : "13",
				"created_time" : "2012-06-27T20:48:39+0000"
			}, {
				"id" : "140077296125820_27",
				"from" : {
					"id" : "100003565959876",
					"name" : "Nissan Denso"
				},
				"message" : "28",
				"created_time" : "2012-06-27T20:51:19+0000"
			}, {
				"id" : "140077296125820_28",
				"from" : {
					"id" : "100003146635856",
					"name" : "Bosch Mip"
				},
				"message" : "29",
				"created_time" : "2012-06-27T20:51:23+0000"
			}, {
				"id" : "140077296125820_29",
				"from" : {
					"id" : "100003565959876",
					"name" : "Nissan Denso"
				},
				"message" : "30",
				"created_time" : "2012-06-27T20:51:28+0000"
			}]
		}
	}]
};

	var BIRTHDAYS = {
		"data" : [{
			"uid" : "100001865154873",
			"name" : "Chrysler Mip",
			"birthday_date" : "11/21",
			"pic_small" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/70451_100001865154873_868329_t.jpg"
		}, {
			"uid" : "100003565959876",
			"name" : "Nissan Denso",
			"birthday_date" : "10/02/1980",
			"pic_small" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/157663_100003565959876_877489160_t.jpg"
		}]
	};

var FRIENDS = {
	"data" : [{
		"uid" : "100001865154873",
		"name" : "Chrysler Mip",
		"pic_small" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/70451_100001865154873_868329_t.jpg",
		"pic_big" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/49146_100001865154873_4879119_n.jpg",
		"pic_square" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/70451_100001865154873_868329_q.jpg",
		"pic" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/70451_100001865154873_868329_s.jpg"
	}, {
		"uid" : "100003565959876",
		"name" : "Nissan Denso",
		"pic_small" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/157663_100003565959876_877489160_t.jpg",
		"pic_big" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/157663_100003565959876_877489160_n.jpg",
		"pic_square" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/157663_100003565959876_877489160_q.jpg",
		"pic" : "http://profile.ak.fbcdn.net/hprofile-ak-snc4/157663_100003565959876_877489160_s.jpg"
	}]
};

	var CHECKINS = {
		"checkins" : [{
			"checkin_id" : "121283751319845",
			"author_uid" : "100003146635856",
			"authorName" : "Bosch Mip",
			"page_id" : "111747032195030",
			"placeName" : "Cherry Street Coffee House",
			"timestamp" : "1322764086",
			"coords" : {
				"longitude" : "-122.3373372687",
				"latitude" : "47.606662507617"
			},
			"comments" : {
				count : 1,
				data : [{
					"name" : "bosch mip",
					"text" : "hi there",
					"id" : "123123213"
				}]
			},
			"likes" : {
				count : 1,
				data : [{
					"name" : "bosch mip",
					"id" : "123123213"
				}]
			}
		}]
	};

var CHECKIN = {
	"message" : "KnoWhutImean, Vern?",
	"placeId" : 86493431461,
	"latitude" : 47.6046,
	"longitude" : -122.33627
};
	
	can.fixture('GET /events', function() {
		return EVENTSLIST;
	});

	can.fixture('GET /birthday', function(){
		return BIRTHDAYS;
	});
	
	can.fixture('GET /nearbyfriends', function() {
		return CHECKINS;
	});
	
	can.fixture('GET /message', function() {
		return MESSAGES;
	});
	
	can.fixture('GET /friends', function() {
		return FRIENDS;
	})
	
});

