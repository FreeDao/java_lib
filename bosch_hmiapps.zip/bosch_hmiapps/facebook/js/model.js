var FB = {};
FB.Models = {};

$(function() {
	
	FB.Models.API = can.Model(
	/* @Static */
	{
		defaults : {
			facebookNewsFeedRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/feed/mipId/%MIPID%?maxMessages=%maxMessages%&includeImages=%includeImages%",
				"requestMethod" : "GET"
			},
			facebookHomeRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/home/mipId/%MIPID%?maxMessages=%maxMessages%&includeImages=%includeImages%",
				"requestMethod" : "GET"
			},
			facebookStatusUpdateRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/status/mipId/%MIPID%?message=%message%",
				"requestMethod" : "PUT"
			},
			facebookLikeRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/like/mipId/%MIPID%?id=%id%",
				"requestMethod" : "PUT"
			},
			facebookUnlikeRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/like/mipId/%MIPID%?id=%id%",
				"requestMethod" : "DELETE"
			},
			facebookPostCommentRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/comment/mipId/%MIPID%?id=%id%&comment=%comment%",
				"requestMethod" : "PUT"
			},
			facebookGetCommentRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/comments/mipId/%MIPID%?id=%id%&limit=%limit%&offset=%offset%&afterId=%afterId%",
				"requestMethod" : "GET"
			},
			facebookSearchPlacesRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/places/mipId/%MIPID%?name=%name%&latitude=%latitude%&longitude=%longitude%&limit=%limit%&offset=%offset%&afterId=%afterId%",
				"requestMethod" : "GET"
			},
			facebookCheckinRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/checkin/mipId/%MIPID%?placeId=%placeId%&message=%message%&latitude=%latitude%&longitude=%longitude%",
				"requestMethod" : "PUT"
			},
			facebookNearbyFriendsRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/checkins/mipId/%MIPID%?time=%time%&distance=%distance%&latitude=%latitude%&longitude=%longitude%",
				"requestMethod" : "GET"
			},
			facebookImageRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/images/mipId/%MIPID%",
				"requestMethod" : "POST"
			},
			facebookEventsRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/events/mipId/%MIPID%?days_back=%daysBack%",
				"requestMethod" : "GET"
			},
			facebookFriendsRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/friends/mipId/%MIPID%?limit=%limit%&offset=%offset%",
				"requestMethod" : "GET"
			},
			facebookFriendsBirthdayRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/friends/birthday/mipId/%MIPID%?limit=%limit%&offset=%offset%",
				"requestMethod" : "GET"
			},
			facebookPrivateMessage : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/inbox/mipId/%MIPID%",
				"requestMethod" : "GET"
			},
			facebookShareLinkRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/link/mipId/%MIPID%?link=%link%&message=%message%",
				"requestMethod" : "PUT"
			},
			facebookProfileRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/profile/mipId/%MIPID%",
				"requestMethod" : "GET"
			}
		},
		sendHttpRequest : function(args) {
//			if(AQ.Com.Model.proxy){
//				this.sendHttpRequestProxy(args);
//			}else{	
				console.warn("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!sendHttpRequest");
				console.warn(args);
				$.ajax({
					url : args.url,
					type : "get",
					//data: JSON.stringify(args.data),
					dataType: args.dataType,
					success : args.success,
					error : args.error
				});
			},
		/**** GET NEWS FEED ****/
		getNewsFeed : function(args) {
			console.log("Getting News Feed...");

			var maxMessages = args.data.maxMessages;
			var includeImages = args.data.includeImages;
			var facebookNewsFeedRequest = this.defaults.facebookNewsFeedRequest;
			console.log(can.fixture.on);
			if (can.fixture.on) {
				facebookNewsFeedRequest.requestUri = "/newsfeed", //FIXTURE
				facebookNewsFeedRequest = JSON.stringify(facebookNewsFeedRequest);
			} else {
			facebookNewsFeedRequest.requestUri = facebookNewsFeedRequest.requestUri.replace("%maxMessages%", maxMessages);
			facebookNewsFeedRequest.requestUri = facebookNewsFeedRequest.requestUri.replace("%includeImages%", includeImages);
			}
			console.log(facebookNewsFeedRequest);
            this.sendHttpRequest({
//				url : '/gateway',
            	url:"/newsfeed",
				data: facebookNewsFeedRequest,
				dataType:'json',
				type : "POST",
				success : args.success,
				error : args.error
			});
		},

		/**** GET HOME ****/
		getLiveFeed : function(args) {
			console.log("Getting livefeed...");
		
			var maxMessages = args.data.maxMessages;
			var includeImages = args.data.includeImages;
			var facebookHomeRequest = this.defaults.facebookHomeRequest;
			facebookHomeRequest.requestUri = facebookHomeRequest.requestUri.replace("%maxMessages%", maxMessages);
			facebookHomeRequest.requestUri = facebookHomeRequest.requestUri.replace("%includeImages%", includeImages);
			
			this.sendHttpRequest({
				url : '/gateway',
				data: facebookHomeRequest,
				dataType: 'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});
		},

		/**** PUT STATUS ****/
		postStatus : function(args) {
			var message = encodeURIComponent(args.data.message);
			var facebookStatusUpdateRequest = this.defaults.facebookStatusUpdateRequest;
			facebookStatusUpdateRequest.requestUri = facebookStatusUpdateRequest.requestUri.replace("%message%", message);
			
			this.sendHttpRequest({
				url : '/gateway',
				data: facebookStatusUpdateRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});
		},

		/**** PUT LIKE ****/
		postLike : function(args) {
			var id = args.data.id;
			id = encodeURIComponent(id);

			var facebookLikeRequest = this.defaults.facebookLikeRequest;
			facebookLikeRequest.requestUri = facebookLikeRequest.requestUri.replace("%id%", id);
			//FIXTURE
			//url : "/like/{id}",
			this.sendHttpRequest({
				url : '/gateway',
				data: facebookLikeRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});			
		},

		/**** DELETE UNLIKE ****/
		postUnlike : function(args) {
			var id = args.data.id;
			id = encodeURIComponent(id);

			var facebookUnlikeRequest = this.defaults.facebookUnlikeRequest;
			facebookUnlikeRequest.requestUri = facebookUnlikeRequest.requestUri.replace("%id%", id);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookUnlikeRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** PUT COMMENT ****/
		postComment : function(args) {
			var id = args.data.id;
			var message = args.data.message;

			message = encodeURIComponent(message);
			id = encodeURIComponent(id);

			var facebookPostCommentRequest = this.defaults.facebookPostCommentRequest;
			facebookPostCommentRequest.requestUri = facebookPostCommentRequest.requestUri.replace("%id%", id);
			facebookPostCommentRequest.requestUri = facebookPostCommentRequest.requestUri.replace("%comment%", message);
			//FIXTURE
			//url : "/comment/{comment}",
			this.sendHttpRequest({
				url : '/gateway',
				data: facebookPostCommentRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});			
		},

		/**** GET ALL COMMENTS ****/
		getComments : function(args) {
			var limit = 10;
			var id = args.data.id;
			var offset = args.offset;
			var afterId = args.afterId;

			var facebookGetCommentRequest = this.defaults.facebookGetCommentRequest;
			facebookGetCommentRequest.requestUri = facebookGetCommentRequest.requestUri.replace("%ID%", id);
			facebookGetCommentRequest.requestUri = facebookGetCommentRequest.requestUri.replace("%LIMIT%", limit);
			facebookGetCommentRequest.requestUri = facebookGetCommentRequest.requestUri.replace("%offset%", offset);
			facebookGetCommentRequest.requestUri = facebookGetCommentRequest.requestUri.replace("%afterId%", afterId);
			//FIXTURE
			//url : "/comment/{id}",
			this.sendHttpRequest({
				url : '/gateway',
				data: facebookGetCommentRequest,
				dataType:'json',
				type : 'GET',
				success : args.success,
				error : args.error
			});
		},

		/**** GET NEARBY PLACES ****/
		getNearbyPlaces : function(args) {
			var name = args.data.name;
			var latitude = args.data.latitude;
			var longitude = args.data.longitude;
			var limit = args.data.limit;
			var offset = args.data.offset;
			var afterId = args.data.afterId;

			var facebookSearchPlacesRequest = this.defaults.facebookSearchPlacesRequest;
			if (can.fixture.on) {
				facebookSearchPlacesRequest.requestUri = "/nearbyplaces"; //FIXTURE
			} else {
			facebookSearchPlacesRequest.requestUri = facebookSearchPlacesRequest.requestUri.replace("%name%", name);
			facebookSearchPlacesRequest.requestUri = facebookSearchPlacesRequest.requestUri.replace("%latitude%", latitude);
			facebookSearchPlacesRequest.requestUri = facebookSearchPlacesRequest.requestUri.replace("%longitude%", longitude);
			facebookSearchPlacesRequest.requestUri = facebookSearchPlacesRequest.requestUri.replace("%limit%", limit);
			facebookSearchPlacesRequest.requestUri = facebookSearchPlacesRequest.requestUri.replace("%offset%", offset);
			facebookSearchPlacesRequest.requestUri = facebookSearchPlacesRequest.requestUri.replace("%afterId%", afterId);
			}
			
			this.sendHttpRequest({
				url : '/nearbyplaces',
				data: facebookSearchPlacesRequest,
				dataType:'json',
				type : 'GET',
				success : args.success,
				error : args.error
			});			
		},

		/**** POST CHECK IN ****/
		postCheckIn : function(args) {
			var latitude = args.data.latitude;
			var longitude = args.data.longitude;
			var placeId = args.data.placeId;
			var message = encodeURIComponent(args.data.message);

			var facebookCheckinRequest = this.defaults.facebookCheckinRequest;
			facebookCheckinRequest.requestUri = facebookCheckinRequest.requestUri.replace("%placeId%", placeId);
			facebookCheckinRequest.requestUri = facebookCheckinRequest.requestUri.replace("%message%", message);
			facebookCheckinRequest.requestUri = facebookCheckinRequest.requestUri.replace("%latitude%", latitude);
			facebookCheckinRequest.requestUri = facebookCheckinRequest.requestUri.replace("%longitude%", longitude);
			//FIXTURE
			//url : "/checkin/{placeid}",
			this.sendHttpRequest({
				url : '/gateway',
				data: facebookCheckinRequest,
				dataType:'json',
				type : 'PUT',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET NEARBY FRIENDS(get checkins) ****/
		getNearbyFriends : function(args) {
			var time = 60 * 24 * 7;
			// 7 days
			var distance = args.data.distance;
			var latitude = args.data.latitude;
			var longitude = args.data.longitude;

			var facebookNearbyFriendsRequest = this.defaults.facebookNearbyFriendsRequest;
			if (can.fixture.on) {
				facebookNearbyFriendsRequest.requestUri = "photo"; //FIXTURE
			} else {
			facebookNearbyFriendsRequest.requestUri = facebookNearbyFriendsRequest.requestUri.replace("%latitude%", latitude);
			facebookNearbyFriendsRequest.requestUri = facebookNearbyFriendsRequest.requestUri.replace("%longitude%", longitude);
			facebookNearbyFriendsRequest.requestUri = facebookNearbyFriendsRequest.requestUri.replace("%distance%", distance);
			facebookNearbyFriendsRequest.requestUri = facebookNearbyFriendsRequest.requestUri.replace("%time%", time);
			}
			this.sendHttpRequest({
				url : '/nearbyfriends',
				data: facebookNearbyFriendsRequest,
				dataType:'json',
				type : 'GET',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET IMAGES ****/
		getImages : function(args) {
			var facebookImageRequest = this.defaults.facebookImageRequest;
			FB.Models.sendHttpRequest({
				url : '/gateway',
				data: facebookImageRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET Events ****/
		getEventsRequest : function(args) {
			var daysBack = args.data.daysBack;
			
			var facebookEventsRequest = this.defaults.facebookEventsRequest;
			if (can.fixture.on) {
				facebookEventsRequest.requestUri = "/events"; //FIXTURE
			} else {
			facebookEventsRequest.requestUri = facebookEventsRequest.requestUri.replace("%daysBack%", daysBack);
			}
			
			this.sendHttpRequest({
				url : "/events",
				data: facebookEventsRequest,
				dataType:'json',
				type : 'GET',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET Friends ****/
		getFriendsRequest : function(args) {
			var limit = 10;
			var offset = args.data.offset;

			var facebookFriendsRequest = this.defaults.facebookFriendsRequest;
			if (can.fixture.on) {
				facebookFriendsRequest.requestUri = "/friends"; //FIXTURE
			} else {
			facebookFriendsRequest.requestUri = facebookFriendsRequest.requestUri.replace("%limit%", limit);
			facebookFriendsRequest.requestUri = facebookFriendsRequest.requestUri.replace("%offset%", offset);
			}
			this.sendHttpRequest({
				url : '/friends',
				data: facebookFriendsRequest,
				dataType:'json',
				type : 'GET',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET Friends Birthday ****/
		getFriendsBirthday : function(args) {
			var limit = 10;
			var offset = args.data.offset;

			var facebookFriendsBirthdayRequest = this.defaults.facebookFriendsBirthdayRequest;
			if (can.fixture.on) {
				facebookFriendsBirthdayRequest.requestUri = "/birthday"; //FIXTURE
			} else {
			facebookFriendsBirthdayRequest.requestUri = facebookFriendsBirthdayRequest.requestUri.replace("%limit%", limit);
			facebookFriendsBirthdayRequest.requestUri = facebookFriendsBirthdayRequest.requestUri.replace("%offset%", offset);
			}
			this.sendHttpRequest({
				url : '/birthday',
				data: facebookFriendsBirthdayRequest,
				dataType:'json',
				type : 'GET',
				success : args.success,
				error : args.error
			});			
		},

		/**** GET Inbox Message ****/
		getPrivateMessage : function(args) {
			var facebookPrivateMessage = this.defaults.facebookPrivateMessage;
			if (can.fixture.on) {
				facebookPrivateMessage.requestUri = "/message"; //FIXTURE
			} 
			this.sendHttpRequest({
				url : '/message',
				data: facebookPrivateMessage,
				dataType:'json',
				type : 'GET',
				success : args.success,
				error : args.error
			});				
		},

		/**** PUT Share Link ****/
		putShareLink : function(args) {
			var link = args.data.link;
			var message = encodeURIComponent(args.data.message);

			var facebookShareLinkRequest = this.defaults.facebookShareLinkRequest;
			facebookShareLinkRequest.requestUri = facebookShareLinkRequest.requestUri.replace("%link%", link);
			facebookShareLinkRequest.requestUri = facebookShareLinkRequest.requestUri.replace("%message%", message);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookShareLinkRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** Get Profile ****/
		getProfile : function(args) {
			var facebookProfileRequest = this.defaults.facebookProfileRequest;

			AQ.Com.Model.sendHttpRequest({
				url : '/gateway',
				data: facebookProfileRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		}
	}, {});
}); 
