var nbcnews = can.Construct({}, {
	
	/**
     * Initialize the home app
     */
    init: function()
    {
        $('aqapp').html( 'nbcnews/views/init.ejs', {} );
    }
});

APP.nbcnews = new nbcnews();

AQ.loadStylesheet("nbcnews/nbcnews.css");

AQ.loadScript("nbcnews/js/model.js", function() {
	AQ.loadScript(["nbcnews/js/fixture.js","nbcnews/js/controller.js"]);
});

