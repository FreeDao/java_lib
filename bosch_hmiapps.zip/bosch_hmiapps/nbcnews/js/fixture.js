//TODO add by Sue, continue...
can.fixture.on = true;
	var	page0 = ["Top Stories", "Most Popular", "US News", "World News", "Weather", "Next Page"];
	var page1 = ["Previous Page", "Politics", "Business", "Entertainment", "Sports", "Next Page"];
	var	page2 = ["Previous Page", "Travel", "Health", "Tech & Science", "TODAY"];
		
	 var TOPICS = [{
				"topicId" : 1,
				"name" : "Top News"
			}, {
				"topicId" : 2,
				"name" : "US News"
			}, {
				"topicId" : 3,
				"name" : "World News"
			}, {
				"topicId" : 4,
				"name" : "Politics"
			}, {
				"topicId" : 5,
				"name" : "Business"
			}, {
				"topicId" : 6,
				"name" : "Entertainment"
			}, {
				"topicId" : 7,
				"name" : "Sports"
			}, {
				"topicId" : 8,
				"name" : "Travel"
			}, {
				"topicId" : 9,
				"name" : "Health"
			}, {
				"topicId" : 10,
				"name" : "Tech \u0026 Science"
			}, {
				"topicId" : 11,
				"name" : "TODAY"
			}, {
				"topicId" : 12,
				"name" : "Weather"
			}];
		
		var STORIES = {
			"newsStories" : [{
				"title" : "Longtime GOP Senate moderate Arlen Specter dies",
				"storyId" : 1318,
				"pubDate" : "05:03 PM UTC, Sun, Oct 14, 2012"
			}, {
				"title" : "Specter legacy resonates on Supreme Court",
				"storyId" : 1352,
				"pubDate" : "08:51 PM UTC, Sun, Oct 14, 2012"
			}, {
				"title" : "Skydiver jumps into stratosphere 24 miles over New Mexico",
				"storyId" : 1304,
				"pubDate" : "12:23 AM UTC, Mon, Oct 15, 2012"
			}, {
				"title" : "Tigers put Yankees in 2-0 hole",
				"storyId" : 1361,
				"pubDate" : "12:52 AM UTC, Mon, Oct 15, 2012"
			}, {
				"title" : "More than 200 diagnosed in fungal meningitis outbreak",
				"storyId" : 1343,
				"pubDate" : "07:33 PM UTC, Sun, Oct 14, 2012"
			}],
			"listId" : 1350267339607,
			"topicId" : 1
		};
		
		var NEWSTORIES = [{//"storyId" : 646,
			"title" : "'Fast and Furious': House Republicans sue Attorney General Eric Holder to get documents",
			"publishDate" : "06:41 PM UTC, Mon, Aug 13, 2012",
			"storyURL" : "http://usnews.nbcnews.com/_news/2012/08/13/13260964-fast-and-furious-house-republicans-sue-attorney-general-eric-holder-to-get-documents?lite",
			"content" : "WASHINGTON - U.S. House Republicans filed a federal lawsuit on Monday against Attorney General Eric Holder, the country's top law enforcement official, seeking to obtain documents on a botched operation nicknamed \"Fast and Furious\" that sought to link Arizona gun sales to Mexican drug cartels.The suit likely means the debate over the anti-gun-trafficking operation will go on for months, lasting th...",
			"imageURL" : "http://msnbcmedial.msn.com/i/MSNBC/Components/Photo/_news/spt-121014-tigers-anibal-sanchez.jpg",
			"byLine" : "NBC News staff and wire services"
		}];
	

can.fixture("GET/topics", function(request,response) {
	response(TOPICS);
});

can.fixture("GET/stories", function(request,response) {
    response(STORIES);
});

can.fixture("GET/newsStories", function(request,response) {
    response(NEWSTORIES);
});

