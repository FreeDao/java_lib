
var News = {};
News.Models = {};

$(function() {
	News.Models.API = can.Model(
	/* @Static */
	{
		defaults : {
			getNewsTopicRequest :{
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/news/topics/mipId/%MIPID%",
				"requestMethod" : "GET"
			}, 
			getTopicStoryRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/news/topic/%topicId%/stories/mipId/%MIPID%?start=%start%&count=%count%",
				"requestMethod" : "GET"
			},
			getNewsStoryRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/news/story/%id%/mipId/%MIPID%",
				"requestMethod" : "GET"
			}
		},
		getNewsTopic : function(args) {
			var url = args.url;
			
			AQ.Com.Model.sendHttpRequest({
				url : '/gateway',
				type : 'POST',
				dataType: 'json',
				data :  this.defaults.getNewsTopicRequest,
				success : args.success,
				error : args.error
			});
		},
		getTopicStories : function(args) {
			var topicId = args.data.topicId;
			var start = args.data.start;
			var count = args.data.count;

			var getTopicStoryRequest = $.extend(true, {}, this.defaults.getTopicStoryRequest);
			getTopicStoryRequest["requestUri"] = getTopicStoryRequest["requestUri"].replace("%topicId%", topicId);
			getTopicStoryRequest["requestUri"] = getTopicStoryRequest["requestUri"].replace("%start%", start);
			getTopicStoryRequest["requestUri"] = getTopicStoryRequest["requestUri"].replace("%count%", count);
			
			AQ.Com.Model.sendHttpRequest({
				url : '/gateway',
				type : 'POST',
				dataType: 'json',
				data: getTopicStoryRequest,
				success : args.success,
				error : args.error
			});
		},
		getNewsStory : function(args) {
			var storyId = args.data.storyId;

			var newsStoryReq = $.extend(true, {}, this.defaults.getNewsStoryRequest);
			newsStoryReq["requestUri"] = newsStoryReq["requestUri"].replace("%id%", storyId);
			
			AQ.Com.Model.sendHttpRequest({
				url : '/gateway',
				type : 'POST',
				dataType: 'json',
				data : newsStoryReq,
				success : args.success,
				error : args.error
			});
		},
		
	}, {});
}); 
