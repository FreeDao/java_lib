var root = this;

$(function() {
	var ttsPlaying = false;

	function refreshHeader() {
		$("#header").remove();
		$("body").prepend("<div id='header'>");
	};

	function refreshPage() {
		$("#pagecontent").remove();
		$("body").append("<div id='pagecontent'>");
	};

	News.Header = can.Control({}, {
		_header : null,
		updateTitle : function(title) {
			this._header.attr("title", title);
		},
		init : function() {
			var that = this;
			if (!that._header)
				that._header = new can.Observe({
					title : "Topics",
					time : "00:00:00",
					icon : "RESERVED for icon url or anything else"
				});
			$("#header").html(can.view("nbcnews/views/header-views/common.ejs", {
				data : that._header
			}));
		},
		"#header-title click" : function() {
			//We have left article detail page, so the next article hard button is no longer available.
			AQ.isNextAvailable = false;
			
			this.updateTitle("Topics");
			pagecontent.showHome();
		}
	});

	/* Controller - PageContent */
	News.Pagecontent = can.Control({
		/** @Static */
		pageIndex : 0,
		currentCategory : "",
		arrTopics : [],
		arrTopicsHeaders : [],
		homeButtons : {
			page0 : new Array(),
			page1 : [{
				topicId : "Previous Page",
				name : "Previous Page"
			}],
			page2 : [{
				topicId : "Previous Page",
				name : "Previous Page"
			}]
		},
		
		/** Article Detail Vars **/
		curArticleArrId : 0,
		arrArticleIDs : []
	}, {
		init : function() {
			this.getNewsTopic();
		},
		
		
		/***  ROUTING  ***/
		"route" : function(data) {
			console.log("#################### Begin NBCNews Routing ####################");
			console.log("data");
			console.log(data);
			console.log("#################### END NBCNews Routing ####################");
			
			var page = data.page;
			var id = data.id;
			
			if(page != "keyboard") {
				$("#header").show();
			}
			
			switch(page) {
				case "home":
					this.showHome();
					break;
				
				case "nextpage":
					News.Pagecontent.pageIndex++;
					this.showHome();
					break;
				
				case "prevpage":
					News.Pagecontent.pageIndex--;
					this.showHome();
					break;

				case "article":
					this.loadArticle(data.id);
					break;
									
				default:
					this.loadNews(page);
			}
		},
		
		
		showHome : function() {
			AQ.isNextAvailable = false;
			header.updateTitle("Topics");

			$('#pagecontent').html(can.view('nbcnews/views/pagecontent-views/main_home.ejs', {
				"data" : News.Pagecontent.homeButtons["page" + News.Pagecontent.pageIndex]
			}));
		},
		".next_page click" : function() {
			can.route.attr({type:"nbcnews",page:"nextpage"});	
		},
		".previous_page click" : function() {
			can.route.attr({type:"nbcnews",page:"prevpage"});	
		},
		".home_list aqbutton click" : function(el) {
			var text = el.text().trim().toLowerCase().replace(/ /g,'');
			if (text != "previouspage") can.route.attr({type:"nbcnews",page:text});
		},
		
		//Hard button integration - next and prev
		loadNextNewsDetail : function() {			
			if(News.Pagecontent.curArticleArrId+1 < News.Pagecontent.arrArticleIDs.length) {
				News.Pagecontent.curArticleArrId++;	
				console.warn("loadNextNewsDetail was called: News.Pagecontent.arrArticleIDs[News.Pagecontent.curArticleArrId]: " + News.Pagecontent.arrArticleIDs[News.Pagecontent.curArticleArrId]);
				this.loadArticle(News.Pagecontent.arrArticleIDs[News.Pagecontent.curArticleArrId]);
			}
		},
		loadPrevNewsDetail : function() {
			if(News.Pagecontent.curArticleArrId-1 >= 0) {
				News.Pagecontent.curArticleArrId--;
				console.warn("loadNextNewsDetail was called: News.Pagecontent.arrArticleIDs[News.Pagecontent.curArticleArrId]: " + News.Pagecontent.arrArticleIDs[News.Pagecontent.curArticleArrId]);
				this.loadArticle(News.Pagecontent.arrArticleIDs[News.Pagecontent.curArticleArrId]);
			}
		},
		
				
		//loadNews: This function needs to be ran AFTER dynamic markup has been created.
		loadNews : function(elementsText) {
			var root = this;
			var elementsText = elementsText.trim();
			News.Pagecontent.currentCategory = elementsText;
			if (News.Pagecontent.currentCategory.toLowerCase().trim() == "previous page" || News.Pagecontent.currentCategory.toLowerCase().trim() == "next page")
				return;
			var topicId = $('.home_list aqbutton span:contains("' + elementsText + '")').parent().attr("id");
			var start = 1;
			var count = 20;
			
			
			var func = function() {
				root.getTopicStories({
					topicId : topicId,
					start : start,
					count : count
				});
				header.updateTitle(elementsText);
			};
			AQ.loadWait(null, func);
		},
		
		"#refresh click" : function() {
			$('#pagecontent').hide();
			$('#pagecontent').fadeIn(300);
			this.displayStoryList(News.Pagecontent.currentTitle);

		},
		"div.story-list aqli click" : function(el) {
			var storyId = el.children(".list-head-line").attr("id");
			this.loadArticle(storyId);
		},
		loadArticle : function(storyId) {
			this.getNewsStory({
				storyId : storyId
			});
			displayPlayorPause();
		},
		
		"#ap-play-icon click" : function() {
			ttsPlaying = !ttsPlaying;
			displayPlayorPause();
		},
		"#ap-menu-icon click" : function() {
			//We have left article detail page, so the next article hard button is no longer available.
			AQ.isNextAvailable = false;
			
			header.updateTitle("Topics");
			
			$('#pagecontent').html(can.view('nbcnews/views/pagecontent-views/main_home.ejs', {
				"data" : News.Pagecontent.homeButtons["page" + News.Pagecontent.pageIndex]
			}));
		},

		"#ap-share-icon click" : function() {
			var text = "Share this news story on";
			new News.Overlay("#pagecontent", {
				text : text
			});
		},

		"#share-facebook click" : function() {
			$("#overlay-container").remove();

			var text = "Posting...";
			new News.OverlayPost("#pagecontent", {
				text : text
			});
			setTimeout(function() {
				$("#overlay-container").remove();
			}, 3000);
		},

		"#share-twitter click" : function() {
			$("#overlay-container").remove();
			var text = "Posting...";
			new News.OverlayPost("#pagecontent", {
				text : text
			});
			setTimeout(function() {
				$("#overlay-container").remove();
			}, 3000);
		},

		"#share-cancel click" : function() {
			$("#overlay-container").hide();
		},

		//get topic story
		getTopicSuccess : function(data) {
			for (var x in data) {
				if (x < 5) {
					News.Pagecontent.homeButtons.page0[x] = data[x];
					if (x == 4 && x < data.length - 1) {
						News.Pagecontent.homeButtons.page0[5] = {
							topicId : "next_page",
							name : "Next Page"
						};
					}

				}
				if (x >= 5 && x < 9) {
					News.Pagecontent.homeButtons.page1[x - 4] = data[x];
					if (x == 8 && x < data.length - 1) {
						News.Pagecontent.homeButtons.page1[x - 3] = {
							topicId : "next_page",
							name : "Next Page"
						};
					}
				}
				if (x >= 9) {
					News.Pagecontent.homeButtons.page2[x - 8] = data[x];
				}
			}

			$("#pagecontent").html(can.view("nbcnews/views/pagecontent-views/main_home.ejs", {
				data : News.Pagecontent.homeButtons.page0
			}));
		},

		getNewsTopic : function() {
			News.Models.API.getNewsTopic({
				url : News.Models.ROOT_URL,
				success : this.getTopicSuccess,
				error : function(err) {
					console.log("Get News Topic caught error: " + JSON.stringify(err));
				}
			});
		},

		//get topic stroies
		getTopicStoriesSuccess : function(data) {
			// var stories = data.newsStories;
			this.displayStoryList(data);
		},

		getTopicStories : function(args) {
			var topicId = args.topicId;
			var start = args.start;
			var count = args.count;
			var _this = this;
			var stories = {};
			var arrIDs = [];
			

			News.Models.API.getTopicStories({
				url : News.Models.ROOT_URL,
				data : {
					topicId : topicId,
					start : start,
					count : count
				},
				success : function(data) {
					_this.getTopicStoriesSuccess(data);
					stories = data;
					console.warn("%%%%%%%%%%%%%%%%%%%%%%%%%% NBCNews data");
					console.warn(data);
					
					$.each(stories.newsStories, function(i) {
						arrIDs.push(this.storyId);
					});
					News.Pagecontent.arrArticleIDs = arrIDs;
				},
				error : _this.error
			});
			
			
		},

		//get news story
		getNewsStorySuccess : function(data) {
			//Set next article is available so that next hard button will work.
			AQ.isNextAvailable = true;
			
			if(News.Pagecontent.currentCategory == "") News.Pagecontent.currentCategory = "Top Stories";
			this.displayArticlePage(News.Pagecontent.currentCategory, data);
		},

		getNewsStory : function(args) {
			var storyId = args.storyId;
			var _this = this;
			News.Models.API.getNewsStory({
				url : News.Models.ROOT_URL,
				data : {
					storyId : storyId
				},
				success : function(data) {
					console.log("success on getNewsStory 000000000000000000000000")
					console.log(data)
					_this.getNewsStorySuccess(data);
				},
				error : function(err) {
					console.log("Get news story caught error: " + JSON.stringify(err));
				}
			});
		},

		displayStoryList : function(data) {
			$('#pagecontent').html(can.view('nbcnews/views/pagecontent-views/story_list.ejs', {
				"data" : data
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		displayArticlePage : function(categoryName, data) {
			header.updateTitle(categoryName);

			$('#pagecontent').html(can.view('nbcnews/views/pagecontent-views/article_page.ejs', {
				"data" : data
			}));
			displayPlayorPause();
			pagingControl.init();
		},
		
	});

	News.Overlay = can.Control({}, {
		init : function(el, opt) {
			$('#pagecontent').append(can.view('nbcnews/views/pagecontent-views/overlay.ejs', {
				"text" : opt.text
			}));
			$('#overlay-container').slideDown(500, function() {
			});
		}
	});

	News.OverlayPost = can.Control({}, {
		init : function(el, opt) {
			$('#pagecontent').append(can.view('nbcnews/views/pagecontent-views/overlay-post.ejs', {
				"text" : opt.text
			}));
			$('#overlay-container').slideDown(500, function() {
			});
		}
	});

	var displayPlayorPause = function() {
		if (ttsPlaying) {
			$("#ap-play-icon").removeClass("ap-play-icon");
			$("#ap-play-icon").addClass("ap-pause-icon");
		} else {
			$("#ap-play-icon").addClass("ap-play-icon");
			$("#ap-play-icon").removeClass("ap-pause-icon");
		}
	}
	
	root.header = new News.Header("#header", {});
	root.pagecontent = new News.Pagecontent("#pagecontent", {});

});

