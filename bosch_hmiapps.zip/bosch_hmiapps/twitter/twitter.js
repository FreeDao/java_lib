var twitter = can.Construct({}, {
	init : function() {
		$('aqapp').html('twitter/views/init.ejs', {});
	}
});

APP.twitter = new twitter();

AQ.loadStylesheet("twitter/twitter.css");

AQ.loadScript("twitter/js/fixture.js", function() {
	AQ.loadScript("twitter/js/model.js", function() {
		AQ.loadScript([ "twitter/js/controller.js", "twitter/js/util.js" ]);
	});
});

