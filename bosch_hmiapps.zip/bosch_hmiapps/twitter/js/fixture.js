$(function() {
	
	can.fixture.on = true;

	var TIME_LINE = {

		"sections" : [ {
				'id' : 1,
				'image' : 'images/shared/480x272/icon-home-facebook.png',
				'username' : 'Samantha Starmer',
				'name' : 'samantha',
				'post_time' : '1m',
				'excerpt' : 'Iorem ipsum dolor sit amet, cons...'
			}, {
				'id' : 2,
				'image' : 'images/shared/480x272/icon-home-facebook.png',
				'username' : 'Jessica Novak',
				'name' : 'jessicanovak',
				'post_time' : '5h',
				'excerpt' : 'sed do eiusmod tempor incididunt...'
			}, {
				'id' : 3,
				'image' : 'images/shared/480x272/icon-home-facebook.png',
				'username' : 'John Kolko',
				'name' : 'jkolko',
				'post_time' : '18 Nov',
				'excerpt' : 'Excepteur sint occaecat cupidatat...'
			}, {
				'id' : 4,
				'image' : 'images/shared/480x272/icon-home-facebook.png',
				'username' : 'Joey Trobiani',
				'name' : 'joeytrobiani',
				'post_time' : '09 Apr',
				'excerpt' : 'Book now with Steven Trobiani of Saint Paul, MN. Read patient...'
			} ]
	};

	can.fixture('POST /time_line', function() {
		return TIME_LINE;
	});

});
