var TWITTER = {};
TWITTER.Models = {};

$(function() {
	TWITTER.Models.API = can.Model({

		defaults : {
			TIME_LINE_URL : '',
		},

		sendHttpRequest : function(args, type, dataType) {
			$.ajax({
				url : args.url,
				data : args.data,
				type : type ? type : 'POST',
				dataType : dataType ? dataType : 'JSON',
				success : args.success,
				error : args.error
			});
		},

		/* Time Line */
		getTimeLine : function(args) {
			args.url = can.fixture.on ? '/time_line' : TWITTER.Models.API.defaults.TIME_LINE_URL;
			this.sendHttpRequest(args);
		},

	}, {});
});
