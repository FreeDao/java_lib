$(function() {
	/* Controller - Header */
	TWITTER.Header = can.Control({
		defaults : {}
	}, {

		header : new can.Observe({
			title : '',
		}),

		hide : function() {
			$("#header").hide();
		},

		show : function() {
			$("#header").show();
		},

		init : function(el) {
			this.header.attr('title', 'Twitter');
			$("#header").html(can.view("twitter/views/header-views/common.ejs", {
				data : this.header
			}));
		},

		updateTitle : function(title) {
			this.header.attr("title", title);
		},

		"#header-title click" : function() {
			can.route.attr({ type : "twitter", page : "home" });
		}
	});

	/* Controller - PageContent */
	TWITTER.Pagecontent = can.Control({
		defaults : {}
	},{
		
		vo_time_line : new can.Observe.List([]),

		title : null,

		init : function() {
			this.title = this.options.header;
			this.loadIndex();
		},

		loadIndex : function() {
			this.loadTimeLine();
		},

		loadPage : function(name, data, title) {

			$('#pagecontent').html(can.view('twitter/views/pagecontent-views/' + name + '.ejs', {
				data : data
			}));

			this.addScrollBarEvents();

			this.updateRoute(title ? title : name.replace(/\_/g, ' '));

		},

		loadPopup : function() {
			$('#pagecontent').append(can.view('twitter/views/pagecontent-views/popup.ejs', {
				data : this.vo_popup
			}));
			$('#popup-container').slideDown(500, function() { });
		},

		closePopup : function() {
			$('#popup-container').slideUp(500, function() { });
		},

		addScrollBarEvents : function() {
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},

		updateTitle : function(title) {
			this.title.updateTitle(title);
		},

		updateRoute : function(route) {
			can.route.attr({
				type : "twitter",
				page : route
			});
		},

		/* Time Line */
		loadTimeLine : function() {

			var self = this;

			var success = function(res) {
				for ( var i in res.sections) {
					self.vo_time_line.push(res.sections[i]);
				}
				self.loadPage('time_line', self.vo_time_line);
			};

			var error = function(res) {
				console.log("Get Time Line request caught error : " + JSON.stringify(res));
			};

			TWITTER.Models.API.getTimeLine({
				data : {
					"type" : 'timeline'
				},
				success : success,
				error : error
			});
		},
	});

	var header = new TWITTER.Header("#header", {});
	new TWITTER.Pagecontent("#pagecontent", { header : header });
});
