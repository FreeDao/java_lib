TWITTER.Models.Util = can.Model({
	init : function() {

	},
}, {});