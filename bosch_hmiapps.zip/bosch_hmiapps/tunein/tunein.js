var tunein = can.Construct({}, {
	init : function() {
		$('aqapp').html('tunein/views/init.ejs', {});
	}
});

APP.tunein = new tunein();

AQ.loadStylesheet("tunein/tunein.css");

$.jsperanto.init(function(t){
	AQ.loadScript("tunein/js/model.js", function() {
		AQ.loadScript([ "tunein/js/controller.js", "tunein/js/fixture.js", "tunein/js/util.js" ]);
	});
}, {
	appName: 'TuneIn',
	lang: AQ.language 
});




