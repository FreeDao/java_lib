$(document).ready(function($) {

	can.fixture.on = true;

	var FAVORITES = {

		"sections" : [ {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'NWPR Classica Music',
			'info' : 'Classica...',
			'id' : '12'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'KSER',
			'info' : 'Sunlit Room',
			'id' : '23334'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'WYEP-FK',
			'info' : 'Afternoon Mix',
			'id' : '42'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'C89.5',
			'info' : 'Janet Jackson - Miss U',
			'id' : '677'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'The Mountain',
			'info' : 'Phil Collins - I...',
			'id' : '789'

		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'Radiolab',
			'info' : 'Unraveling Belero',
			'id' : '780'

		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'name' : 'FM101',
			'info' : 'Faraway',
			'id' : '677'
		} ]
	};

	var LOCAL_RADIO = {

		"sections" : [ {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.3',
			'name' : 'KEXP-FM',
			'category' : 'Indie',
			'info' : 'Gary Clark Jr. - Bright Lights',
			'id' : '456566'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.7',
			'name' : 'KSER',
			'category' : 'Public',
			'info' : 'Sunlit Room',
			'id' : '795646'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.9',
			'name' : 'NWPR Classical Music',
			'category' : 'Public',
			'info' : 'Classical Music (NWPR)',
			'id' : '6845464'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '105.7',
			'name' : 'FM105.7',
			'category' : 'Pop',
			'info' : 'Young For You',
			'id' : '795554444'
		} ]
	};

	var RECENTS = {

		"sections" : [ {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.3',
			'name' : 'KEXP-FM',
			'category' : 'Indie',
			'info' : 'Gary Clark Jr. - Bright Lights',
			'id' : '456566'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.7',
			'name' : 'KSER',
			'category' : 'Public',
			'info' : 'Sunlit Room',
			'id' : '795646'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.9',
			'name' : 'NWPR Classical Music',
			'category' : 'Public',
			'info' : 'Classical Music (NWPR)',
			'id' : '6845464'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '105.7',
			'name' : 'FM105.7',
			'category' : 'Pop',
			'info' : 'Young For You',
			'id' : '795554444'
		} ]
	};

	var RECOMMENDED = {

		"sections" : [ {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.3',
			'name' : 'KEXP-FM',
			'category' : 'Indie',
			'info' : 'Gary Clark Jr. - Bright Lights',
			'id' : '456566'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.7',
			'name' : 'KSER',
			'category' : 'Public',
			'info' : 'Sunlit Room',
			'id' : '795646'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '90.9',
			'name' : 'NWPR Classical Music',
			'category' : 'Public',
			'info' : 'Classical Music (NWPR)',
			'id' : '6845464'
		}, {
			'logo' : 'images/shared/480x272/icon-home-facebook.png',
			'frequency' : '105.7',
			'name' : 'FM105.7',
			'category' : 'Pop',
			'info' : 'Young For You',
			'id' : '795554444'
		} ]
	};

	var MUSIC = {

		"sections" : [ {
			'category' : 'Adult Contemp'
		}, {
			'category' : 'Alt Rock'
		}, {
			'category' : "Children's"
		}, {
			'category' : 'Classic Rock'
		}, {
			'category' : 'Classical'
		}, {
			'category' : 'Country'
		} ]
	};

	var TALK = {

		"sections" : [ {
			'category' : 'Business'
		}, {
			'category' : 'Comedy'
		}, {
			'category' : "Conservative"
		}, {
			'category' : 'Entertainment'
		}, {
			'category' : 'Ideas'
		}, {
			'category' : 'News'
		} ]
	};

	var SPORTS = {

		"sections" : [ {
			'category' : 'College Football'
		}, {
			'category' : 'ESPN'
		}, {
			'category' : "MLB Playoffs On ESPN"
		}, {
			'category' : 'More Sports and Teams'
		}, {
			'category' : 'NASCAR'
		}, {
			'category' : 'Sports Talk'
		} ]
	};

	var LOCATIONS = {

		"sections" : [ {
			'category' : 'Africa'
		}, {
			'category' : 'Antarctica'
		}, {
			'category' : "Asia"
		}, {
			'category' : 'Australia'
		}, {
			'category' : 'Central America'
		}, {
			'category' : 'Europe'
		} ]
	};

	var LANGUAGE = {

		"sections" : [ {
			'category' : 'Aboriginal'
		}, {
			'category' : 'Afrikaans'
		}, {
			'category' : "Albanian"
		}, {
			'category' : 'Arabic'
		}, {
			'category' : 'Armenian'
		}, {
			'category' : 'BashKir'
		} ]
	};

	var PODCASTS = {

		"sections" : [ {
			'category' : 'Music'
		}, {
			'category' : 'Talk'
		}, {
			'category' : "Sports"
		} ]
	};

	var NEWS = {
			
		"sections" : [ {
			'category' : 'Local Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Tcoma AM',
				'info' : 'Classica test...',
				'id' : '7892451'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Vocccce Of Vashon',
				'info' : 'Norfthfdfwest Music',
				'id' : '780923'
			} ]
		}, {
			'category' : 'Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Eock 107',
				'info' : 'U2 - Sunfdday Bloody Sunday',
				'id' : '7889321'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'NWfdsPR Clafdssica Music',
				'info' : 'Classicallll...',
				'id' : '123723'
			} ]
		} ]
	};
	
	var SEARCH_RESULTS = {

		"sections" : [ {
			'category' : 'Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'station name1',
				'info' : 'classic...',
				'id' : '25632'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'station name2',
				'info' : 'Northwest good',
				'id' : '7451'
			} ]
		}, {
			'category' : 'Shows',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'PodCast Title1',
				'id' : '7564656'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'PodCast Title2',
				'id' : '4130323'
			} ]
		} ]
	};

	var MUSIC_LIST = {

		"sections" : [ {
			'category' : 'Local Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Tacoma FM',
				'info' : 'Classica...',
				'id' : '789221'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Voice Of Vashon',
				'info' : 'Northwest Music',
				'id' : '787823'
			} ]
		}, {
			'category' : 'Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Rock 107',
				'info' : 'U2 - Sunday Bloody Sunday',
				'id' : '789421'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'NWPR Classica Music',
				'info' : 'Classica...',
				'id' : '789231'
			} ]
		} ]
	};

	var TALK_LIST = {

		"sections" : [ {
			'category' : 'Local Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Tacoma FM',
				'info' : 'Classica...',
				'id' : '789221'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Voice Of Vashon',
				'info' : 'Northwest Music',
				'id' : '787823'
			} ]
		}, {
			'category' : 'Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Rock 107',
				'info' : 'U2 - Sunday Bloody Sunday',
				'id' : '789421'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'NWPR Classica Music',
				'info' : 'Classica...',
				'id' : '789231'
			} ]
		} ]
	};

	var SPORTS_LIST = {

		"sections" : [ {
			'category' : 'Local Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Tacoma FM',
				'info' : 'Classica...',
				'id' : '789221'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Voice Of Vashon',
				'info' : 'Northwest Music',
				'id' : '787823'
			} ]
		}, {
			'category' : 'Stations',
			'stations' : [ {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'Rock 107',
				'info' : 'U2 - Sunday Bloody Sunday',
				'id' : '789421'
			}, {
				'logo' : 'images/shared/480x272/icon-home-facebook.png',
				'name' : 'NWPR Classica Music',
				'info' : 'Classica...',
				'id' : '789231'
			} ]
		} ]
	};

	can.fixture('POST /favorites', function() {
		return FAVORITES;
	});

	can.fixture('POST /local_raido', function() {
		return LOCAL_RADIO;
	});

	can.fixture('POST /recents', function() {
		return RECENTS;
	});

	can.fixture('POST /recommended', function() {
		return RECOMMENDED;
	});

	can.fixture('POST /music_category', function() {
		return MUSIC;
	});

	can.fixture('POST /talk_category', function() {
		return TALK;
	});

	can.fixture('POST /sports_category', function() {
		return SPORTS;
	});

	can.fixture('POST /location_category', function() {
		return LOCATIONS;
	});

	can.fixture('POST /language_category', function() {
		return LANGUAGE;
	});

	can.fixture('POST /podcasts_category', function() {
		return PODCASTS;
	});

	can.fixture('POST /news_category', function() {
		return NEWS;
	});

	can.fixture('POST /search_results', function() {
		return SEARCH_RESULTS;
	});

	can.fixture('POST /music_list', function() {
		return MUSIC_LIST;
	});

	can.fixture('POST /talk_list', function() {
		return TALK_LIST;
	});

	can.fixture('POST /sports_list', function() {
		return SPORTS_LIST;
	});
	
	can.fixture('POST /location_list', function() {
		return SPORTS_LIST;
	});
	
	can.fixture('POST /language_list', function() {
		return SPORTS_LIST;
	});

});
