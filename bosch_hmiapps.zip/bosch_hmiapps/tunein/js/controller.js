$(function() {
	/* Controller - Header */
	TI.Header = can.Control({
		defaults : { 
			menu : $.t('title_tuneIn')
			
		}
	}, {
		
		header : new can.Observe({
			title : '',
		}),
		
		hide : function() {
			$("#header").hide();
		},
		
		show : function() {
			$("#header").show();
		},
		
		init : function(el) {
			this.header.attr('title', 'TuneIn');
			$("#header").html(can.view("tunein/views/header-views/common.ejs", {
				data : this.header
			}));
		},
		
		updateTitle : function(title) {
			this.header.attr("title","TuneIn");
		},

		"#header-title click" : function() {
			can.route.attr({ type : "tunein", page : "home" });
		}
	});

	/* Controller - PageContent */
	TI.Pagecontent = can.Control({
		defaults : { 
			menu : $.t('title_tuneIn')
		}
	}, {
		
		/* Menu VO */
		vo_category_menu : new can.Observe.List([
             $.t('submenu_search'), 'Favorites', 'Now Playing', 'Local Radio', 
             'Recents', 'Recommended', 'Music', 'Sports', 'News', 
             'Talk', 'By Location', 'By Language', 'Podcasts'
        ]),
		vo_favorites : new can.Observe.List([]),
		vo_local_radio : new can.Observe.List([]),
		vo_recents : new can.Observe.List([]),
		vo_recommended : new can.Observe.List([]),
		vo_music_category : new can.Observe.List([]),
		vo_talk_category : new can.Observe.List([]),
		vo_sports_category : new can.Observe.List([]),
		vo_location_category : new can.Observe.List([]),
		vo_language_category : new can.Observe.List([]),
		vo_podcasts_category : new can.Observe.List([]),
		vo_news_category : new can.Observe.List([]),
		
		/* Category List VO */
		vo_music_list : new can.Observe.List([]),
		vo_talk_list : new can.Observe.List([]),
		vo_sports_list : new can.Observe.List([]),
		vo_location_list : new can.Observe.List([]),
		vo_language_list : new can.Observe.List([]),
		vo_search_results : new can.Observe.List([]),
		
		/* Station Player VO */
		vo_station : new can.Observe(),
		
		/* Share VO */
		vo_share : new can.Observe(),
		
		/* Popup VO */
		vo_popup : new can.Observe(),
		
		title : null,
		
		init : function() {
			this.title = this.options.header;
			this.loadIndex();
		},
		
		loadIndex : function() {
			this.loadCategoryMenu();			
		},
		
		loadPage : function(name, data, title) {
			console.log(">>>>>" + this.options.menu);
			
			$('#pagecontent').html(can.view('tunein/views/pagecontent-views/' + name + '.ejs', {
				data : data
			}));
			
			this.addScrollBarEvents();
			
			var newTitle = title ? title : name.replace(/\_/g, ' ');
			
			this.updateTitle(newTitle);
		
			this.updateRoute(name);	
			
		},
		
		loadPopup : function() {
			$('#pagecontent').append(can.view('tunein/views/pagecontent-views/popup.ejs', {
				data : this.vo_popup
			}));
			$('#popup-container').slideDown(500, function() { });
		},
		
		closePopup : function() {
			$('#popup-container').slideUp(500, function() { });
		},
		
		addScrollBarEvents : function() {
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
			});
		},
		
		updateTitle : function(title) {
			this.title.updateTitle(title);
		},
		
		updateRoute : function(route) {
			can.route.attr({ type : "tunein", page : route });
		},
		
		/* Menu */
		loadCategoryMenu : function() {
			this.loadPage('category_menu', this.vo_category_menu);
		},
		
		/* Search */
		loadSearch:function(){		
			header.hide();
			root.template.buildListTemplate("search_board", null, "", "keyboard", "Search", "input-text", "", "status-input", "Delete", "delete", "123/ABC", "numExchange", "OK", "ok_btn");
			$('#ok').hide();
		},
		
		/* Favorites */
		loadFavorites : function() {
			
			var self = this;
			
			var success = function(res) {
				//self.vo_favorites.concat(res.sections);
				//for (var i in res.sections) {
				//	self.vo_favorites.push(res.sections[i]);
				//}
				self.vo_favorites = new can.Observe.List(res.sections);
				self.loadPage('favorites', self.vo_favorites);
			};

			var error = function(res) {
				console.log("Get Favorites request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getFavorites({
				data : {
					"type" : 'Favorites'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Local Radio */
		loadLocalRadio : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_local_radio.push(res.sections[i]);
				}
				self.loadPage('local_radio', self.vo_local_radio);
			};

			var error = function(res) {
				console.log("Get Local Radio request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getLocalRadio({
				data : {
					"type" : 'LocalRadio'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Recents */
		loadRecents : function() {
			
			var self = this;
			
			var success = function(res) {
				/*
				for (var i in res.sections) {
					self.vo_recents.push(res.sections[i]);
				}
				*/
				self.vo_recents = new can.Observe.List(res.sections);
				self.loadPage('recents', self.vo_recents);
			};

			var error = function(res) {
				console.log("Get Recent request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getRecents({
				data : {
					"type" : 'Recents'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Recommended */
		loadRecommended : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_recommended.push(res.sections[i]);
				}
				self.loadPage('recommended', self.vo_recommended);
			};

			var error = function(res) {
				console.log("Get Recommended request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getRecommended({
				data : {
					"type" : 'Recommended'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Music Category */
		loadMusicCategory : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_music_category.push(res.sections[i]);
				}
				self.loadPage('music', self.vo_music_category);				
			};

			var error = function(res) {
				console.log("Get Music Category request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getMusicCategory({
				data : {
					"type" : 'MusicCategory'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Talk Category */
		loadTalkCategory : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_talk_category.push(res.sections[i]);
				}
				self.loadPage('talk', self.vo_talk_category);
			};

			var error = function(res) {
				console.log("Get Talk Category request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getTalkCategory({
				data : {
					"type" : 'TalkCategory'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Sports Category */
		loadSportsCategory : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_sports_category.push(res.sections[i]);
				}
				self.loadPage('sports', self.vo_sports_category);
			};

			var error = function(res) {
				console.log("Get Sports Category request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getSportsCategory({
				data : {
					"type" : 'SportsCategory'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Location Category */
		loadLocationCategory : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_location_category.push(res.sections[i]);
				}
				self.loadPage('location', self.vo_location_category, 'Choose Location');
			};

			var error = function(res) {
				console.log("Get Location Category request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getLocationCategory({
				data : {
					"type" : 'LocationCategory'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Language Category */
		loadLanguageCategory : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_language_category.push(res.sections[i]);
				}
				self.loadPage('language', self.vo_language_category);
			};

			var error = function(res) {
				console.log("Get Language Category request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getLanguageCategory({
				data : {
					"type" : 'LanguageCategory'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Podcasts Category */
		loadPodcastsCategory : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_podcasts_category.push(res.sections[i]);
				}
				self.loadPage('podcasts', self.vo_podcasts_category);
			};

			var error = function(res) {
				console.log("Get Podcasts Category request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getPodcastsCategory({
				data : {
					"type" : 'PodcastsCategory'
				},
				success : success,
				error : error
			});
			
		},
		
		/* News Category */
		loadNewsCategory : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_news_category.push(res.sections[i]);
				}
				self.loadPage('news', self.vo_news_category);
			};

			var error = function(res) {
				console.log("Get News Category request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getNewsCategory({
				data : {
					"type" : 'NewsCategory'
				},
				success : success,
				error : error
			});
		},
		
		/* Music List */
		loadMusicList : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_music_list.push(res.sections[i]);
				}
				self.loadPage('music_list', self.vo_music_list);
			};

			var error = function(res) {
				console.log("Get Music List request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getMusicList({
				data : {
					"type" : 'MusicList'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Talk List */
		loadTalkList : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_talk_list.push(res.sections[i]);
				}
				self.loadPage('talk_list', self.vo_talk_list);
			};

			var error = function(res) {
				console.log("Get Talk List request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getTalkList({
				data : {
					"type" : 'TalkList'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Sports List */
		loadSportsList : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_sports_list.push(res.sections[i]);
				}
				self.loadPage('sports_list', self.vo_sports_list);
			};

			var error = function(res) {
				console.log("Get Sports List request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getSportsList({
				data : {
					"type" : 'SportsList'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Location List */
		loadLocationList : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_location_list.push(res.sections[i]);
				}
				self.loadPage('location_list', self.vo_location_list);
			};

			var error = function(res) {
				console.log("Get Location List request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getLocationList({
				data : {
					"type" : 'LocationList'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Language List */
		loadLanguageList : function() {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_language_list.push(res.sections[i]);
				}
				self.loadPage('language_list', self.vo_language_list);
			};

			var error = function(res) {
				console.log("Get Language List request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getLocationList({
				data : {
					"type" : 'LanguageList'
				},
				success : success,
				error : error
			});
			
		},
		
		/* Station Player */
		loadStationPlayer : function() {
			this.loadPage('station_player', this.vo_station, this.vo_station.attr('name'));
		},
		
		/* Station Player Menu */
		loadStationPlayerMenu : function() {
			this.loadPage('station_player_menu', {});
		},
		
		/* Share */
		loadShare : function() {
			this.loadPage('share', this.vo_share);
		},
		
		/* Search results */
		loadSearchResults : function(data) {
			
			var self = this;
			
			var success = function(res) {
				for (var i in res.sections) {
					self.vo_search_results.push(res.sections[i]);
				}
				self.title.show();
				self.loadPage('search_results', self.vo_search_results);				
			};
			
			var error = function(res){
				console.log("Get Search Results request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getSearchResults({
				data : data,
				success : success,
				error : error
			});
		},
		
		/** Click Events **/
		/* Menu Click */
		'#search click' : function() {
			this.loadSearch();
		},	
		
		'#favorites click' : function() {
			this.loadFavorites();
		},
		
		'#now_playing click' : function() {
			this.loadStationPlayer();
		},	
	
		'#local_radio click' : function() {
			this.loadLocalRadio();
		},
		
		'#recents click' : function() {
			this.loadRecents();
		},
		
		'#recommended click' : function() {
			this.loadRecommended();
		},
		
		'#music click' : function() {
			this.loadMusicCategory();
		},
		
		'#talk click' : function() {
			this.loadTalkCategory();
		},
		
		'#news click' : function(){
			this.loadNewsCategory();
		},
		
		'#sports click' : function() {
			this.loadSportsCategory();
		},
		
		'#by_location click' : function() {
			this.loadLocationCategory();
		},
		
		'#by_language click' : function() {
			this.loadLanguageCategory();
		},
		
		'#podcasts click' : function() {
			this.loadPodcastsCategory();
		},
		
		/* Station List Click */
		'.station-list .list-li-a, .station-list .list-li-b click' : function(el) {
			this.vo_station = el.data('station');
			this.loadStationPlayer();
		},
		
		/* Category List Click */
		'#music-category-list .list-li-a click' : function() {
			this.loadMusicList();
		},
		
		'#talk-category-list .list-li-a click' : function() {
			this.loadTalkList();
		},
		
		'#sports-category-list .list-li-a click' : function() {
			this.loadSportsList();
		},
		
		'#location-category-list .list-li-a click' : function() {
			this.loadLocationList();
		},
		
		'#language-category-list .list-li-a click' : function() {
			this.loadLanguageList();
		},
		
		/* Share Click */
		'#player-share click' : function() {
			this.vo_popup.attr({
				'text' : 'Share Station On',
				'buttons' : ['F', 'T', 'Cancel']
			});
			this.loadPopup();
		},
		
		'#f_btn click' : function() {
			this.vo_share.attr({
				'service' : 'facebook',
				'station' : this.vo_station
			});
			this.loadShare();
		},
		
		'#t_btn click' : function() {
			this.vo_share.attr({
				'service' : 'twitter',
				'station' : this.vo_station
			});
			this.loadShare();
		},
		
		'#cancel_btn click' : function() {
			this.closePopup();
		},
		
		/* Station Player Click */
		'#player-menu click' : function() {
			this.loadStationPlayerMenu();
		},
	
		/* Station Player Menu Click */
		'#main-menu click' : function() {
			this.loadIndex();
		},
		
		'#my-favorites click' : function() {
			
			var self = this;
			
			var success = function(res) {
				if (res.sections.length > 0) {
					self.loadFavorites();
				} else {
					self.loadStationPlayer();
					self.vo_popup.attr({
						'text' : 'You have no favorites saved. Search for new stations ?',
						'buttons' : ['Yes', 'No']
					});
					self.loadPopup();
				}
			};

			var error = function(res) {
				console.log("Get Favorites request caught error : " + JSON.stringify(res));
			};
			
			TI.Models.API.getFavorites({
				data : {
					"type" : 'Favorites'
				},
				success : success,
				error : error
			});
		},
		
		/* Station Player Menu Popup Click */
		'#yes_btn click' : function() {
			this.loadSearch();
		},
		
		'#no_btn click' : function() {
			this.closePopup();
		},
		
		/* Search Click */
		'#search_board  #ok_btn click' : function() {
			var data = $('#status-input').val().trim();
			if (data != '') {
				console.log("Input content is : " + data);
				this.loadSearchResults(data);
			} else {
				console.log("Input content is empty, please input again!!");
			}
		},
	});
	
	var header = new TI.Header("#header", {});
	new TI.Pagecontent("#pagecontent", {header : header});
});
