var TI = {};
TI.Models = {};

$(function() {
	TI.Models.API = can.Model({
		
		defaults : {
			FAVORITES_URL : '',
			LOCAL_RADIO_URL : '',
			RECENTS_URL : '',
			RECOMMENDED_URL : '',
			MUSIC_CATEGORY_URL : '',
			TALK_CATEGORY_URL : '',
			SPORTS_CATEGORY_URL : '',
			LOCATION_CATEGORY_URL : '',
			LANGUAGE_CATEGORY_URL : '',
			PODCASTS_CATEGORY_URL : '',
			NEWS_CATEGORY_URL : '',
			
			MUSIC_LIST_URL : '',
			TALK_LIST_URL : '',
			SPORTS_LIST_URL : '',
			LOCATION_LIST_URL : '',
			LANGUAGE_LIST_URL : '',
			
			SEARCH_RESULTS_URL : '',
			
		},

		sendHttpRequest : function(args, type, dataType) {
			$.ajax({
				url : args.url,
				data : args.data,
				type : type ? type : 'POST',
				dataType : dataType ? dataType : 'JSON',
				success : args.success,
				error : args.error
			});
		},
		
		/** Get Category **/
		
		/* Favorites */
		getFavorites : function(args) {
			args.url = can.fixture.on ? '/favorites' : TI.Models.API.defaults.FAVORITES_URL;
            this.sendHttpRequest(args);
		},
		
		/* Local Radio */
		getLocalRadio : function(args) {
			args.url = can.fixture.on ? '/local_raido' : TI.Models.API.defaults.LOCAL_RADIO_URL;
            this.sendHttpRequest(args);
		},
		
		/* Recents */
		getRecents : function(args) {
			args.url = can.fixture.on ? '/recents' : TI.Models.API.defaults.RECENTS_URL;
            this.sendHttpRequest(args);
		},
		
		/* Recommended */
		getRecommended : function(args) {
			args.url = can.fixture.on ? '/recommended' : TI.Models.API.defaults.RECOMMENDED_URL;
            this.sendHttpRequest(args);
		},
		
		/* Music Category */
		getMusicCategory : function(args) {
			args.url = can.fixture.on ? '/music_category' : TI.Models.API.defaults.MUSIC_CATEGORY_URL;
            this.sendHttpRequest(args);
		},
		
		/* Talk Category */
		getTalkCategory : function(args) {
			args.url = can.fixture.on ? '/talk_category' : TI.Models.API.defaults.TALK_CATEGORY_URL;
            this.sendHttpRequest(args);
		},
		
		/* Sports Category */
		getSportsCategory : function(args) {
			args.url = can.fixture.on ? '/sports_category' : TI.Models.API.defaults.SPORTS_CATEGORY_URL;
            this.sendHttpRequest(args);
		},
		
		/* Location Category */
		getLocationCategory : function(args){
			args.url = can.fixture.on ? '/location_category' : TI.Models.API.defaults.LOCATION_CATEGORY_URL;
            this.sendHttpRequest(args);
		},
		
		/* Language Category */
		getLanguageCategory : function(args){
			args.url = can.fixture.on ? '/language_category' : TI.Models.API.defaults.LANGUAGE_CATEGORY_URL;
            this.sendHttpRequest(args);
		},
		
		/* Podcasts Category */
		getPodcastsCategory : function(args){
			args.url = can.fixture.on ? '/podcasts_category' : TI.Models.API.defaults.PODCASTS_CATEGORY_URL;
            this.sendHttpRequest(args);
		},
		
		/* News Category */
		getNewsCategory : function(args){
			args.url = can.fixture.on ? '/news_category' : TI.Models.API.defaults.NEWS_CATEGORY_URL;
            this.sendHttpRequest(args);
		},
		
		/* Search Results */
		getSearchResults : function(args){
			args.url = can.fixture.on ? '/search_results' : TI.Models.API.defaults.SEARCH_RESULTS_URL;
			this.sendHttpRequest(args);
		},
		
		/* Music List */
		getMusicList : function(args){
			args.url = can.fixture.on ? '/music_list' : TI.Models.API.defaults.MUSIC_LIST_URL;
            this.sendHttpRequest(args);
		},
		
		/* Talk List */
		getTalkList : function(args){
			args.url = can.fixture.on ? '/talk_list' : TI.Models.API.defaults.TALK_LIST_URL;
            this.sendHttpRequest(args);
		},
		
		/* Sports List */
		getSportsList : function(args){
			args.url = can.fixture.on ? '/sports_list' : TI.Models.API.defaults.SPORTS_LIST_URL;
            this.sendHttpRequest(args);
		},
		
		/* Location List */
		getLocationList : function(args){
			args.url = can.fixture.on ? '/location_list' : TI.Models.API.defaults.LOCATION_LIST_URL;
            this.sendHttpRequest(args);
		},
		
		/* Language List */
		getLanguageList : function(args){
			args.url = can.fixture.on ? '/language_list' : TI.Models.API.defaults.LANGUAGE_LIST_URL;
            this.sendHttpRequest(args);
		},

	}, { });
});
