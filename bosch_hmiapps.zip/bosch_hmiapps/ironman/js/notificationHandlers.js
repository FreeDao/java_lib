var Socket = {
	_socket: null,
	_connect: function(){
		if (!this._socket) this._socket = io.connect();
	},
	on : function(event, cb) {
		this._connect();
		this._socket.on(event, cb);
	},
	emit : function(event, data) {
		this._connect();
		this._socket.emit(event, data);
	}
};
Socket.on("aqEncoderEvent", function(data){
	var i = 0;
	while(i++ < data.steps) {
		if (data.encoderDirection == 0) {
			glbSpace.selectableElementsControl.scrollRight();
		} else if(data.encoderDirection == 1){
			glbSpace.selectableElementsControl.scrollLeft();
		}
		
	}
});
Socket.on("aqHardKeyEvent", function(data){
	switch(data.eHardKeyEvent) {
	case "11":
	case "12":
	case "13":
	case "14":
	case "15":
		glbSpace.selectableElementsControl.backButton();
		break;
	case "26":
	case "27":
	case "28":
	case "29":
	case "30":
		glbSpace.selectableElementsControl.enterButton();
		break;
	}
});
Socket.on("aqSwcKeyEvent", function(data){
	switch(data.eSWCKeyEvent) {
	case "11":
	case "12":
	case "13":
	case "14":
	case "15":
		glbSpace.selectableElementsControl.backButton();
		break;
	case "26":
	case "27":
	case "28":
	case "29":
	case "30":
		glbSpace.selectableElementsControl.enterButton();
		break;
	}
});