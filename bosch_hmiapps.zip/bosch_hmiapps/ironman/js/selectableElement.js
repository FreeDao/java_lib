$(function(){
	//Hard Button Functions
	var SelectableElements = can.Control({
		init: function(){
			this.scrollCount = 0;
			this.app = [];
			this.sort = false;
			this.group = 1;
			this.ele = null;
		},
		getSelectableElements: function() {
			this.app = $('aqapp');
			var selectableElements = [];
			this.app.find('*[selectable'+this.group+']').each(function(index){
				//selectableElements.push(this.id);
				selectableElements.push(this);
			});
			return selectableElements;
		},
		scrollRight: function() {
			this.sort = ($('#sort-az-popup').css('display') == 'block') ? true : false;
			
			if(!this.sort) {
				var ticks = 1;
				var elements = this.getSelectableElements();
				console.log(elements);
				//this.app.find("#" + elements[this.scrollCount-1]).removeClass("selected");
				this.ele = elements[this.scrollCount-1];
				if (this.ele) $(this.ele).attr("style",$(this.ele).attr("style").replace(/border\:[^\,]*/,""));
				this.scrollCount += ticks;	
				if(this.scrollCount > elements.length) this.scrollCount = (this.scrollCount - elements.length);
				//this.app.find("#" + elements[this.scrollCount-1]).addClass("selected");
				this.ele = elements[this.scrollCount-1];
				if (this.ele) $(this.ele).attr("style", "border:2px solid #00D6FF;"+$(this.ele).attr("style"));
			} else {
				this.sortAZ('right');
			}
		},
		scrollLeft: function() {
			this.sort = ($('#sort-az-popup').css('display') == 'block') ? true : false;
			
			if(!this.sort) {
				var ticks = 1
				var elements = this.getSelectableElements();
				this.ele = elements[this.scrollCount-1];
				if (this.ele) $(this.ele).attr("style",$(this.ele).attr("style").replace(/border\:[^\,]*/,""));
				this.scrollCount = (this.scrollCount - ticks <= 0) ? this.scrollCount = elements.length - (ticks-this.scrollCount) : this.scrollCount -= ticks; 

				this.ele = elements[this.scrollCount-1];
				if (this.ele) $(this.ele).attr("style", "border:2px solid #00D6FF;"+$(this.ele).attr("style"));
			} else {
				this.sortAZ('left');
			}
		},
		enterButton: function() {
			if (this.ele) $(this.ele).click();
		},
		backButton: function() {
			//window.location.reload();
			window.location = "../main.html";
		},
		sortAZ : function(direction) {
			var letterObj = $('.sorter');
			var letter = letterObj.text();
			if(letter == "") letterObj.text('A');
			var newLetter;
			
			var az = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			var azIndex = az.search(letter);
			
			if(direction == "right") {
				letterObj.addClass('sortRight');
				setTimeout(function(){letterObj.removeClass('sortRight')}, 250);
				
				if (azIndex+1 < az.length) {
					newLetter = az.charAt(azIndex+1);
				} else {
					newLetter = 'Z';
				}
			} else {
				letterObj.addClass('sortLeft');
				setTimeout(function(){letterObj.removeClass('sortLeft')}, 250);
				
				if (azIndex-1 > 0) {
					newLetter = az.charAt(azIndex-1);
				} else {
					newLetter = 'A';
				}
			}
			letterObj.text(newLetter);
		}
	});
	glbSpace.selectableElementsControl = new SelectableElements('body');
});