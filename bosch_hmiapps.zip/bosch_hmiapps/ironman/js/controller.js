var glbSpace = this;

$(function() {
	var BinaryUtils = {
			binaryToBase64 : function(input) {
				var base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
				var ret = new Array();
				var i = 0;
				var j = 0;
				var char_array_3 = new Array(3);
				var char_array_4 = new Array(4);
				var in_len = input.length;
				var pos = 0;
				while (in_len--) {
					char_array_3[i++] = input[pos++];
					if (i == 3) {
						char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
						char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
						char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
						char_array_4[3] = char_array_3[2] & 0x3f;

						for ( i = 0; (i < 4); i++)
							ret += base64_chars.charAt(char_array_4[i]);
						i = 0;
					}
				}
				if (i) {
					for ( j = i; j < 3; j++)
						char_array_3[j] = 0;

					char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
					char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
					char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
					char_array_4[3] = char_array_3[2] & 0x3f;

					for ( j = 0; (j < i + 1); j++)
						ret += base64_chars.charAt(char_array_4[j]);

					while ((i++ < 3))
					ret += '=';

				}
				return ret;
			},
			getLongAtArray : function(arr, index) {
				return ((parseFloat(arr[0 + index], 10) & 0xff) * 0x100000000000000)
						+ ((parseFloat(arr[1 + index], 10) & 0xff) * 0x1000000000000)
						+ ((parseFloat(arr[2 + index], 10) & 0xff) * 0x10000000000)
						+ ((parseFloat(arr[3 + index], 10) & 0xff) * 0x100000000)
						+ ((parseFloat(arr[4 + index], 10) & 0xff) * 0x1000000)
						+ ((parseFloat(arr[5 + index], 10) & 0xff) * 0x10000)
						+ ((parseFloat(arr[6 + index], 10) & 0xff) * 0x100)
						+ (parseFloat(arr[7 + index], 10) & 0xFF);
			},
			getIntAtArray : function(arr, index) {
				return ((parseFloat(arr[0 + index], 10) & 0xff) * 0x1000000)
						+ ((parseFloat(arr[1 + index], 10) & 0xff) * 0x10000)
						+ ((parseFloat(arr[2 + index], 10) & 0xff) * 0x100)
						+ (parseFloat(arr[3 + index], 10) & 0xFF);
			},
			getShortAtArray : function(arr, index) {
				return ((parseFloat(arr[0 + index], 10) & 0xff) * 0x100)
						+ (parseFloat(arr[1 + index], 10) & 0xff);
			},
			getArrayAtLong : function(longVal) {
				var o = [];
				var temp = longVal;
				o[0] = this.getInt(parseFloat(temp / 0x100000000000000));
				temp = temp % 0x100000000000000;
				o[1] = this.getInt(parseFloat(temp / 0x1000000000000));
				temp = temp % 0x1000000000000;
				o[2] = this.getInt(parseFloat(temp / 0x10000000000));
				temp = temp % 0x10000000000;
				o[3] = this.getInt(parseFloat(temp / 0x100000000));
				temp = temp % 0x100000000;
				o[4] = this.getInt(parseFloat(temp / 0x1000000));
				temp = temp % 0x1000000;
				o[5] = this.getInt(parseFloat(temp / 0x10000));
				temp = temp % 0x10000;
				o[6] = this.getInt(parseFloat(temp / 0x100));
				temp = temp % 0x100;
				o[7] = this.getInt(parseFloat(temp));
				for ( var i = 0; i < o.length; i++) {
					if (o[i] >= 128)
						o[i] = o[i] - 256;
				}
				return o;
			},
			getArrayAtInt : function(intVal) {
				var o = [];
				var temp = intVal;
				o[0] = this.getInt(parseFloat(temp / 0x1000000));
				temp = temp % 0x1000000;
				o[1] = this.getInt(parseFloat(temp / 0x10000));
				temp = temp % 0x10000;
				o[2] = this.getInt(parseFloat(temp / 0x100));

				temp = temp % 0x100;
				o[3] = this.getInt(parseFloat(temp));

				for (var i = 0; i < o.length; i++) {
				    if (o[i] >= 128) {
				        o[i] = o[i] - 256;
				    } 
				}
				return o;
			},
			getArrayAtShort : function (shortVal) {
				var obj = [];
				var temp = shortVal;
				obj[0] = this.getInt(parseFloat(temp / 0x100));
				temp = temp % 0x100;
				obj[1] = this.getInt(parseFloat(temp));
				for (var i = 0; i < obj.length; i++) {
				    if (obj[i] >= 128) {
				        obj[i] = obj[i] - 256;
				    } 
				}
				return obj;
			},
			strToCharArray : function(str) {
				var arrObj = [];
				if (str) {
					for ( var i = 0; i < str.length; i++) {
						arrObj[i] = str.charCodeAt(i);
					}
				}
				return arrObj;
			},
			getInt : function (val) {
			    if (val == null || val < 1 || (val + "").indexOf('E') >= 0 || (val + "").indexOf('e') >= 0) {
			        val = 0;
			    } else {
			        val = parseInt(val, 10);
			    }
				return val;
			},
			getCRC16Value : function(bytes) {
				if (bytes) {
					var crc = 0xffff;
					var polynomial = 0x1021;
					var bit;
					var c15;
					for (var b in bytes) {
						for (var i = 0; i < 8; i++) {
							bit = ((bytes[b] >> (7 - i) & 1) == 1);
							c15 = ((crc >> 15 & 1) == 1);
							crc <<= 1;
							if (c15 ^ bit) {
								crc ^=polynomial;
							}
						}
					}
					crc &= 0xffff;
					var high = (crc & 0xff00) >>> 8;
					var low = crc & 0x00ff;
					return [high, low];
				} else {
					return null;
				}
			}
	};
	Pandora = function() {
		this._dataPool = [];
		this._payloads = [];
		this._socket   = null;
		this._timer    = null;
		var TrackArt = {
			_trackArtPool : [],
			_trackArtPoolCount : 0,
			_timer : null,
			process : function(payload) {
				if (TrackArt._timer) {
					clearTimeout(TrackArt._timer);
				} 
				TrackArt._timer = setTimeout(function(){
					TrackArt._trackArtPool = [];
					TrackArt._trackArtPoolCount = 0;
				},5000);
				
				if (payload.length > 7) {
					if (payload[0] == 0x95) {
						var trackToken = BinaryUtils.getIntAtArray(payload, 1);
						var segmentIndex = payload[5];
						var totalSegments = payload[6];
						var body = payload.slice(7);
						TrackArt._trackArtPool[segmentIndex] = body;
						TrackArt._trackArtPoolCount++;
						if (TrackArt._trackArtPoolCount == totalSegments){
							var images = [];
							var i = 0;
							while(i < totalSegments) {
								images = images.concat(TrackArt._trackArtPool[i++]);
							}
							var encodedImages = BinaryUtils.binaryToBase64(images);
							$("#pandoraPics").attr("src","data:image/png;base64," + encodedImages);
							TrackArt._trackArtPool = [];
							TrackArt._trackArtPoolCount = 0;
						}
					}
				}
			}
		};
		this._handlers = {
			0x95 : TrackArt.process
		};
	};
	Pandora.prototype = {
		formatRequest : function(payload) {
			var crcdata = [];	
			crcdata.push(0x00);
			crcdata.push(0x00);
			crcdata = crcdata.concat(BinaryUtils.getArrayAtInt(payload.length));
			crcdata = crcdata.concat(payload);
			var crcArray = BinaryUtils.getCRC16Value(crcdata);
			var command = [];
			command.push(0x7E);
			command = command.concat(crcdata);
			command = command.concat(crcArray);
			command.push(0x7C);
			return command;
		},
		_processPayloads : function() {
			while(this._payloads.length > 0) {
				var payload = this._payloads.shift();
				if (payload && payload.length > 0) {
					var handler = this._handlers[payload[0]];
					if (handler && typeof handler === 'function') {
						handler(payload);
					}
				}
			}
		},
		_processDataPoll : function() {
			var haveMessage = this._dataPool.length >= 10;
			while (haveMessage) {
				if (this._timer) {
					clearTimeout(this._timer);
				} 
				//7E(Start) 00(Type) 00(Sequence Number) 00 00 00 05(Payload Length) BA 00 03 28 CE(Payload) 11 03(CRC Code) 7C(End)
				if (this._dataPool[0] == 0x7E 
						&& this._dataPool[1] == 0x00
						&& this._dataPool[2] == 0x00) {
					var length = BinaryUtils.getIntAtArray(this._dataPool, 3);
					if (this._dataPool.length >= 10 + length) {
						var message = this._dataPool.splice(0, 10 + length);
						var payload = message.slice(7, 7 + length);
						var crcData = message.slice(1, 7 + length);
						var crcCode = message.slice(message.length - 3, message.length - 2);
						this._payloads.push(payload);
					} else {
						haveMessage = false;
						var that = this;
						this._timer = setTimeout(function(){
							that._dataPool = [];
						},5000);
					}
				} else {
					//The data pool is error. Reset the data
					this._dataPool = [];
					haveMessage = false;
				}
			}
			this._processPayloads();
		},
		_handleData : function(data) {
			var tmp = [];
			for (var i = 0; i < data.length; i++) {
				if (data[i]== 0x7D) {
					if (data[i+1] == 0x5C) {
						tmp.push(0x7C);
						i++;
					} else if (data[i+1] == 0x5D) {
						tmp.push(0x7D);
						i++;
					} else if (data[i+1] == 0x5E) {
						tmp.push(0x7E);
						i++;
					} else {
						tmp.push(data[i]);
					}
				} else {
					tmp.push(data[i]);
				}
			}
			this._dataPool = this._dataPool.concat(tmp);
			this._processDataPoll();
		},
		_plog : function(data) {
			var str = $("#pandoraRes").val();
			if (str != "") {
				str += "\n";
			}
			$(data).each(function(index, item){
				var hexString = parseInt(item).toString(16);
				while (hexString.length < 2) {
					hexString = "0" + hexString;
				}
				str += hexString + " ";
			})
			$("#pandoraRes").val(str.toUpperCase());
		},
		_connect : function() {
			var that = this;
			if (!that._socket) {
				that._socket = io.connect("/CommandControl").send("Pandora");
				that._socket.on('AsyncEvent', function(data) {
					that._plog(data);
					that._handleData(data);
				});
			}
		},
		send : function(cmd) {
			this._connect();
			var data = this.formatRequest(cmd);
			this._socket.emit("Command", data);
		},
		sessionStart : function (apiVersion, cId, albumArtDimension, stationArtDimensionn) {
			if (!apiVersion) apiVersion = 3;
			if (!cId) cId= "APITOOL0";
			if (!albumArtDimension) albumArtDimension = 200;
			if (!stationArtDimensionn) stationArtDimensionn = 44;
			
			var payload = [];
			payload.push(0x00); //command
			payload = payload.concat(BinaryUtils.getArrayAtShort(apiVersion)); //api_version
			var payloadTextInfo = BinaryUtils.strToCharArray(cId);
			payload = payload.concat(payloadTextInfo); //accessory_id
			payload = payload.concat(BinaryUtils.getArrayAtShort(albumArtDimension)); //album_art_dimension
			payload.push(0x02); //image_type
			payload.push(0x00); //flags
			payload = payload.concat(BinaryUtils.getArrayAtShort(stationArtDimensionn)); //text
			this.send(payload);
		},
		sessionTerminate : function(){
			var payload = [];
			payload.push(0x05); 
			this.send(payload);
		},
		getTrackAlbumArt : function(){
			var payload = [];
			payload.push(0x14); 
			payload = payload.concat(BinaryUtils.getArrayAtInt(4000));
			this.send(payload);
		},
		eventTrackPlay : function(){
			var payload = [];
			payload.push(0x30); 
			this.send(payload);
		},
		eventTrackPause : function(){
			var payload = [];
			payload.push(0x31); 
			this.send(payload);
		},
		eventTrackSkip : function(){
			var payload = [];
			payload.push(0x32); 
			this.send(payload);
		}
	};

	var Socket = {
			_socket: null,
			_connect: function(){
				if (!this._socket) this._socket = io.connect();
			},
			on : function(event, cb) {
				this._connect();
				this._socket.on(event, cb);
			},
			emit : function(event, data) {
				this._connect();
				this._socket.emit(event, data);
			}
		};

		var PolicySocket = {
			_socket: null,
			_connect: function(){
				if (!this._socket) this._socket = io.connect("/policy");
			},
			on : function(event, cb) {
				this._connect();
				this._socket.on(event, cb);
			},
			emit : function(event, data) {
				this._connect();
				this._socket.emit(event, data);
			}
		};
	
		var NavItem = can.Observe({}, {});
	/**
	 * Page content controller
	 */
	var pagecontent_control = can.Control({},{
		init : function(el) {
			this.showHome();
		},
		/**
		 * Loads the homepage of the app based on the current page
		 */
		showHome : function() {		
			var that = this;
			glbSpace.iHardware = 0;
			glbSpace.iNavInterrupts = 0;
			that.pandora = new Pandora();
			glbSpace.winWidth = screen.width;
			if(winWidth < 490) $('#logCreate a').text("Create");

			//Insert Navigation Main
			$('#pagecontent').html(can.view("ironman/views/contain.ejs", {}));
			$('nav').prepend(can.view( 'ironman/views/navMain.ejs', {}));
			that.navItem = new NavItem( {id: null } );
			$("#nav_home").hide();
			$('#navBody').html(can.view( 'ironman/views/itemPop.ejs',{navItem:that.navItem}));

			//Listen to Bluetooth Status
			Socket.on('BluetoothData', function(data) {
				if (typeof data === 'string') {
					data = JSON.parse(data);
				}
				that._btStatus = data.btStatus;
				switch(data.btStatus) {
				case 1: 
					$('#bluetoothBtn').removeClass('btn-warning btn-danger btn-success').addClass('btn-info');
					break;
				case 2: 
					$('#bluetoothBtn').removeClass('btn-warning btn-info btn-success').addClass('btn-danger');
					break;
				case 3: 
					$('#bluetoothBtn').removeClass('btn-warning btn-info btn-danger').addClass('btn-success');
					break;
				case 0: 
				default:
					$('#bluetoothBtn').removeClass('btn-info btn-danger btn-success').addClass('btn-warning');
					break;
				}
			});
			Socket.on('HuResponseDada', function(data) {
				console.log("socket.on(HuResponseDada) - data: " + data);
			});
			Socket.on('LocationDada', function(data) {
				console.warn('socket return LocationDada');
				that.parseHmiSocketResponse('hmiGetLocation', data);
			});
			Socket.on('StorageDada', function(data) {
				console.warn('socket return StorageDada');
				that.parseHmiSocketResponse('hmiAppStorage', data);
			});
			Socket.on('DateTimeData', function(data) {
				console.warn('socket return DateTimeData');
				that.parseHmiSocketResponse('hmiGetTime', data);
			});
			Socket.on('VehicleData', function(data) {
				console.warn('socket return VehicleData');
				that.parseHmiSocketResponse('hmiGetVehicleData', data);
			});
			Socket.on('HUPInfoData', function(data) {
				console.warn('socket return VehicleData');
				that.parseHmiSocketResponse('hmiGetHUPInfo', data);
			});
			Socket.on("aqEncoderEvent", function(data){
				that.parseHmiSocketResponse('hmiHardwareEvents', data);
			});
			Socket.on("aqHardKeyEvent", function(data){
				that.parseHmiSocketResponse('hmiHardwareEvents', data);
			});
			Socket.on("aqSwcKeyEvent", function(data){
				that.parseHmiSocketResponse('hmiHardwareEvents', data);
			});
			
			//Scott: 10/5: Added this code not realizing it already existed in this file.
			//keeping for now in case we decide to keep this code instead of currently implemented version
			/*Socket.on("aqNavInfoStatus", function(data){
				that.parseHupPlatformSocketResponse('aqNavInfoStatus', data);
			});
			Socket.on("aqBtprofileOnOffStatus", function(data){
				that.parseHupPlatformSocketResponse('aqBtprofileOnOffStatus', data);
			});*/
			
			Socket.on("aqNavSetDestinationStatus", function(data){
				that.parseHupPlatformSocketResponse('aqNavSetDestinationStatus', data);
			});
			Socket.on("aqSetPhoneCallPermission", function(data){
				that.parseHupPlatformSocketResponse('aqSetPhoneCallPermission', data);
			});
			Socket.on("aqSetPhoneSmsPermission", function(data){
				that.parseHupPlatformSocketResponse('aqSetPhoneSmsPermission', data);
			});
			Socket.on("aqSetHmiLayerView", function(data){
				if(data.bAppbuttonPressed == "1" ) {
					window.location = "../main.html";
				} 				
			});
			Socket.on("aqSendSmsStatus", function(data){
				$('#navData').append(JSON.stringify(data) + "<br>");
			});
			Socket.on("aqDialPhoneNumberStatus", function(data){
				$('#navData').append(JSON.stringify(data) + "<br>");
			});
			Socket.on("aqTtsPlaybackStatus",function(data){
				$('#navData').append(JSON.stringify(data) + "<br>");
			});
			
			Socket.on('HandsetProfileData', function(data) {
				console.warn('socket return HandsetProfileData');
				that.parseHupHapSocketResponse('hupHapGetHandsetProfile', data);
			});
			Socket.on('ChoreoProfileData', function(data) {
				$('#navData').append(JSON.stringify(data) + "<br><br>");
			});
			/* TODO: Need to add socket.on message for hmiNavInterrupts when bosch is done with their portion */
			PolicySocket.on("POLICY", function(data){
				that.parseHmiSocketResponse('hmiEnableKeyboard', data);
			});
			//get Bluetooth status
			var btCmd = {command: 'getBtStatus'};
			Socket.emit('BluetoothEvent', btCmd);
			
			this.logPosition = "middle";
			this._updateLogPosition();
			$("#logOutput,nav").css("overflow-y","scroll");
			
			
			$('#logData').html(can.view('ironman/logs/logs.ejs'));
			Socket.on('LoggerData', function(data) {
				$('#logData').html(data);
			});
		},
		
		"#navSubItems li click" : function(el) {
			$('#navSubItems').replaceWith(can.view( 'ironman/views/' + el.children('a').attr("id") + '.ejs', {}));
			$('#navTop').append("<h3> - " + el.children('a').text() + "</h3>");
			return false;
		},
		//API LI Click - Brings up the api overlay
		"nav ul.subNav li click" : function(el) {
			this.ele=el;
			this.navItem.attr('id',$(el).children('a').attr('id'));
			$(el).parents().eq(1).find('a.active').removeClass('active');
  			$(el).addClass('active');
			$('#navContent').show();
			// If we are loading huDialPhoneNumber or huSendSms, check the appStorage in HUP first for phone call permission.
			if (el.text() == "huDialPhoneNumber") {
				glbSpace.checkingPhoneCallPermission = true;
				var cmd = {
					key : "aqSetPhoneCallPermission",
					command : "retrieve"
				};
				Socket.emit("StorageEvent", cmd);
			} else if (el.text() == "huSendSms") {
				glbSpace.checkingSmsPermission = true;
				var cmd = {
					key : "aqSetPhoneSmsPermission",
					command : "retrieve"
				};
				Socket.emit("StorageEvent", cmd);
			}
			return false;
		},
		"#navTop h1 click" : function(el) {
			$('nav ul').replaceWith(can.view( 'ironman/views/navMain.ejs', {}));
			el.parent().children('h3').remove();
		},
		"#navExit click" : function() {
			var that = this;
			$("#apiClear").click();
			$("#navData").empty();
			$('#navContent').hide(function() {
				$(that.ele).removeClass('active');
				//that.navItem.removeAttr('el');
			});
			that.navItem.attr('id', 'blank');
		},
		"#bluetooth ul.dropdown-menu a click" : function(el){
			//get Bluetooth status
			alert((parseInt($(el).attr("val")) != 0) != (this._btStatus != 0));
			if ((parseInt($(el).attr("val")) != 0) != (this._btStatus != 0)) {
				var btCmd = {command: 'toggleBtStatus'};
				Socket.emit('BluetoothEvent', btCmd);
			}
		},
		// OUTBOUND APIs HERE - some need different processing before sending
		".sendCommand click" : function(el) {
			var that = this;
			var apiName = el.parents('#navContent').find('#apiName').text();
			//check the input and text area
			var isvalid = true;
			$(".command-form").find('input, textarea, select').each(function(){
				isvalid = isvalid && this.checkValidity();
			});

			if (!isvalid) {
				$('#navData').append("Some input value is not valid, please check.<br>");
				return false;
			}
			
			/* HMI and HUP */
			if( apiName.indexOf("hmi") == 0) {
				switch (apiName) {
				case "hmiGetTime":
					Socket.emit("DateTimeEvent", '{"command": "getDateTime"}');
					break;
				case "hmiGetLocation":
					Socket.emit("LocationEvent", '{"locationType":0}');
					break;
				case "hmiAppStorage":
					var paras = can.deparam($(".command-form").serialize());
					var cmd = {
						key : paras.key,
						value : paras.value
					};
					if (cmd.value) {
						cmd.command="store";
					} else {
						cmd.command="retrieve";
					}
					Socket.emit("StorageEvent", cmd);
					break;
				case "hmiNavInterrupts":
					/* TODO: Add TurnByTurn api when bosch is done with their portion.  */
					break;
				case "hmiHardwareEvents":
					/* Sheldon says this is not needed */
					//DO not need do anything
					break;
				case "hmiEnableKeyboard":
					var appName = $("input[name='appName']").val();
					PolicySocket.emit("ApplicationName", appName);
					break;
				case "hmiGetVehicleData":
					Socket.emit("VehicleDataEvent", '{"command": "getVehicleData"}');
					break;
				case "hmiGetHUPInfo":
					Socket.emit("HUPInfoEvent", '{"command": "getHUPInfo"}');
					break;
				default:
					break;
				}
			/* HUP and HAP */ 
			} else if( apiName.indexOf("hupHap") == 0) {
				console.info("HupHap API: " + apiName);
				if(apiName == "hupHapGetHandsetProfile") {
					Socket.emit("HandsetProfileEvent", '{"command": "getHandsetProfile"}');
				}
				
			/* HUP and Choreo */ 
			} else if( apiName.indexOf("hupChoreo") == 0) {
				console.info("Choreo API: " + apiName);
				this.parseHupChoreoResponse(apiName);
				
			/* HUP and 3rd Application */ 
			} else if( apiName.indexOf("hupPhone") == 0) {

			/* HUP and Platform */
			} else if( apiName.indexOf("hu") == 0) {
				if (apiName == "huDialPhoneNumber") {
					if($('#aqSetPhoneCallPermission').val() == 0) {
						$('#navData').append("aqSetPhoneCallPermission is set to false, therefore you cannot use huDialPhoneNumber.<br>");
						//$('#navContent input').val("");
						isvalid = false;
					}
				} else if (apiName == "huSendSms") {
					if($('#aqSetPhoneSmsPermission').val() == 0) {
						$('#navData').append("aqSendSmsStatus is set to false, therefore you cannot use huSendSms.<br>");
						//$('#navContent input').val("");
						isvalid = false;
					}
				}				
				if (isvalid) {
					$('textarea').each(function(){
						$(this).val($(this).val().replace(/[\s\n\t\r]+/g,""));
					});
					var paras = can.deparam($(".command-form").serialize());
					Socket.emit("HuApiEvent", paras);
					console.warn("# # # # # # # # # # HuApiEvent paras");
					console.warn(paras);
					//$("#navExit").click();
				}
			}
			setTimeout(this.scrollPre, 250);
		},
		
		"#apiClear click" : function() {
			$('#navData').text('');
		},
		"#placesSearchGo click" : function() {
			var isvalid = true;
			$(".command-form").find('input').each(function(){
				isvalid = isvalid && this.checkValidity();
			});

			if (!isvalid) {
				$(".command-form input[name='submit']").click();
			} else {
				this.parseHupChoreoResponse("hupChoreoGooglePlacesSearch");
			}
		},
		"#placesSearchGo1 click" : function() {
			var isvalid = true;
			$(".command-form").find('input').each(function(){
				isvalid = isvalid && this.checkValidity();
			});

			if (!isvalid) {
				$(".command-form input[name='submit']").click();
			} else {
				this.parseHupChoreoResponse("hupChoreoGooglePlacesSearch1");
			}
		},
		".pandoraConnect click" : function() {
			this.pandora.sessionStart();
			$("#pandoraReq").val("7E 00 00 00 00 00 11 00 00 03 41 50 49 54 4F 4F 4C 30 00 C8 01 00 00 64 88 FA 7C");
		},
		".pandoraPlay click" : function() {
			this.pandora.eventTrackPlay();
			$("#pandoraReq").val("7E 00 00 00 00 00 01 30 F4 AC 7C");
		},
		".pandoraPause click" : function() {
			this.pandora.eventTrackPause();
			$("#pandoraReq").val("7E 00 00 00 00 00 01 31 E4 8D 7C");
		},
		".pandoraSkip click" : function() {
			this.pandora.eventTrackSkip();
			$("#pandoraReq").val("7E 00 00 00 00 00 01 32 D4 EE 7C");
		},
		".pandoraGetTrackAlbumArt click" : function() {
			this.pandora.getTrackAlbumArt();
			$("#pandoraReq").val("7E 00 00 00 00 00 05 14 00 00 0F A0 D4 EE 7C");
		},
		".pandoraDisconnect click" : function() {
			this.pandora.sessionTerminate();
			$("#pandoraReq").val("7E 00 00 00 00 00 01 05 D4 EE 7C");
		},
		/*"#hupChoreoGooglePlacesSearch click" : function() {
			$('#navSend').children('a').attr('disabled', true);
			$('#navSend').children('a').unbind('click');
		},*/
		
		
		scrollPre: function() {
				$('#logOutput').scrollTop($('#logData').height());
		},
		
		parseHupChoreoResponse: function(apiName) {
			console.warn("inside ChoreoAPIs");
			if(apiName == "hupChoreoGetProfile") {
				Socket.emit("ChoreoProfileEvent", '{"command": "getChoreoProfile"}');
			} else if(apiName == "hupChoreoGooglePlacesSearch") {
				var searchTerm = $('#placesSearchText').val();
				searchTerm = escape(searchTerm);
				//var url = '%CHOREO_SERVER_URL_BASE%/api/1.0/places/mipId/%MIPID%?latitude=47.6097&longitude=-122.3331&radius=500&sensor=true&language=en&keyword=' + searchTerm;
				var url = 'http://nissanmip-mipgw-r3.viaaq.net:80/aqMIP/api/1.0/places/mipId/ad914582-377b-11e2-ae46-e5e1e2f6ccad?latitude=47.6097&longitude=-122.3331&radius=500&sensor=true&language=en&keyword=' + searchTerm;
				console.log(url);
				$.ajax({
					url: "http://10.20.71.93:8081/a.json",
					type: 'GET',
					crossDomain: true,
					dataType:"json",
					success: function(data) {
						$('#navData').append(JSON.stringify(data) + "<br><br>");
					},
					error: function(data) {
						//Do something
					}
				});
//				$.ajax({
//					url: '/gateway',
//					type: 'POST',
//					data: JSON.stringify({
//						"requestUri": url,
//						"requestMethod": "GET"
//					}),
//					success: function(data) {
//						$('#navData').append(JSON.stringify(data) + "<br><br>");
//					},
//					error: function(data) {
//						//Do something
//					}
//				});
			} else if(apiName == "hupChoreoGooglePlacesSearch1") {
				$.ajax({
					url: "http://10.20.71.93:8081/b.json",
					type: 'GET',
					crossDomain: true,
					dataType:"json",
					success: function(data) {
						$('#navData').append(JSON.stringify(data) + "<br><br>");
					},
					error: function(data) {
						//Do something
					}
				});
			}
		},
		
		parseHmiSocketResponse: function(apiName,data) {
			var selector = "#navData" ;
			var content = "";
			if (typeof data === "object") {
				data = JSON.stringify(data);
			}
			if (apiName == "hmiGetVehicleData") {
				content = "<span class='apiResult'>Vehicle Data: " + data + "</span><br/>";
			} else if (apiName == "hmiGetHUPInfo") {
				content = "<span class='apiResult'>HUP Info: " + data + "</span><br/>";
			} else if(apiName == "hmiGetTime") {
				content = "<span class='apiResult'>Time: " + data + "</span><br/>";
			} else if(apiName == "hmiGetLocation") {
				content = "<span class='apiResult'>aqNavInfoStatus: " + data + "</span><br/>";
			} else if(apiName == "hmiAppStorage") {
				//If this storage message is a retrieval for phone call or SMS permission, set the proper value.
				//Otherwise set the text for the hmiAppStorage api
				var dataAsJSON = JSON.parse(data);
				if(dataAsJSON.key == "aqSetPhoneCallPermission" && checkingPhoneCallPermission == true) {
					$('#aqSetPhoneCallPermission').val(dataAsJSON.value);
					checkingPhoneCallPermission = false;
				} else if(dataAsJSON.key == "aqSetPhoneSmsPermission" && checkingSmsPermission == true) {
					$('#aqSetPhoneSmsPermission').val(dataAsJSON.value);
					checkingSmsPermission = false;
				} else {
					content = "<span class='apiResult'>Info: " + data + "</span><br/>";
				}

			} else if(apiName == "hmiNavInterrupts") {
				/* Add data response when Bosch completes the TurnByTurn api */		
				iNavInterrupts++;
				content = "<span class='apiResult'>Nav Interrupts: " + iNavInterrupts + "</span><br/>";
				
			} else if(apiName == "hmiHardwareEvents") {
				iHardware++;
				content = "<span class='apiResult'>Hard Events: " + data + "</span><br/>";

			} else if(apiName == "hmiEnableKeyboard") {
				$(JSON.parse(data)).each(function(index, item){
					if (item.name == "keyboard") {
						if (item.status) {
							$('.apiKeyboard').slideDown(250, function() {
								$('.apiKeyboard').show();
							});
						} else {
							$('.apiKeyboard').slideUp(250, function() {
								$('.apiKeyboard').hide();
							});
						}
					}
		    	});
			}
			$(selector).append(content);
		},
		parseHupPlatformSocketResponse: function(apiName,data) {
			var selector = "#navData" ;
			var content = "";
			
			if(apiName == "aqSetPhoneCallPermission") {
				$('#aqSetPhoneCallPermission').val(data.bCallPermission);
			} else if(apiName == "aqSetPhoneSmsPermission") {
				$('#aqSetPhoneSmsPermission').val(data.bSMSPermission);
			} else if(apiName == "aqNavSetDestinationStatus") {
				content = "<span class='apiResult'>Nav Destination Status: " + JSON.stringify(data) + "</span><br/>";
				$(selector).append(content);
			} else if(apiName == "aqTtsPlaybackStatus"){
				content = "<span class='apiResult'>Nav Tts Status: " + JSON.stringify(data) + "</span><br/>";
				$(selector).append(content);
			}

			//Scott: 10/5: Added this code not realizing it already existed in this file.
			//keeping for now in case we decide to keep this code instead of currently implemented version
			/*else if(apiName == "aqNavInfoStatus") {
				content = "<span class='apiResult'>Nav Info Status: " + data + "</span><br/>";
				$(selector).append(content);
			}
			
			 else if(apiName == "aqBtprofileOnOffStatus"){
				console.warn("aqBtprofileOnOffStatus");
				console.warn(data);
				var dataAsJson = JSON.parse(data);
				if(dataAsJson.btConnectionState == 0) {
					$('#bluetooth .btn').removeClass('btn-success').addClass('btn-warning');
				} else if(dataAsJson.btConnectionState == 1) {
					$('#bluetooth .btn').removeClass('btn-warning').addClass('btn-success');
				}
			}*/

		},
		parseHupHapSocketResponse: function(apiName,data) {
			if(apiName == "hupHapGetHandsetProfile") {
				$('#navData').append(JSON.stringify(data) + "<br><br>");
			}
		},
		
		sendMessage: function(msg) {
			Socket.emit("LoggerEvent", JSON.stringify(msg));
		},
		"#logWatch click" : function() {
			this.sendMessage({command: "watchlogger"});
		},
		"#logCreate click" : function() {
			this.sendMessage({command: "createlogger"});
		},
		"#logUnwatch click" : function() {
			this.sendMessage({command: "unwatchlogger"});
		},
		_updateLogPosition : function() {
			var _logOutputHeight = 208;
			var _preHeightLess = 17;
			var _allHeight = 385;
			var navHeight = 0;
			var logOutputHeight = 0;
			var preHeight = 0;
			
			if(winWidth < 490) {
				_logOutputHeight = 95;
				_preHeightLess = 10;
				_allHeight = 192;
			}
			
			switch (this.logPosition) {
			case "top":
				navHeight = 0;
				logOutputHeight = _allHeight;
				preHeight = _allHeight - _preHeightLess;
				break;
			case "middle":
				navHeight = _allHeight - _logOutputHeight;
				logOutputHeight = _logOutputHeight;
				preHeight = _logOutputHeight - _preHeightLess;
				break;
			case "bottom":
				navHeight = _allHeight;
				logOutputHeight = 0;
				preHeight = 0;
				break;
			}
			$('nav').css({
				height: navHeight
			});
			$('#logContainer').animate({
				top: navHeight + $("#navTop").height()
			}, 300);
			$('#logOutput').css({
				height: logOutputHeight
			});
			$('#logOutput pre').css({
				"min-height": preHeight
			});
		},
		"#logMin click" : function() {
			if(this.logPosition != "bottom"){
				if(this.logPosition == "middle") {
					this.logPosition = "bottom";
				} else if(this.logPosition == "top") {
					this.logPosition = "middle";
				}
				this._updateLogPosition();
			}
		},
		"#logMax click" : function() {
			if(this.logPosition != "top"){
				if(this.logPosition == "middle") {
					this.logPosition = "top";
				} else if(this.logPosition == "bottom") {
					this.logPosition = "middle";
				}
				this._updateLogPosition();
			}
		},		
	});
	root.pagecontent = new pagecontent_control("#pagecontent");
});
