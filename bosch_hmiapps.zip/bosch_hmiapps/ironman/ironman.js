var ironman = can.Construct({}, {
	
	/**
     * Initialize the iranmon app
     */
    init: function()
    {
        $('aqapp').html( 'ironman/views/init.ejs', {} );
    }
});

APP.ironman = new ironman();

AQ.loadStylesheet("ironman/ironman.css");
AQ.loadStylesheet("ironman/bootstrap/css/bootstrap.css");
AQ.loadScript(["ironman/js/jquery-1.7.2.min.js","ironman/js/can.jquery-1.0.7.js"], function() {
	AQ.loadScript(["ironman/bootstrap/js/bootstrap.min.js",
	               "/socket.io/socket.io.js",
	               "ironman/js/controller.js"], function() {
		AQ.loadScript(["ironman/js/selectableElement.js",
		               "ironman/js/notificationHandlers.js"]);
	});
});
