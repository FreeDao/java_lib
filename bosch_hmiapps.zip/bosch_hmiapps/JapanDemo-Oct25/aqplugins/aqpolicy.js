
var that = this;
 
$(window).load(function(){

	var AQPolicy = can.Construct({
		init: function(){
				$('body').append(can.view('../aqplugins/views/policy-overlay.ejs', {
					"text" : ""
				}));
		},
		displayOverlay : function(action, text) {
			if(action == "show") {
				$('#policy-overlay-container').replaceWith(can.view('../aqplugins/views/policy-overlay.ejs', {
					"text" : text
				}));
				$('#policy-overlay-container').slideDown(500, function() { });

			} else if (action == "hide"){
				$('#policy-overlay-container').slideUp(500, function() { });
			}
		},
		"#confirm-yes click" : function() {
			$('#policy-overlay-container').slideUp(500, function() {
			});
		},

		"#confirm-no click" : function() {
			$('#policy-overlay-container').slideUp(500, function() {
			});
		},
	});
	that.aqpolicy = new AQPolicy();


});


