
var that = this;
 
$(window).load(function(){

	var AQNavigation = can.Construct({
		init: function(){
			$('body').append(can.view('../aqplugins/views/navigation.ejs', { }));
		},
		displayNavigation : function(action) {
			if(action == "show") {
				$('#navigation-container').replaceWith(can.view('../aqplugins/views/navigation.ejs', { }));
				$('#navigation-container').slideDown(500, function() { });

			} else if (action == "hide"){
				$('#navigation-container').slideUp(500, function() { });
			}
		},
	});
	that.aqnavigation = new AQNavigation();


});


