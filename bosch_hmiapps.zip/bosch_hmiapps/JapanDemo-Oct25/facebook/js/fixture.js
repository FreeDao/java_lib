var LIVEFEED = {
		"data" : [{
			"id" : "100003565868302_135148013280727",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "New day has come, Thuy Anh",
			"comments" : {
				"count" : 1,
				"data" : [{
					"id" : "100003565868302_135148013280727_145092",
					"from" : {
						"id" : "100003565868302",
						"name" : "John"
					},
					"message" : "yes, you are right!",
					"created_time" : "2012-03-21T00:26:01+0000"
				}]
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/135148013280727"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/135148013280727"
			}],
			"created_time" : "2012-03-21T00:24:20+0000"
		}, {
			"id" : "100003565868302_134484826680379",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "This is a really long status post. Some random text, and here\u0027s some more.",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/134484826680379"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/134484826680379"
			}],
			"created_time" : "2012-03-19T23:25:39+0000"
		}, {
			"id" : "100003565868302_134455673349961",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "LOL BRB",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/134455673349961"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/134455673349961"
			}],
			"created_time" : "2012-03-19T22:34:11+0000"
		}, {
			"id" : "100003565868302_134454130016782",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Check this out!",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/134454130016782"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/134454130016782"
			}],
			"created_time" : "2012-03-19T22:31:17+0000"
		}, {
			"id" : "100003565868302_134378303357698",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Hey it\u0027s working",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/134378303357698"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/134378303357698"
			}],
			"created_time" : "2012-03-19T20:16:33+0000"
		}, {
			"id" : "100003565868302_134375963357932",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Just got here. The weather is great!",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/134375963357932"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/134375963357932"
			}],
			"created_time" : "2012-03-19T20:12:49+0000"
		}, {
			"id" : "100003565868302_132557943539734",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Cool!",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/132557943539734"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/132557943539734"
			}],
			"created_time" : "2012-03-16T23:49:07+0000"
		}, {
			"id" : "100003565868302_132557286873133",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Hi all!",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/132557286873133"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/132557286873133"
			}],
			"created_time" : "2012-03-16T23:47:39+0000"
		}, {
			"id" : "100003565868302_132553710206824",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "This is gonna be a great weekend. Seattle, rain, clouds, what else you want for the great weekend? Any ideas or plans? Let me know if somebody comes up with something interesting!",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/132553710206824"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/132553710206824"
			}],
			"created_time" : "2012-03-16T23:39:43+0000"
		}, {
			"id" : "100003565868302_132547013540827",
			"type" : "status",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "http://www.google.com",
			"comments" : {
				"count" : 0
			},
			"actions" : [{
				"name" : "Comment",
				"link" : "http://www.facebook.com/100003565868302/posts/132547013540827"
			}, {
				"name" : "Like",
				"link" : "http://www.facebook.com/100003565868302/posts/132547013540827"
			}],
			"created_time" : "2012-03-16T23:23:55+0000"
		}],
		"paging" : {
			"previous" : "https://graph.facebook.com/me/feed?access_token\u003dAAACZBsR8HZByMBAK2TJZClaK1dGl3cpdaFPn4KGZBos54iOShdvZCrnOBYojQZChtIoYwZC5pd0xHNZAi7ZC8y1NXJPAvdSRXcM3Et9SqNmaAnwZDZD\u0026limit\u003d25\u0026since\u003d1332289460\u0026__previous\u003d1",
			"next" : "https://graph.facebook.com/me/feed?access_token\u003dAAACZBsR8HZByMBAK2TJZClaK1dGl3cpdaFPn4KGZBos54iOShdvZCrnOBYojQZChtIoYwZC5pd0xHNZAi7ZC8y1NXJPAvdSRXcM3Et9SqNmaAnwZDZD\u0026limit\u003d25\u0026until\u003d1329887653"
		}
	};

	var CHECKINPLACES = {
		"data" : [{
			"name" : "The Animal Rescue Site Store",
			"category" : "Retail and consumer merchandise",
			"location" : {
				"street" : "600 University St Suite 1000",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98101",
				"latitude" : 47.60916,
				"longitude" : -122.33265
			}
		}, {
			"name" : "Pike Place Market",
			"category" : "Local business",
			"location" : {
				"street" : "1st \u0026 Pike Street",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98101",
				"latitude" : 47.609384269192,
				"longitude" : -122.34116876458
			},
			"id" : "86493431461"
		}, {
			"name" : "Seattle Ferry Terminal",
			"category" : "Local business",
			"location" : {
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "35772",
				"latitude" : 47.602848032316,
				"longitude" : -122.33896652781
			},
			"id" : "114792641936871"
		}, {
			"name" : "Allrecipes.com",
			"category" : "Website",
			"location" : {
				"street" : "413 Pine St, Suite 500",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98101",
				"latitude" : 47.611458477289,
				"longitude" : -122.33641937332
			},
			"id" : "71158748377"
		}, {
			"name" : "Downtown Seattle",
			"category" : "Local business",
			"location" : {
				"street" : "400 Pine Street (Westlake Center)",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98101",
				"latitude" : 47.611080469122,
				"longitude" : -122.33623805674
			},
			"id" : "152852791404880"
		}, {
			"name" : "Seattle Aquarium",
			"category" : "Attractions/things to do",
			"location" : {
				"street" : "1483 Alaskan Way, Pier 59",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98101-2051",
				"latitude" : 47.607671831633,
				"longitude" : -122.34253926268
			},
			"id" : "141795792557"
		}, {
			"name" : "Dr. Martens",
			"category" : "Company",
			"location" : {
				"street" : "Cobbs Lane",
				"city" : "Wollaston",
				"country" : "United Kingdom",
				"zip" : "NN297SW",
				"latitude" : 47.60932,
				"longitude" : -122.33903
			},
			"id" : "110998592305221"
		}, {
			"name" : "Jones Soda",
			"category" : "Food/beverages",
			"location" : {
				"street" : "1000 1st Ave South, Suite 100",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98134",
				"latitude" : 47.620874236445,
				"longitude" : -122.33985193342
			},
			"id" : "19018463345"
		}, {
			"name" : "Space Needle",
			"category" : "Landmark",
			"location" : {
				"street" : "400 Broad Street",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98109",
				"latitude" : 47.620515719062,
				"longitude" : -122.34919862626
			},
			"id" : "88603851976"
		}, {
			"name" : "SEOmoz",
			"category" : "Software",
			"location" : {
				"street" : "119 Pine Street, Suite 400",
				"city" : "Seattle",
				"state" : "WA",
				"country" : "United States",
				"zip" : "98101",
				"latitude" : 47.610167569017,
				"longitude" : -122.33982876194
			},
			"id" : "8489236245"
		}],
		"paging" : {
			"next" : "https://graph.facebook.com/search?limit\u003d10\u0026access_token\u003dAAACZBsR8HZByMBAK2TJZClaK1dGl3cpdaFPn4KGZBos54iOShdvZCrnOBYojQZChtIoYwZC5pd0xHNZAi7ZC8y1NXJPAvdSRXcM3Et9SqNmaAnwZDZD\u0026format\u003djson\u0026type\u003dplace\u0026center\u003d47.6046,-122.3362\u0026offset\u003d10\u0026__after_id\u003d8489236245"
		}
	};

	var CHECKINSEARCH = {
		"checkins" : [{
			"checkin_id" : "113914065400822",
			"author_uid" : "100003466874382",
			"authorName" : "Matty Damon",
			"page_id" : "121814297829270",
			"placeName" : "Seattle\u0027s Best Coffee",
			"timestamp" : "1329421550",
			"coords" : {
				"longitude" : "-122.33667809732",
				"latitude" : "47.60989234441"
			}
		}, {
			"checkin_id" : "133026996824472",
			"author_uid" : "100003515170743",
			"authorName" : "Jill",
			"page_id" : "114792641936871",
			"placeName" : "Seattle Ferry Terminal",
			"timestamp" : "1331697365",
			"coords" : {
				"longitude" : "-122.33896652781",
				"latitude" : "47.602848032316"
			}
		}, {
			"checkin_id" : "112243682236137",
			"author_uid" : "100003515170743",
			"authorName" : "Jill",
			"page_id" : "74993773631",
			"placeName" : "Kells Irish Restaurant \u0026 Pub",
			"timestamp" : "1329460303",
			"coords" : {
				"longitude" : "-122.34234181855",
				"latitude" : "47.610378593978"
			}
		}, {
			"checkin_id" : "111893212271184",
			"author_uid" : "100003515170743",
			"authorName" : "Jill",
			"page_id" : "114792641936871",
			"placeName" : "Seattle Ferry Terminal",
			"timestamp" : "1329420153",
			"coords" : {
				"longitude" : "-122.33896652781",
				"latitude" : "47.602848032316"
			}
		}, {
			"checkin_id" : "106369536156885",
			"author_uid" : "100003515170743",
			"authorName" : "Jill",
			"page_id" : "115622245134654",
			"placeName" : "Boka Kitchen \u0026 Bar",
			"timestamp" : "1328747743",
			"coords" : {
				"longitude" : "-122.33629243231",
				"latitude" : "47.604880040487"
			}
		}]
	};

	var CHECKIN = {
		"message" : "KnoWhutImean, Vern?",
		"placeId" : 86493431461,
		"latitude" : 47.6046,
		"longitude" : -122.33627
	};

	var GETCOMMENT = {
		"paging" : {
			"next" : "https://graph.facebook.com/100003565868302_135148013280727/comments?limit\u003d5\u0026access_token\u003dAAACZBsR8HZByMBAK2TJZClaK1dGl3cpdaFPn4KGZBos54iOShdvZCrnOBYojQZChtIoYwZC5pd0xHNZAi7ZC8y1NXJPAvdSRXcM3Et9SqNmaAnwZDZD\u0026format\u003djson\u0026offset\u003d5\u0026__after_id\u003d100003565868302_135148013280727_173076"
		},
		"data" : [{
			"id" : "100003565868302_135148013280727_145092",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "yes, you are right!",
			"created_time" : "2012-03-21T00:26:01+0000"
		}, {
			"id" : "100003565868302_135148013280727_173063",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Fixtures are radically cool!",
			"created_time" : "2012-03-27T22:27:51+0000"
		}, {
			"id" : "100003565868302_135148013280727_173068",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Fixtures are radically cool!",
			"created_time" : "2012-03-27T22:30:46+0000"
		}, {
			"id" : "100003565868302_135148013280727_173074",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Fixtures are radically cool!",
			"created_time" : "2012-03-27T22:33:18+0000"
		}, {
			"id" : "100003565868302_135148013280727_173076",
			"from" : {
				"id" : "100003565868302",
				"name" : "John"
			},
			"message" : "Fixtures are radically cool!",
			"created_time" : "2012-03-27T22:33:30+0000"
		}]
	};

	var STATUSUPDATE = {
		"message" : "I am feeling a bit piqued today..."
	};