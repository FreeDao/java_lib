$(function() {
	
	FB.Models.API = can.Model(
	/* @Static */
	{
		defaults : {
			facebookNewsFeedRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/feed/mipId/%MIPID%?maxMessages=%maxMessages%&includeImages=%includeImages%",
				"requestMethod" : "GET"
			},
			facebookHomeRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/home/mipId/%MIPID%?maxMessages=%maxMessages%&includeImages=%includeImages%",
				"requestMethod" : "GET"
			},
			facebookStatusUpdateRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/status/mipId/%MIPID%?message=%message%",
				"requestMethod" : "PUT"
			},
			facebookLikeRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/like/mipId/%MIPID%?id=%id%",
				"requestMethod" : "PUT"
			},
			facebookUnlikeRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/like/mipId/%MIPID%?id=%id%",
				"requestMethod" : "DELETE"
			},
			facebookPostCommentRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/comment/mipId/%MIPID%?id=%id%&comment=%comment%",
				"requestMethod" : "PUT"
			},
			facebookGetCommentRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/comments/mipId/%MIPID%?id=%id%&limit=%limit%&offset=%offset%&afterId=%afterId%",
				"requestMethod" : "GET"
			},
			facebookSearchPlacesRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/places/mipId/%MIPID%?name=%name%&latitude=%latitude%&longitude=%longitude%&limit=%limit%&offset=%offset%&afterId=%afterId%",
				"requestMethod" : "GET"
			},
			facebookCheckinRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/checkin/mipId/%MIPID%?placeId=%placeId%&message=%message%&latitude=%latitude%&longitude=%longitude%",
				"requestMethod" : "PUT"
			},
			facebookNearbyFriendsRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/checkins/mipId/%MIPID%?time=%time%&distance=%distance%&latitude=%latitude%&longitude=%longitude%",
				"requestMethod" : "GET"
			},
			facebookImageRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/images/mipId/%MIPID%",
				"requestMethod" : "POST"
			},
			facebookEventsRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/events/mipId/%MIPID%?days_back=%daysBack%",
				"requestMethod" : "GET"
			},
			facebookFriendsRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/friends/mipId/%MIPID%?limit=%limit%&offset=%offset%",
				"requestMethod" : "GET"
			},
			facebookFriendsBirthdayRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/friends/birthday/mipId/%MIPID%?limit=%limit%&offset=%offset%",
				"requestMethod" : "GET"
			},
			facebookPrivateMessage : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/inbox/mipId/%MIPID%",
				"requestMethod" : "GET"
			},
			facebookShareLinkRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/link/mipId/%MIPID%?link=%link%&message=%message%",
				"requestMethod" : "PUT"
			},
			facebookProfileRequest : {
				"requestUri" : "%CHOREO_SERVER_URL_BASE%/api/1.0/facebook/profile/mipId/%MIPID%",
				"requestMethod" : "GET"
			}
		},

		sendHttpRequest : function(args) {
			if(FB.Models.proxy){
				this.sendHttpRequestProxy(args);
			}else{	
				$.ajax({
					url: args.url,
					data: args.data,
					type: args.type,
					dataType: args.dataType,
					success: args.success,
					error: args.error
				});
			}
		},
		sendHttpRequestProxy : function(args) {
			args.data = JSON.parse(args.data);
			// take the url and replace the mipid and %CHOREO_SERVER_URL_BASE%
				
			var endurl = args.data.requestUri.toString().replace("%CHOREO_SERVER_URL_BASE%", FB.Models.ROOT_URL);
			endurl = endurl.replace("%MIPID%", FB.Models.MipId);
						
			$.ajax({
				url : endurl,
				//data: args.data,
				type: args.data.requestMethod,
				dataType: args.dataType,
				success: args.success,
				error: args.error
			});
		},

		/**** GET NEWS FEED ****/
		getNewsFeed : function(args) {
			console.log("Getting News Feed...");

			var maxMessages = args.data.maxMessages;
			var includeImages = args.data.includeImages;
			var facebookNewsFeedRequest = this.defaults.facebookNewsFeedRequest;
			facebookNewsFeedRequest = JSON.stringify(facebookNewsFeedRequest);
			facebookNewsFeedRequest = facebookNewsFeedRequest.replace("%maxMessages%", maxMessages);
			facebookNewsFeedRequest = facebookNewsFeedRequest.replace("%includeImages%", includeImages);

			console.log("facebookNewsFeedRequest");
			console.log(facebookNewsFeedRequest);
            this.sendHttpRequest({
				url : '/gateway',
				data: facebookNewsFeedRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});
		},

		/**** GET HOME ****/
		getLiveFeed : function(args) {
			console.log("Getting livefeed...");
		
			var maxMessages = args.data.maxMessages;
			var includeImages = args.data.includeImages;
			var facebookHomeRequest = this.defaults.facebookHomeRequest;
			facebookHomeRequest = JSON.stringify(facebookHomeRequest);
			facebookHomeRequest = facebookHomeRequest.replace("%maxMessages%", maxMessages);
			facebookHomeRequest = facebookHomeRequest.replace("%includeImages%", includeImages);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookHomeRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});
		},

		/**** PUT STATUS ****/
		postStatus : function(args) {
			var message = encodeURIComponent(args.data.message);
			var facebookStatusUpdateRequest = this.defaults.facebookStatusUpdateRequest;
			facebookStatusUpdateRequest = JSON.stringify(facebookStatusUpdateRequest);
			facebookStatusUpdateRequest = facebookStatusUpdateRequest.replace("%message%", message);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookStatusUpdateRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});
		},

		/**** PUT LIKE ****/
		postLike : function(args) {
			var id = args.data.id;
			id = encodeURIComponent(id);

			var facebookLikeRequest = this.defaults.facebookLikeRequest;
			facebookLikeRequest = JSON.stringify(facebookLikeRequest);
			facebookLikeRequest = facebookLikeRequest.replace("%id%", id);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookLikeRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});			
		},

		/**** DELETE UNLIKE ****/
		postUnlike : function(args) {
			var id = args.data.id;
			id = encodeURIComponent(id);

			var facebookUnlikeRequest = this.defaults.facebookUnlikeRequest;
			facebookUnlikeRequest = JSON.stringify(facebookUnlikeRequest);
			facebookUnlikeRequest = facebookUnlikeRequest.replace("%id%", id);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookUnlikeRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** PUT COMMENT ****/
		postComment : function(args) {
			var id = args.data.id;
			var message = args.data.message;

			message = encodeURIComponent(message);
			id = encodeURIComponent(id);

			var facebookPostCommentRequest = this.defaults.facebookPostCommentRequest;
			facebookPostCommentRequest = JSON.stringify(facebookPostCommentRequest);
			facebookPostCommentRequest = facebookPostCommentRequest.replace("%id%", id);
			facebookPostCommentRequest = facebookPostCommentRequest.replace("%comment%", message);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookPostCommentRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});			
		},

		/**** GET ALL COMMENTS ****/
		getComments : function(args) {
			var limit = 10;
			var id = args.data.id;
			var offset = args.offset;
			var afterId = args.afterId;

			var facebookGetCommentRequest = this.defaults.facebookGetCommentRequest;
			facebookGetCommentRequest = JSON.stringify(facebookGetCommentRequest);
			facebookGetCommentRequest = facebookGetCommentRequest.replace("%ID%", id);
			facebookGetCommentRequest = facebookGetCommentRequest.replace("%LIMIT%", limit);
			facebookGetCommentRequest = facebookGetCommentRequest.replace("%offset%", offset);
			facebookGetCommentRequest = facebookGetCommentRequest.replace("%afterId%", afterId);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookGetCommentRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});
		},

		/**** GET NEARBY PLACES ****/
		getNearbyPlaces : function(args) {
			var name = args.data.name;
			var latitude = args.data.latitude;
			var longitude = args.data.longitude;
			var limit = args.data.limit;
			var offset = args.data.offset;
			var afterId = args.data.afterId;

			var facebookSearchPlacesRequest = this.defaults.facebookSearchPlacesRequest;
			facebookSearchPlacesRequest = JSON.stringify(facebookSearchPlacesRequest);
			facebookSearchPlacesRequest = facebookSearchPlacesRequest.replace("%name%", name);
			facebookSearchPlacesRequest = facebookSearchPlacesRequest.replace("%latitude%", latitude);
			facebookSearchPlacesRequest = facebookSearchPlacesRequest.replace("%longitude%", longitude);
			facebookSearchPlacesRequest = facebookSearchPlacesRequest.replace("%limit%", limit);
			facebookSearchPlacesRequest = facebookSearchPlacesRequest.replace("%offset%", offset);
			facebookSearchPlacesRequest = facebookSearchPlacesRequest.replace("%afterId%", afterId);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookSearchPlacesRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});			
		},

		/**** POST CHECK IN ****/
		postCheckIn : function(args) {
			var latitude = args.data.latitude;
			var longitude = args.data.longitude;
			var placeId = args.data.placeId;
			var message = encodeURIComponent(args.data.message);

			var facebookCheckinRequest = this.defaults.facebookCheckinRequest;
			facebookCheckinRequest = JSON.stringify(facebookCheckinRequest);
			facebookCheckinRequest = facebookCheckinRequest.replace("%placeId%", placeId);
			facebookCheckinRequest = facebookCheckinRequest.replace("%message%", message);
			facebookCheckinRequest = facebookCheckinRequest.replace("%latitude%", latitude);
			facebookCheckinRequest = facebookCheckinRequest.replace("%longitude%", longitude);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookCheckinRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET NEARBY FRIENDS ****/
		getNearbyFriends : function(args) {
			var time = 60 * 24 * 7;
			// 7 days
			var distance = args.data.distance;
			var latitude = args.data.latitude;
			var longitude = args.data.longitude;

			var facebookNearbyFriendsRequest = this.defaults.facebookNearbyFriendsRequest;
			facebookNearbyFriendsRequest = JSON.stringify(facebookNearbyFriendsRequest);
			facebookNearbyFriendsRequest = facebookNearbyFriendsRequest.replace("%latitude%", latitude);
			facebookNearbyFriendsRequest = facebookNearbyFriendsRequest.replace("%longitude%", longitude);
			facebookNearbyFriendsRequest = facebookNearbyFriendsRequest.replace("%distance%", distance);
			facebookNearbyFriendsRequest = facebookNearbyFriendsRequest.replace("%time%", time);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookNearbyFriendsRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET IMAGES ****/
		getImages : function(args) {
			var facebookImageRequest = this.defaults.facebookImageRequest;
			facebookImageRequest = JSON.stringify(facebookImageRequest);
			FB.Models.sendHttpRequest({
				url : '/gateway',
				data: facebookImageRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET Events ****/
		getEventsRequest : function(args) {
			var facebookEventsRequest = this.defaults.facebookEventsRequest;
			facebookEventsRequest = JSON.stringify(facebookEventsRequest);
			
			this.sendHttpRequest({
				url : '/gateway',
				data: facebookImageRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET Friends ****/
		getFriendsRequest : function(args) {
			var limit = 10;
			var offset = args.data.offset;

			var facebookFriendsRequest = this.defaults.facebookFriendsRequest;
			facebookFriendsRequest = JSON.stringify(facebookFriendsRequest);
			facebookFriendsRequest = facebookFriendsRequest.replace("%limit%", limit);
			facebookFriendsRequest = facebookFriendsRequest.replace("%offset%", offset);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookFriendsRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** GET Friends Birthday ****/
		getFriendsBirthday : function(args) {
			var limit = 10;
			var offset = args.data.offset;

			var facebookFriendsBirthdayRequest = this.defaults.facebookFriendsBirthdayRequest;
			facebookFriendsBirthdayRequest = JSON.stringify(facebookFriendsBirthdayRequest);
			facebookFriendsBirthdayRequest = facebookFriendsBirthdayRequest.replace("%limit%", limit);
			facebookFriendsBirthdayRequest = facebookFriendsBirthdayRequest.replace("%offset%", offset);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookFriendsBirthdayRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});			
		},

		/**** GET Inbox Message ****/
		getPrivateMessage : function(args) {
			var facebookPrivateMessage = this.defaults.facebookPrivateMessage;
			facebookPrivateMessage = JSON.stringify(facebookPrivateMessage);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookPrivateMessage,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** PUT Share Link ****/
		putShareLink : function(args) {
			var link = args.data.link;
			var message = encodeURIComponent(args.data.message);

			var facebookShareLinkRequest = this.defaults.facebookShareLinkRequest;
			facebookShareLinkRequest = JSON.stringify(facebookShareLinkRequest);
			facebookShareLinkRequest = facebookShareLinkRequest.replace("%link%", link);
			facebookShareLinkRequest = facebookShareLinkRequest.replace("%message%", message);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookShareLinkRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		},

		/**** Get Profile ****/
		getProfile : function(args) {
			var facebookProfileRequest = this.defaults.facebookProfileRequest;
			facebookProfileRequest = JSON.stringify(facebookProfileRequest);

			this.sendHttpRequest({
				url : '/gateway',
				data: facebookProfileRequest,
				dataType:'json',
				type : 'POST',
				success : args.success,
				error : args.error
			});				
		}
	}, {

	});

	FB.Models.ROOT_URL = "http://208.79.147.22:9011/aqMIP";
	//FB.Models.ROOT_URL = "/proxy.php?route=";
	FB.Models.MipId = "24d43025-0f42-11e2-bf90-330a4a33aa4b";
	FB.Models.proxy = false;
}); 
