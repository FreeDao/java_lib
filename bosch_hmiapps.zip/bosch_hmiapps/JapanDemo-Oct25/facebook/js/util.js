FB.Models.Util = can.Model(
/* @Static */
{
	init: function(){
		
	},
	
	/* Accepts the date string and returns human readable string */
	formatDate: function(arg){
		var obj = new Date(arg);
		var diff = parseInt( (new Date()).getTime() - obj.getTime() )/1000; //in seconds for easier use
		
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var month = months[ obj.getMonth() ];
		var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var day = days[ obj.getDay() ];
		var date = obj.getDate();
		var year = obj.getFullYear();
		var hour = obj.getHours();
		var minute = obj.getMinutes();
		
		if(hour > 12){
			hour -= 12;
			var timePostfix = "pm";
		}else if(hour == 12){
			var timePostfix = "pm";
		}else{
			var timePostfix = "am";
		}
		
		if(minute < 10){
			minute = "0"+minute;
		}
		
		
		if( diff < 10 ){ //10 seconds
			
			return "just now";
			
		}else if( diff < 60 ){ //1 minute
			
			return "1 minute ago";
			
		}else if( diff < 3600 ){ //60 minutes
			
			return parseInt( diff / 60 )+" minutes ago";
			
		}//else if( diff < 3600 ){ //1 hour
			
			//return "less than an hour ago";
			
		//}
		else if( diff < 3600*24 ){ //24 hours
			
			return parseInt( diff / 3600 )+" hours ago";
			
		}else if( diff < 3600*24 ){ //1 days
			
			return "Yesterday";		
			
		}else if( diff < 3600*24*7 ){ //7 days
			
			//return day+" at "+hour+":"+minute+""+timePostfix;
			return day;
			
		}else if( diff > 3600*24*7 ){ //Greater than 7 days
			
			//return day+" at "+hour+":"+minute+""+timePostfix;
			return month+" "+date;
			
		}
		
		//else if( year == (new Date()).getFullYear() ){ //the same year
			
		//	return month+" "+date+" at "+hour+":"+minute+""+timePostfix;
			
		//}else{
			
		//	return month+" "+date+", "+year+" at "+hour+":"+minute+""+timePostfix;
			
		//}
	},
	
	
	/* Merges 2 arrays of JSONs and removes duplicates based on given children (unique id) and sorts based on given children (date/float/int) */
	mergeArrays: function(args){
		
		if( typeof args.arr1 == 'undefined' ){
			throw "mergeArrays: You have to pass at least 1 array object";
			return;
		}else{
			var arr1 = args.arr1;
		}
		
		if( typeof args.arr2 == 'undefined' ){
			var doesMerge = false;
		}else{
			var doesMerge = true;
			var arr2 = args.arr2;
		}
		
		if( typeof args.unique == 'undefined'){
			var doesUnique = false;
		}else{
			var doesUnique = true;
			unique = args.unique;
		}
		
		if( typeof args.sort == 'undefined'){
			var doesSort = false;
		}else{
			var doesSort = true;
			sort = args.sort;
		}
		
		
		
		if(doesMerge){
			$.merge(arr1, arr2);
		}
		
		
		if(doesUnique)
		{
			var existingIDs = [];
			arr1 = $.grep(arr1, function(v) {
			    if ($.inArray(v[unique], existingIDs) !== -1) {
			        return false;
			    }
			    else {
			        existingIDs.push(v.id);
			        return true;
			    }
			});
		}
		
		if(doesSort){
			arr1.sort(function(a, b)
			{
				try{
					var akey = (new Date(a[sort])).getTime();
				    var bkey = (new Date(b[sort])).getTime();
				}catch(err){
					var akey = parseFloat( a[sort] );
				    var bkey = parseFloat( b[sort] );
				}
			    
			    
			    if(akey < bkey) return 1;
			    if(akey > bkey) return -1;
			    return 0;
			});
		}
		
		
		//console.log("SUCCESSFUL MERGE. doesMerge="+doesMerge+", doesUnique="+doesUnique+", doesSort="+doesSort);
		//console.log(arr1);
		return arr1;
		
	}
},
/* @Prototype */
{});