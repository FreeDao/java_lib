var FB = {};
FB.Models = {};

var that = this;

$(function() {
	var insideFun = this;

	function navHome() {
		pagecontent.showPage();
	}
	that.navHome = navHome;

	var ttsPlaying = false;
	//TODO temporary params for store response data, will refine later
	var LIVEFEED = null;
	var curId = null;
	var NEARBYPLACES = null;
	var FRIENDS = null;
	var currentControl = null;
	/* Controller - Header */
	FB.Header = can.Control({
		defaults : {}
	}, {
		_header : null,
		updateTitle : function(title){
			this._header.attr("title",title);
		},
		init : function() {
			var that = this;
			if (!that._header) that._header = new can.Observe({ title: "Facebook", icon : "RESERVED for icon url or anything else"});
			$("#header").html(can.view("views/header-views/common.ejs", {
				data : that._header
			}));
		},
		"#header-title click" : function() {
			this.updateTitle("Facebook");
			pagecontent.showPage();
		}
	});

	/* Controller - PageContent */
	FB.Pagecontent = can.Control({
		/** @Static */

		defaults : {
			homeButtons : {
				page0 : ["News Feed", "Status", "Events", "Nearby", "Check-In", "Next Page"],
				page1 : ["Previous Page", "Message", "Friends"]
			},
			status : ["I'm in the car", "Out saving the world", "Heading home now!", "Pre-written status message", "Pre-written status message", "Custom message"],
			events : ["Future", "Past", "Birthdays"],
			checkin : ["Seattle Aquarium", "Washington State Convention Center", "Seattle Art Museum", "Sheraton Seattle Hotel", "The Westin Seattle", "Nordstrom Flagship Seattle"],
			/*friends : ["Clark Kent", "Bruce Wayne", "Diana of Themy", "Jean Grey", "John Stewart", "Ororo lqadi T'Challa", "bla bla ..."],*/
			messages : [{
				name : "Jean Grey",
				date : "4/30"
			}, {
				name : "Clark Kent",
				date : "4/27"
			}, {
				name : "Peter Benjamin Parker",
				date : "4/6"
			}, {
				name : "Barbara Gordon",
				date : "3/31"
			}, {
				name : "Barbara Gordon",
				date : "3/30"
			}, {
				name : "Barbara Gordon",
				date : "3/29"
			}, {
				name : "Barbara Gordon",
				date : "3/28"
			}],
			presetComments : ["Pre-written comment message", "Pre-written comment message", "Pre-written comment message", "Pre-written comment message", "Pre-written status message", "Custom message"],
			customComments : ["Custom Message", "Custom Message", "Custom Message", "Custom Message", "Custom Message"],
			eventList : [{
				name : "Name of Event",
				date : "4/30"
			}, {
				name : "Name of Event",
				date : "4/27"
			}, {
				name : "Name of Event",
				date : "4/6"
			}, {
				name : "Name of Event",
				date : "3/31"
			}, {
				name : "Name of Event",
				date : "3/30"
			}, {
				name : "Name of Event",
				date : "3/29"
			}, {
				name : "Name of Event",
				date : "3/28"
			}],
			phoneNumberList : ["000-000-0000", "000-000-0000", "000-000-0000"]
		}
	}, {
		_pageIndex : 0,
		init : function() {
			this.showPage();
		},
		showPage : function() {
			var that = this;
			$('#pagecontent').html(can.view('views/pagecontent-views/main_home.ejs', {
				"data" : FB.Pagecontent.defaults.homeButtons["page" + that._pageIndex]
			}));
		},
		".next_page click" : function() {
			this._pageIndex++;
			this.showPage();
		},
		".previous_page click" : function() {
			this._pageIndex--;
			this.showPage();
		},
		"#news_feed click" : function() {
			var func = function() {
				//refreshPage();
				if (currentControl) currentControl.destroy();
				currentControl = new FB.NewsFeed("#pagecontent", {})
			}
			loadWA(null, func);
		},

		"#status click" : function() {
			//$("#header").hide();
			$('#pagecontent').html(can.view('views/pagecontent-views/status.ejs', {
			}));
		},

		/* Comment Post */
		"#status-input click" : function() {
			$("#status-input").val("");
		},

		"#comment_post #ok click" : function() {
			var msg = $("#status-input").val();
			if (!msg)
				return;
			var id = curId;
			//TODO commenting a post
			var success = function(data) {
				console.log("Commenting a post success!");
			}
			var error = function(err) {
				console.log("Commenting a post caught error : " + JSON.stringify(err));
			}

			FB.Models.API.postComment({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					id : id,
					message : msg
				},
				success : success,
				error : error
			});

			$("#header").show();
			var func = function() {
				if (currentControl) currentControl.destroy();
				currentControl = new FB.NewsFeed("#pagecontent", {})
			}
			loadWA(null, func);
			header.updateTitle("Newsfeed");
		},

		"#comment_post #preset click" : function() {
			console.log(1);
			$("#header").show();
			$('#pagecontent').html(can.view('views/pagecontent-views/preset-comment.ejs', {
				data : FB.Pagecontent.defaults.presetComments
			}));

			header.updateTitle("Preset Comments");
		},
		/* End of Status Post */
		/* Preset Comment */
		".preset-comment-list .list-text click" : function(el) {
			if (el.parent().hasClass("custom_message")) {
				$('#pagecontent').html(can.view('views/pagecontent-views/custom-status.ejs', {
					data : FB.Pagecontent.defaults.customComments
				}));
				header.updateTitle("Custom Comments");
			} else {

				$("#header").show();
				var func = function() {
					//refreshPage();
					if (currentControl) currentControl.destroy();
					currentControl = new FB.NewsFeed("#pagecontent", {})
				}
				loadWA(null, func);
				header.updateTitle("Newsfeed");
			}
		},

		/* End of Preset Comment */

		/* Custom Comments */
		".custom-status-list .edit-message click" : function() {
			header.updateTitle("Edit Custom Messages");
			$('#pagecontent').html(can.view('views/pagecontent-views/custom-status-edit.ejs', {
				data : ["Custom Messages", "Custom Messages", "Custom Messages", "Custom Messages", "Custom Messages"]
			}));
		},

		".custom-status-list .custom_message click" : function() {
			$("#header").show();
			var func = function() {
				//refreshPage();
				if (currentControl) currentControl.destroy();
				currentControl = new FB.NewsFeed("#pagecontent", {})
			}
			loadWA(null, func);
			header.updateTitle("Newsfeed");
		},
		/* End of Custom Comments */

		/* Edit List */
		".custom-status-edit .custom_messages click" : function() {
			$("#header").hide();
			$('#pagecontent').html(can.view('views/pagecontent-views/post-comment-edit.ejs', {
			}));
		},
		/* End of Edit List*/

		"#comment_edit_post #ok click" : function() {
			console.log(1);
			$("#header").show();
			$('#pagecontent').html(can.view('views/pagecontent-views/custom-status.ejs', {
				data : FB.Pagecontent.defaults.customComments
			}));
			header.updateTitle("Custom Comments");
		},

		/* Status */
		"#status_post #preset click" : function() {
			$("#header").show();
			$('#pagecontent').html(can.view('views/pagecontent-views/preset-status.ejs', {
				data : FB.Pagecontent.defaults.status
			}));
			header.updateTitle("Status");
		},

		"#status_post #ok click" : function() {
			//TODO updating facebook status
			var msg = $("#status-input").val();
			if (!msg)
				return;

			var success = function(data) {
				console.log("Commenting a post success!");

				$("#header").show();
				var func = function() {
					if (currentControl) currentControl.destroy();
					currentControl = new FB.NewsFeed("#pagecontent", {})
				}
				loadWA(null, func);
				header.updateTitle("Newsfeed");
			}
			var error = function(err) {
				console.log("Commenting a post caught error : " + JSON.stringify(err));
			}

			FB.Models.API.postStatus({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					message : msg
				},
				success : success,
				error : error
			});
		},

		".present-status-list .list-text click" : function(el) {
			if (el.parent().hasClass("custom_message")) {
				$('#pagecontent').html(can.view('views/pagecontent-views/custom-status.ejs', {
					data : FB.Pagecontent.defaults.customComments
				}));
				header.updateTitle("Custom Status");
			} else {

				$("#header").show();
				var func = function() {
					//refreshPage();
					if (currentControl) currentControl.destroy();
					currentControl = new FB.NewsFeed("#pagecontent", {})
				}
				loadWA(null, func);
				header.updateTitle("Newsfeed");
			}
		},

		".custom-status-list .list-text click" : function(el) {
			if (el.parent().hasClass("edit-message")) {

				header.updateTitle("Edit Custom Messages");
				$('#pagecontent').html(can.view('views/pagecontent-views/custom-status-edit.ejs', {
					data : ["Custom Messages", "Custom Messages", "Custom Messages", "Custom Messages", "Custom Messages"]
				}));
			} else {

				$("#header").show();
				var func = function() {
					if (currentControl) currentControl.destroy();
					currentControl = new FB.NewsFeed("#pagecontent", {})
				}
				loadWA(null, func);
				header.updateTitle("Newsfeed");
			}
		},

		/* End of Status */

		/* Events */
		"#events click" : function() {
			header.updateTitle("Events");
			$('#pagecontent').html(can.view('views/pagecontent-views/event-menu.ejs', {
				data : FB.Pagecontent.defaults.events
			}));

		},

		".events-list .list-text click" : function(el) {
			var ev = el.text();
			header.updateTitle("Events: " + ev);
			if (ev == "Birthdays") {
				//get friends birthday
				this.getFriendsBirthday();
			} else {
				$('#pagecontent').html(can.view('views/pagecontent-views/event-menu-list.ejs', {
					data : FB.Pagecontent.defaults.eventList
				}));
			}
		},

		/**** GET Friends Birthday ****/
		getFriendsBirthday : function() {
			var offset = '';
			var limit = '';

			var success = function(data) {
				console.log("Retrieving the friends birthday success!" + JSON.stringify(data));
				var message = data;
				$('#pagecontent').html(can.view('views/pagecontent-views/event-menu-list.ejs', {
					data : message.data
				}));
			}
			var error = function(err) {
				console.log("Retrieving the friends caught error : " + JSON.stringify(err));
			}

			FB.Models.API.getFriendsBirthday({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					limit : limit,
					offset : offset
				},
				success : success,
				error : error
			});
		},

		".event-menu-list .list-text click" : function() {
			//alert("Jump to navigation!");
		},
		/* End of Events */

		/* Nearby */
		"#nearby click" : function() {
			header.updateTitle("Nearby Friends");
			if (currentControl) currentControl.destroy();
			currentControl = new FB.Nearby("#pagecontent", {});
		},
		/* End of Nearby*/

		/* Check in */
		"#check-in click" : function() {
			//TODO searching nearby places
			var success = function(data) {
				NEARBYPLACES = data;
				console.log("Searching nearby places success!");
				header.updateTitle("Check In");
				$('#pagecontent').html(can.view('views/pagecontent-views/check-in-list.ejs', {
					data : NEARBYPLACES.data
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
					scrollratio : 0.3
				});
			}
			var error = function(err) {
				console.log("Searching nearby places caught error : " + JSON.stringify(err));
			}

			FB.Models.API.getNearbyPlaces({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					name : '',
					latitude : 47.6045,
					longitude : -122.3378,
					limit : 10,
					afterId : '',
					offset : ''
				},
				success : success,
				error : error
			});

		},

		".check-in-list .list-text click" : function(el) {
			var id = el.attr("id");
			var nearbyPlace = this.getNearbyPlaceById(id, NEARBYPLACES);

			$('#pagecontent').html(can.view('views/pagecontent-views/post-check-in-msg.ejs', {
				data : nearbyPlace
			}));
		},

		getNearbyPlaceById : function(id, checkins) {
			var place = null;
			$.each(checkins.data, function(i) {
				if (this.id == id) {
					place = this;
				}
			});
			console.log("get nearby place by id : " + JSON.stringify(place));
			return place;
		},

		"#nf_button_post click" : function(el) {
			var placeId = $(".container").attr("id");
			var that = this;
			//TODO put checkin
			var success = function() {
				console.log("Put checkin success!");
				header.updateTitle("FaceBook");
				that.init();
			};

			var error = function() {
				console.log("Put checkin caught error : " + JSON.stringify(err));
			};

			FB.Models.API.postCheckIn({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					placeId : placeId,
					message : '',
					latitude : 47.6045,
					longitude : -122.3378,
				},
				success : success,
				error : error
			});
		},

		"#nf_button_cancel click" : function() {
			header.updateTitle("Check In");
			$('#pagecontent').html(can.view('views/pagecontent-views/check-in-list.ejs', {
				data : NEARBYPLACES.data
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
				scrollratio : 0.3
			});
		},
		/* End of Check in */

		/* Messages */
		"#message click" : function() {
			header.updateTitle("Messages");
			$('#pagecontent').html(can.view('views/pagecontent-views/messages.ejs', {
				data : FB.Pagecontent.defaults.messages
			}));
			new scrollbar_control("#scrollbar", {
				viewport : $(".scroll-main"),
				scrollratio : 0.3
			});
		},

		".message-list .list-text click" : function() {
			$('#pagecontent').html(can.view('views/pagecontent-views/message-detail.ejs', {
			}));

			displayPlayorPause();
		},

		".message-page #nf_button_call click" : function() {
			header.updateTitle("Select Number");
			$('#pagecontent').html(can.view('views/pagecontent-views/phone-number-list.ejs', {
				data : FB.Pagecontent.defaults.phoneNumberList
			}));
		},

		".phone-list .list-text click" : function(el) {
			var phonenumber = el.text();
			overlay("popup-calling.ejs", phonenumber);
		},

		"#call-cancel click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
		},

		/* End of Message*/

		/* Friends */
		"#friends click" : function() {
			//retrieving the friends
			var offset = '';

			var success = function(data) {
				FRIENDS = data;
				console.log("Retrieving the friends success!");
				header.updateTitle("Friends");
				$('#pagecontent').html(can.view('views/pagecontent-views/friends-list.ejs', {
					data : FRIENDS.data
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
					scrollratio : 0.3
				});
			}
			var error = function(err) {
				console.log("Retrieving the friends caught error : " + JSON.stringify(err));
			}

			FB.Models.API.getFriendsRequest({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					offset : offset
				},
				success : success,
				error : error
			});
		},

		".friends-list .list-text click" : function(el) {
			var name = el.text();
			header.updateTitle(name);
			if (!LIVEFEED) {
				if (currentControl) currentControl.destroy();
				currentControl = new FB.NewsFeed().init();
			}

			/*
			 $('#pagecontent').html(can.view('views/pagecontent-views/newsfeed-list.ejs', {
			 "data" : LIVEFEED.data
			 }));
			 new scrollbar_control("#scrollbar", {
			 viewport : $(".scroll-main"),
			 scrollratio : 0.3
			 });*/

		},
		/* End of Friends */

	});

	FB.Nearby = can.Control({}, {
		init : function() {
			this.loadNearbyList();
		},
		loadNearbyList : function() {
			//TODO searching checkin of friends
			var success = function(data) {
				var nearbyFriends = data;
				console.log("Searching checkin of friends success!");

				$('#pagecontent').html(can.view('views/pagecontent-views/nearby-list.ejs', {
					"data" : CHECKINSEARCH.checkins/* nearbyFriends.checkins*/
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
					scrollratio : 0.3
				});
			}
			var error = function(err) {
				console.log("Searching checkin of friends caught error : " + JSON.stringify(err));
			}

			FB.Models.API.getNearbyFriends({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					latitude : 47.6045,
					longitude : -122.3378,
					distance : 100
				},
				success : success,
				error : error
			});

		},
		".nearby-list .nf-username click" : function(el) {
			var location = el.find($(".placeName")).text();
			overlay("popup_nearby_location.ejs", location);
		},
		"#navigate-nearby-yes click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
			header.updateTitle("Nearby Friends");
			$('#pagecontent').html(can.view('views/pagecontent-views/nearby-detail.ejs', {
			}));
		},
		"#navigate-nearby-no click" : function() {
			$('#overlay-container').slideUp(500, function() {
			});
		}
	});

	/* NewsFeed */
	FB.NewsFeed = can.Control({}, {
		init : function() {
			this.loadNewsfeedList();
		},
		loadNewsfeedList : function() {
			console.log("Getting News Feed...");

			var success = function(data) {
				console.log("Get news feed success!");
				LIVEFEED = data;
				console.warn(LIVEFEED.data);
				$('#pagecontent').html(can.view('views/pagecontent-views/newsfeed-list.ejs', {
					"data" : LIVEFEED.data
				}));
				new scrollbar_control("#scrollbar", {
					viewport : $(".scroll-main"),
					scrollratio : 0.3
				});
			};

			var error = function(err) {
				console.log("Get news feed caught error : " + JSON.stringify(err));
			};

			FB.Models.API.getNewsFeed({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					maxMessages : 20,
					includeImages : true
				},
				success : success,
				error : error
			});
		},
		"#refresh click" : function() {
			$('#pagecontent').hide();
			this.loadNewsfeedList();
			$('#pagecontent').fadeIn(300);
		},
		".status-message click" : function(el) {
			var that = this;
			var func = function() {
				var id = el.attr('data-id');
				curId = id;
				
				$('#pagecontent').html(can.view('views/pagecontent-views/newsfeed-detail.ejs', {
					data : that.getNewsFeedById(id, LIVEFEED)
				}));
				displayPlayorPause();
			}
			loadWA("Loading...", func);
		},
		"#nf-play-icon click" : function() {
			ttsPlaying = !ttsPlaying;
			displayPlayorPause();
		},
		"#nf_button_like click" : function(el) {
			//var id = $(".container").attr('id');
			var id = curId;
			//put like request
			var success = function(data) {
				var origin = parseInt($(".likes-count").text());
				console.log(origin);
				$(".likes-count").text(origin + 1);
			};
			console.log("like happened");
			var error = function(err) {
				console.log("Put 'Like' caught error : " + JSON.stringify(err));
			}
			FB.Models.API.postLike({
				url : FB.Models.ROOT_URL,
				mipId : FB.Models.MipId,
				data : {
					id : id
				},
				success : success,
				error : error
			});
		},
		"#nf_button_comment click" : function() {
			$("#header").hide();
			$('#pagecontent').html(can.view('views/pagecontent-views/post-comment.ejs', {
			}));
		},
		getNewsFeedById : function(id, livefeed) {
			var feed = null;
			$.each(livefeed.data, function(i) {
				if (this.id == id) {
					feed = this;
				}
			});
			console.log("get news feed by id : " + JSON.stringify(feed));
			return feed;
		}
	});

	var displayPlayorPause = function() {
		if (ttsPlaying) {
			$("#nf-play-icon").removeClass("nf-play-icon");
			$("#nf-play-icon").addClass("nf-pause-icon");
		} else {
			$("#nf-play-icon").addClass("nf-play-icon");
			$("#nf-play-icon").removeClass("nf-pause-icon");
		}
	};

	var loadWA = function(message, func) {
		$('#pagecontent').html(can.view('views/pagecontent-views/waiting-animation.ejs', {
			data : message
		}));
		header.updateTitle("Newsfeed");
		setTimeout(func, 2000);
	};

	var refreshHeader = function() {
		$("#header").remove();
		$("#fb_app").prepend("<div id='header'>");
	};

	var refreshPage = function() {
		$("#pagecontent").remove();
		$("#fb_app").append($("<div>").attr("id","pagecontent"));
	};

	var overlay = function(overlay, location) {
		$('#overlay-container').remove();
		$('#pagecontent').append(can.view('views/pagecontent-views/overlay.ejs', {
			"overlay" : overlay,
			"location" : location
		}));
		$('#overlay-container').slideDown(500, function() {
		});
	};

	var header = new FB.Header("#header", {});
	var pagecontent = new FB.Pagecontent("#pagecontent", {});
});
