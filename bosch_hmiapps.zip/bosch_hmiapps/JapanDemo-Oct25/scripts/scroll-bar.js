	var scrollbar_control = can.Control({
		init : function(el,opt) {
		/*
		* opt{viewport:the target object to scroll, scrollratio:the movement ratio of scrollbar}
		*/
			var viewport = opt.viewport;
			var scrollratio = opt.scrollratio;
			this.viewport = viewport;
			this.scrollratio = scrollratio;
			viewport.scrollTop(9999);
			var max_val = viewport.scrollTop();
			this.max_val = max_val;
			viewport.scrollTop(0);
			if(scrollratio<0 || scrollratio>1){
				console.log("invalid scroll ratio, must be in 0 to 1");
				console.log("using default ratio: 10%");
				this.deleta = max_val * 0.1;
			}else{
				this.deleta = max_val * scrollratio;
			}
			this.slider_range = parseInt($("#scroll-bar",el).css("height")) - parseInt($("#scroll-slider",el).css("height"));
			this.slider = $("#scroll-slider",el);
			this.slider.css("top",0);
			console.log("max_val="+max_val);
			console.log("deleta="+this.deleta);
			console.log("slider_range="+this.slider_range);
			console.log("scrollratio="+this.scrollratio);
		},
		
		/*"#up-scroll-button onmousedown" : function(el){
			el.css("background-image","url(../images/shared/sb_btn_up_p.png)");
		},
		
		"#up-scroll-button onmouseup" : function(el){
			el.css("background-image","url(../images/shared/sb_btn_up_e.png)");
		},
		
		"#down-scroll-button onmousedown" : function(el){
			el.css("background-image","url(../images/shared/sb_btn_dwn_p.png)");
		},
		
		"#down-scroll-button onmouseup" : function(el){
			el.css("background-image","url(../images/shared/sb_btn_dwn_e.png)");
		},*/
		
		"#up-scroll-button click" : function(){
		console.log("up");
			this.viewport.scrollTop(this.viewport.scrollTop()-this.deleta);
			if(this.viewport.scrollTop() == 0){
				this.slider.css("top",0);
				return;
			}
			var position = parseInt(this.slider.css("top"))-this.scrollratio*this.slider_range;
			if(position>0){
				this.slider.css("top",position);
			}else{
				this.slider.css("top",0);
			}
		},
		
		"#down-scroll-button click" : function(){
		console.log("down");
			this.viewport.scrollTop(this.viewport.scrollTop()+this.deleta);
			if(this.viewport.scrollTop() == this.max_val){
				this.slider.css("top",this.slider_range);
				return;
			}
			var position = parseInt(this.slider.css("top"))+this.scrollratio*this.slider_range;
			if(position<this.slider_range){
				this.slider.css("top",position);
			}else{
				this.slider.css("top",this.slider_range);
			}
		}
	});