

var that = this;
 
$(window).load(function(){

	var AQButton = can.Construct({
		init: function(){
			
		},
		"aqbutton click" : function(el, ev) {
			//ev.preventDefault();
			//el.addClass('aqbutton_active');
		}
	});
	that.aqbutton = new AQButton();


});


