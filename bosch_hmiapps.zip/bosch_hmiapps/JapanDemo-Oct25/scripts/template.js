


var that = this;
 
$(window).load(function(){

	var itgenTemplates = can.Construct({
		init: function(){
			
		},
		buildListTemplate : function( 
							_pageId, // Page ID
							_aqliData, // data passed to the view
							_aqliView, // html structured view for each aqli
							_view, // itgen template to use
							_buttonOneText, // Button text
							_buttonOneId, // Button ID
							_buttonTwoText, // Button text
							_buttonTwoId, // Button ID
							_buttonThreeText, // Button text
							_buttonThreeId // Button ID
							)
		{
		
			var data = { 
				pageId 			: _pageId,
				buttonOneText 	: _buttonOneText,
				buttonOneId 	: _buttonOneId,
				buttonTwoText 	: _buttonTwoText,
				buttonTwoId 	: _buttonTwoId,
				buttonThreeText : _buttonThreeText,
				buttonThreeId 	: _buttonThreeId,
				aqli 			: _aqliData
			}
			
			this.itgenChangeView(_view, _aqliView, data);	
		
		},
		itgenChangeView : function(view, aqliView, data) {			
			
			$('#pagecontent').html(can.view("../views/" + view, {
				"data" : data,
				"aqliView" : aqliView
			}));
			
			
			/*
			if ( typeof aqlist != "undefined") {
				that.listLoader.init();
				aqlist.reset();
				leftScrollbar.init();
						}*/
			
		},
		updateKeyboardInput : function(char){
			var txt = $("#text-search-input").text();
			$("#text-search-input").html(txt + char + "<img id='blinker' />");
		},
		replaceKeyboardInput : function(newStr){
			$("#text-search-input").html(newStr + "<img id='blinker' />");
		},
		caps : function(){
			
		},
		deleteLast : function(){
			var index = $("#text-search-input").text().length;
			var newStr = $("#text-search-input").text().slice(0, index - 1);
			this.replaceKeyboardInput(newStr)
		},
		fadeIn : function(){
			var that = this;
			$("#blinker").fadeIn(800, function(){
				that.fadeOut();
			})
		},
		fadeOut : function(){
			var that = this;
			$("#blinker").fadeOut(800, function(){
				that.fadeIn();
			})
			
			//$("." + classname).fadeOut(800).fadeIn(800, function () {effectFadeOut(classname)})
		}
	});
	
	that.template = new itgenTemplates();


});


