
var that = this;//window


 
$(document).ready(function($){

	var AQListConstruct = can.Construct({
		init:function(){
			
		},
		// what the current margin is set to
		margin : 0,
		// the maximum margin allowed without overflowing the aqli list
		maxMargin : 0,
		// the height of one aqli
		aqliHeight : 0,
		// total number of rows
		numRows : 0,
		pages : 0,
		pageAllowance : null,
		//number of aqli shown on the screen, typically between 3 and 6.
		aqliShown : 0,
		currentPage : 1,
		rightBarEvent : "itemUp",
		pageCount : function(val) {
				var aqliSelected = 0;
				var aqliTotal = 0;
			var index = 0;
			var aqliHeight = parseInt($("aqli").first().height());
			var margin = parseInt($("aqli").first().css("margin"));
				
				$("aqli").each(function(){
					aqliTotal++;
				});
				
				aqliTotal = (aqliTotal > 20) ? 20 : aqliTotal;
			index = (val) ? val : 1;
				
			$("#page-count").text(((Math.round(margin / aqliHeight) * -1) + 1) + "/" + aqliTotal);
				
		},
		marginCheck : function(margin, page){
			
			var that = this;
			
			var increment = ($("aqli").length >= 20) ? 20 : $("aqli").length;
			
			// height of the first aqli
			this.aqliHeight = $('aqli').first().height();
			
			// get the number of rows displayed to the user
			this.numRows = Math.round($('aqul').height() / this.aqliHeight);
			
			// the user cannot scroll pass this margin
			this.maxMargin = increment * this.aqliHeight - (this.numRows * this.aqliHeight);

			var diff = this.margin + margin;

			if (page == 'up'){				
				if (diff > 0){
					this.pageAllowance = 0;		
				} 
			} else if (page == 'down') {			

				//console.log("this.margin: " + this.margin + " >= " + this.maxMargin - (this.numRows * this.aqliHeight));

				if (Math.abs(this.margin) >= this.maxMargin - (this.numRows * this.aqliHeight)){
					this.pageAllowance = this.maxMargin * -1;
				}							
			} else {

				if (diff > 0){
					return false;
				} else if (Math.abs(diff) > this.maxMargin){
					return false;
				}
			}				
			
			return true;
		},
		aqulNoFill : function(){
			// if the result set doesn't have enough to fill aqul, don't do anything

			var aqli = $("aqli");
			var aqul = $("aqul");
			
			if (aqul.height() > ((aqli.length * aqli.first().height() - 30))){
				return false;
			} else {
				return true;
			}
		},
		up : function() {
				if (this.marginCheck(this.aqliHeight)){
					this.margin += this.aqliHeight;
					$('aqli:not(.more-hidden)').first().css('margin-top', this.margin + 'px');
				leftScrollbar.up();
					this.pageCount();	
				}else{
				$('aqli:not(.more-hidden)').first().css('margin-top', '0px');
				leftScrollbar.scrollTop();
				}
			
		},
		down : function() {
				if (this.marginCheck(this.aqliHeight * -1)){
					this.margin -= this.aqliHeight;	
					$('aqli:not(.more-hidden)').first().css('margin-top', this.margin + 'px');
				leftScrollbar.down();
					this.pageCount();	
				}else{
					$('aqli:not(.more-hidden)').first().css('margin-top', (this.maxMargin * -1) + 'px');	
				leftScrollbar.scrollBottom();
				}
		},		
		pageUp : function(){		
				this.marginCheck(this.aqliHeight * this.numRows, 'up');	
				if (this.pageAllowance == null){
					this.margin += this.aqliHeight * this.numRows;
					$('aqli:not(.more-hidden)').first().css('margin-top', this.margin + 'px');
				leftScrollbar.pageUp();
				} else {
					this.margin = this.pageAllowance;	
					$('aqli:not(.more-hidden)').first().css('margin-top', this.pageAllowance + 'px');	
					this.pageAllowance = null;
				leftScrollbar.scrollTop();
				}				
				
		},
		pageDown : function(){			
				this.marginCheck(this.aqliHeight * this.numRows, 'down');
				if (this.pageAllowance == null){
					this.margin -= this.aqliHeight * this.numRows;
					$('aqli:not(.more-hidden)').first().css('margin-top', this.margin + 'px');
				leftScrollbar.pageDown();
				} else {
					this.margin = this.pageAllowance;	
					$('aqli:not(.more-hidden)').first().css('margin-top', this.pageAllowance + 'px');	
					this.pageAllowance = null;
				leftScrollbar.scrollBottom();
				}	
				
		},
		reset : function(){
			this.margin = 0;
			this.maxMargin = 0;
			this.aqliHeight = 0;
			this.numRows = 0;
			this.pageAllowance = null;
			this.aqliShown = 0;
			this.pageCount();
		}
	});
	
	that.aqlist = new AQListConstruct();
	
	var AQListController = can.Control({
		init: function(){		 		
	 		
		},
		"#listPageUp click" : function(){
			event.preventDefault();
			if (aqlist.aqulNoFill()){
				aqlist.pageUp();
			}
			that.navigation.resultIndex -= 3;
			aqlist.pageCount();
			that.navigation.shiftLocations(that.navigation.resultIndex, 3);
		},
		"#listItemUp click" : function(){
			event.preventDefault();
			if (aqlist.aqulNoFill()){
				aqlist.up();
			}
			that.navigation.resultIndex--;
			aqlist.pageCount();
			that.navigation.shiftLocations(that.navigation.resultIndex, 3);
		},
		"#listItemDown click" : function(){
			event.preventDefault();
			if (aqlist.aqulNoFill()){
				aqlist.down();
			}
			that.navigation.resultIndex++;
			aqlist.pageCount();
			that.navigation.shiftLocations(that.navigation.resultIndex, 3);
		},
		"#listPageDown click" : function(){
			event.preventDefault();
			if (aqlist.aqulNoFill()){
				aqlist.pageDown();
			}
			that.navigation.resultIndex += 3;
			aqlist.pageCount();
			that.navigation.shiftLocations(that.navigation.resultIndex, 3);
		},
		".left-scroll-circle click" : function(el){
			var letter = el.find('.left-scroll-text').text();
			var array;
			
			$('aqli .list-text').each(function(){
				aqlist.aqliShown = 0;
				
				$(this).parent().css('display','block');
				var x = $(this).text();
				
				if (x.charAt(0) == letter){

				} else {
					$(this).parent().css('display','none');
				}
				
				$('aqli').first().css('margin-top', '0px');
				
				$('aqli').each(function(){
					if ($(this).css('display') == 'block'){ 
						aqlist.aqliShown++;
					}
				});
			});

		}
	});

	new AQListController("body");
	
	});
	
