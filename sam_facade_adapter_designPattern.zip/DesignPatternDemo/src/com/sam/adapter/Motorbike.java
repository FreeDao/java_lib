package com.sam.adapter;

public class Motorbike {
	public void startMove(){
		System.out.println("Start to go home....");
	};
	public void moveTo(){
		System.out.println("I am on the way,I am excited and a bit nervous....");
	};
	public void stop(){
		System.out.println("oh,I am back. I love my home ...");
	};
}
