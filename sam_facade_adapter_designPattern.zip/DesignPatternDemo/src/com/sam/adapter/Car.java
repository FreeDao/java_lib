package com.sam.adapter;

public interface Car {
	public void startMove();
	public void moveTo();
	public void stop();
	
}
